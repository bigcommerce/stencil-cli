/* */ 
"format cjs";
module.exports = require("./lib/babel/api/register/node-polyfill");
