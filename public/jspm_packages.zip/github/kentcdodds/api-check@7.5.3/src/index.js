import apiCheckFactory from './api-check';

export default apiCheckFactory;
