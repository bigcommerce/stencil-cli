define(["github:meenie/jschannel@0.0.5/src/jschannel"], function(main) {
  return main;
});