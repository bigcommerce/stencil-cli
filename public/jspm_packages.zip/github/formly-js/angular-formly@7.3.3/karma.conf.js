/* eslint-env node */
require('babel/register');
module.exports = require('./other/karma.conf.es6');
