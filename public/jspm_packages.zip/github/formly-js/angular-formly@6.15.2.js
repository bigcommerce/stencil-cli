define(["github:formly-js/angular-formly@6.15.2/dist/formly"], function(main) {
  return main;
});