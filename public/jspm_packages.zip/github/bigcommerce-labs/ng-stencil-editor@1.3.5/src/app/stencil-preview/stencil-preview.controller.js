export default class StencilPreviewCtrl {
    /*@ngInject*/
    constructor($sce, BC_APP_CONFIG, configService, loadingService, previewControls) {
        this._$sce = $sce;
        this._BC_APP_CONFIG = BC_APP_CONFIG;
        this._configService = configService;
        this._loadingService = loadingService;
        this._previewControls = previewControls;
    }

    getSize() {
        return this._previewControls.getSize();
    }

    getIframeUrl() {
        if (!this._iframeUrl) {
            // On first load, add the config id to the url, which is used to redirect and add a cookie for
            // the preview. Subsequent changes/previews will update the cookie value via the SDK.
            this._iframeUrl = this._$sce.trustAsResourceUrl(
                this._BC_APP_CONFIG.config.ShopPath + '?stencilEditor=' + this._configService.getConfig().id
            );
        }

        return this._iframeUrl;
    }

    isFlipped() {
        return this._previewControls.isFlipped();
    }

    isLoading() {
        return this._loadingService.isLoading();
    }

    refreshIframe() {
        return this._configService.refreshIframe();
    }

    requiresRefresh() {
        return this._configService.requiresRefresh();
    }
}
