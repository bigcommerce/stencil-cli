import 'angular';
import 'angular-mocks';

import StencilPreviewCtrl from './stencil-preview.controller.js';

describe('StencilPreviewCtrl: ', () =>  {
    let $controller;
    let $rootScope;
    let $scope;
    let controller;
    let configService = jasmine.createSpyObj('configService', [
        'getConfig',
        'refreshIframe',
        'requiresRefresh'
    ]);
    let loadingService = jasmine.createSpyObj('loadingService', [
        'isLoading',
    ]);

    function createController($scope) {
        return $controller(StencilPreviewCtrl, {
            $scope: $scope,
            configService: configService,
            loadingService: loadingService,
            previewControls: {}
        });
    }

    beforeEach(inject(($injector) => {
        $rootScope = $injector.get('$rootScope');
        $scope = $rootScope.$new();
        $controller = $injector.get('$controller');
    }));

    describe('refreshIframe() method', () => {
        it('should call configService.refreshIframe()', () => {
            controller = createController($scope);

            controller.refreshIframe();

            expect(configService.refreshIframe).toHaveBeenCalled();
        });
    });
});
