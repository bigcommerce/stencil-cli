import ChannelService from 'src/app/services/channel.service.js';
import ConfigService from 'src/app/services/config.service.js';
import FontsService from 'src/app/services/fonts.service.js';
import LoadingService from 'src/app/services/loading.service.js';
import SessionService from 'src/app/services/session.service.js';
import VariationService from 'src/app/services/variation.service.js';
import VersionService from 'src/app/services/version.service.js';

export default angular.module('ng-stencil-editor.services', [])
    .service('channelService', ChannelService)
    .service('configService', ConfigService)
    .service('fontsService', FontsService)
    .service('loadingService', LoadingService)
    .service('sessionService', SessionService)
    .service('variationService', VariationService)
    .service('versionService', VersionService);
