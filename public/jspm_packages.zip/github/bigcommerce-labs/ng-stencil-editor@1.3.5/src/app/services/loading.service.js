export default class LoadingService {
    /*@ngInject*/
    constructor() {
        this._isLoading = false;
    }

    isLoading(value) {
        if (!_.isUndefined(value)) {
            this._isLoading = value;
        }

        return this._isLoading;
    }
}
