/* */ 
"format global";
var gulp = require('gulp');

gulp.task('staticAssets', [
    'copy:svg',
    'copy:fonts',
    'copy:images',
    'copy:css',
    'copy:scss',
    'copy:js'
]);
