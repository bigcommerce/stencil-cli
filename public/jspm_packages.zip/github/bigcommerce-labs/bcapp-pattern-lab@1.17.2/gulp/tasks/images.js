/* */ 
"format global";
var gulp = require('gulp'),
    config = require('../config'),
    handleErrors = require('../util/handleErrors'),
    imagemin = require('gulp-imagemin');

function images() {

    var stream = gulp.src(config.images.src + '/**/*')
        .pipe(imagemin()) // Optimize
        .on('error', handleErrors)
        .pipe(gulp.dest(config.images.build));

    return stream;

}

gulp.task('images', ['clean:images'], images);
