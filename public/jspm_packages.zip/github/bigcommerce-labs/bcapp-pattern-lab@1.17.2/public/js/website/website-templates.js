/* */ 
(function(module) {
try { module = angular.module("website-templates"); }
catch(err) { module = angular.module("website-templates", []); }
module.run(["$templateCache", function($templateCache) {
  "use strict";
  $templateCache.put("src/website/js/icons/icons.tpl.html",
    "<form action=\"#\" class=\"form\">\n" +
    "    <fieldset class=\"form-fieldset\">\n" +
    "        <div class=\"form-field\">\n" +
    "            <label for=\"icons\" class=\"form-label\">Filter:</label>\n" +
    "            <input\n" +
    "                type=\"text\"\n" +
    "                class=\"form-input\"\n" +
    "                id=\"icons\"\n" +
    "                placeholder=\"Filter the list below by icon name\"\n" +
    "                ng-model=\"iconName\">\n" +
    "        </div>\n" +
    "    </fieldset>\n" +
    "</form>\n" +
    "\n" +
    "<hr>\n" +
    "\n" +
    "<ul class=\"iconExample test\">\n" +
    "    <li class=\"iconExample-item\" ng-repeat=\"icon in icons | filter:iconName\">\n" +
    "        <img class=\"iconExample-glyph\" src=\"/svg/icons/{{ icon.src }}\">\n" +
    "        {{ icon.name }}\n" +
    "    </li>\n" +
    "</ul>\n" +
    "");
}]);
})();

(function(module) {
try { module = angular.module("website-templates"); }
catch(err) { module = angular.module("website-templates", []); }
module.run(["$templateCache", function($templateCache) {
  "use strict";
  $templateCache.put("src/website/js/examples/accordion/accordion-example.tpl.html",
    "<accordion close-others=\"oneAtATime\">\n" +
    "    <accordion-group heading=\"Static Header, initially expanded\" is-open=\"true\">\n" +
    "        This content is straight in the template.\n" +
    "    </accordion-group>\n" +
    "    <accordion-group heading=\"{{group.title}}\" ng-repeat=\"group in groups\">\n" +
    "        {{group.content}}\n" +
    "    </accordion-group>\n" +
    "    <accordion-group heading=\"Dynamic Body Content\">\n" +
    "        <p>The body of the accordion group grows to fit the contents</p>\n" +
    "        <button class=\"button small\" ng-click=\"addItem()\">Add Item</button>\n" +
    "        <div ng-repeat=\"item in items\">{{item}}</div>\n" +
    "    </accordion-group>\n" +
    "    <accordion-group is-open=\"isopen\">\n" +
    "        <accordion-heading>\n" +
    "            I can have markup, too! <small>I'm small</small>\n" +
    "        </accordion-heading>\n" +
    "        This is just some content to illustrate fancy headings.\n" +
    "    </accordion-group>\n" +
    "</accordion>\n" +
    "\n" +
    "\n" +
    "<accordion>\n" +
    "    <accordion-group heading=\"Single accordion panel, start open\" is-open=\"true\">\n" +
    "        This content is straight in the template.\n" +
    "    </accordion-group>\n" +
    "</accordion>\n" +
    "\n" +
    "<accordion>\n" +
    "    <accordion-group heading=\"Single accordion panel, start closed\">\n" +
    "        This content is straight in the template.\n" +
    "    </accordion-group>\n" +
    "</accordion>\n" +
    "");
}]);
})();

(function(module) {
try { module = angular.module("website-templates"); }
catch(err) { module = angular.module("website-templates", []); }
module.run(["$templateCache", function($templateCache) {
  "use strict";
  $templateCache.put("src/website/js/examples/accordion/accordion-minor-example.tpl.html",
    "<accordion class=\"accordion--minor\" close-others=\"oneAtATime\">\n" +
    "    <accordion-group heading=\"Accordion Minor Example\" is-open=\"true\">\n" +
    "        Content for a minor accordion is spaced tighter than normal accordions\n" +
    "    </accordion-group>\n" +
    "    <accordion-group heading=\"Another minor section\">\n" +
    "        <p>The body of the accordion group grows to fit the contents</p>\n" +
    "        <button class=\"button small\" ng-click=\"addItem()\">Add Item</button>\n" +
    "        <div ng-repeat=\"item in items\">{{item}}</div>\n" +
    "    </accordion-group>\n" +
    "</accordion>\n" +
    "");
}]);
})();

(function(module) {
try { module = angular.module("website-templates"); }
catch(err) { module = angular.module("website-templates", []); }
module.run(["$templateCache", function($templateCache) {
  "use strict";
  $templateCache.put("src/website/js/examples/accordion/accordion.tpl.html",
    "<section class=\"labExample\">\n" +
    "\n" +
    "    <div class=\"labExample-demo\">\n" +
    "\n" +
    "        <h2>Accordion</h2>\n" +
    "\n" +
    "        <p>\n" +
    "            <label class=\"checkbox\">\n" +
    "                <input type=\"checkbox\" ng-model=\"oneAtATime\">\n" +
    "                Open only one at a time\n" +
    "            </label>\n" +
    "        </p>\n" +
    "\n" +
    "        <div ng-include=\"'src/website/js/examples/accordion/accordion-example.tpl.html'\"></div>\n" +
    "\n" +
    "        <hr>\n" +
    "\n" +
    "    </div>\n" +
    "\n" +
    "    <div class=\"labExample-code\">\n" +
    "        <textarea ui-codemirror=\"{\n" +
    "            'lineNumbers': true,\n" +
    "            'theme':'default',\n" +
    "            'readOnly': 'true',\n" +
    "            'lineWrapping' : false,\n" +
    "            'mode': 'text/html',\n" +
    "            autoClearEmptyLines: true\n" +
    "        }\">\n" +
    "<accordion close-others=\"oneAtATime\">\n" +
    "    <accordion-group heading=\"Static Header, initially expanded\" is-open=\"true\">\n" +
    "        This content is straight in the template.\n" +
    "    </accordion-group>\n" +
    "    <accordion-group heading=\"{{group.title}}\" ng-repeat=\"group in groups\">\n" +
    "        {{group.content}}\n" +
    "    </accordion-group>\n" +
    "    <accordion-group heading=\"Dynamic Body Content\">\n" +
    "        <p>The body of the accordion group grows to fit the contents</p>\n" +
    "        <button class=\"button small\" ng-click=\"addItem()\">Add Item</button>\n" +
    "        <div ng-repeat=\"item in items\">{{item}}</div>\n" +
    "    </accordion-group>\n" +
    "    <accordion-group is-open=\"isopen\">\n" +
    "        <accordion-heading>\n" +
    "            I can have markup, too! <small>I'm small</small>\n" +
    "        </accordion-heading>\n" +
    "        This is just some content to illustrate fancy headings.\n" +
    "    </accordion-group>\n" +
    "</accordion>\n" +
    "\n" +
    "\n" +
    "<accordion>\n" +
    "    <accordion-group heading=\"Single accordion panel, start open\" is-open=\"true\">\n" +
    "        This content is straight in the template.\n" +
    "    </accordion-group>\n" +
    "</accordion>\n" +
    "\n" +
    "<accordion>\n" +
    "    <accordion-group heading=\"Single accordion panel, start closed\">\n" +
    "        This content is straight in the template.\n" +
    "    </accordion-group>\n" +
    "</accordion>\n" +
    "        </textarea>\n" +
    "    </div>\n" +
    "\n" +
    "    <div class=\"labExample-notes\">\n" +
    "        <h5>Notes: </h5>\n" +
    "        <p>\n" +
    "            Accessible accordion:\n" +
    "        </p>\n" +
    "        <ul>\n" +
    "            <li><s>set accordion-id on the accordion-group</s></li>\n" +
    "            <li><s>the heading links to the id of content, which is the same as accordion-id</s></li>\n" +
    "            <li><s>when the user hits enter on the heading, it toggles the content body open/close</s></li>\n" +
    "        </ul>\n" +
    "\n" +
    "        <p>\n" +
    "            <strong>EDIT:</strong> Need to re-think accordion accessibilty and do\n" +
    "            a real job of updating Angular-Foundation to associate ids to <code>aria-controls</code>\n" +
    "        </p>\n" +
    "    </div>\n" +
    "\n" +
    "</section>\n" +
    "\n" +
    "<section class=\"labExample\">\n" +
    "\n" +
    "    <div class=\"labExample-demo\">\n" +
    "\n" +
    "        <h3>Accordion <small>[.accordion--minor]</small></h3>\n" +
    "\n" +
    "        <div ng-include=\"'src/website/js/examples/accordion/accordion-minor-example.tpl.html'\"></div>\n" +
    "\n" +
    "        <hr>\n" +
    "\n" +
    "    </div>\n" +
    "\n" +
    "    <div class=\"labExample-code\">\n" +
    "        <textarea ui-codemirror=\"{\n" +
    "            'lineNumbers': true,\n" +
    "            'theme':'default',\n" +
    "            'readOnly': 'true',\n" +
    "            'lineWrapping' : false,\n" +
    "            'mode': 'text/html',\n" +
    "            autoClearEmptyLines: true\n" +
    "        }\">\n" +
    "<accordion class=\"accordion--minor\" close-others=\"oneAtATime\">\n" +
    "    <accordion-group heading=\"Accordion Minor Example\" is-open=\"true\">\n" +
    "        Content for a minor accordion is spaced tighter than normal accordions\n" +
    "    </accordion-group>\n" +
    "    <accordion-group heading=\"Another minor section\">\n" +
    "        <p>The body of the accordion group grows to fit the contents</p>\n" +
    "        <button class=\"button small\" ng-click=\"addItem()\">Add Item</button>\n" +
    "        <div ng-repeat=\"item in items\">{{item}}</div>\n" +
    "    </accordion-group>\n" +
    "</accordion>\n" +
    "        </textarea>\n" +
    "    </div>\n" +
    "\n" +
    "    <div class=\"labExample-notes\">\n" +
    "        <h5>Notes: </h5>\n" +
    "        <p>\n" +
    "            Similar in role to <a href=\"/panels.html\">Minor Panel</a> and shares styling.\n" +
    "            Use in situations where space maybe tight or constrained, like a sidebar.\n" +
    "        </p>\n" +
    "        <p>\n" +
    "            Place modifier class to a normal accordion <code>.accordion--minor</code>.\n" +
    "            Currently this is not ideal as modifier is not applied to component root.\n" +
    "        </p>\n" +
    "    </div>\n" +
    "\n" +
    "</section>\n" +
    "");
}]);
})();

(function(module) {
try { module = angular.module("website-templates"); }
catch(err) { module = angular.module("website-templates", []); }
module.run(["$templateCache", function($templateCache) {
  "use strict";
  $templateCache.put("src/website/js/examples/bc-datepicker/bc-datepicker.tpl.html",
    "<section class=\"labExample\">\n" +
    "    <div class=\"labExample-demo\">\n" +
    "        <h3>BC Datepicker</h3>\n" +
    "\n" +
    "        <p>\n" +
    "            Datepickers are added with an attribute directive to a input element.\n" +
    "            It can also be displayed in line if the directive is in a non-input element.\n" +
    "        </p>\n" +
    "\n" +
    "        <div class=\"labBlockRow\">\n" +
    "            <div class=\"labCol\">\n" +
    "                <div class=\"labBlock\">\n" +
    "                    <div class=\"labBlock-preview\">\n" +
    "                        <form action=\"#\" class=\"form\">\n" +
    "                            <fieldset class=\"form-fieldset\">\n" +
    "                                <div class=\"form-field\">\n" +
    "                                    <label class=\"form-label\" for=\"datepicker\">Select a Date</label>\n" +
    "                                    <input class=\"form-input has-action\" id=\"datepicker\" type=\"text\" bc-datepicker ng-model=\"date\" options=\"bcDatepickerCtrl.options\"/>\n" +
    "                                    <button class=\"button button--icon button--inputAction\">\n" +
    "                                        <span class=\"u-hiddenVisually\">Select a Date</span>\n" +
    "                                        <icon glyph=\"ic-event\"></icon>\n" +
    "                                    </button>\n" +
    "                                </div>\n" +
    "                            </fieldset>\n" +
    "                        </form>\n" +
    "                        <h5>Selected date: <span class=\"selected-date\">{{date}}</span></h5>\n" +
    "                    </div>\n" +
    "                    <pre class=\"labBlock-example u-bgGreysLightest\">input type=\"text\" bc-datepicker ng-model=\"date\"</pre>\n" +
    "                </div>\n" +
    "            </div>\n" +
    "\n" +
    "            <div class=\"labCol\">\n" +
    "                <div class=\"labBlock\">\n" +
    "                    <div class=\"labBlock-preview\">\n" +
    "                        <div bc-datepicker ng-model=\"date2\"></div>\n" +
    "                    </div>\n" +
    "                    <pre class=\"labBlock-example u-bgGreysLightest\">div bc-datepicker ng-model=\"date2\"</pre>\n" +
    "                </div>\n" +
    "            </div>\n" +
    "        </div>\n" +
    "\n" +
    "        <hr/>\n" +
    "    </div>\n" +
    "\n" +
    "    <div class=\"labExample-code\">\n" +
    "        <h4>Useage</h4>\n" +
    "\n" +
    "<textarea ui-codemirror=\"{\n" +
    "'lineNumbers': true,\n" +
    "'theme':'default',\n" +
    "'readOnly': 'true',\n" +
    "'lineWrapping' : false,\n" +
    "'mode': 'text/html',\n" +
    "autoClearEmptyLines: true\n" +
    "}\">\n" +
    "<input\n" +
    "    class=\"form-input\"\n" +
    "    type=\"text\"\n" +
    "    bc-datepicker\n" +
    "    options=\"bcDatepickerCtrl.options\"\n" +
    "    ng-model=\"date\"\n" +
    "/>\n" +
    "\n" +
    "<div bc-datepicker ng-model=\"date2\"></div></textarea>\n" +
    "\n" +
    "    </div>\n" +
    "\n" +
    "    <div class=\"labExample-notes\">\n" +
    "        <h5>Notes:</h5>\n" +
    "        <p>\n" +
    "            BC Datepicker directive can be called with <code>bc-datepicker</code>\n" +
    "            attribute. I can be placed on a text input or a basic <code>&lt;div /&gt;</code>\n" +
    "        </p>\n" +
    "        <p>\n" +
    "            It takes an optional attribute of <code>options</code>, which you can\n" +
    "            a JSON object to as defined below.\n" +
    "        </p>\n" +
    "    </div>\n" +
    "\n" +
    "</section>\n" +
    "<section class=\"labExample\">\n" +
    "\n" +
    "    <div class=\"labExample-code\">\n" +
    "        <h4>Options</h4>\n" +
    "\n" +
    "<textarea ui-codemirror=\"{\n" +
    "'lineNumbers': true,\n" +
    "'theme':'default',\n" +
    "'readOnly': 'true',\n" +
    "'lineWrapping' : false,\n" +
    "'mode': 'javascript',\n" +
    "autoClearEmptyLines: true\n" +
    "}\">\n" +
    "{\n" +
    "    'appendTo': document.body,\n" +
    "    'autoClose': true,\n" +
    "    'autoHideOnBlur': true,\n" +
    "    'autoHideOnClick': true,\n" +
    "    'date': true,\n" +
    "    'dateValidator': Function.prototype,\n" +
    "    'dayFormat': 'DD',\n" +
    "    'initialValue': null,\n" +
    "    'inputFormat': moment.localeData().longDateFormat('L'),\n" +
    "    'invalidate': true,\n" +
    "    'max': null,\n" +
    "    'min': null,\n" +
    "    'monthFormat': 'MMM YYYY',\n" +
    "    'monthsInCalendar': 1,\n" +
    "    'required': false,\n" +
    "    'styles': {\n" +
    "        back: 'datepicker-back',\n" +
    "        container: 'datepicker',\n" +
    "        date: 'datepicker-date',\n" +
    "        dayBody: 'datepicker-days-body',\n" +
    "        dayBodyElem: 'datepicker-day',\n" +
    "        dayConcealed: 'datepicker-day-concealed',\n" +
    "        dayDisabled: 'is-disabled',\n" +
    "        dayHead: 'datepicker-days-head',\n" +
    "        dayHeadElem: 'datepicker-day-name',\n" +
    "        dayPrevMonth: 'datepicker-day-prev-month',\n" +
    "        dayNextMonth: 'datepicker-day-next-month',\n" +
    "        dayRow: 'datepicker-days-row',\n" +
    "        dayTable: 'datepicker-days',\n" +
    "        month: 'datepicker-month',\n" +
    "        monthLabel: 'datepicker-month',\n" +
    "        next: 'datepicker-next',\n" +
    "        positioned: 'datepicker-attachment',\n" +
    "        selectedDay: 'is-selected',\n" +
    "        selectedTime: 'datepicker-time-selected',\n" +
    "        time: 'datepicker-time',\n" +
    "        timeList: 'datepicker-time-list',\n" +
    "        timeOption: 'datepicker-time-option'\n" +
    "    },\n" +
    "    'time': false,\n" +
    "    'timeFormat': 'HH:mm',\n" +
    "    'timeInterval': 1800,\n" +
    "    'timeValidator': Function.prototype,\n" +
    "    'weekdayFormat': 'short',\n" +
    "    'weekStart': moment().weekday(0).day()\n" +
    "}</textarea>\n" +
    "\n" +
    "    </div>\n" +
    "\n" +
    "    <div class=\"labExample-notes\">\n" +
    "        <h5>Notes:</h5>\n" +
    "        <p>\n" +
    "            Description of each option can be found in <a href=\"https://github.com/bevacqua/rome/tree/v1.2.3\">Rome's (Calendar) Repo</a>\n" +
    "        </p>\n" +
    "    </div>\n" +
    "\n" +
    "</section>\n" +
    "");
}]);
})();

(function(module) {
try { module = angular.module("website-templates"); }
catch(err) { module = angular.module("website-templates", []); }
module.run(["$templateCache", function($templateCache) {
  "use strict";
  $templateCache.put("src/website/js/examples/alerts/alerts.tpl.html",
    "<section class=\"labExample\">\n" +
    "\n" +
    "    <div class=\"labExample-demo\">\n" +
    "\n" +
    "        <h2>Alerts</h2>\n" +
    "\n" +
    "        <alert ng-repeat=\"alert in alerts\" type=\"alert.type\" close=\"closeAlert($index)\">{{alert.msg}}</alert>\n" +
    "\n" +
    "        <button class=\"button\" ng-click=\"addAlert()\">Add Alert</button>\n" +
    "\n" +
    "        <hr>\n" +
    "\n" +
    "    </div>\n" +
    "\n" +
    "    <div class=\"labExample-code\">\n" +
    "\n" +
    "<textarea ui-codemirror=\"{\n" +
    "    'lineNumbers': true,\n" +
    "    'theme':'default',\n" +
    "    'readOnly': 'true',\n" +
    "    'lineWrapping' : false,\n" +
    "    'mode': 'text/html',\n" +
    "    autoClearEmptyLines: true\n" +
    "}\">\n" +
    "<alert\n" +
    "    ng-repeat=\"alert in alerts\"\n" +
    "    type=\"alert.type\"\n" +
    "    close=\"closeAlert($index)\"\n" +
    ">\n" +
    "    {{alert.msg}}\n" +
    "</alert></textarea>\n" +
    "\n" +
    "    </div>\n" +
    "\n" +
    "    <div class=\"labExample-notes\">\n" +
    "        <h5>Notes:</h5>\n" +
    "        <p>\n" +
    "            Alerts can be used to inform users about the actions they perform.\n" +
    "            They can be displayed at a page level or inside a specific container.\n" +
    "        </p>\n" +
    "        <p>\n" +
    "            Please use the appropriate level alert for the message. <strong>Not everything is an error.</strong>\n" +
    "        </p>\n" +
    "    </div>\n" +
    "\n" +
    "</section>\n" +
    "\n" +
    "\n" +
    "<section class=\"labExample\">\n" +
    "\n" +
    "    <div class=\"labExample-demo\">\n" +
    "\n" +
    "        <h2>More complex example uses</h2>\n" +
    "\n" +
    "        <alert type=\"'success'\" close=\"closeAlert($index)\">\n" +
    "            <h2 class=\"alertBox-heading\">Cool! You've received an order where your customer paid by PayPal!</h2>\n" +
    "            To claim your funds, follow the instructions in the email Paypal has just sent you.\n" +
    "        </alert>\n" +
    "\n" +
    "        <alert type=\"'warning'\" close=\"closeAlert($index)\">\n" +
    "            <h2 class=\"alertBox-heading\">You have used 80B (80%) of your 100B monthly storage allowance</h2>\n" +
    "            You can avoid charges and get extra features by <a href=\"#\">upgrading your plan</a>.\n" +
    "        </alert>\n" +
    "\n" +
    "        <alert type=\"'error'\" close=\"closeAlert($index)\">\n" +
    "            <h2 class=\"alertBox-heading\">Hey, the Bigcommerce account owner has an unpaid invoice.</h2>\n" +
    "            To avoid account suspension or termination, please pay your invoice or call <strong>1-808-699-0911 (US)</strong>.\n" +
    "        </alert>\n" +
    "\n" +
    "        <alert type=\"'info'\" close=\"closeAlert($index)\">\n" +
    "            Analytics just got a whole lot smarter. <button class=\"button button--primary button--small\">Learn More</button>\n" +
    "        </alert>\n" +
    "\n" +
    "        <alert close=\"closeAlert($index)\">\n" +
    "            You're cool\n" +
    "        </alert>\n" +
    "\n" +
    "        <hr>\n" +
    "\n" +
    "    </div>\n" +
    "\n" +
    "    <div class=\"labExample-code\">\n" +
    "\n" +
    "<textarea ui-codemirror=\"{\n" +
    "    'lineNumbers': true,\n" +
    "    'theme':'default',\n" +
    "    'readOnly': 'true',\n" +
    "    'lineWrapping' : false,\n" +
    "    'mode': 'text/html',\n" +
    "    autoClearEmptyLines: true\n" +
    "}\">\n" +
    "<alert\n" +
    "    type=\"'error'\"\n" +
    "    close=\"closeAlert($index)\"\n" +
    ">\n" +
    "    <h2 class=\"alertBox-heading\">Alert title</h2>\n" +
    "    Alert body text with some <strong>strong text</strong> and a\n" +
    "    <button class=\"button button--primary button--small\">Button</button>\n" +
    "</alert></textarea>\n" +
    "\n" +
    "    </div>\n" +
    "\n" +
    "    <div class=\"labExample-notes\">\n" +
    "        <h5>Notes:</h5>\n" +
    "        <p>\n" +
    "            Alerts have the ability to take HTML in their body so you can build more\n" +
    "            informative alerts.\n" +
    "        </p>\n" +
    "        <p>\n" +
    "            Just remember to use <code>alertBox-heading</code> for your alert title.\n" +
    "        </p>\n" +
    "    </div>\n" +
    "\n" +
    "</section>\n" +
    "\n" +
    "");
}]);
})();

(function(module) {
try { module = angular.module("website-templates"); }
catch(err) { module = angular.module("website-templates", []); }
module.run(["$templateCache", function($templateCache) {
  "use strict";
  $templateCache.put("src/website/js/examples/bc-dropdown/bc-dropdown.tpl.html",
    "<h3>Dropdowns</h3>\n" +
    "\n" +
    "<section class=\"labExample\">\n" +
    "\n" +
    "    <div class=\"labExample-demo\">\n" +
    "\n" +
    "        <h4>Dropdown Buttons</h4>\n" +
    "\n" +
    "        <ul class=\"inlineList\">\n" +
    "\n" +
    "            <li>\n" +
    "                <span>Small</span>\n" +
    "                <div bc-dropdown>\n" +
    "                    <button type=\"button\" class=\"button button--small dropdown-button\" bc-dropdown-toggle>Click</button>\n" +
    "                    <ul bc-dropdown-menu>\n" +
    "                        <li class=\"dropdown-menu-item\"><a href=\"#\" ng-click=\"$event.preventDefault()\">One</a></li>\n" +
    "                        <li class=\"dropdown-menu-item\"><a href=\"#\" ng-click=\"$event.preventDefault()\">Two</a></li>\n" +
    "                        <li class=\"dropdown-menu-item\"><a href=\"#\" ng-click=\"$event.preventDefault()\">Three</a></li>\n" +
    "                    </ul>\n" +
    "                </div>\n" +
    "            </li>\n" +
    "\n" +
    "            <li>\n" +
    "                <span>Default</span>\n" +
    "                <div id=\"dropdown-standard\" bc-dropdown>\n" +
    "                    <button type=\"button\" class=\"button dropdown-button\" bc-dropdown-toggle>Click</button>\n" +
    "                    <ul bc-dropdown-menu>\n" +
    "                        <li class=\"dropdown-menu-item\"><a href=\"#\" ng-click=\"$event.preventDefault()\">One</a></li>\n" +
    "                        <li class=\"dropdown-menu-item\"><a href=\"#\" ng-click=\"$event.preventDefault()\">Two</a></li>\n" +
    "                        <li class=\"dropdown-menu-item\"><a href=\"#\" ng-click=\"$event.preventDefault()\">Three</a></li>\n" +
    "                    </ul>\n" +
    "                </div>\n" +
    "            </li>\n" +
    "\n" +
    "            <li>\n" +
    "                <span>Large</span>\n" +
    "                <div id=\"dropdown-standard\" bc-dropdown>\n" +
    "                    <button type=\"button\" class=\"button button--large dropdown-button\" bc-dropdown-toggle>Click</button>\n" +
    "                    <ul bc-dropdown-menu>\n" +
    "                        <li class=\"dropdown-menu-item\"><a href=\"#\" ng-click=\"$event.preventDefault()\">One</a></li>\n" +
    "                        <li class=\"dropdown-menu-item\"><a href=\"#\" ng-click=\"$event.preventDefault()\">Two</a></li>\n" +
    "                        <li class=\"dropdown-menu-item\"><a href=\"#\" ng-click=\"$event.preventDefault()\">Three</a></li>\n" +
    "                    </ul>\n" +
    "                </div>\n" +
    "            </li>\n" +
    "\n" +
    "            <li>\n" +
    "                <span>Primary</span>\n" +
    "                <div bc-dropdown>\n" +
    "                    <button type=\"button\" class=\"button button--primary dropdown-button\" bc-dropdown-toggle>Click</button>\n" +
    "                    <ul bc-dropdown-menu>\n" +
    "                        <li class=\"dropdown-menu-item\"><a href=\"#\" ng-click=\"$event.preventDefault()\">One</a></li>\n" +
    "                        <li class=\"dropdown-menu-item\"><a href=\"#\" ng-click=\"$event.preventDefault()\">Two</a></li>\n" +
    "                        <li class=\"dropdown-menu-item\"><a href=\"#\" ng-click=\"$event.preventDefault()\">Three</a></li>\n" +
    "                    </ul>\n" +
    "                </div>\n" +
    "            </li>\n" +
    "\n" +
    "        </ul>\n" +
    "\n" +
    "        <hr>\n" +
    "\n" +
    "    </div>\n" +
    "\n" +
    "    <div class=\"labExample-code\">\n" +
    "\n" +
    "<textarea ui-codemirror=\"{\n" +
    "    'lineNumbers': true,\n" +
    "    'theme':'default',\n" +
    "    'readOnly': 'true',\n" +
    "    'lineWrapping' : false,\n" +
    "    'mode': 'text/html',\n" +
    "    autoClearEmptyLines: true\n" +
    "}\"><div bc-dropdown>\n" +
    "    <button type=\"button\" class=\"button button--primary dropdown-button\" bc-dropdown-toggle>Click</button>\n" +
    "    <ul bc-dropdown-menu>\n" +
    "        <li class=\"dropdown-menu-item\"><a href=\"#\" ng-click=\"$event.preventDefault()\">One</a></li>\n" +
    "        <li class=\"dropdown-menu-item\"><a href=\"#\" ng-click=\"$event.preventDefault()\">Two</a></li>\n" +
    "        <li class=\"dropdown-menu-item\"><a href=\"#\" ng-click=\"$event.preventDefault()\">Three</a></li>\n" +
    "    </ul>\n" +
    "</div></textarea>\n" +
    "\n" +
    "    </div>\n" +
    "\n" +
    "    <div class=\"labExample-notes\">\n" +
    "        <h5>Notes:</h5>\n" +
    "        <p>The dropdown menu is toggled by the click of a sibling <code>button[bc-dropdown-toggle]</code>.</p>\n" +
    "        <p>The dropdown indicator will be styled by the <code>.dropdown-button</code> class on that button</p>\n" +
    "    </div>\n" +
    "\n" +
    "</section>\n" +
    "\n" +
    "<section class=\"labExample\">\n" +
    "\n" +
    "    <div class=\"labExample-demo\">\n" +
    "\n" +
    "        <h4>Split Buttons</h4>\n" +
    "\n" +
    "        <ul class=\"inlineList\">\n" +
    "\n" +
    "            <li>\n" +
    "                <span>Small</span>\n" +
    "                <div id=\"dropdown-splitButton\" bc-dropdown>\n" +
    "                    <button type=\"button\" class=\"button button--small button--split\">\n" +
    "                        Click\n" +
    "                        <span bc-dropdown-toggle></span>\n" +
    "                    </button>\n" +
    "                    <ul bc-dropdown-menu>\n" +
    "                        <li class=\"dropdown-menu-item\"><a href=\"#\" ng-click=\"$event.preventDefault()\">One</a></li>\n" +
    "                        <li class=\"dropdown-menu-item\"><a href=\"#\" ng-click=\"$event.preventDefault()\">Two</a></li>\n" +
    "                        <li class=\"dropdown-menu-item\"><a href=\"#\" ng-click=\"$event.preventDefault()\">Three</a></li>\n" +
    "                    </ul>\n" +
    "                </div>\n" +
    "            </li>\n" +
    "\n" +
    "            <li>\n" +
    "                <span>Default</span>\n" +
    "                <div bc-dropdown>\n" +
    "                    <button type=\"button\" class=\"button button--split\">\n" +
    "                        Click\n" +
    "                        <span bc-dropdown-toggle></span>\n" +
    "                    </button>\n" +
    "                    <ul bc-dropdown-menu>\n" +
    "                        <li class=\"dropdown-menu-item\"><a href=\"#\" ng-click=\"$event.preventDefault()\">One</a></li>\n" +
    "                        <li class=\"dropdown-menu-item\"><a href=\"#\" ng-click=\"$event.preventDefault()\">Two</a></li>\n" +
    "                        <li class=\"dropdown-menu-item\"><a href=\"#\" ng-click=\"$event.preventDefault()\">Three</a></li>\n" +
    "                    </ul>\n" +
    "                </div>\n" +
    "            </li>\n" +
    "\n" +
    "            <li>\n" +
    "                <span>Large</span>\n" +
    "                <div bc-dropdown>\n" +
    "                    <button type=\"button\" class=\"button button--large button--split\">\n" +
    "                        Click\n" +
    "                        <span bc-dropdown-toggle></span>\n" +
    "                    </button>\n" +
    "                    <ul bc-dropdown-menu>\n" +
    "                        <li class=\"dropdown-menu-item\"><a href=\"#\" ng-click=\"$event.preventDefault()\">One</a></li>\n" +
    "                        <li class=\"dropdown-menu-item\"><a href=\"#\" ng-click=\"$event.preventDefault()\">Two</a></li>\n" +
    "                        <li class=\"dropdown-menu-item\"><a href=\"#\" ng-click=\"$event.preventDefault()\">Three</a></li>\n" +
    "                    </ul>\n" +
    "                </div>\n" +
    "            </li>\n" +
    "\n" +
    "            <li>\n" +
    "                <span>Primary</span>\n" +
    "                <div bc-dropdown>\n" +
    "                    <button type=\"button\" class=\"button button--primary button--split\">\n" +
    "                        Click\n" +
    "                        <span bc-dropdown-toggle></span>\n" +
    "                    </button>\n" +
    "                    <ul bc-dropdown-menu>\n" +
    "                        <li class=\"dropdown-menu-item\"><a href=\"#\" ng-click=\"$event.preventDefault()\">One</a></li>\n" +
    "                        <li class=\"dropdown-menu-item\"><a href=\"#\" ng-click=\"$event.preventDefault()\">Two</a></li>\n" +
    "                        <li class=\"dropdown-menu-item\"><a href=\"#\" ng-click=\"$event.preventDefault()\">Three</a></li>\n" +
    "                    </ul>\n" +
    "                </div>\n" +
    "            </li>\n" +
    "\n" +
    "        </ul>\n" +
    "\n" +
    "        <hr>\n" +
    "\n" +
    "    </div>\n" +
    "\n" +
    "    <div class=\"labExample-code\">\n" +
    "\n" +
    "<textarea ui-codemirror=\"{\n" +
    "    'lineNumbers': true,\n" +
    "    'theme':'default',\n" +
    "    'readOnly': 'true',\n" +
    "    'lineWrapping' : false,\n" +
    "    'mode': 'text/html',\n" +
    "    autoClearEmptyLines: true\n" +
    "}\"><div bc-dropdown>\n" +
    "    <button type=\"button\" class=\"button button--primary button--split\">\n" +
    "        Click\n" +
    "        <span bc-dropdown-toggle></span>\n" +
    "    </button>\n" +
    "    <ul bc-dropdown-menu>\n" +
    "        <li class=\"dropdown-menu-item\"><a href=\"#\" ng-click=\"$event.preventDefault()\">One</a></li>\n" +
    "        <li class=\"dropdown-menu-item\"><a href=\"#\" ng-click=\"$event.preventDefault()\">Two</a></li>\n" +
    "        <li class=\"dropdown-menu-item\"><a href=\"#\" ng-click=\"$event.preventDefault()\">Three</a></li>\n" +
    "    </ul>\n" +
    "</div></textarea>\n" +
    "\n" +
    "    </div>\n" +
    "\n" +
    "    <div class=\"labExample-notes\">\n" +
    "        <h5>Notes:</h5>\n" +
    "        <p>The split button works in a similar fashion to the regular dropdown button, except that it has two triggers: the button, and the dropdown trigger.</p>\n" +
    "        <p>The dropdown toggle is a small span that's placed within the button. This toggles the dropdown menu when clicked.</p>\n" +
    "        <p>The actual button can trigger a separate action; this is reserved for actions relating to the dropdown contents.</p>\n" +
    "    </div>\n" +
    "\n" +
    "</section>\n" +
    "\n" +
    "\n" +
    "<section class=\"labExample\">\n" +
    "\n" +
    "    <div class=\"labExample-demo\">\n" +
    "\n" +
    "        <h4>Other dropdowns</h4>\n" +
    "\n" +
    "        <ul class=\"inlineList\">\n" +
    "            <li>\n" +
    "                <span>Button</span>\n" +
    "                <div bc-dropdown>\n" +
    "                    <button type=\"button\" class=\"button\" bc-dropdown-toggle>Click</button>\n" +
    "                    <ul bc-dropdown-menu>\n" +
    "                        <li class=\"dropdown-menu-item\"><a href=\"#\" ng-click=\"$event.preventDefault()\">One</a></li>\n" +
    "                        <li class=\"dropdown-menu-item\"><a href=\"#\" ng-click=\"$event.preventDefault()\">Two</a></li>\n" +
    "                        <li class=\"dropdown-menu-item\"><a href=\"#\" ng-click=\"$event.preventDefault()\">Three</a></li>\n" +
    "                    </ul>\n" +
    "                </div>\n" +
    "            </li>\n" +
    "\n" +
    "            <li>\n" +
    "                <span>Icons</span>\n" +
    "                <div id=\"dropdown-image\" bc-dropdown>\n" +
    "                    <a style=\"display: inline-block\" href=\"#\" bc-dropdown-toggle>\n" +
    "                        <icon glyph=\"ic-settings\"></icon>\n" +
    "                    </a>\n" +
    "                    <ul bc-dropdown-menu>\n" +
    "                        <li class=\"dropdown-menu-item\"><a href=\"#\" ng-click=\"$event.preventDefault()\">One</a></li>\n" +
    "                        <li class=\"dropdown-menu-item\"><a href=\"#\" ng-click=\"$event.preventDefault()\">Two</a></li>\n" +
    "                        <li class=\"dropdown-menu-item\"><a href=\"#\" ng-click=\"$event.preventDefault()\">Three</a></li>\n" +
    "                    </ul>\n" +
    "                </div>\n" +
    "            </li>\n" +
    "\n" +
    "            <li>\n" +
    "                <span>Link</span>\n" +
    "                <div bc-dropdown>\n" +
    "                    <a bc-dropdown-toggle class=\"dropdown-button\">Click here for a dropdown</a>\n" +
    "                    <ul bc-dropdown-menu>\n" +
    "                        <li class=\"dropdown-menu-item\"><a href=\"#\" ng-click=\"$event.preventDefault()\">One</a></li>\n" +
    "                        <li class=\"dropdown-menu-item\"><a href=\"#\" ng-click=\"$event.preventDefault()\">Two</a></li>\n" +
    "                        <li class=\"dropdown-menu-item\"><a href=\"#\" ng-click=\"$event.preventDefault()\">Three</a></li>\n" +
    "                    </ul>\n" +
    "                </div>\n" +
    "            </li>\n" +
    "        </ul>\n" +
    "\n" +
    "        <hr>\n" +
    "\n" +
    "    </div>\n" +
    "\n" +
    "    <div class=\"labExample-code\">\n" +
    "\n" +
    "<textarea ui-codemirror=\"{\n" +
    "    'lineNumbers': true,\n" +
    "    'theme':'default',\n" +
    "    'readOnly': 'true',\n" +
    "    'lineWrapping' : false,\n" +
    "    'mode': 'text/html',\n" +
    "    autoClearEmptyLines: true\n" +
    "}\"><div id=\"dropdown-image\" bc-dropdown>\n" +
    "    <a href=\"#\" bc-dropdown-toggle>\n" +
    "        <icon glyph=\"ic-settings\"></icon>\n" +
    "    </a>\n" +
    "    <ul bc-dropdown-menu>\n" +
    "        <li class=\"dropdown-menu-item\"><a href=\"#\" ng-click=\"$event.preventDefault()\">One</a></li>\n" +
    "        <li class=\"dropdown-menu-item\"><a href=\"#\" ng-click=\"$event.preventDefault()\">Two</a></li>\n" +
    "        <li class=\"dropdown-menu-item\"><a href=\"#\" ng-click=\"$event.preventDefault()\">Three</a></li>\n" +
    "    </ul>\n" +
    "</div></textarea>\n" +
    "\n" +
    "    </div>\n" +
    "\n" +
    "    <div class=\"labExample-notes\">\n" +
    "        <h5>Notes:</h5>\n" +
    "        <p>Dropdowns can take other forms too – as long as they're contained within a <code>[bc-dropdown]</code>, a <code>[bc-dropdown-toggle]</code> should trigger its sibling <code>[bc-dropdown-menu]</code>.</p>\n" +
    "    </div>\n" +
    "\n" +
    "</section>\n" +
    "");
}]);
})();

(function(module) {
try { module = angular.module("website-templates"); }
catch(err) { module = angular.module("website-templates", []); }
module.run(["$templateCache", function($templateCache) {
  "use strict";
  $templateCache.put("src/website/js/examples/bc-pagination/bc-pagination.tpl.html",
    "<section class=\"labExample\">\n" +
    "\n" +
    "    <div class=\"labExample-demo\">\n" +
    "\n" +
    "        <h2>Pagination</h2>\n" +
    "\n" +
    "        <bc-pagination\n" +
    "            total-items=\"totalItems\"\n" +
    "            page=\"currentPage\"\n" +
    "            items-per-page=\"itemsPerPage\"\n" +
    "            on-change=\"onSelectPage\"\n" +
    "            rotate=\"false\"\n" +
    "            max-size=\"maxSize\"\n" +
    "            limits=\"customLimits\"\n" +
    "            class=\"pagination firstPagination\"> <!-- Class added just for tests -->\n" +
    "        </bc-pagination>\n" +
    "\n" +
    "    </div>\n" +
    "\n" +
    "    <div class=\"labExample-demo\">\n" +
    "\n" +
    "        <bc-pagination\n" +
    "            total-items=\"totalItems\"\n" +
    "            page=\"currentPage\"\n" +
    "            items-per-page=\"itemsPerPage\"\n" +
    "            on-change=\"onSelectPage\"\n" +
    "            rotate=\"true\"\n" +
    "            max-size=\"maxSize\"\n" +
    "            class=\"pagination\">\n" +
    "        </bc-pagination>\n" +
    "\n" +
    "    </div>\n" +
    "\n" +
    "    <div class=\"labExample-demo\">\n" +
    "\n" +
    "        <bc-pagination\n" +
    "            total-items=\"totalItems\"\n" +
    "            page=\"currentPage\"\n" +
    "            items-per-page=\"itemsPerPage\"\n" +
    "            on-change=\"onSelectPage\"\n" +
    "            rotate=\"false\"\n" +
    "            boundary-links=\"true\"\n" +
    "            max-size=\"maxSize\"\n" +
    "            show-limits=\"false\"\n" +
    "            class=\"pagination\">\n" +
    "        </bc-pagination>\n" +
    "\n" +
    "        <hr>\n" +
    "\n" +
    "    </div>\n" +
    "\n" +
    "    <div class=\"labExample-code\">\n" +
    "\n" +
    "<textarea ui-codemirror=\"{\n" +
    "    'lineNumbers': true,\n" +
    "    'theme':'default',\n" +
    "    'readOnly': 'true',\n" +
    "    'lineWrapping' : false,\n" +
    "    'mode': 'text/html',\n" +
    "    autoClearEmptyLines: true\n" +
    "}\">\n" +
    "<bc-pagination\n" +
    "    total-items=\"totalItems\"\n" +
    "    page=\"currentPage\"\n" +
    "    items-per-page=\"itemsPerPage\"\n" +
    "    on-change=\"onSelectPage\"\n" +
    "    rotate=\"false\"\n" +
    "    max-size=\"maxSize\"\n" +
    "    limits=\"customLimits\"\n" +
    "    class=\"pagination\">\n" +
    "</bc-pagination></textarea>\n" +
    "\n" +
    "    </div>\n" +
    "\n" +
    "    <div class=\"labExample-notes\">\n" +
    "        <h5>Notes:</h5>\n" +
    "        <p>\n" +
    "            Pagination controls can be displayed above and below a dataset that you\n" +
    "            would like to page over. Pagination controls are displayed to the right of\n" +
    "            that dataset, make sure you utilise the CSS classname of <code>pagination</code>.\n" +
    "        </p>\n" +
    "        <p>\n" +
    "            Pagination has a vast amount of options available, most can be\n" +
    "            <a href=\"http://pineconellc.github.io/angular-foundation/#/pagination\">viewed here</a>.\n" +
    "        </p>\n" +
    "        <p>\n" +
    "            The only addition to the Bigcommerce Pagination is the ability to show user define-able\n" +
    "            limits to the number of rows of data that are displayed to the user at any one time, via <code>show-limits</code>.\n" +
    "        </p>\n" +
    "        <p>\n" +
    "            The form controls below can alter the pagination controls on the page.\n" +
    "        </p>\n" +
    "        <div class=\"form-row\">\n" +
    "            <div class=\"form-field\">\n" +
    "                <label for=\"total\" class=\"form-label\">Total Items</label>\n" +
    "                <input type=\"text\" class=\"form-input\" id=\"total\" ng-model=\"totalItems\">\n" +
    "            </div>\n" +
    "            <div class=\"form-field\">\n" +
    "                <label for=\"items\" class=\"form-label\">Items per page</label>\n" +
    "                <input type=\"text\" class=\"form-input\" id=\"items\" ng-model=\"itemsPerPage\">\n" +
    "            </div>\n" +
    "        </div>\n" +
    "    </div>\n" +
    "\n" +
    "</section>\n" +
    "\n" +
    "\n" +
    "<section class=\"labExample\">\n" +
    "\n" +
    "    <div class=\"labExample-demo\">\n" +
    "\n" +
    "        <h2>Pager</h2>\n" +
    "\n" +
    "        <pager\n" +
    "            class=\"pagination\"\n" +
    "            total-items=\"totalItems\"\n" +
    "            page=\"currentPage\">\n" +
    "        </pager>\n" +
    "\n" +
    "        <hr>\n" +
    "\n" +
    "    </div>\n" +
    "\n" +
    "    <div class=\"labExample-code\">\n" +
    "\n" +
    "<textarea ui-codemirror=\"{\n" +
    "    'lineNumbers': true,\n" +
    "    'theme':'default',\n" +
    "    'readOnly': 'true',\n" +
    "    'lineWrapping' : false,\n" +
    "    'mode': 'text/html',\n" +
    "    autoClearEmptyLines: true\n" +
    "}\">\n" +
    "<pager\n" +
    "    class=\"pagination\"\n" +
    "    total-items=\"totalItems\"\n" +
    "    page=\"currentPage\">\n" +
    "</pager></textarea>\n" +
    "\n" +
    "    </div>\n" +
    "\n" +
    "    <div class=\"labExample-notes\">\n" +
    "        <h5>Notes:</h5>\n" +
    "        <p>\n" +
    "            Pagination can also come in the form of a pager, which only has next\n" +
    "            and previous options.\n" +
    "        </p>\n" +
    "    </div>\n" +
    "\n" +
    "</section>\n" +
    "");
}]);
})();

(function(module) {
try { module = angular.module("website-templates"); }
catch(err) { module = angular.module("website-templates", []); }
module.run(["$templateCache", function($templateCache) {
  "use strict";
  $templateCache.put("src/website/js/examples/bc-server-table/bc-server-table.tpl.html",
    "<h3>Data Table</h3>\n" +
    "\n" +
    "<!-- TODO: Fix this filter before adding it back – It doesn't actually work.\n" +
    "<form method=\"post\" class=\"form\" ng-submit=\"bcServerTableDemoCtrl.bcServerTable.updateTable()\">\n" +
    "    <fieldset class=\"form-fieldset\">\n" +
    "        <div class=\"form-field\">\n" +
    "            <label class=\"form-label\" for=\"time\">Filter:</label>\n" +
    "            <div class=\"form-prefixPostfix\">\n" +
    "                <input class=\"form-input\" id=\"time\" type=\"text\" placeholder=\"Keywords\" ng-model=\"bcServerTableDemoCtrl.bcServerTable.filters.time\">\n" +
    "                <button class=\"button button--primary form-prefixPostfix-button--postfix\" id=\"updateFilter\" type=\"submit\">Update</button>\n" +
    "                <button class=\"button form-prefixPostfix-button--postfix\" type=\"reset\" ng-click=\"bcServerTableDemoCtrl.clearTable($event)\">Reset table</button>\n" +
    "            </div>\n" +
    "        </div>\n" +
    "    </fieldset>\n" +
    "</form>\n" +
    "-->\n" +
    "\n" +
    "<bc-pagination class=\"pagination\" id=\"pagination\"\n" +
    "               on-change=\"bcServerTableDemoCtrl.bcServerTable.updatePage(page, limit)\"\n" +
    "               total-items=\"bcServerTableDemoCtrl.bcServerTable.pagination.total\"\n" +
    "               page=\"bcServerTableDemoCtrl.bcServerTable.pagination.page\"\n" +
    "               items-per-page=\"bcServerTableDemoCtrl.bcServerTable.pagination.limit\"\n" +
    "               max-size=\"5\">\n" +
    "</bc-pagination>\n" +
    "\n" +
    "<table class=\"table\">\n" +
    "    <thead class=\"table-thead\">\n" +
    "        <th><input ng-click=\"bcServerTableDemoCtrl.bcServerTable.selectAllRows()\" ng-checked=\"bcServerTableDemoCtrl.bcServerTable.allSelected\" type=\"checkbox\"/></th>\n" +
    "        <th><bc-sort-by table-id=\"{{ bcServerTableDemoCtrl.bcServerTable.id }}\" id=\"sortByName\" sort-value=\"name\" column-name=\"Name\"></bc-sort-by></th>\n" +
    "        <th><bc-sort-by table-id=\"{{ bcServerTableDemoCtrl.bcServerTable.id }}\" id=\"sortByStar\" sort-value=\"star\" column-name=\"Star\"></bc-sort-by></th>\n" +
    "        <th><bc-sort-by table-id=\"{{ bcServerTableDemoCtrl.bcServerTable.id }}\" id=\"sortByLocation\" sort-value=\"sf-location\" column-name=\"SF Location\"></bc-sort-by></th>\n" +
    "    </thead>\n" +
    "    <tbody class=\"table-tbody\">\n" +
    "        <tr id=\"row-{{ $index }}\" class=\"tableRow\" ng-repeat=\"row in bcServerTableDemoCtrl.bcServerTable.rows\">\n" +
    "            <td><input ng-model=\"bcServerTableDemoCtrl.bcServerTable.selectedRows[row[bcServerTableDemoCtrl.bcServerTable.tableConfig.rowIdKey]]\" type=\"checkbox\"/></td>\n" +
    "            <td>{{row.name}}</td>\n" +
    "            <td>{{row.star}}</td>\n" +
    "            <td>{{row['sf-location']}}</td>\n" +
    "        </tr>\n" +
    "    </tbody>\n" +
    "</table>\n" +
    "\n" +
    "<hr>\n" +
    "\n" +
    "    <div class=\"labExample-code\">\n" +
    "        <h4>Usage</h4>\n" +
    "\n" +
    "<textarea ui-codemirror=\"{\n" +
    "'lineNumbers': true,\n" +
    "'theme':'default',\n" +
    "'readOnly': 'true',\n" +
    "'lineWrapping' : false,\n" +
    "'mode': 'text/html',\n" +
    "autoClearEmptyLines: true\n" +
    "}\">\n" +
    "<form method=\"post\" class=\"form\" ng-submit=\"bcServerTableDemoCtrl.bcServerTable.updateTable()\">\n" +
    "    <fieldset class=\"form-fieldset\">\n" +
    "        <div class=\"form-field\">\n" +
    "            <label class=\"form-label\" for=\"time\">Filter:</label>\n" +
    "            <div class=\"form-prefixPostfix\">\n" +
    "                <input class=\"form-input\" id=\"time\" type=\"text\" placeholder=\"Keywords\" ng-model=\"bcServerTableDemoCtrl.bcServerTable.filters.time\">\n" +
    "                <button class=\"button button--primary form-prefixPostfix-button--postfix\" id=\"updateFilter\" type=\"submit\">Update</button>\n" +
    "                <button class=\"button form-prefixPostfix-button--postfix\" type=\"reset\" ng-click=\"bcServerTableDemoCtrl.clearTable($event)\">Reset table</button>\n" +
    "            </div>\n" +
    "        </div>\n" +
    "    </fieldset>\n" +
    "</form>\n" +
    "<bc-pagination class=\"pagination\" id=\"pagination\"\n" +
    "               on-change=\"bcServerTableDemoCtrl.bcServerTable.updatePage(page, limit)\"\n" +
    "               total-items=\"bcServerTableDemoCtrl.bcServerTable.pagination.total\"\n" +
    "               page=\"bcServerTableDemoCtrl.bcServerTable.pagination.page\"\n" +
    "               items-per-page=\"bcServerTableDemoCtrl.bcServerTable.pagination.limit\"\n" +
    "               max-size=\"5\">\n" +
    "</bc-pagination>\n" +
    "<table class=\"table\">\n" +
    "    <thead class=\"table-thead\">\n" +
    "        <th><input type=\"checkbox\"/></th>\n" +
    "        <th>Name</th>\n" +
    "        <th>Star</th>\n" +
    "        <th>Location</th>\n" +
    "    </thead>\n" +
    "    <tbody class=\"table-tbody\">\n" +
    "        <tr id=\"row-{{ $index }}\" class=\"tableRow\">\n" +
    "            <td><input type=\"checkbox\"/></td>\n" +
    "            <td>{{row.name}}</td>\n" +
    "            <td>{{row.star}}</td>\n" +
    "            <td>{{row.location}}</td>\n" +
    "        </tr>\n" +
    "    </tbody>\n" +
    "</table></textarea>\n" +
    "\n" +
    "    </div>\n" +
    "\n" +
    "    <div class=\"labExample-notes\">\n" +
    "        <h5>Notes:</h5>\n" +
    "        <p>The Data table uses a combination of the table component, pagination, and a filter to organise data and enable filtration\n" +
    "            and navigation of large datasets. It should be used in interactive tables with possibly large amounts of rows; like Orders or Products.\n" +
    "        </p>\n" +
    "    </div>\n" +
    "");
}]);
})();

(function(module) {
try { module = angular.module("website-templates"); }
catch(err) { module = angular.module("website-templates", []); }
module.run(["$templateCache", function($templateCache) {
  "use strict";
  $templateCache.put("src/website/js/examples/buttons/buttons.tpl.html",
    "<h3>Buttons</h3>\n" +
    "<div>\n" +
    "    <h4>Single toggle</h4>\n" +
    "    <pre>{{singleModel}}</pre>\n" +
    "    <button type=\"button\" class=\"button\" ng-model=\"singleModel\" btn-checkbox btn-checkbox-true=\"1\" btn-checkbox-false=\"0\">\n" +
    "        Single Toggle\n" +
    "    </button>\n" +
    "    <h4>Checkbox</h4>\n" +
    "    <pre>{{checkModel}}</pre>\n" +
    "    <div class=\"buttonGroup\">\n" +
    "        <button class=\"button\" ng-model=\"checkModel.left\" btn-checkbox>Left</button>\n" +
    "        <button class=\"button\" ng-model=\"checkModel.middle\" btn-checkbox>Middle</button>\n" +
    "        <button class=\"button\" ng-model=\"checkModel.right\" btn-checkbox>Right</button>\n" +
    "    </div>\n" +
    "    <h4>Radio</h4>\n" +
    "    <pre>{{radioModel}}</pre>\n" +
    "    <div class=\"buttonGroup\">\n" +
    "        <button class=\"button\" ng-model=\"radioModel\" btn-radio=\"'Left'\">Left</button>\n" +
    "        <button class=\"button\" ng-model=\"radioModel\" btn-radio=\"'Middle'\">Middle</button>\n" +
    "        <button class=\"button\" ng-model=\"radioModel\" btn-radio=\"'Right'\">Right</button>\n" +
    "    </div>\n" +
    "</div>\n" +
    "\n" +
    "");
}]);
})();

(function(module) {
try { module = angular.module("website-templates"); }
catch(err) { module = angular.module("website-templates", []); }
module.run(["$templateCache", function($templateCache) {
  "use strict";
  $templateCache.put("src/website/js/examples/color-picker/color-picker.tpl.html",
    "<section class=\"labExample\">\n" +
    "\n" +
    "    <div class=\"labExample-demo\">\n" +
    "\n" +
    "        <h2>Color Picker</h2>\n" +
    "\n" +
    "        <color-picker\n" +
    "            palette=\"palette\"\n" +
    "            ng-model=\"modelValue\">\n" +
    "        </color-picker>\n" +
    "\n" +
    "        <h4>Selected colour: <span style=\"color:{{modelValue}}\">{{modelValue}}</span></h4>\n" +
    "\n" +
    "        <hr>\n" +
    "\n" +
    "    </div>\n" +
    "\n" +
    "    <div class=\"labExample-code\">\n" +
    "        <textarea ui-codemirror=\"{\n" +
    "            'lineNumbers': true,\n" +
    "            'theme':'default',\n" +
    "            'readOnly': 'true',\n" +
    "            'lineWrapping' : false,\n" +
    "            'mode': 'text/html',\n" +
    "            autoClearEmptyLines: true\n" +
    "        }\">\n" +
    "<color-picker\n" +
    "    palette=\"palette\"\n" +
    "    ng-model=\"modelValue\">\n" +
    "</color-picker></textarea>\n" +
    "    </div>\n" +
    "\n" +
    "    <div class=\"labExample-notes\">\n" +
    "        <h5>Notes: </h5>\n" +
    "\n" +
    "    </div>\n" +
    "\n" +
    "</section>\n" +
    "\n" +
    "<section class=\"labExample\">\n" +
    "\n" +
    "    <div class=\"labExample-demo\">\n" +
    "\n" +
    "        <h2>Color Input</h2>\n" +
    "\n" +
    "        <div class=\"form-field\">\n" +
    "            <form-input-color\n" +
    "                label-text=\"inputLabelText\"\n" +
    "                ng-model=\"inputModelValue\"\n" +
    "                palette=\"inputPalette\"\n" +
    "                placeholder-text=\"inputPlaceholderText\"\n" +
    "            >\n" +
    "            </form-input-color>\n" +
    "        <h4>Selected colour: <span style=\"color:{{inputModelValue}}\">{{inputModelValue}}</span></h4>\n" +
    "        </div>\n" +
    "\n" +
    "        <hr>\n" +
    "\n" +
    "    </div>\n" +
    "\n" +
    "    <div class=\"labExample-code\">\n" +
    "        <textarea ui-codemirror=\"{\n" +
    "            'lineNumbers': true,\n" +
    "            'theme':'default',\n" +
    "            'readOnly': 'true',\n" +
    "            'lineWrapping' : false,\n" +
    "            'mode': 'text/html',\n" +
    "            autoClearEmptyLines: true\n" +
    "        }\">\n" +
    "<form-input-color\n" +
    "    label-text=\"inputLabelText\"\n" +
    "    ng-model=\"inputModelValue\"\n" +
    "    palette=\"inputPalette\"\n" +
    "    placeholder-text=\"inputPlaceholderText\"\n" +
    ">\n" +
    "</form-input-color></textarea>\n" +
    "\n" +
    "    </div>\n" +
    "\n" +
    "    <div class=\"labExample-notes\">\n" +
    "        <h5>Notes: </h5>\n" +
    "\n" +
    "    </div>\n" +
    "\n" +
    "</section>\n" +
    "\n" +
    "");
}]);
})();

(function(module) {
try { module = angular.module("website-templates"); }
catch(err) { module = angular.module("website-templates", []); }
module.run(["$templateCache", function($templateCache) {
  "use strict";
  $templateCache.put("src/website/js/examples/credit-card/credit-card-example.tpl.html",
    "<form>\n" +
    "    <fieldset class=\"form-fieldset\">\n" +
    "        <legend class=\"form-legend\">Payment details</legend>\n" +
    "        <div class=\"form-body\">\n" +
    "\n" +
    "            <!-- optional separate component: credit-card-types -->\n" +
    "            <credit-card-types\n" +
    "                    selected-type=\"creditCardCtrl.ccData.ccType\"\n" +
    "                    supported-types=\"creditCardCtrl.ccConfig.supportedTypes\">\n" +
    "            </credit-card-types>\n" +
    "\n" +
    "            <!-- Credit Card component can live anywhere in a form -->\n" +
    "            <credit-card\n" +
    "                eager-type=\"true\"\n" +
    "                cc-data=\"creditCardCtrl.ccData\"\n" +
    "                cc-config=\"creditCardCtrl.ccConfig\">\n" +
    "            </credit-card>\n" +
    "            <!-- Credit Card -->\n" +
    "\n" +
    "            <div class=\"form-actions\">\n" +
    "                <a href=\"#\">Cancel</a>\n" +
    "                <button class=\"button button--primary\" type=\"submit\">Submit</button>\n" +
    "            </div>\n" +
    "        </div>\n" +
    "    </fieldset>\n" +
    "</form>\n" +
    "");
}]);
})();

(function(module) {
try { module = angular.module("website-templates"); }
catch(err) { module = angular.module("website-templates", []); }
module.run(["$templateCache", function($templateCache) {
  "use strict";
  $templateCache.put("src/website/js/examples/credit-card/credit-card.tpl.html",
    "<section class=\"labExample\">\n" +
    "    <div class=\"labExample-demo\" id=\"labExampleCreditCard\">\n" +
    "        <h2>Credit Card Payment Pattern</h2>\n" +
    "\n" +
    "        <form>\n" +
    "    <fieldset class=\"form-fieldset\">\n" +
    "        <legend class=\"form-legend\">Payment details</legend>\n" +
    "        <div class=\"form-body\">\n" +
    "\n" +
    "            <!-- optional separate component: credit-card-types -->\n" +
    "            <credit-card-types\n" +
    "                    selected-type=\"creditCardCtrl.ccData.ccType\"\n" +
    "                    supported-types=\"creditCardCtrl.ccConfig.supportedTypes\">\n" +
    "            </credit-card-types>\n" +
    "\n" +
    "            <!-- Credit Card component can live anywhere in a form -->\n" +
    "            <credit-card\n" +
    "                eager-type=\"true\"\n" +
    "                cc-data=\"creditCardCtrl.ccData\"\n" +
    "                cc-config=\"creditCardCtrl.ccConfig\">\n" +
    "            </credit-card>\n" +
    "            <!-- Credit Card -->\n" +
    "\n" +
    "            <div class=\"form-actions\">\n" +
    "                <a href=\"#\">Cancel</a>\n" +
    "                <button class=\"button button--primary\" type=\"submit\">Submit</button>\n" +
    "            </div>\n" +
    "        </div>\n" +
    "    </fieldset>\n" +
    "</form>\n" +
    "\n" +
    "        <hr>\n" +
    "    </div>\n" +
    "\n" +
    "    <div class=\"labExample-code\">\n" +
    "        <textarea ui-codemirror=\"{\n" +
    "        'lineNumbers': true,\n" +
    "        'theme':'default',\n" +
    "        'readOnly': 'true',\n" +
    "        'lineWrapping' : false,\n" +
    "        'mode': 'text/html',\n" +
    "        autoClearEmptyLines: true\n" +
    "        }\">\n" +
    "<form>\n" +
    "    <fieldset class=\"form-fieldset\">\n" +
    "        <legend class=\"form-legend\">Payment details</legend>\n" +
    "        <div class=\"form-body\">\n" +
    "\n" +
    "            <!-- optional separate component: credit-card-types -->\n" +
    "            <credit-card-types\n" +
    "                    selected-type=\"creditCardCtrl.ccData.ccType\"\n" +
    "                    supported-types=\"creditCardCtrl.ccConfig.supportedTypes\">\n" +
    "            </credit-card-types>\n" +
    "\n" +
    "            <!-- Credit Card component can live anywhere in a form -->\n" +
    "            <credit-card\n" +
    "                eager-type=\"true\"\n" +
    "                cc-data=\"creditCardCtrl.ccData\"\n" +
    "                cc-config=\"creditCardCtrl.ccConfig\">\n" +
    "            </credit-card>\n" +
    "            <!-- Credit Card -->\n" +
    "\n" +
    "            <div class=\"form-actions\">\n" +
    "                <a href=\"#\">Cancel</a>\n" +
    "                <button class=\"button button--primary\" type=\"submit\">Submit</button>\n" +
    "            </div>\n" +
    "        </div>\n" +
    "    </fieldset>\n" +
    "</form></textarea>\n" +
    "\n" +
    "        <br>\n" +
    "\n" +
    "        <textarea ui-codemirror=\"{\n" +
    "        'lineNumbers': true,\n" +
    "        'theme':'default',\n" +
    "        'readOnly': 'true',\n" +
    "        'lineWrapping' : false,\n" +
    "        'mode': 'text/html',\n" +
    "        autoClearEmptyLines: true\n" +
    "        }\">\n" +
    "ctrl.ccData = {\n" +
    "    ccNumber: '',\n" +
    "    ccCvv: '',\n" +
    "    ccName: '',\n" +
    "    ccExpiry: {\n" +
    "        month: '',\n" +
    "        year: ''\n" +
    "    },\n" +
    "    ccType: '',\n" +
    "};\n" +
    "\n" +
    "ctrl.ccConfig = {\n" +
    "    cardCode: true,\n" +
    "    fullName: true,\n" +
    "};</textarea>\n" +
    "    </div>\n" +
    "\n" +
    "    <div class=\"labExample-notes\">\n" +
    "        <h5>Notes:</h5>\n" +
    "        <p>\n" +
    "            The credit card component relies on <a href=\"https://github.com/bendrucker/angular-credit-cards\" target=\"_blank\">angular-credit-cards</a>\n" +
    "            for <code>ccNumber</code> and <code>ccCvc</code>. The <code>ccExpiry</code> directive is a custom directive that formats/validates\n" +
    "            the expiration date in a MM / YY format. Also, the credit card type is not explicitly entered but deduced from the credit card number.\n" +
    "        </p>\n" +
    "        <ul>\n" +
    "            <li><code>ccData</code>: an object containing the credit card data bound to the directive</li>\n" +
    "            <li><code>ccConfig</code>: an object with the configuration for the credit-card directive\n" +
    "                <ul>\n" +
    "                    <li><code>cardCode</code>: boolean value indicating whether cvv is shown (default true)</li>\n" +
    "                    <li><code>cardCodeRequired</code>: boolean value indicating whether the card code field is required. This only matters if <code>cardCode</code> is true. (default true)</li>\n" +
    "                    <li><code>fullName</code>: boolean value indicating whether the full name field is required/shown (default true)</li>\n" +
    "                </ul>\n" +
    "            </li>\n" +
    "            <li><code>eagerType</code>: an optional boolean value indicating whether eager type detection\n" +
    "                (infer and expose the credit card type before the full number is entered) is enabled. (default true)\n" +
    "            </li>\n" +
    "        </ul>\n" +
    "\n" +
    "        <p>\n" +
    "            The credit-card-types display in the example exists as a separate component, but will most likely be used alongside the credit-card component.\n" +
    "            The component displays the list of supported card types. Once a card type has been selected (or detected by the credit-card component), all\n" +
    "            the credit card types other than the selected one becomes greyed-out.\n" +
    "        </p>\n" +
    "        <ul>\n" +
    "            <li><code>selectedType</code>: string value indicating the card type: 'American Express', 'Diners Club', 'Discover', 'MasterCard', 'Visa'. Note that these values\n" +
    "                are the same as the ones that are detected by the credit-card directive.\n" +
    "            </li>\n" +
    "            <li><code>supportedTypes</code>: an array of a selection of supported credit card types. This has the same strings representing the card types:\n" +
    "                'American Express', 'Diners Club', 'Discover', 'MasterCard', 'Visa'.\n" +
    "            </li>\n" +
    "        </ul>\n" +
    "\n" +
    "        <div class=\"form-field\">\n" +
    "            <label class=\"form-label\">Form Display Options</label>\n" +
    "            <input class=\"form-checkbox\" type=\"checkbox\" id=\"creditCardForm_cvv\" ng-model=\"creditCardCtrl.ccConfig.cardCode\">\n" +
    "            <label for=\"creditCardForm_cvv\" class=\"form-label\">Show CVV field</label>\n" +
    "            <input class=\"form-checkbox\" type=\"checkbox\" id=\"creditCardForm_fullName\" ng-model=\"creditCardCtrl.ccConfig.fullName\">\n" +
    "            <label for=\"creditCardForm_fullName\" class=\"form-label\">Show Name field</label>\n" +
    "        </div>\n" +
    "    </div>\n" +
    "</section>\n" +
    "");
}]);
})();

(function(module) {
try { module = angular.module("website-templates"); }
catch(err) { module = angular.module("website-templates", []); }
module.run(["$templateCache", function($templateCache) {
  "use strict";
  $templateCache.put("src/website/js/examples/loading-indicators/loading-indicators.tpl.html",
    "<section class=\"labExample\">\n" +
    "\n" +
    "    <div class=\"labExample-demo\">\n" +
    "\n" +
    "        <h3>Loading Notification</h3>\n" +
    "\n" +
    "        <button class=\"loading-request button\" ng-click=\"loadingIndicatorsCtrl.fakeHttpRequest()\">Simulate minor update</button>\n" +
    "        <loading-notification></loading-notification>\n" +
    "\n" +
    "    </div>\n" +
    "\n" +
    "    <div class=\"labExample-code\">\n" +
    "\n" +
    "<textarea ui-codemirror=\"{\n" +
    "    'lineNumbers': true,\n" +
    "    'theme':'default',\n" +
    "    'readOnly': 'true',\n" +
    "    'lineWrapping' : false,\n" +
    "    'mode': 'text/html',\n" +
    "    autoClearEmptyLines: true\n" +
    "}\">\n" +
    "\n" +
    "<loading-notification></loading-notification>\n" +
    "</textarea>\n" +
    "\n" +
    "    </div>\n" +
    "\n" +
    "    <div class=\"labExample-notes\">\n" +
    "        <h5>Notes:</h5>\n" +
    "        <p>\n" +
    "            The loading notification should be used anywhere an interaction may\n" +
    "            cause a small delay, but doesn't stop the user interacting with the page.\n" +
    "        </p>\n" +
    "        <p>\n" +
    "            This will automatically listen for <code>ajaxRequestRunning</code> from\n" +
    "            <code>ng-common</code> when placed on the page. Placement should be near the top.\n" +
    "        </p>\n" +
    "    </div>\n" +
    "\n" +
    "</section>\n" +
    "\n" +
    "\n" +
    "<section class=\"labExample\">\n" +
    "\n" +
    "    <div class=\"labExample-demo\">\n" +
    "\n" +
    "        <h3>Loading Overlay</h3>\n" +
    "\n" +
    "\n" +
    "        <form class=\"form\" id=\"loadingOverlay-example1\">\n" +
    "            <fieldset class=\"form-fieldset\">\n" +
    "\n" +
    "                <legend class=\"form-legend\">\n" +
    "                    <a class=\"e2e-toggleLoading button\" ng-click=\"loadingIndicatorsCtrl.toggleManualLoading()\">Toggle a loading state on this form</a>\n" +
    "                </legend>\n" +
    "\n" +
    "                <div class=\"form-body\" loading-overlay=\"loadingIndicatorsCtrl.manualLoading\">\n" +
    "\n" +
    "                    <div class=\"form-field\">\n" +
    "                        <label class=\"form-label\" for=\"input12\">Input Label</label>\n" +
    "                        <input class=\"form-input\" id=\"input12\" type=\"text\" placeholder=\"Placeholder text\">\n" +
    "                    </div>\n" +
    "\n" +
    "                    <div class=\"form-field\">\n" +
    "                        <label class=\"form-label\" for=\"input4\">Prefixed Label <small>(Inc. tax)</small></label>\n" +
    "                        <div class=\"form-prefixPostfix\">\n" +
    "                            <span class=\"form-prefixPostfix-label form-prefixPostfix-label--prefix\" id=\"prefixDesc1\">AUD $</span>\n" +
    "                            <input class=\"form-input form-prefixPostfix-input\" id=\"input4\" type=\"text\" placeholder=\"Placeholder text\" aria-describedby=\"prefixDesc1\">\n" +
    "                        </div>\n" +
    "                    </div>\n" +
    "\n" +
    "                    <div class=\"form-field\">\n" +
    "                        <label class=\"form-label\" for=\"input7\">Postfixed Button</label>\n" +
    "                        <div class=\"form-prefixPostfix\">\n" +
    "                            <input class=\"form-input\" id=\"input7\" type=\"text\" placeholder=\"Placeholder text\">\n" +
    "                            <input class=\"button form-prefixPostfix-button--postfix\" type=\"submit\" value=\"Save\">\n" +
    "                        </div>\n" +
    "                    </div>\n" +
    "\n" +
    "                </div>\n" +
    "\n" +
    "            </fieldset>\n" +
    "        </form>\n" +
    "\n" +
    "\n" +
    "\n" +
    "        <form class=\"form\" id=\"loadingOverlay-example2\">\n" +
    "            <fieldset class=\"form-fieldset\">\n" +
    "\n" +
    "                <legend class=\"form-legend\">\n" +
    "                    <a class=\"e2e-triggerStateChange button\" ng-click=\"loadingIndicatorsCtrl.fakeStateTransition()\">Initiate a fake state transition on this form</a>\n" +
    "                </legend>\n" +
    "\n" +
    "                <div class=\"form-body\" loading-overlay use-ui-router=\"true\">\n" +
    "\n" +
    "                    <div class=\"form-field\">\n" +
    "                        <label class=\"form-label\" for=\"input12\">Input Label</label>\n" +
    "                        <input class=\"form-input\" id=\"input12\" type=\"text\" placeholder=\"Placeholder text\">\n" +
    "                    </div>\n" +
    "\n" +
    "                    <div class=\"form-field\">\n" +
    "                        <label class=\"form-label\" for=\"input4\">Prefixed Label <small>(Inc. tax)</small></label>\n" +
    "                        <div class=\"form-prefixPostfix\">\n" +
    "                            <span class=\"form-prefixPostfix-label form-prefixPostfix-label--prefix\" id=\"prefixDesc1\">AUD $</span>\n" +
    "                            <input class=\"form-input form-prefixPostfix-input\" id=\"input4\" type=\"text\" placeholder=\"Placeholder text\" aria-describedby=\"prefixDesc1\">\n" +
    "                        </div>\n" +
    "                    </div>\n" +
    "\n" +
    "                    <div class=\"form-field\">\n" +
    "                        <label class=\"form-label\" for=\"input7\">Postfixed Button</label>\n" +
    "                        <div class=\"form-prefixPostfix\">\n" +
    "                            <input class=\"form-input\" id=\"input7\" type=\"text\" placeholder=\"Placeholder text\">\n" +
    "                            <input class=\"button form-prefixPostfix-button--postfix\" type=\"submit\" value=\"Save\">\n" +
    "                        </div>\n" +
    "                    </div>\n" +
    "\n" +
    "                </div>\n" +
    "\n" +
    "            </fieldset>\n" +
    "        </form>\n" +
    "\n" +
    "\n" +
    "    </div>\n" +
    "\n" +
    "    <div class=\"labExample-code\">\n" +
    "\n" +
    "<textarea ui-codemirror=\"{\n" +
    "'lineNumbers': true,\n" +
    "'theme':'default',\n" +
    "'readOnly': 'true',\n" +
    "'lineWrapping' : false,\n" +
    "'mode': 'text/html',\n" +
    "autoClearEmptyLines: true\n" +
    "}\"><div class=\"your-container\" loading-overlay=\"loadingIndicatorsCtrl.manualLoading\">\n" +
    "&hellip;\n" +
    "</div>\n" +
    "\n" +
    "<div class=\"form-body\" loading-overlay use-ui-router=\"true\">\n" +
    "&hellip;\n" +
    "</div></textarea>\n" +
    "\n" +
    "    </div>\n" +
    "\n" +
    "    <div class=\"labExample-notes\">\n" +
    "        <h5>Notes:</h5>\n" +
    "        <p>\n" +
    "            The <code>loading-overlay</code> <em>should</em> be able to be placed on any\n" +
    "            container, modal or panel.\n" +
    "        </p>\n" +
    "        <p>\n" +
    "            It is used to indicate a section change, page load, or full panel refresh,\n" +
    "            where the user will not be able to interact with the page during that change.\n" +
    "        </p>\n" +
    "        <p>\n" +
    "            You can manually set the loading state by passing the directive a boolean.\n" +
    "            Or you set it to <code>use-ui-router</code>, where it will listen for\n" +
    "            <code>$stateChangeStart</code>, <code>$stateChangeSuccess</code> and <code>$stateChangeError</code>\n" +
    "        </p>\n" +
    "    </div>\n" +
    "\n" +
    "</section>\n" +
    "");
}]);
})();

(function(module) {
try { module = angular.module("website-templates"); }
catch(err) { module = angular.module("website-templates", []); }
module.run(["$templateCache", function($templateCache) {
  "use strict";
  $templateCache.put("src/website/js/examples/modal/modal-formatted.tpl.html",
    "<div class=\"modal-header\">\n" +
    "    <h2 class=\"modal-header-title\">A Modal Title</h2>\n" +
    "    <a class=\"modal-close\" ng-click='modalContentCtrl.cancel($event)' href=\"#\">\n" +
    "        <icon glyph=\"ic-close\"></icon>\n" +
    "    </a>\n" +
    "</div>\n" +
    "<div class=\"modal-body\">\n" +
    "    <h4>Some Modal Content</h4>\n" +
    "    <p>\n" +
    "        Lorem ipsum dolor sit amet, consectetur adipisicing elit. Inventore\n" +
    "        necessitatibus consequuntur quo totam quos, odio impedit. Nostrum pariatur,\n" +
    "        culpa blanditiis. Nostrum ipsam maiores sed dolores adipisci qui itaque,\n" +
    "        commodi accusantium.\n" +
    "    </p>\n" +
    "</div>\n" +
    "<div class=\"modal-footer\">\n" +
    "    <a class=\"modal-footer-link\" ng-click=\"modalContentCtrl.cancel($event)\" href=\"#\">\n" +
    "        Cancel modal link\n" +
    "    </a>\n" +
    "    <a class=\"button button--small button--primary\" ng-click=\"modalContentCtrl.ok($event)\" href=\"#\">\n" +
    "        Primary modal action\n" +
    "    </a>\n" +
    "</div>\n" +
    "");
}]);
})();

(function(module) {
try { module = angular.module("website-templates"); }
catch(err) { module = angular.module("website-templates", []); }
module.run(["$templateCache", function($templateCache) {
  "use strict";
  $templateCache.put("src/website/js/examples/modal/modal-small.tpl.html",
    "<div class=\"modal-header\">\n" +
    "    <h2 class=\"modal-header-title\">A Small Modal</h2>\n" +
    "    <a class=\"modal-close\" ng-click='modalContentCtrl.cancel($event)' href=\"#\">\n" +
    "        <icon glyph=\"ic-close\"></icon>\n" +
    "    </a>\n" +
    "</div>\n" +
    "<div class=\"modal-body\">\n" +
    "    <p>\n" +
    "        Lorem ipsum dolor sit amet, consectetur adipisicing elit. Inventore\n" +
    "    </p>\n" +
    "</div>\n" +
    "<div class=\"modal-footer\">\n" +
    "    <a class=\"modal-footer-link\" ng-click=\"modalContentCtrl.cancel($event)\" href=\"#\">cancel</a>\n" +
    "    <a class=\"button button--small button--primary modal-footer-button\" ng-click=\"modalContentCtrl.ok($event)\" href=\"#\">OK</a>\n" +
    "</div>\n" +
    "");
}]);
})();

(function(module) {
try { module = angular.module("website-templates"); }
catch(err) { module = angular.module("website-templates", []); }
module.run(["$templateCache", function($templateCache) {
  "use strict";
  $templateCache.put("src/website/js/examples/modal/modal-unformatted.tpl.html",
    "<div>\n" +
    "    <p>\n" +
    "        Lorem ipsum dolor sit amet, consectetur adipisicing elit. Inventore necessitatibus consequuntur quo totam quos, odio impedit. Nostrum pariatur, culpa blanditiis. Nostrum ipsam maiores sed dolores adipisci qui itaque, commodi accusantium.\n" +
    "    </p>\n" +
    "</div>\n" +
    "");
}]);
})();

(function(module) {
try { module = angular.module("website-templates"); }
catch(err) { module = angular.module("website-templates", []); }
module.run(["$templateCache", function($templateCache) {
  "use strict";
  $templateCache.put("src/website/js/examples/modal/modal.tpl.html",
    "<section class=\"labExample\">\n" +
    "\n" +
    "    <div class=\"labExample-demo\">\n" +
    "\n" +
    "        <h2>Modals</h2>\n" +
    "        <p>\n" +
    "            It is often necessary to display content inside a pop-up modal window.\n" +
    "            In almost all cases a modal should look and contain the following structural\n" +
    "            elements.\n" +
    "        </p>\n" +
    "\n" +
    "        <a\n" +
    "            class=\"button button--primary\"\n" +
    "            id=\"openModal--formatted\"\n" +
    "            ng-click=\"modalCtrl.openFormattedModal($event)\"\n" +
    "            href=\"#\">\n" +
    "            Open the default modal\n" +
    "        </a>\n" +
    "\n" +
    "    </div>\n" +
    "\n" +
    "</section>\n" +
    "\n" +
    "\n" +
    "<section class=\"labExample\">\n" +
    "\n" +
    "    <div class=\"labExample-demo\">\n" +
    "\n" +
    "        <h3>Modal Template</h3>\n" +
    "        <p>\n" +
    "            The general structure of this modal can be achieved by using the following\n" +
    "            HTML mark-up in your template file, which is used to build the internals of the modal.\n" +
    "        </p>\n" +
    "\n" +
    "    </div>\n" +
    "\n" +
    "    <div class=\"labExample-code\">\n" +
    "\n" +
    "<textarea ui-codemirror=\"{\n" +
    "    'lineNumbers': true,\n" +
    "    'theme':'default',\n" +
    "    'readOnly': 'true',\n" +
    "    'lineWrapping' : false,\n" +
    "    'mode': 'text/html',\n" +
    "    'autoClearEmptyLines': true\n" +
    "}\">\n" +
    "<div class=\"modal-header\">\n" +
    "    <h2 class=\"modal-header-title\">A Modal Title</h2>\n" +
    "    <a class=\"modal-close\" ng-click='modalContentCtrl.cancel($event)' href=\"#\">\n" +
    "        <icon glyph=\"ic-close\"></icon>\n" +
    "    </a>\n" +
    "</div>\n" +
    "<div class=\"modal-body\">\n" +
    "    <h4>Some Modal Content</h4>\n" +
    "    <p>\n" +
    "        Lorem ipsum dolor sit amet, consectetur adipisicing elit. Inventore\n" +
    "        necessitatibus consequuntur quo totam quos, odio impedit. Nostrum pariatur,\n" +
    "        culpa blanditiis. Nostrum ipsam maiores sed dolores adipisci qui itaque,\n" +
    "        commodi accusantium.\n" +
    "    </p>\n" +
    "</div>\n" +
    "<div class=\"modal-footer\">\n" +
    "    <a class=\"modal-footer-link\" ng-click=\"modalContentCtrl.cancel($event)\" href=\"#\">\n" +
    "        Cancel modal link\n" +
    "    </a>\n" +
    "    <a class=\"button button--small button--primary\" ng-click=\"modalContentCtrl.ok($event)\" href=\"#\">\n" +
    "        Primary modal action\n" +
    "    </a>\n" +
    "</div></textarea>\n" +
    "\n" +
    "    </div>\n" +
    "\n" +
    "    <div class=\"labExample-notes\">\n" +
    "        <h5>Notes:</h5>\n" +
    "        <p>\n" +
    "            This example should serve as a basis for most of the use-cases for\n" +
    "            implementing a modal. Use the following predefined classes in your html:\n" +
    "        </p>\n" +
    "        <ul>\n" +
    "            <li><code>modal-header</code></li>\n" +
    "            <li><code>modal-title</code></li>\n" +
    "            <li><code>modal-close</code></li>\n" +
    "            <li><code>modal-body</code></li>\n" +
    "            <li><code>modal-footer</code></li>\n" +
    "            <li><code>modal-link</code></li>\n" +
    "        </ul>\n" +
    "        <p>\n" +
    "            Please only use <code>button--small</code> in the <code>modal-footer</code>.\n" +
    "            <code>modal-footer</code> should also only contain one primary and one secondary action.\n" +
    "        </p>\n" +
    "    </div>\n" +
    "\n" +
    "</section>\n" +
    "\n" +
    "<section class=\"labExample\">\n" +
    "\n" +
    "    <div class=\"labExample-demo\">\n" +
    "        <h3>Modal Service <span class=\"u-colorGreysMedium\">[angular.js]</span></h3>\n" +
    "        <p>\n" +
    "            The modal component is interfaced through the angular <code>$modal</code>\n" +
    "            service. This service has only 1 method: <code>get</code>, which takes\n" +
    "            an options object.\n" +
    "        </p>\n" +
    "        <p>An example of using <code>$modal</code> service:</p>\n" +
    "    </div>\n" +
    "\n" +
    "    <div class=\"labExample-code\">\n" +
    "\n" +
    "<textarea ui-codemirror=\"{\n" +
    "    'lineNumbers': true,\n" +
    "    'theme':'default',\n" +
    "    'readOnly': 'true',\n" +
    "    'lineWrapping' : false,\n" +
    "    'mode': 'javascript',\n" +
    "    'autoClearEmptyLines': true\n" +
    "}\">\n" +
    "$modal.open({\n" +
    "    controller: 'ModalContentCtrl as modalContentCtrl',\n" +
    "    templateUrl: 'src/website/js/examples/modal/modal-bc.tpl.html',\n" +
    "    windowClass: 'modal--small'\n" +
    "});</textarea>\n" +
    "\n" +
    "    </div>\n" +
    "\n" +
    "    <div class=\"labExample-notes\">\n" +
    "        <h5>Notes:</h5>\n" +
    "        <p>\n" +
    "            <code>windowClass</code> is optional, the default size for a modal is\n" +
    "            currently the same as <code>modal--large</code>, so you don't need to declare it.\n" +
    "        </p>\n" +
    "        <p>\n" +
    "            If you really need a smaller modal though, <code>modal--small</code>\n" +
    "            is available. The same template mark-up is applicable.\n" +
    "        </p>\n" +
    "        <a\n" +
    "            class=\"button button--small\"\n" +
    "            id=\"openModal--formatted\"\n" +
    "            ng-click=\"modalCtrl.openSmallModal($event)\"\n" +
    "            href=\"#\">\n" +
    "            Open a small modal\n" +
    "        </a>\n" +
    "    </div>\n" +
    "\n" +
    "    <div class=\"labExample-demo\">\n" +
    "        <p>The following is the list of available options: </p>\n" +
    "        <ul>\n" +
    "            <li><code>templateUrl</code> - a path to a template representing modal's content.</li>\n" +
    "            <li><code>template</code> - inline template representing the modal's content.</li>\n" +
    "            <li><code>scope</code> - a scope instance to be used for the modal's content (actually the $modal service is going to create a child scope of a provided scope). Defaults to $rootScope.</li>\n" +
    "            <li><code>controller</code> - a controller for a modal instance - it can initialize scope used by modal. Accepts the \"controller-as\" syntax, and can be injected with $modalInstance.</li>\n" +
    "            <li><code>resolve</code> - members that will be resolved and passed to the controller as locals; it is equivalent of the resolve property for AngularJS routes.</li>\n" +
    "            <li><code>backdrop</code> - controls presence of a backdrop. Allowed values: true (default), false (no backdrop), 'static' - backdrop is present but modal window is not closed when clicking outside of the modal window.</li>\n" +
    "            <li><code>keyboard</code> - indicates whether the dialog should be closable by hitting the ESC key, defaults to true.</li>\n" +
    "            <li><code>windowClass</code> -  additional CSS class(es) to be added to a modal window template. Predefined classes are <code>modal--large</code> and <code>modal--small</code>.</li>\n" +
    "        </ul>\n" +
    "    </div>\n" +
    "\n" +
    "</section>\n" +
    "");
}]);
})();

(function(module) {
try { module = angular.module("website-templates"); }
catch(err) { module = angular.module("website-templates", []); }
module.run(["$templateCache", function($templateCache) {
  "use strict";
  $templateCache.put("src/website/js/examples/tabs/tabs.tpl.html",
    "<h2>Tabs</h2>\n" +
    "\n" +
    "<section class=\"labExample\">\n" +
    "\n" +
    "    <div class=\"labExample-demo\">\n" +
    "\n" +
    "        <h3>Basic Tabs</h3>\n" +
    "\n" +
    "        <tabset>\n" +
    "            <tab heading=\"Static title\">Static content</tab>\n" +
    "            <tab ng-repeat=\"tab in tabsCtrl.tabs\" heading=\"{{tab.title}}\" active=\"tab.active\">\n" +
    "                {{tab.content}}\n" +
    "            </tab>\n" +
    "            <tab select=\"tabsCtrl.tabClicked()\">\n" +
    "                <tab-heading>Log!</tab-heading>\n" +
    "                I've got an HTML heading, and a select callback. Pretty cool!\n" +
    "            </tab>\n" +
    "        </tabset>\n" +
    "\n" +
    "        <hr>\n" +
    "\n" +
    "    </div>\n" +
    "\n" +
    "    <div class=\"labExample-code\">\n" +
    "\n" +
    "<textarea ui-codemirror=\"{\n" +
    "'lineNumbers': true,\n" +
    "'theme':'default',\n" +
    "'readOnly': 'true',\n" +
    "'lineWrapping' : false,\n" +
    "'mode': 'text/html',\n" +
    "autoClearEmptyLines: true\n" +
    "}\">\n" +
    "<tabset>\n" +
    "    <tab heading=\"Static title\">Static content</tab>\n" +
    "    <tab ng-repeat=\"tab in tabsCtrl.tabs\" heading=\"{{tab.title}}\" active=\"tab.active\">\n" +
    "        {{tab.content}}\n" +
    "    </tab>\n" +
    "    <tab select=\"tabsCtrl.tabClicked()\">\n" +
    "        <tab-heading>Log!</tab-heading>\n" +
    "        I've got an HTML heading, and a select callback. Pretty cool!\n" +
    "    </tab>\n" +
    "</tabset></textarea>\n" +
    "\n" +
    "    </div>\n" +
    "\n" +
    "    <div class=\"labExample-notes\">\n" +
    "        <h5>Notes:</h5>\n" +
    "        <p>\n" +
    "            Headings can be set via the <code>heading</code> attribute or the\n" +
    "            <code>&lt;tab-heading/&gt;</code> element in side the <code>tab</code>.\n" +
    "        </p>\n" +
    "        <p>\n" +
    "            <code>active</code> sets the currently active tab.\n" +
    "        </p>\n" +
    "        <p>\n" +
    "            <code>select</code> allows for an optional expression to be called when\n" +
    "            the tab is selected.\n" +
    "        </p>\n" +
    "    </div>\n" +
    "\n" +
    "</section>\n" +
    "\n" +
    "<section class=\"labExample\">\n" +
    "\n" +
    "    <div class=\"labExample-demo\">\n" +
    "\n" +
    "        <h3>Vertical Tabs</h3>\n" +
    "\n" +
    "        <tabset vertical=\"true\" type=\"navType\">\n" +
    "            <tab heading=\"Vertical 1\">Vertical content 1</tab>\n" +
    "            <tab heading=\"Vertical 2\">Vertical content 2</tab>\n" +
    "            <tab heading=\"Vertical 3\">Vertical content 3</tab>\n" +
    "        </tabset>\n" +
    "\n" +
    "        <hr>\n" +
    "\n" +
    "    </div>\n" +
    "\n" +
    "    <div class=\"labExample-code\">\n" +
    "\n" +
    "<textarea ui-codemirror=\"{\n" +
    "'lineNumbers': true,\n" +
    "'theme':'default',\n" +
    "'readOnly': 'true',\n" +
    "'lineWrapping' : false,\n" +
    "'mode': 'text/html',\n" +
    "autoClearEmptyLines: true\n" +
    "}\">\n" +
    "<tabset vertical=\"true\" type=\"navType\">\n" +
    "    <tab heading=\"Vertical 1\">Vertical content 1</tab>\n" +
    "    <tab heading=\"Vertical 2\">Vertical content 2</tab>\n" +
    "    <tab heading=\"Vertical 3\">Vertical content 3</tab>\n" +
    "</tabset></textarea>\n" +
    "\n" +
    "    </div>\n" +
    "\n" +
    "    <div class=\"labExample-notes\">\n" +
    "        <h5>Notes:</h5>\n" +
    "        <p>\n" +
    "            An optional attribute of <code>vertical</code> enables the vertical\n" +
    "            variant of the tabs component to be used.\n" +
    "        </p>\n" +
    "    </div>\n" +
    "\n" +
    "</section>\n" +
    "\n" +
    "");
}]);
})();

(function(module) {
try { module = angular.module("website-templates"); }
catch(err) { module = angular.module("website-templates", []); }
module.run(["$templateCache", function($templateCache) {
  "use strict";
  $templateCache.put("src/website/js/examples/tooltip/tooltip.tpl.html",
    "<section class=\"labExample\">\n" +
    "\n" +
    "    <div class=\"labExample-demo\">\n" +
    "\n" +
    "        <h3>Tooltips</h3>\n" +
    "\n" +
    "        <p>\n" +
    "            Tooltips can be placed on any elements via custom attributes. The content\n" +
    "            and positioning of the tooltip are also set via these attributes.\n" +
    "        </p>\n" +
    "\n" +
    "        <div class=\"labBlockRow\">\n" +
    "\n" +
    "            <div class=\"labCol\">\n" +
    "                <div class=\"labBlock\">\n" +
    "                    <div class=\"labBlock-preview\">\n" +
    "                        <a href=\"#\" class=\"has-tip\" tooltip-append-to-body=\"true\" tooltip-placement=\"left\" tooltip=\"On the Left!\">Tooltip left</a>\n" +
    "                    </div>\n" +
    "                    <pre class=\"labBlock-example u-bgGreysLightest\">tooltip-placement=\"left\" tooltip=\"On the Left!\"</pre>\n" +
    "                </div>\n" +
    "            </div>\n" +
    "\n" +
    "            <div class=\"labCol\">\n" +
    "                <div class=\"labBlock\">\n" +
    "                    <div class=\"labBlock-preview\">\n" +
    "                        <a href=\"#\" class=\"has-tip\" tooltip-append-to-body=\"true\" tooltip-placement=\"right\" tooltip=\"On the Right!\">Tooltip right</a>\n" +
    "                    </div>\n" +
    "                    <pre class=\"labBlock-example u-bgGreysLightest\">tooltip-placement=\"right\" tooltip=\"On the Right!\"</pre>\n" +
    "                </div>\n" +
    "            </div>\n" +
    "\n" +
    "            <div class=\"labCol\">\n" +
    "                <div class=\"labBlock\">\n" +
    "                    <div class=\"labBlock-preview\">\n" +
    "                        <a href=\"#\" class=\"has-tip\" tooltip-append-to-body=\"true\" tooltip-placement=\"bottom\" tooltip=\"On the Bottom!\">Tooltip bottom</a>\n" +
    "                    </div>\n" +
    "                    <pre class=\"labBlock-example u-bgGreysLightest\">tooltip-placement=\"bottom\" tooltip=\"On the Bottom!\"</pre>\n" +
    "                </div>\n" +
    "            </div>\n" +
    "\n" +
    "            <div class=\"labCol\">\n" +
    "                <div class=\"labBlock\">\n" +
    "                    <div class=\"labBlock-preview\">\n" +
    "                        <a href=\"#\" class=\"has-tip\" tooltip-append-to-body=\"true\" tooltip-placement=\"top\" tooltip=\"On the Top!\">Tooltip top</a>\n" +
    "                    </div>\n" +
    "                    <pre class=\"labBlock-example u-bgGreysLightest\">tooltip-placement=\"top\" tooltip=\"On the Top!\"</pre>\n" +
    "                </div>\n" +
    "            </div>\n" +
    "\n" +
    "        </div>\n" +
    "\n" +
    "        <hr>\n" +
    "\n" +
    "    </div>\n" +
    "\n" +
    "    <div class=\"labExample-code\">\n" +
    "\n" +
    "<textarea ui-codemirror=\"{\n" +
    "'lineNumbers': true,\n" +
    "'theme':'default',\n" +
    "'readOnly': 'true',\n" +
    "'lineWrapping' : false,\n" +
    "'mode': 'text/html',\n" +
    "autoClearEmptyLines: true\n" +
    "}\">\n" +
    "<a\n" +
    "    href=\"#\"\n" +
    "    class=\"has-tip\"\n" +
    "    tooltip-append-to-body=\"true\"\n" +
    "    tooltip-placement=\"left\"\n" +
    "    tooltip=\"On the Left!\"\n" +
    ">Tooltip left</a></textarea>\n" +
    "\n" +
    "    </div>\n" +
    "\n" +
    "    <div class=\"labExample-notes\">\n" +
    "        <h5>Notes:</h5>\n" +
    "        <p>\n" +
    "            The content of the tooltip is set via the <code>tooltip</code> attribute.\n" +
    "        </p>\n" +
    "        <p>\n" +
    "            Basic positioning of tooltips is achieved via the <code>tooltip-placement</code>\n" +
    "            attribute, which can be 1 of 4 values: left, right, top or bottom.\n" +
    "        </p>\n" +
    "        <p>\n" +
    "            <strong>N.B. Please always use</strong> <code>tooltip-append-to-body=\"true\"</code>.\n" +
    "            You cannot guarantee your tooltip is wrapped in a close enough\n" +
    "            parent that is relatively positioned, for the inline tooltip to\n" +
    "            have the correctly calculated <code>top</code> value.\n" +
    "        </p>\n" +
    "        <p>\n" +
    "            This is a naive default by Angular Foundation, which Foundation itself doesn't do.\n" +
    "        </p>\n" +
    "    </div>\n" +
    "\n" +
    "</section>\n" +
    "\n" +
    "<section class=\"labExample\">\n" +
    "\n" +
    "    <div class=\"labExample-demo\">\n" +
    "\n" +
    "        <h3>Advanced Tooltips</h3>\n" +
    "\n" +
    "        <div class=\"labBlockRow\">\n" +
    "\n" +
    "            <div class=\"labCol\">\n" +
    "                <div class=\"labBlock\">\n" +
    "                    <div class=\"labBlock-preview\">\n" +
    "                        <a href=\"#\" class=\"has-tip\" tooltip-append-to-body=\"true\" tooltip-animation=\"false\" tooltip=\"I don't fade. :-(\">Not animated</a>\n" +
    "                    </div>\n" +
    "                    <pre class=\"labBlock-example u-bgGreysLightest\">tooltip-animation=\"false\"</pre>\n" +
    "                </div>\n" +
    "            </div>\n" +
    "\n" +
    "            <div class=\"labCol\">\n" +
    "                <div class=\"labBlock\">\n" +
    "                    <div class=\"labBlock-preview\">\n" +
    "                        <a href=\"#\" class=\"has-tip\" tooltip-append-to-body=\"true\" tooltip-popup-delay=\"1000\" tooltip=\"appears with delay\">Delayed</a>\n" +
    "                    </div>\n" +
    "                    <pre class=\"labBlock-example u-bgGreysLightest\">tooltip-popup-delay=\"1000\"</pre>\n" +
    "                </div>\n" +
    "            </div>\n" +
    "\n" +
    "            <div class=\"labCol\">\n" +
    "                <div class=\"labBlock\">\n" +
    "                    <div class=\"labBlock-preview\">\n" +
    "                        <a href=\"#\" class=\"has-tip\" tooltip-append-to-body=\"true\" tooltip-html-unsafe=\"I've been made <b>bold</b>!\">HTML contents</a>\n" +
    "                    </div>\n" +
    "                    <pre class=\"labBlock-example u-bgGreysLightest\">tooltip-html-unsafe=\"I've been made &lt;b&gt;bold&lt;/b&gt;!\"</pre>\n" +
    "                </div>\n" +
    "            </div>\n" +
    "\n" +
    "        </div>\n" +
    "\n" +
    "        <hr>\n" +
    "\n" +
    "    </div>\n" +
    "\n" +
    "    <div class=\"labExample-code\">\n" +
    "\n" +
    "<textarea ui-codemirror=\"{\n" +
    "'lineNumbers': true,\n" +
    "'theme':'default',\n" +
    "'readOnly': 'true',\n" +
    "'lineWrapping' : false,\n" +
    "'mode': 'text/html',\n" +
    "autoClearEmptyLines: true\n" +
    "}\">\n" +
    "<a href=\"#\" class=\"has-tip\" tooltip-append-to-body=\"true\" tooltip-animation=\"false\" tooltip=\"I don't fade. :-(\">Not animated</a>\n" +
    "\n" +
    "<a href=\"#\" class=\"has-tip\" tooltip-append-to-body=\"true\" tooltip-popup-delay=\"1000\" tooltip=\"appears with delay\">Delayed</a>\n" +
    "\n" +
    "<a href=\"#\" class=\"has-tip\" tooltip-append-to-body=\"true\" tooltip-html-unsafe=\"I've been made <b>bold</b>!\">HTML contents</a></textarea>\n" +
    "\n" +
    "    </div>\n" +
    "\n" +
    "    <div class=\"labExample-notes\">\n" +
    "        <h5>Notes:</h5>\n" +
    "        <p>\n" +
    "            Provided are 2 extra display options that can remove animations via\n" +
    "            <code>tooltip-animation</code> and delay the display of a particular\n" +
    "            tooltip via <code>tooltip-popup-deplay</code>\n" +
    "        </p>\n" +
    "        <p>\n" +
    "            An alternative for the <code>tooltip</code> attribute is the\n" +
    "            <code>tooltip-html-unsafe</code>, where you can pass unsanitised\n" +
    "            HTML strings to be displayed as the tooltip content.\n" +
    "        </p>\n" +
    "        <p>\n" +
    "            <strong>N.B. Animation helpers have yet to make it to Pattern-Lab.</strong>\n" +
    "        </p>\n" +
    "    </div>\n" +
    "\n" +
    "</section>\n" +
    "\n" +
    "<section class=\"labExample\">\n" +
    "\n" +
    "    <div class=\"labExample-demo\">\n" +
    "\n" +
    "        <h3>Tooltips Triggers</h3>\n" +
    "\n" +
    "        <div class=\"labBlockRow\">\n" +
    "\n" +
    "            <div class=\"labCol\">\n" +
    "                <div class=\"labBlock is-light\">\n" +
    "                    <div class=\"labBlock-preview\">\n" +
    "                        <label class=\"form-label\" for=\"tooltip1\">Focus Trigger</label>\n" +
    "                        <input type=\"text\" tooltip=\"See? Now click away...\" tooltip-append-to-body=\"true\" tooltip-trigger=\"focus\" tooltip-placement=\"right\" placeholder=\"Focus in me&hellip;\" class=\"form-input\" id=\"tooltip1\" />\n" +
    "                    </div>\n" +
    "                    <pre class=\"labBlock-example u-bgGreysLightest\">tooltip-trigger=\"focus\"</pre>\n" +
    "                </div>\n" +
    "            </div>\n" +
    "\n" +
    "            <div class=\"labCol\">\n" +
    "                <div class=\"labBlock is-light\">\n" +
    "                    <div class=\"labBlock-preview\">\n" +
    "                        <label class=\"form-label\" for=\"tooltip2\">Mouse Trigger</label>\n" +
    "                        <input type=\"text\" tooltip=\"Now move your mouse away...\" tooltip-append-to-body=\"true\" tooltip-trigger=\"mouseenter\" tooltip-placement=\"top\" placeholder=\"Hover over me&hellip;\" class=\"form-input\" id=\"tooltip2\" />\n" +
    "                    </div>\n" +
    "                    <pre class=\"labBlock-example u-bgGreysLightest\">tooltip-trigger=\"mouseenter\"</pre>\n" +
    "                </div>\n" +
    "            </div>\n" +
    "\n" +
    "            <div class=\"labCol\">\n" +
    "                <div class=\"labBlock is-light\">\n" +
    "                    <div class=\"labBlock-preview\">\n" +
    "                        <label class=\"form-label\" for=\"tooltip3\">Click Trigger <small class=\"has-tip\" tooltip-append-to-body=\"true\" tooltip=\"Click again to dismiss...\" tooltip-trigger=\"click\" tooltip-placement=\"right\" >What is this?</small></label>\n" +
    "                        <input type=\"text\" class=\"form-input\" id=\"tooltip3\" />\n" +
    "                    </div>\n" +
    "                    <pre class=\"labBlock-example u-bgGreysLightest\">tooltip-trigger=\"click\"</pre>\n" +
    "                </div>\n" +
    "            </div>\n" +
    "\n" +
    "        </div>\n" +
    "\n" +
    "        <hr>\n" +
    "\n" +
    "    </div>\n" +
    "\n" +
    "    <div class=\"labExample-code\">\n" +
    "\n" +
    "<textarea ui-codemirror=\"{\n" +
    "'lineNumbers': true,\n" +
    "'theme':'default',\n" +
    "'readOnly': 'true',\n" +
    "'lineWrapping' : false,\n" +
    "'mode': 'text/html',\n" +
    "autoClearEmptyLines: true\n" +
    "}\">\n" +
    "<input\n" +
    "    tooltip-trigger=\"focus\"\n" +
    "    tooltip=\"See? Now click away...\"\n" +
    "    tooltip-append-to-body=\"true\"\n" +
    "    tooltip-placement=\"right\"\n" +
    "    type=\"text\"\n" +
    "    placeholder=\"Focus in me&hellip;\"\n" +
    "    class=\"form-input\" /></textarea>\n" +
    "\n" +
    "    </div>\n" +
    "\n" +
    "    <div class=\"labExample-notes\">\n" +
    "        <h5>Notes:</h5>\n" +
    "        <p>\n" +
    "            By default tooltips are triggered by the <code>mouseenter</code> event,\n" +
    "            but there maybe times when you require additional control.\n" +
    "        </p>\n" +
    "        <p>\n" +
    "            By using the <code>tooltip-trigger</code> attribute, you can opt to display\n" +
    "            a tooltip via <code>focus</code>, <code>click</code> or <code>mouseenter</code> events manually, depending on your need.\n" +
    "        </p>\n" +
    "    </div>\n" +
    "\n" +
    "</section>\n" +
    "");
}]);
})();
