import 'angular';
import 'angular-mocks';
import 'angular-gettext';
import 'angular-sanitize';
import 'lodash';
import 'ng-common';
import 'src/app/templates.js';

beforeEach(angular.mock.module('ng-common'));
beforeEach(angular.mock.module('ng-stencil-editor.templates'));
