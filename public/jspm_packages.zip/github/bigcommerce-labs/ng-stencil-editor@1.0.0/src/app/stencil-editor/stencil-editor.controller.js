import _ from 'lodash';
import ConfirmResetModal from 'src/app/modals/confirm-reset-modal/confirm-reset-modal.controller.js';
import ApplyThemeNotAvailableModal from 'src/app/modals/apply-theme-not-available-modal/apply-theme-not-available-modal.controller.js';

export default class StencilEditorCtrl {
    /*@ngInject*/
    constructor($scope, $modal, schemaResolve, stencilConfig, BC_APP_CONFIG) {
        this._$modal = $modal;
        this._BC_APP_CONFIG = BC_APP_CONFIG;
        this._stencilConfig = stencilConfig;
        this._fields = [];

        this.editorForm = null;
        this.schema = schemaResolve;

        this.init();
        this.initFields();

        $scope.$on('variationChanged', () => {
            this.init();
            this.initFields();
        });
    }

    init() {
        this.config = this._stencilConfig.getConfig();
        this.variation = this._stencilConfig.getActiveVariation();
        this.variations = this._stencilConfig.getVariations();

        // ensure our form is in its pristine state
        if (this.editorForm) {
            this.editorForm.$setPristine();
            this.editorForm.$setUntouched();

            _.each(this._fields, (field) => {
                if (field.templateOptions) {
                    field.templateOptions.updated = false;
                }
            });
        }
    }

    initFields() {
        this._fields.length = 0;

        // hydrate the schema with the config data
        _.each(this.schema, (fieldset) => {
            _.each(fieldset.settings, (field) => {
                const key = field.key;
                let value;

                if (_.isUndefined(key)) {
                    return;
                }

                value = this.config.settings[key];

                if (_.isUndefined(value)) {
                    return;
                }

                // TODO: yar, here be performance problems
                field.watcher = { listener: (field, newValue, oldValue) => {
                    const updated = newValue !== oldValue && field.formControl.$dirty;

                    if (updated) {
                        this._stencilConfig.save(this.config);
                    }

                    field.templateOptions.updated = updated;
                }};
                field.defaultValue = _.toString(value);

                this._fields.push(field);
            });
        });
    }

    reset() {
        this._$modal
            .open({
                controller: ConfirmResetModal,
                controllerAs: 'confirmResetModalCtrl',
                templateUrl: 'app/modals/confirm-reset-modal/confirm-reset-modal.tpl.html',
                windowClass: 'modal'
            })
            .result.then(() => {
                this._stencilConfig.reset();
                this._stencilConfig.save(this.config);

                this.init();
            });
    }

    submit() {
        this._stencilConfig.commit(this.config).then(() => {
            this.init();
        });
    }

    apply() {
        if (this._BC_APP_CONFIG.isProduction) {
            this._stencilConfig.publish(this.config).then(() => {
                this.init();
            });
        } else {
            this._$modal
                .open({
                    controller: ApplyThemeNotAvailableModal,
                    controllerAs: 'applyThemeNotAvailableModalCtrl',
                    templateUrl: 'app/modals/apply-theme-not-available-modal/apply-theme-not-available-modal.tpl.html',
                    windowClass: 'modal'
                });
        }
    }
}
