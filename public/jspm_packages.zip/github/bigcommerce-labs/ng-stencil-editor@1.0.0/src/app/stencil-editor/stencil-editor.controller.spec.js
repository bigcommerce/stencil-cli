import 'angular';
import 'angular-mocks';

import StencilEditorController from './stencil-editor.controller.js';

describe('StencilEditorCtrl: ', () =>  {
    let $controller,
        $rootScope,
        $scope,
        controller,
        stencilConfig = jasmine.createSpyObj('stencilConfig', [
            'commit',
            'getConfig',
            'getActiveVariation',
            'getVariations',
            'publish',
            'reset',
            'save'
        ]),
        $modal = jasmine.createSpyObj('$modal', [
            'open'
        ]);

    function createController($scope, isProduction) {
        return $controller(StencilEditorController, {
            $scope: $scope,
            $modal: $modal,
            schemaResolve: {},
            stencilConfig: stencilConfig,
            BC_APP_CONFIG: {isProduction: !!isProduction}
        });
    }

    beforeEach(inject(($injector) => {
        $rootScope = $injector.get('$rootScope');
        $scope = $rootScope.$new();
        $controller = $injector.get('$controller');
    }));

    describe('reset() method', () => {

        beforeEach(() => {
            $modal.open.and.returnValue({
                result: {
                    then: (cb) => { cb(); }
                }
            });
        });

        it('should call stencilConfig.reset(), init(), and then stencilConfig.save()', () => {
            controller = createController($scope);
            spyOn(controller, 'init');

            controller.reset();

            expect($modal.open).toHaveBeenCalled();

            expect(stencilConfig.reset).toHaveBeenCalled();
            expect(stencilConfig.save).toHaveBeenCalledWith(controller.config);
            expect(controller.init).toHaveBeenCalled();
        });
    });

    describe('submit() method', () => {
        beforeEach(() => {
            stencilConfig.commit.and.returnValue({
                then: (cb) => { cb(); }
            });
        });

        it('should call stencilConfig.commit', () => {
            controller = createController($scope);

            controller.submit();

            expect(stencilConfig.commit).toHaveBeenCalled();
        });

        it('should call init when stencilConfig.commit resolves', () => {
            controller = createController($scope);
            spyOn(controller, 'init');

            controller.submit();

            expect(controller.init).toHaveBeenCalled();
        });
    });

    describe('apply() method', () => {

        describe('in development', () => {
            beforeEach(() => {
                $modal.open.and.returnValue({
                    result: {
                        then: (cb) => { cb(); }
                    }
                });
            });

            it('should open a modal', () => {
                controller = createController($scope);
                spyOn(controller, 'init');

                controller.reset();

                expect($modal.open).toHaveBeenCalled();
            });
        });

        describe('in production', () => {
            beforeEach(() => {
                stencilConfig.publish.and.returnValue({
                    then: (cb) => { cb(); }
                });
            });

            it('should call stencilConfig.publish', () => {
                controller = createController($scope, true);

                controller.apply();

                expect(stencilConfig.publish).toHaveBeenCalled();
            });

            it('should call init when stencilConfig.publish resolves', () => {
                controller = createController($scope, true);
                spyOn(controller, 'init');

                controller.apply();

                expect(controller.init).toHaveBeenCalled();
            });
        });
    });
});
