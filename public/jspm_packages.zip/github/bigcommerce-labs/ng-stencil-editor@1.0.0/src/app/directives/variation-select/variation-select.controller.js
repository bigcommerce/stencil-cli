import LostChangesModalCtrl from 'src/app/modals/lost-changes-modal/lost-changes-modal.controller.js';

export default class {
    /*@ngInject*/
    constructor ($modal, stencilConfig) {
        this._$modal = $modal;
        this._stencilConfig = stencilConfig;
    }

    getCurrentVariantionId() {
        return this.variation.id;
    }

    isCurrentVariation (variationId) {
        return this.getCurrentVariantionId() === variationId;
    }

    confirm($event, variationName) {
        $event.preventDefault();

        if (this.form.$dirty) {
            this.warn(variationName);
        } else {
            this._stencilConfig.setVariationName(variationName);
        }
    }

    warn(variationName) {
        this._$modal
            .open({
                controller: LostChangesModalCtrl,
                controllerAs: 'lostChangesModalCtrl',
                templateUrl: 'app/modals/lost-changes-modal/lost-changes-modal.tpl.html',
                windowClass: 'modal'
            })
            .result.then(() => {
                this._stencilConfig.setVariationName(variationName);
            });
    }
}
