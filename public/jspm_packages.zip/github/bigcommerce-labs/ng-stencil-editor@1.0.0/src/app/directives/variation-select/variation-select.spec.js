import 'angular';
import 'angular-mocks';

import VariationSelectCtrl from 'src/app/directives/variation-select/variation-select.controller.js';

describe('Variation select directive: ', () => {
    const stencilConfig = jasmine.createSpyObj('stencilConfig', [
            'setVariationName',
        ]);
    const fakeModalInstance = {
        result: {
            then(confirmCallback, cancelCallback) {
                this.confirmCallBack = confirmCallback;
                this.cancelCallback = cancelCallback;
            }
        },
        close( item ) {
            this.result.confirmCallBack( item );
        },
        dismiss( type ) {
            this.result.cancelCallback( type );
        }
    };
    const mockEvent = jasmine.createSpyObj('$event', [
        'preventDefault',
    ]);

    let $modal = {
        open: () => {
            return fakeModalInstance;
        }
    };
    let $controller;
    let $rootScope;
    let $scope;
    let controller;

    function createController($scope) {
        return $controller(VariationSelectCtrl, {
            $scope: $scope,
            $modal: $modal,
            stencilConfig: stencilConfig
        });
    }

    beforeEach(() => {
        angular.mock.module(function($provide) {
            $provide.value('stencilConfig', stencilConfig);
        });
    });

    beforeEach(inject(($injector) => {
        $rootScope = $injector.get('$rootScope');
        $scope = $rootScope.$new();
        $controller = $injector.get('$controller');
    }));

    describe('getCurrentVariantionId() method', () => {
        it('should return an id', () => {
            controller = createController($scope);
            controller.variation = {
                id: 1
            };
            expect(controller.getCurrentVariantionId()).toEqual(1);
        });
    });

    describe('isCurrentVariation() method', () => {
        it('should return true when variation id matches the current variation id', () => {
            controller = createController($scope);
            controller.variation = {
                id: 1
            };
            expect(controller.isCurrentVariation(1)).toEqual(true);
        });

        it('should return false when variation id does not match the current variation id', () => {
            controller = createController($scope);
            controller.variation = {
                id: 2
            };
            expect(controller.isCurrentVariation(1)).toEqual(false);
        });
    });

    describe('confirm() method', () => {
        it('should set a new variation name with a clean form', () => {
            controller = createController($scope);
            controller.form = {
                $dirty: false
            };
            controller.confirm(mockEvent, 'Warm');
            expect(mockEvent.preventDefault).toHaveBeenCalled();
            expect(controller._stencilConfig.setVariationName).toHaveBeenCalledWith('Warm');
        });

        it('should warn the user before switching the variation with a dirty form', () => {
            controller = createController($scope);
            controller.form = {
                $dirty: true
            };
            spyOn(controller, 'warn');
            controller.confirm(mockEvent, 'Warm');
            expect(mockEvent.preventDefault).toHaveBeenCalled();
            expect(controller.warn).toHaveBeenCalledWith('Warm');
        });
    });

    describe('warn() method', () => {
        beforeEach(() => {
            spyOn($modal, 'open').and.returnValue(fakeModalInstance);
            controller = createController($scope);
            controller.form = {
                $dirty: true
            };
            controller.confirm(mockEvent, 'Warm');
        });

        it('should open a modal to warn the user of unsaved changes', () => {
            expect(controller._$modal.open).toHaveBeenCalled();
        });

        it('should set a new variation name when the modal is closed', () => {
            controller._$modal.open().close();
            expect(controller._stencilConfig.setVariationName).toHaveBeenCalledWith('Warm');
        });

    });

});
