export default class {
    /*@ngInject*/
    constructor ($q, $rootScope) {
        this._$q = $q;

        $rootScope.$on('themeRelay', (event, data) => {
            this.chan.call({
                method: data.method,
                params: JSON.stringify(data.params || {}),
                success: angular.noop
            });
        });
    }
}
