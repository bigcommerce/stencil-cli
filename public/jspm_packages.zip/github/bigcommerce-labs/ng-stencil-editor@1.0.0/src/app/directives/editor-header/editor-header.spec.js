import 'angular';
import 'angular-mocks';
import './editor-header.module.js';

describe('Stencil Editor Left Panel Header', () => {
    let $compile;
    let $scope;
    let compiledElement;

    const themeName = 'Stencil';
    const themeVersion = '1.2.3';
    const $modal = {};
    const stencilConfig = {
        getConfig: () => {
            return {
                name: themeName,
                version: themeVersion
            };
        }
    };

    beforeEach(() => {
        angular.mock.module('ng-stencil-editor.directives.editor-header');

        angular.mock.module(function($provide) {
            $provide.value('$modal', $modal);
            $provide.value('stencilConfig', stencilConfig);
        });
    });

    beforeEach(inject($injector => {
        $compile = $injector.get('$compile');
        $scope = $injector.get('$rootScope').$new();
    }));

    function compileDirective(scope, tpl) {
        const element = angular.element(tpl || '<editor-header></editor-header>');

        compiledElement = $compile(element)(scope);

        scope.$digest();
    }

    describe('Editor Header', () => {
        beforeEach(() => {
            compileDirective($scope);
        });

        it('should display the theme name', () => {
            expect(compiledElement.find('h2').text()).toBe(themeName);
        });

        it('should display the theme version', () => {
            expect(compiledElement.find('small').text()).toBe(themeVersion);
        });
    });
});
