export default class AppCtrl {
    /*@ngInject*/
    constructor($window, gettextCatalog, stencilConfig) {
        this._gettextCatalog = gettextCatalog;
        this._stencilConfig = stencilConfig;

        $window.addEventListener('beforeunload', _.bind(this.confirmExit, this));
        $window.addEventListener('unload', _.bind(this.resetConfig, this));
    }

    confirmExit(event) {
        const confirmationMessage = this._gettextCatalog.getString('You will lose all unsaved changes.');

        // Cross-browser compatibility
        event.returnValue = confirmationMessage;

        return confirmationMessage;
    }

    resetConfig() {
        this._stencilConfig.reset();
        this._stencilConfig.saveNative();
    }
}
