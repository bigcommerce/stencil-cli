export default class StencilConfig {
    /*@ngInject*/
    constructor($http, $rootScope, $sce, API, BC_APP_CONFIG) {
        this._config = {};
        this._configSettingsBackup = {};
        this._refresh = false;
        this._$http = $http;
        this._$rootScope = $rootScope;
        this._$sce = $sce;
        this._API = API;
        this._BC_APP_CONFIG = BC_APP_CONFIG;
    }

    backupSettings(configSettings) {
        this._configSettingsBackup = _.cloneDeep(configSettings);
    }

    commit(config) {
        return this.save(config, { params: { commit: true }});
    }

    fetch() {
        return this._$http.get(this._API.BASE_PATH + this._API.CONFIG_PATH)
            .then(resp => this.setConfig(resp.data));
    }

    getConfig() {
        return this._config;
    }

    getActiveVariation() {
        return _.find(this._config.variations, {name: this._config.variationName});
    }

    getStoreUrl() {
        return this._$sce.trustAsResourceUrl(this._BC_APP_CONFIG.storeUrl);
    }

    getVariations() {
        return this._config.variations;
    }

    publish(config) {
        return this.save(config, { params: { commit: true, publish: true }});
    }

    requiresRefresh(refreshValue) {
        if (!_.isUndefined(refreshValue)) {
            this._refresh = refreshValue;
        }

        return this._refresh;
    }

    reset() {
        _.extend(this._config.settings, this._configSettingsBackup);

        return this._config;
    }

    save(config, options = {}) {
        options = _.defaults(options, {
            data: config.settings,
            method: 'post',
            url: this._API.BASE_PATH + this._API.CONFIG_PATH
        });

        return this._$http(options)
            .then((resp) => {
                const requiresRefresh = resp.data.forceReload;

                this.requiresRefresh(requiresRefresh);
                this._$rootScope.$broadcast('configSaved', resp.data);

                return resp;
            });
    }

    saveNative() {
        const request = new XMLHttpRequest();

        // Making a native AJAX request because $http was unreliable when called
        // from onunload event
        request.open('POST', this._API.BASE_PATH + this._API.CONFIG_PATH, true);
        request.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded; charset=UTF-8');
        request.send(this.getConfig());
    }

    setConfig(configToSet) {
        this._config = configToSet;
        this.backupSettings(this._config.settings);

        return this._config;
    }

    setVariationName(variationName) {
        const url = this._API.BASE_PATH + this._API.SET_VARIATION_NAME_PATH;

        return this._$http.post(url, {name: variationName}).then(() =>
            // Pull in and set the config for this particular variation.
            this.fetch().then(() => {
                // Let everyone know the variation changed.
                this._$rootScope.$broadcast('variationChanged', variationName);
            })
        );
    }
}
