import StencilConfigService from 'src/app/services/stencil-config.service.js';
import StencilSchemaService from 'src/app/services/stencil-schema.service.js';

export default angular.module('ng-stencil-editor.services', [])
    .service('stencilConfig', StencilConfigService)
    .service('stencilSchema', StencilSchemaService);
