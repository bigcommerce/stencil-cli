import 'angular';
import 'angular-mocks';

import StencilPreviewCtrl from './stencil-preview.controller.js';

describe('StencilPreviewCtrl: ', () =>  {
    let $controller;
    let $rootScope;
    let $scope;
    let controller;
    let channelService = jasmine.createSpyObj('channelService', [
        'createChannel',
        'emit',
    ]);
    let configService = {
        getConfig: angular.noop,
        requiresRefresh: angular.noop
    };

    function createController($scope) {
        return $controller(StencilPreviewCtrl, {
            $scope: $scope,
            configService: configService,
            channelService: channelService,
            previewControls: {}
        });
    }

    beforeEach(inject(($injector) => {
        $rootScope = $injector.get('$rootScope');
        $scope = $rootScope.$new();
        $controller = $injector.get('$controller');
    }));

    describe('refreshIframe() method', () => {
        it('should call emit "reload-page" event when triggered', () => {
            controller = createController($scope);

            controller.refreshIframe();

            expect(channelService.emit).toHaveBeenCalledWith('reload-page');
        });

        it('should call configService.requiresRefresh() with false when triggered', () => {
            spyOn(configService, 'requiresRefresh');

            controller = createController($scope);

            controller.refreshIframe();

            expect(configService.requiresRefresh).toHaveBeenCalledWith(false);
        });
    });
});
