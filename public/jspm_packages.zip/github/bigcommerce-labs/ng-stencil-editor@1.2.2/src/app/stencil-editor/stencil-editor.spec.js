import 'angular';
import 'angular-mocks';
import 'angular-formly';
import './stencil-editor.module.js';
import mockSchema from 'tests/mocks/schema.mock.js';
import SchemaService from 'src/app/services/version.service.js';

describe('Stencil Editor Left Panel', () => {
    let $compile;
    let $scope;
    let compiledElement;
    let versionService;
    let settings;

    beforeEach(() => {
        angular.mock.module('formly');
        angular.mock.module('ng-stencil-editor.stencil-editor');
    });

    beforeEach(inject($injector => {
        $compile = $injector.get('$compile');
        $scope = $injector.get('$rootScope').$new();
        versionService = new SchemaService();

        $scope.schema = versionService.mapFieldsets(mockSchema);
    }));

    function compileDirective(scope, tpl) {
        const element = angular.element(tpl || `
            <form name="testyForm">
                <div heading="{{ fieldset.name }}" ng-repeat="fieldset in schema">
                    <fieldset class="form-fieldset">
                        <formly-form fields="fieldset.settings"
                                     form="testyForm"
                                     model="testModel">
                        </formly-form>
                    </fieldset>
                </div>
            </form>`
        );

        compiledElement = $compile(element)(scope);

        scope.$digest();
    }

    // Testing we send everything correctly to Formly
    describe('Form', () => {
        function getTextArray(tag) {
            return _.compact(_.map(compiledElement.find(tag), element => {
                return angular.element(element).text().trim();
            }));
        }

        function getIdsFromSchema(type) {
            return _.pluck(_.where(_.first($scope.schema).settings, { type: type }), 'id');
        }

        function getAllSettings() {
            return _.flatten(_.pluck(mockSchema, 'settings'));
        }

        function filterTagByAttr(tag, attr, value) {
            const elements = compiledElement.find(tag);

            return _.filter(elements, elem => angular.element(elem).attr(attr) === value);
        }

        beforeEach(() => {
            settings = getAllSettings();

            compileDirective($scope);
        });

        it('should contain all the settings headings specified in the schema', () => {
            const headings = getTextArray('h5');
            const expectedHeadings = _.pluck(_.where(settings, { type: 'heading' }), 'content');

            expect(headings).toEqual(expectedHeadings);
        });

        it('should contain all the labels specified in the schema', () => {
            const labels = getTextArray('label');
            const expectedLabels = _.compact(_.pluck(settings, 'label'));

            _.each(expectedLabels, label => {
                expect(_.contains(labels, label)).toBe(true);
            });
        });

        it('should contain the checkboxes specified in the schema', () => {
            const checkboxesIds = getIdsFromSchema('checkbox');
            const checkboxes = filterTagByAttr('input', 'type', 'checkbox');

            _.each(checkboxes, checkbox => {
                expect(_.contains(checkboxesIds, angular.element(checkbox).attr('id'))).toBe(true);
            });
        });

        it('should contain the radio buttons specified in the schema', () => {
            const radioIds = getIdsFromSchema('radio');
            const radios = filterTagByAttr('radio', 'type', 'radio');

            _.each(radios, radio => {
                expect(_.contains(radioIds, angular.element(radio).attr('name'))).toBe(true);
            });
        });
    });
});
