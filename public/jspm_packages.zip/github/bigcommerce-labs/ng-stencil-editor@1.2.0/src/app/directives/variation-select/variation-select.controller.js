import LostChangesModalCtrl from 'src/app/modals/lost-changes-modal/lost-changes-modal.controller.js';

export default class VariationSelectCtrl {
    /*@ngInject*/
    constructor($modal, $q, channelService, variationService) {
        this._$modal = $modal;
        this._$q = $q;
        this._channelService = channelService;
        this.activeVariation = variationService.activeVariation.bind(variationService);
        this.currentVariation = variationService.currentVariation.bind(variationService);
        this.getVariations = variationService.getVariations.bind(variationService);
        this.variationChange = this.variationChange || _.noop;
    }

    isActiveVariation(variation) {
        return this.activeVariation().id === variation.id;
    }

    isCurrentVariation(variation) {
        return this.currentVariation().id === variation.id;
    }

    confirm($event, variation) {
        return this
            .warn($event, variation)
            .then(() => this.emitSetCookie(variation))
            .then(() => this.activeVariation(variation))
            .then(() => this.variationChange(variation));
    }

    emitSetCookie(variation) {
        return this._channelService.emit('set-cookie', {
            data: { configurationId: variation.configurationId }
        });
    }

    warn($event, variation) {
        if (this.editorForm.$dirty) {
            $event.preventDefault();

            return this._$modal
                .open({
                    controller: LostChangesModalCtrl,
                    controllerAs: 'lostChangesModalCtrl',
                    resolve: { variation: () => variation },
                    templateUrl: 'app/modals/lost-changes-modal/lost-changes-modal.tpl.html',
                    windowClass: 'modal'
                })
                .result;
        } else {
            return this._$q.when(variation);
        }
    }
}
