describe('ajaxInterceptorService', function() {

    var ajaxInterceptor,
        rootScope;

    beforeEach(module('ng-common.ajax-request-status.service'));

    beforeEach(inject(function ($injector, $rootScope) {
        ajaxInterceptor = $injector.get('ajaxRequestStatus');
        rootScope = $rootScope;

        spyOn(rootScope, '$emit').andCallThrough();
    }));

    describe('ajaxRequest method', function() {
        it('should emit ajaxRequestRunning and true', function() {
            ajaxInterceptor.request();
            expect(rootScope.$emit).toHaveBeenCalledWith('ajaxRequestRunning', true);
        });

        it('should return the config', function() {
            var config = ajaxInterceptor.request('test');
            expect(config).toBe('test');
        });
    });

    describe('ajaxRequestError method', function() {
        it('should emit ajaxRequestRunning and false', function() {
            ajaxInterceptor.request();
            ajaxInterceptor.requestError();
            expect(rootScope.$emit).toHaveBeenCalledWith('ajaxRequestRunning', false);
        });

        it('should return a rejected promise', function() {
            ajaxInterceptor.requestError('error')
                .catch(function(err) {
                    expect(err).toEqual('error');
                });
            rootScope.$digest();
        });
    });

    describe('ajaxResponse method', function() {
        it('should emit ajaxRequestRunning and false', function() {
            ajaxInterceptor.request();
            ajaxInterceptor.response();
            expect(rootScope.$emit).toHaveBeenCalledWith('ajaxRequestRunning', false);
        });

        it('should return the response passed', function() {
            var response = ajaxInterceptor.response('response');
            expect(response).toEqual('response');
        });
    });

    describe('ajaxResponseError method', function() {
        it('should emit ajaxRequestRunning and false', function() {
            ajaxInterceptor.request();
            ajaxInterceptor.responseError();
            expect(rootScope.$emit).toHaveBeenCalledWith('ajaxRequestRunning', false);
        });

        it('should return a rejected promise', function() {
            ajaxInterceptor.responseError('error')
                .catch(function(err) {
                    expect(err).toEqual('error');
                });
            rootScope.$digest();
        });
    });
});
