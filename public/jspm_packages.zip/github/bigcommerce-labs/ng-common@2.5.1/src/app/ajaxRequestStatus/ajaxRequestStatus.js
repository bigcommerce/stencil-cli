angular.module('ng-common.ajax-request-status', [
    'ng-common.ajax-request-status.service'
]);
