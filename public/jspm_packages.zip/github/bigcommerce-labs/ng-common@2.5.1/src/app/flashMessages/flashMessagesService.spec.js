describe('flashMessagesService', function() {
    var $timeout,
        flashMessages;

    beforeEach(module('ng-common.flash-messages.service'));

    beforeEach(inject(function ($injector) {
        flashMessages = $injector.get('flashMessages');
        $timeout = $injector.get('$timeout');
    }));

    describe('addMessage method', function() {
        it('Should create a flash message containing the message', function () {
            flashMessages.addMessage({
                template: 'Testing... 123',
                type: 'success'
            });
            expect(flashMessages.messages[0].template).toBe('Testing... 123');
        });

        it('Should remove the flash message after the given amount of time', function () {
            flashMessages.addMessage({
                template: 'Testing... 123',
                type: 'success',
                time: 1
            });
            $timeout.flush(1);
            expect(flashMessages.messages[0]).toBeUndefined();
        });

        it('Should fetch the template if a templateUrl is passed', inject(function ($templateCache) {
            spyOn($templateCache, 'get').andReturn('<div></div>');
            flashMessages.addMessage({
                templateUrl: 'app/test.tpl.html',
                type: 'success',
                time: 1000
            });
            $timeout.flush(1000);
            expect($templateCache.get).toHaveBeenCalledWith('app/test.tpl.html');
        }));

        it('Should correctly interpolate the template with the passed context', inject(function($templateCache) {
            $templateCache.put('app/test.tpl.html', 'Sell more with {{ firstName }} {{ lastName }}!');
            flashMessages.addMessage({
                templateUrl: 'app/test.tpl.html',
                type: 'success',
                context: {
                    firstName: 'Big',
                    lastName: 'Commerce'
                }
            });
            expect(flashMessages.messages[0].template).toEqual('Sell more with Big Commerce!');
        }));

        it('Should not remove the message if persistent option is passed', function() {
            flashMessages.addMessage({
                template: 'Testing... 123',
                type: 'success',
                time: 10,
                persistent: true
            });
            $timeout.flush(10);
            expect(flashMessages.messages[0]).toBeDefined();
        });

        it('Should remove all current non-persistent messages if a new message arrives (exclusive = true by default)', function() {
            flashMessages.addMessage({
                template: 'Testing... 123',
                type: 'success',
                persistent: true
            });

            flashMessages.success('Testing... 123');
            expect(flashMessages.messages.length).toBe(2);

            flashMessages.success('Testing... 123');
            expect(flashMessages.messages.length).toBe(2);

            flashMessages.addMessage({
                template: 'Testing... 123',
                type: 'success',
                exclusive: false
            });

            expect(flashMessages.messages.length).toBe(3);
        });

        it('should make persistent messages higher priority (lower number) than normal messages', function() {
            var persistent,
                normal;

            flashMessages.addMessage({
                template: 'Persistent',
                type: 'success',
                persistent: true
            });

            flashMessages.success('Normal');

            persistent = _.find(flashMessages.messages, { template: 'Persistent' });
            normal = _.find(flashMessages.messages, { template: 'Normal' });

            expect(persistent.priority).toBeLessThan(normal.priority);
        });

        it('should order the messages array by priority when a new message is added', function() {
            flashMessages.addMessage({
                template: 'Second',
                type: 'success',
                persistent: true
            });

            flashMessages.addMessage({
                template: 'First',
                type: 'success',
                priority: 0
            });

            expect(flashMessages.messages[0].template).toBe('First');
            expect(flashMessages.messages[1].template).toBe('Second');
        });

        it('Should remove only messages with the same exclusive key', function() {
            flashMessages.success('Testing... 123');

            flashMessages.addMessage({
                template: 'Testing... 123',
                type: 'success',
                exclusive: 'test-key'
            });

            flashMessages.addMessage({
                template: 'Testing... 123',
                type: 'success',
                exclusive: 'test-key'
            });

            expect(flashMessages.messages.length).toBe(2);
        });
    });

    describe('convenience methods', function() {
        var template = 'Hello World',
            addMessageSpy;

        beforeEach(function() {
            addMessageSpy = spyOn(flashMessages, 'addMessage');
        });

        describe('success method', function() {
            it('Should call addMessage passing the SUCCESS message type', function() {
                flashMessages.success(template);

                expect(flashMessages.addMessage).toHaveBeenCalled();
                expect(addMessageSpy.mostRecentCall.args[0].template).toBe(template);
                expect(addMessageSpy.mostRecentCall.args[0].type).toBe('success');
            });

            it('Should take options as a second parameter', function() {
                flashMessages.success(template, {
                    time: 2
                });

                expect(flashMessages.addMessage).toHaveBeenCalled();
                expect(addMessageSpy.mostRecentCall.args[0].time).toBe(2);
            });

            it('Should optionally take options as the first parameter', function() {
                flashMessages.success({
                    template: template,
                    time: 2
                });

                expect(flashMessages.addMessage).toHaveBeenCalled();
                expect(addMessageSpy.mostRecentCall.args[0].template).toBe(template);
                expect(addMessageSpy.mostRecentCall.args[0].type).toBe('success');
                expect(addMessageSpy.mostRecentCall.args[0].time).toBe(2);
            });
        });

        describe('error method', function() {
            it('Should call addMessage passing the ERROR message type', function() {
                flashMessages.error(template);

                expect(flashMessages.addMessage).toHaveBeenCalled();
                expect(addMessageSpy.mostRecentCall.args[0].template).toBe(template);
                expect(addMessageSpy.mostRecentCall.args[0].type).toBe('error');
            });
        });

        describe('info method', function() {
            it('Should call addMessage passing the INFO message type', function() {
                flashMessages.info(template);

                expect(flashMessages.addMessage).toHaveBeenCalled();
                expect(addMessageSpy.mostRecentCall.args[0].template).toBe(template);
                expect(addMessageSpy.mostRecentCall.args[0].type).toBe('info');
            });
        });

    });
});
