describe('flash-messages', function() {
    beforeEach(function() {
        browser.get('/examples/flash-messages/index.html');
        protractor.getInstance().ignoreSynchronization = true;
    });

    it('should add a flash message when clicked', function() {
        element(by.css('.add-message')).click();

        expect(element.all(by.tagName('alert')).count()).toBe(1);
    });

    it('should add just one flash message when clicked twice (exclusive by default)', function() {
        element(by.css('.add-message')).click();
        element(by.css('.add-message')).click();

        expect(element.all(by.tagName('alert')).count()).toBe(1);
    });

    it('should remove the flash messages after the specified timeout', function() {
        element(by.model('appCtrl.time')).sendKeys('1');
        element(by.css('.add-message')).click();

        expect(element.all(by.tagName('alert')).count()).toBe(0);
    });
});
