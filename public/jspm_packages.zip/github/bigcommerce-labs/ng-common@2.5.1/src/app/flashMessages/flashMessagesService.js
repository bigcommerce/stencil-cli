angular.module('ng-common.flash-messages.service', [
    'ng-common.flash-messages.constants',
    'ng-common.lodash'
])
    .factory('flashMessages', function flashMessages(_, $interpolate, $rootScope, $templateCache, $timeout, MESSAGE_STATUSES, PRIORITY) {
        var defaultOptions = {
                exclusive: true,
                priority: PRIORITY.DEFAULT,
                time: 10 * 1000 // 10 seconds
            },
            service;

        service = {
            addMessage: addMessage,
            error: generateConvenienceFunction(MESSAGE_STATUSES.ERROR),
            getMessages: getMessages,
            info: generateConvenienceFunction(MESSAGE_STATUSES.INFO),
            messages: [],
            success: generateConvenienceFunction(MESSAGE_STATUSES.SUCCESS)
        };

        init();

        function init() {
            $rootScope.$on('$stateChangeSuccess', removeMessages);
        }

        /**
         * Method for adding success flash messages.
         * @param {string} type type of flash message that should be added
         * @return {function} convenience function that calls addMessage with
         *         the proper message type. Also handles dynamic parameters.
         */
        function generateConvenienceFunction(type) {
            return function convenienceFunction(template, options) {
                options = createOptionsObject(template, options);
                options.type = type;

                service.addMessage(options);
            };
        }

        function getMessages() {
            return service.messages;
        }

        /**
         * Private function that generates an options object from passed params
         * @param {(string|object)} template a string to use for the error message, or the options
         *        config object
         * @param {object=} options optional config object
         * @return {object} config object that includes the template property
         */
        function createOptionsObject(template, options) {
            options = options || {};
            if (typeof template === 'object') {
                options = template;
            } else if (typeof template === 'string') {
                options.template = template;
            }

            return options;
        }

        function removeMessageById(id) {
            _.remove(service.messages, {
                id: id
            });
        }

        function removeMessages() {
            service.messages.length = 0;
        }

        function removeNonPersistentMessages() {
            _.remove(service.messages, function removeNonPersistent(message) {
                return !message.persistent;
            });
        }

        function removeMessageByExclusiveKey(key) {
            _.remove(service.messages, {
                exclusive: key
            });
        }

        function registerFlashMessage(options) {
            var id = _.uniqueId('flash-message');

            if (_.isString(options.exclusive)) {
                removeMessageByExclusiveKey(options.exclusive);
            } else if (options.exclusive) {
                removeNonPersistentMessages();
            }

            service.messages.push(_.defaults(options, {
                id: id
            }));

            if (!options.persistent) {
                $timeout(function removeMessageTimeout() {
                    removeMessageById(id);
                }, options.time);
            }
        }

        function fetchTemplate(templateUrl) {
            return $templateCache.get(templateUrl);
        }

        function compileTemplate(template, context) {
            context = context || {};
            return $interpolate(template)(context);
        }

        function sortMessagesByPriority() {
            service.messages = _.sortBy(service.messages, 'priority');
        }

        /**
         * Add a flash message to display to the user
         * @param {object} options config object to create the flash message with.
         */
        function addMessage(options) {
            options = _.defaults(options, defaultOptions);

            // generic message has no type, type now an optional parameter
            options.type = MESSAGE_STATUSES[options.type.toUpperCase()]  || '';

            if (options.persistent) {
                options.priority = PRIORITY.PERSISTENT;
            }

            if (options.templateUrl) {
                options.template = fetchTemplate(options.templateUrl);
            }

            options.template = compileTemplate(options.template, options.context);

            registerFlashMessage(options);
            sortMessagesByPriority();
        }

        return service;
    });
