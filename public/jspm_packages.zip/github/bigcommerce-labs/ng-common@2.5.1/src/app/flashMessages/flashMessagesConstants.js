angular.module('ng-common.flash-messages.constants', [])
    .constant('MESSAGE_STATUSES', {
        CRITICAL: 'error',
        ERROR: 'error',
        INFO: 'info',
        LOW: 'info',
        MODERATE: 'error',
        PROMOTION: 'success',
        SUCCESS: 'success',
        WARNING: 'error'
    })
    .constant('PRIORITY', {
        PERSISTENT: 10,
        DEFAULT: 20
    });
