angular.module('ng-common.event-messages', [
    'ng-common.event-messages.provider'
]);
