angular.module('ng-common.event-messages.provider', [
    'ng-common.lodash'
])
    .provider('eventMessages', function eventMessagesProvider() {
        var provider = this;

        provider.namespace = '';
        provider.subscriptions = [];
        provider.targetOrigin = '*';

        provider.$get = $get;
        provider.setOtherWindow = setOtherWindow;
        provider.setTargetOrigin = setTargetOrigin;
        provider.setNamespace = setNamespace;
        provider.sendPostMessage = sendPostMessage;

        function getHash(length) {
            var possible = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789',
                text = '';

            if (typeof length === 'undefined') {
                length = 5;
            }

            for (var i = 0; i < length; i++) {
                text += possible.charAt(Math.floor(Math.random() * possible.length));
            }

            return text + '.' + (+new Date()).toString(36);
        }

        function setOtherWindow(window) {
            provider.otherWindow = window;
        }

        function setNamespace(ns) {
            provider.namespace = ns;
        }

        function setTargetOrigin(target) {
            provider.targetOrigin = target;
        }

        function sendPostMessage(message) {
            message = angular.toJson(message);
            message = provider.namespace + ':' + message;

            provider.otherWindow.postMessage(message, provider.targetOrigin);
        }

        // @ngInject
        function $get(_, $rootScope, $window, $q) {
            var service = {
                postMessage: postMessage,
                subscribe: subscribe,
                setOtherWindowById: setOtherWindowById
            };

            $window.addEventListener('message', function messageEventListener(event) {
                // We are only concerned about messages that are strings
                if (typeof event.data !== 'string') {
                    return;
                }

                if (event.data.substr(0, provider.namespace.length) === provider.namespace) {
                    var messageStart = provider.namespace.length + 1,
                        dataString = event.data.substr(messageStart),
                        data = angular.fromJson(dataString),
                        subsToNotify = _.where(provider.subscriptions, {name: data.name});

                    _.each(subsToNotify, function(sub) {
                        $rootScope.$apply(function() {
                            var replyToData = sub.callback(data.data);

                            if (typeof data.replyHash !== 'undefined') {
                                $q.when(replyToData).then(function(rData) {
                                    provider.sendPostMessage({
                                        name: data.replyHash,
                                        data: rData
                                    });
                                });
                            }

                            if (sub.burnAfterReading) {
                                provider.subscriptions = _.without(provider.subscriptions, sub);
                            }
                        });
                    });
                }
            });

            function postMessage(name, data, callback) {
                var message,
                    replyHash;

                if (typeof data === 'function') {
                    callback = data;
                    data = {};
                }

                message = {
                    name: name,
                    data: data
                };

                // Send and forget if no callback
                if (typeof callback !== 'undefined') {
                    replyHash = getHash(8);

                    message.replyHash = replyHash;
                    // Create a onetime subscription
                    provider.subscriptions.push({
                        name: replyHash,
                        callback: callback,
                        burnAfterReading: true
                    });
                }

                provider.sendPostMessage(message);
            }

            function subscribe(name, callback) {
                provider.subscriptions.push({
                    name: name,
                    callback: callback,
                    burnAfterReading: false
                });
            }

            function setOtherWindowById(windowId) {
                provider.otherWindow = angular.element('#' + windowId)[0].contentWindow;
            }

            return service;
        }
    });
