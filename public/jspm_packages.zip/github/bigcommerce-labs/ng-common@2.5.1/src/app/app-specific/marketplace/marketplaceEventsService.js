angular.module('ng-common.marketplace-events.service', [
    'ng-common.event-tracker',
    'ng-common.marketplace.constants'
])

    .factory('marketplaceEvents', function marketplaceEvents(eventTracker, BC_APP_CONFIG, EVENTS, VERSIONS) {
        var namespace = EVENTS.MARKETPLACE_NAMESPACE,
            defaults = {
                marketplaceVersion: VERSIONS.NEW_MARKETPLACE
            },
            service = {
                triggerAppInstall        : triggerAppInstall,
                triggerAppInstallStarted : triggerAppInstallStarted,
                triggerAppLaunch         : triggerAppLaunch,
                triggerAppSearch         : triggerAppSearch,
                triggerAppUninstall      : triggerAppUninstall,
                triggerViewAppScreenshot : triggerViewAppScreenshot
            };

        init();

        function init() {
            defaults.storeHash = getStoreHash();
            defaults.cpVersion = getCpVersion();
        }

        function getStoreHash() {
            return BC_APP_CONFIG.store_hash ? BC_APP_CONFIG.store_hash : BC_APP_CONFIG.storeInfo.information.id;
        }

        function getCpVersion() {
            return BC_APP_CONFIG.cp2_enabled ? VERSIONS.CP2 : VERSIONS.CP1;
        }

        function track(name, data) {
            _.defaults(data, defaults, { name: name });
            eventTracker.track(namespace + name, data);
        }

        function triggerAppLaunch(appId) {
            track(EVENTS.APP_LAUNCH, { appId: appId });
        }

        function triggerAppInstall(appId) {
            track(EVENTS.APP_INSTALL, { appId: appId });
        }

        function triggerAppInstallStarted(appId) {
            track(EVENTS.APP_INSTALL_STARTED, { appId: appId });
        }

        function triggerAppUninstall(appId) {
            track(EVENTS.APP_UNINSTALLED, { appId: appId });
        }

        function triggerAppSearch(query) {
            track(EVENTS.APP_SEARCH, { query: query });
        }

        function triggerViewAppScreenshot(data) {
            track(EVENTS.APP_SCREENSHOT_VIEW, {
                appId: data.appId,
                screenshotId: data.screenshotId
            });
        }

        return service;
    });
