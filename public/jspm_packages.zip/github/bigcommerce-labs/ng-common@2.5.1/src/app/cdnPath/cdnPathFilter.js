angular.module('ng-common.cdn-path.filter', ['ng-common.bc-app'])
    .filter('cdnPath', function cdnPathFilter(BC_APP_CONFIG) {
        return function(assetPath) {
            var cdnPath = BC_APP_CONFIG.cdnPath;

            return cdnPath + assetPath;
        };
    });
