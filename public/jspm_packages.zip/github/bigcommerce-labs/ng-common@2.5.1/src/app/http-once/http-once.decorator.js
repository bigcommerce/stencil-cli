/*
 * http-once decorator
 *
 * Adds support for the "once" property in $http config objects. This will automatically cancel
 * any previous $http request based on an arbitrary key. Example:
 *      $http.get('/example/url', { once: 'arbitrary' });
 *
 * This code utilizes the $http config "timeout" property. It is primarily useful for acting on
 * only the last of multiple rapid user inputs, but should work for any case where multiple
 * requests can be fired before the previous one has completed.
 */
angular.module('ng-common.http-once.decorator', ['ng-common.lodash'])
    .config(function httpOnceDecorator(_, $provide) {
        $provide.decorator('$http', function httpOnceDecorator($delegate, $injector) {
            var $http = $delegate,
                httpOnce = $injector.get('httpOnce'),
                methods = ['get', 'delete', 'head', 'jsonp'],
                methodsWithData = ['post', 'put', 'patch'];

            // Extend the base service to get its non-function properties
            angular.extend(httpOnceWrap, $http);

            // Some methods only have two arguments
            _.each(methods, function httpOnceEach(method) {
                httpOnceWrap[method] = function httpOnceMethodWrap(url, config) {
                    if (config && config.once) {
                        httpOnceCancel(config);
                    }

                    return $http[method].call($http, url, config);
                };
            });

            // Some methods have three arguments, including a data object
            _.each(methodsWithData, function httpOnceEach(method) {
                httpOnceWrap[method] = function httpOnceMethodWrap(url, data, config) {
                    if (config && config.once) {
                        httpOnceCancel(config);
                    }

                    return $http[method].call($http, url, data, config);
                };
            });

            function httpOnceCancel(config) {
                // Our key can be any string, from something arbitrary (a person model's name value)
                // to something complex (url + method + id + random number)
                var key = config.once;

                // Cancel existing request, if it exists
                if (httpOnce.check(key)) {
                    httpOnce.cancel(key);
                }

                // Create a new promise and store it for the next request
                config.timeout = httpOnce.create(key).promise;
            }

            function httpOnceWrap(config) {
                if (config.once) {
                    httpOnceCancel(config);
                }

                return $http.call($http, config);
            }

            return httpOnceWrap;
        });
    });
