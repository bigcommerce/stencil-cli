angular.module('ng-common.seed-data', [
    'ng-common.bc-app',
    'ng-common.seed-data.provider',
    'ng-common.seed-data.http-decorator'
])
    .config(function(seedDataProvider, $injector) {
        var BC_SEED_DATA;

        try {
            BC_SEED_DATA = $injector.get('BC_SEED_DATA');
        } catch (e) {
            // Failing silently since the missing BC_SEED_DATA constant will
            // not cause seed-data to fail
        }
        angular.forEach(BC_SEED_DATA || {}, function (data, key) {
            seedDataProvider.put(key, data);
        });
    });
