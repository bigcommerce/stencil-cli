describe('Decorator: http', function() {

    var $httpBackend, $http, $httpCache, getRequest;

    beforeEach(module('ng-common.seed-data.http-decorator'));

    beforeEach(module(function($provide) {
        var keys = ['sampleSeededData', 'sampleSeededDataWithParams'];
        $provide.value('seedData', {
            check: function(key) {
                var check = keys.indexOf(key);

                return check !== -1;
            },
            pluck: function(key) {
                _.pull(keys, key);

                return key;
            }
        });
    }));

    beforeEach(inject(function($injector) {
        $httpBackend = $injector.get('$httpBackend');
        $http = $injector.get('$http');
        $httpCache = $injector.get('$cacheFactory').get('$http');
        $httpBackend.when('GET', '/sample.json').respond([]);
        $httpBackend.when('GET', '/no-seeded-data.json').respond([]);
        $httpBackend.when('GET', '/with-params.json?a=foo&b=bar').respond([]);

        getRequest = function() {
            return $http.get('/sample.json', {seededDataKey: 'sampleSeededData'});
        };
    }));

    afterEach(function() {
        $httpBackend.verifyNoOutstandingRequest();
    });

    describe('monkey patched $http.get()', function() {
        it('should work as per normal if no seeded data', function() {
            $httpBackend.expect('GET', '/no-seeded-data.json');
            $http.get('/no-seeded-data.json');

            $httpBackend.flush();
        });

        it('should return seeded data and not go to the backend', function() {
            getRequest();

            expect(function() {
                $httpBackend.flush();
            }).toThrow();
        });

        it('should go to backend on subsequent requests of seeded data', function() {
            getRequest();

            $httpBackend.expect('GET', '/sample.json');
            getRequest();
            $httpBackend.flush();
        });

        it('should return promise with success and error methods', function() {
            var promise = getRequest();

            expect(promise.success).toBeDefined();
            expect(promise.error).toBeDefined();
        });

        it('should set the cache when data is seeded and caching is turned on', function() {
            var url = '/sample.json',
                urlWithParams = '/sample.json?a=foo&b=bar';

            expect($httpCache.get(url)).not.toBeDefined();
            expect($httpCache.get(urlWithParams)).not.toBeDefined();

            $http.get('/sample.json', {cache: true, seededDataKey: 'sampleSeededData'});
            $http.get('/sample.json', {params: {b: 'bar', a: 'foo'}, cache: true, seededDataKey: 'sampleSeededDataWithParams'});
            expect($httpCache.get(url)).toBeDefined();
            expect($httpCache.get(urlWithParams)).toBeDefined();
        });
    });
});
