angular.module('ng-common.event-tracker', [
    'ng-common.bc-app',
    'ng-common.event-tracker.provider',
    'ng-common.event-tracker.directive'
])
    .config(function(eventTrackerProvider, BC_APP_CONFIG) {
        eventTrackerProvider.setThirdPartyTrackerService(BC_APP_CONFIG.eventTrackerService);
    });
