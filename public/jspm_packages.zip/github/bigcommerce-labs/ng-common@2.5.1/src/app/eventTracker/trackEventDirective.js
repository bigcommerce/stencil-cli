angular.module('ng-common.event-tracker.directive', ['ng-common.event-tracker.provider'])
    .directive('trackEvent', function trackEventDirective($parse, $rootScope, eventTracker) {
        return {
            restrict: 'A',
            link: function trackEventLink(scope, elem, attr) {
                var name = attr.trackEvent,
                    properties = scope.$eval(attr.trackEventProperties),
                    options = scope.$eval(attr.trackEventOptions),
                    on = attr.trackEventOn || 'click';

                elem.bind(on, function trackEventClickHandler() {
                    eventTracker.track(name, properties, options, function trackEventCallback() {
                        scope.$eval(attr.trackEventCallback, {});
                    });
                });
            }
        };
    });
