angular.module('app', ['ng-common.seed-data'])
    .controller('AppCtrl', function($http) {
        var Ctrl = this;

        Ctrl.firstRequestItems = Ctrl.secondRequestItems = Ctrl.thirdRequestItems = [];

        // Using seeded data and since it's the first request, it will not go to the server
        $http.get('/examples/seed-data/sample.json', {seededDataKey: 'sampleSeededData'}).success(function(data) {
            Ctrl.firstRequestItems = data;
        });

        // Running a second request for the same file will cause an ajax request
        $http.get('/examples/seed-data/sample.json').success(function(data) {
            Ctrl.secondRequestItems = data;
        });

        // Running a third request, even if it has the same seededDataKey as before, will cause an ajax request
        $http.get('/examples/seed-data/sample.json', {seededDataKey: 'sampleSeededData'}).success(function(data) {
            Ctrl.thirdRequestItems = data;
        });
    });
