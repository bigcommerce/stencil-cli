angular.module('ng-common.bc-app', [])
    .constant('BC_APP_CONFIG', {});

angular.module('app', [
    'ng-common',
    'ngMockE2E'
])
    .config(function($httpProvider) {
        $httpProvider.interceptors.push('ajaxRequestStatus');
    })

    .run(function($httpBackend) {
        $httpBackend.whenGET('/testAjaxInterceptor').respond('Hello World');

        // Catch-all
        $httpBackend.whenGET(/.*/).passThrough();
        $httpBackend.whenPOST(/.*/).passThrough();
        $httpBackend.whenDELETE(/.*/).passThrough();
        $httpBackend.whenPUT(/.*/).passThrough();
    })

    .controller('AppCtrl', function($http, $rootScope) {
        var ctrl = this;

        ctrl.doingAjax = false;

        ctrl.makeAjax = function() {
            $http.get('/testAjaxInterceptor')
                .then(function(data) {
                    console.log(data);
                });
        };

        $rootScope.$on('ajaxRequestRunning', function(event, val) {
            ctrl.doingAjax = val;
        });
    });
