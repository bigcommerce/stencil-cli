// Build SASS assets
module.exports = {
    "options": {
        "bundleExec": true
    },
    "build": {
        "files": {
        }
    }
};
