module.exports = {
    options: {
        vendor_scripts: ['<%= karmaVendors %>'],
        swigVarControls: ['[[', ']]'],
        swigCache: false,
        port: '<%= serverPort %>',
        keep_alive: false
    },
    deploy: {
        options: {
            scripts: 'dist/js/<%= package.name %>.min.js',
            stylesheets: 'dist/css/<%= package.name %>.min.css'
        }
    },
    server: {
        options: {
            scripts: 'build/js/**/*.js',
            stylesheets: 'build/css/**/*.css'
        }
    }
};
