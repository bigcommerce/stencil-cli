module.exports = {
    "run_js_files": {
        "files": ["src/**/*.{js,tpl.html}"],
        "tasks": [
            "jshint:all", // Make sure the JS files are lint free
            "clean:build_js", // Remove any JS files in the build folder
            "copy:build_js",
            "html2js:build", // Build Templates
            "i18n-compile",
            "karma:watch:run",
            "clean:transclude",
            "copy:transclude"
        ]
    },
    "run_sass_files": {
        "files": ["src/sass/**/*.{scss,sass}"],
        "tasks": [
            "sass:build",
            "clean:transclude",
            "copy:transclude"
        ]
    },
    "run_static_files": {
        "files": ["src/static/**/*"],
        "tasks": [
            "build", // These don't change much, so just run the whole build process
            "clean:transclude",
            "copy:transclude"
        ]
    },
    "server_js_files": {
        "options": {
            "livereload": true,
            "livereloadOnError": false
        },
        "files": ["src/**/*.{js,tpl.html}"],
        "tasks": [
            "jshint:all", // Make sure the JS files are lint free
            "clean:build_js", // Remove any JS files in the build folder
            "copy:build_js",
            "html2js:build", // Build Templates
            "i18n-compile",
            "karma:watch:run"
        ]
    },
    "server_sass_files": {
        "options": {
            // Do not have Livereload watch these files as the
            // css_changes below will be used instead.
            "livereload": false
        },
        "files": ["src/sass/**/*.{scss,sass}"],
        "tasks": [
            "sass:build"
        ]
    },
    // We watch the final css file in the build folder so livereload properly
    // refreshes the CSS without refreshing the whole page.
    "server_css_changes": {
        "options": {
            "livereload": true,
            "livereloadOnError": false
        },
        "files": ["build/css/<%= package.name %>.css"],
        "tasks": []
    },
    "server_static_files": {
        "options": {
            "livereload": true
        },
        "files": ["src/static/**/*"],
        "tasks": [
            "build" // These don't change much, so just run the whole build process
        ]
    },
    // We the example files so livereload will trigger
    "server_example_files": {
        "options": {
            "livereload": true
        },
        "files": ["examples/**/*"],
        "tasks": []
    }
};
