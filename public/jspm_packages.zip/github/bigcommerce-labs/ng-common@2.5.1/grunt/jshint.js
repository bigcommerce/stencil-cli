module.exports = {
    options: {
        jshintrc: 'grunt/.jshintrc'
    },
    all: ['src/**/*.js']
};
