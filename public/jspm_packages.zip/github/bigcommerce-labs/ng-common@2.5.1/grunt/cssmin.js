module.exports = {
    "deploy": {
        "files": {
            "build/css/<%= package.name %>.min.css": "build/css/<%= package.name %>.css"
        }
    }
};
