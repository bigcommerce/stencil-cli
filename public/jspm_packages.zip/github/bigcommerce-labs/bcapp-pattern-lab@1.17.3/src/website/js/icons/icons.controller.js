/* */ 
angular.module('website.icons.controller', [])

    .controller('IconsCtrl', function($scope) {
        $scope.icons = window.icons;
    });
