/* */ 
angular.module('bcapp-pattern-lab.form-input-color.controller', [])

    .controller('FormInputColorCtrl', function($element) {
        const ctrl = this;
        const hexColorRegex = /^#(([0-9a-fA-F]{2}){3}|([0-9a-fA-F]){3})$/;

        let isVisible = false;

        ctrl.onChange = onChange;
        ctrl.hidePicker = hidePicker;
        ctrl.isPickerVisible = isPickerVisible;
        ctrl.setModelCtrl = setModelCtrl;
        ctrl.showPicker = showPicker;
        ctrl.uniqueId = getUniqueID('formInputColor-');

        function onChange() {
            if (hexColorRegex.test(ctrl.color)) {
                ctrl.lastValidColor = ctrl.color;
                ctrl.ngModelCtrl.$setViewValue(ctrl.color);
            }
        }

        function getUniqueID(idPrefix) {
            return _.uniqueId(idPrefix);
        }

        function isPickerVisible(isVisibleToSet) {
            if (isVisibleToSet !== undefined) {
                isVisible = isVisibleToSet;
            }

            return isVisible;
        }

        function hidePicker($event) {
            if ($element[0].contains($event.target)) {
                return;
            }

            ctrl.isPickerVisible(false);
        }

        function render() {
            ctrl.color = ctrl.ngModelCtrl.$viewValue;
            ctrl.lastValidColor = ctrl.color;
        }

        function setModelCtrl(ngModelCtrl) {
            ctrl.ngModelCtrl = ngModelCtrl;
            ctrl.ngModelCtrl.$render = render;
        }

        function showPicker($event) {
            $event.preventDefault();

            ctrl.isPickerVisible(true);
        }
    });
