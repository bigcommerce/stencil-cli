/* */ 
angular.module('bcapp-pattern-lab.bc-dropdown.directive', [
    'bcapp-pattern-lab.bc-dropdown.controller'
])
    .directive('bcDropdown', ($document) => {
        return {
            bindToController: true,
            controller: 'BcDropdownController',
            controllerAs: 'bcDropdownController',
            restrict: 'EA',
            compile: (tElement) => {
                tElement.attr('role', 'combobox');

                return ($scope, $element, attrs, ctrl) => {
                    // This directive is a composite of 2 separate Foundation directives
                    // which don't provide hooks to know when it's clicked or opened
                    // they do however deal with propagation of events so this, somewhat blind
                    // document event is safe. All it does is swap aria states at the moment
                    // in a cheap way to keep this directive in sync with it's child directive
                    $document.on('click', ctrl.closeDropdown);

                    $element.on('$destroy', () => {
                        $document.off('click', ctrl.closeDropdown);
                    });
                };
            }
        };
    });
