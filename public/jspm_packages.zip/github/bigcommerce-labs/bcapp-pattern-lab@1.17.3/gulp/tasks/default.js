/* */ 
"format global";
var gulp = require('gulp');

gulp.task('default', function() {
    console.log('Run "gulp run, gulp build or gulp deploy"');
});
