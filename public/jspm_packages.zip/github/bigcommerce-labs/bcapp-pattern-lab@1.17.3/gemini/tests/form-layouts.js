/* */ 
"format global";
var gemini = require('gemini'),
    viewport = require('../viewport');

gemini.suite('form layouts', function(suite) {
    suite.setUrl('/forms.html');

    gemini.suite('form row', function(suite) {
        suite
            .setCaptureElements('#labExampleFormRow')
            .capture('normal');
    });

    gemini.suite('form row xsmall', function(suite) {
        suite
            .before(viewport.xsmallViewport)
            .setCaptureElements('#labExampleFormRow')
            .capture('normal');
    });
});
