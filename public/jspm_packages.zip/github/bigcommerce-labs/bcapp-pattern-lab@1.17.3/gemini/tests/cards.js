/* */ 
"format global";
var gemini = require('gemini'),
    injectScripts = require('../injectScripts');

gemini.suite('cards', function(suite) {
    suite
        .setUrl('/cards.html')
        .before(function(actions) {
            actions
                .executeJS(injectScripts)
                .executeJS(function(window) {
                    window.stubImageSrc('.card-image');
                });
        });

    gemini.suite('card', function(suite) {
        suite
            .setCaptureElements('#labExampleCard .card')
            .capture('normal');
    });

    gemini.suite('card figcaption overlay', function(suite) {
        suite
            .setCaptureElements('#labExampleCardFigcaptionOverlay .card')
            .capture('hover', function(actions) {
                actions.mouseMove('#labExampleCardFigcaptionOverlay .card-figure', { x: 20, y: 20 });
            });
    });

    gemini.suite('card footer', function(suite) {
        suite
            .setCaptureElements('#labExampleCardFooter .card')
            .capture('normal');
    });
});
