import 'angular';
import 'angular-mocks';
import PreviewControlsCtrl from './preview-controls.controller.js';

describe('Preview Controls Controller', () => {
    let $controller,
        $rootScope,
        $scope,
        controller,
        previewControlsService = jasmine.createSpyObj('previewControlsService', [
            'canFlip',
            'getSize',
            'setSize',
            'flip',
            'isFlipped'
        ]);

    previewControlsService.canFlip.and.callFake(function() {
        return true;
    });

    previewControlsService.getSize.and.callFake(function() {
        return 'mobile';
    });

    previewControlsService.isFlipped.and.callFake(function() {
        return true;
    });

    const configService = {
        getConfig: () => {
            return {
                name: 'Stencil',
                version: '1.2.3'
            };
        }
    };

    function createController($scope) {
        return $controller(PreviewControlsCtrl, {
            $scope: $scope,
            configResolve: {},
            previewControls: previewControlsService,
            configService: configService
        });
    }

    beforeEach(inject(($injector) => {
        $rootScope = $injector.get('$rootScope');
        $scope = $rootScope.$new();
        $controller = $injector.get('$controller');
    }));

    describe('setSize() method', () => {

        beforeEach(() => {
            controller = createController($scope);
        });

        it('should set new size', () => {
            controller.setSize('mobile');
            expect(previewControlsService.setSize).toHaveBeenCalledWith('mobile');
        });

        it('should check if preview should flip', () => {
            controller.setSize('mobile');
            expect(previewControlsService.getSize).toHaveBeenCalled();
            expect(previewControlsService.canFlip).toHaveBeenCalledWith('mobile');
            expect(previewControlsService.flip).toHaveBeenCalled();
        });

    });

    describe('isFlipped() method', () => {
        beforeEach(() => {
            controller = createController($scope);
        });

        it('should check if it preview is flipped', () => {
            controller.isFlipped();
            expect(previewControlsService.isFlipped).toHaveBeenCalled();
        });
    });

    describe('getSize() method', () => {
        beforeEach(() => {
            controller = createController($scope);
        });

        it('should check if it preview is flipped', () => {
            controller.getSize();
            expect(previewControlsService.getSize).toHaveBeenCalled();
        });
    });

});
