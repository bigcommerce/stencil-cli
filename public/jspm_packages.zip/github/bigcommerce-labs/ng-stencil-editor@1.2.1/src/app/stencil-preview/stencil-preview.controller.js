export default class StencilPreviewCtrl {
    /*@ngInject*/
    constructor($sce, BC_APP_CONFIG, configService, channelService, previewControls) {
        this._$sce = $sce;
        this._BC_APP_CONFIG = BC_APP_CONFIG;
        this._channelService = channelService;
        this._configService = configService;
        this._iframeUrl = null;
        this._previewControls = previewControls;
    }

    getSize() {
        return this._previewControls.getSize();
    }

    getIframeUrl() {
        if (!this._iframeUrl) {
            this._iframeUrl = this._$sce.trustAsResourceUrl(
                this._BC_APP_CONFIG.config.ShopPath +
                '?stencilEditor=' + this._configService.getConfig().id
            );
        }

        return this._iframeUrl;
    }

    isFlipped() {
        return this._previewControls.isFlipped();
    }

    isLoading() {
        return this._configService.isLoading();
    }

    refreshIframe() {
        this._channelService.emit('reload-page');
        this._configService.requiresRefresh(false);
    }

    requiresRefresh() {
        return this._configService.requiresRefresh();
    }
}
