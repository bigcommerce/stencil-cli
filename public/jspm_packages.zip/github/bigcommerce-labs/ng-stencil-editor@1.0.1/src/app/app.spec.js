import 'angular';
import 'angular-mocks';

import AppCtrl from './app.controller.js';

describe('App Ctrl: ', () => {
    let stencilConfig = jasmine.createSpyObj('stencilConfig', [
            'getConfig',
            'getEditorToken',
            'reset',
            'hasChanges',
            'saveNative',
        ]),
        $cookies = jasmine.createSpyObj('$cookies', ['remove']),
        $controller,
        $rootScope,
        $scope,
        $window,
        controller;

    function createController($scope) {
        return $controller(AppCtrl, {
            $cookies: $cookies,
            $scope: $scope,
            $window: $window,
            stencilConfig: stencilConfig
        });
    }

    beforeEach(inject(($injector) => {
        $rootScope = $injector.get('$rootScope');
        $scope = $rootScope.$new();
        $controller = $injector.get('$controller');
        $window = $injector.get('$window');
    }));

    describe('constructor', () => {
        it('should setup the eventListeners', () => {
            spyOn($window, 'addEventListener');

            controller = createController($scope);

            expect($window.addEventListener).toHaveBeenCalledWith('beforeunload', jasmine.any(Function));
            expect($window.addEventListener).toHaveBeenCalledWith('unload', jasmine.any(Function));
            expect($window.addEventListener).toHaveBeenCalledWith('mouseover', jasmine.any(Function));
        });

        it('should setup the initial cookie', () => {
            const token = 'testToken';

            stencilConfig.getEditorToken.and.returnValue(token);
            controller = createController($scope);

            expect($cookies.stencil_editor_enabled).toBe(token);
        });
    });

    describe('confirmExit() method', () => {
        const event = {};

        it('should return a confirmation message', () => {
            controller = createController($scope);
            stencilConfig.hasChanges.and.returnValue(true);

            expect(controller.confirmExit(event)).toEqual(jasmine.any(String));
        });

        it('should set the event.returnValue for cross-browser support', () => {
            controller = createController($scope);

            const confirmationMessage = controller.confirmExit(event);

            expect(event.returnValue).toEqual(confirmationMessage);
        });
    });

    describe('resetConfig() method', () => {
        it('should call stencilConfig reset method', () => {
            controller = createController($scope);

            controller.resetConfig();

            expect(stencilConfig.reset).toHaveBeenCalled();
        });

        it('should call stencilConfig saveNative method', () => {
            controller = createController($scope);

            controller.resetConfig();

            expect(stencilConfig.saveNative).toHaveBeenCalled();
        });
    });
});
