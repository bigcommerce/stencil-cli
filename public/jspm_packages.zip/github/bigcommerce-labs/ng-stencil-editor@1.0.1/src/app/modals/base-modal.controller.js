export default class BaseModalCtrl {
    /*@ngInject*/
    constructor($modalInstance) {
        this._$modalInstance = $modalInstance;
    }

    ok($event) {
        $event.preventDefault();

        this._$modalInstance.close();
    }

    cancel($event) {
        $event.preventDefault();

        this._$modalInstance.dismiss();
    }
}
