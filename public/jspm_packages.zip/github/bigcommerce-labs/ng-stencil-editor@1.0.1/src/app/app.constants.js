export default angular.module('ng-stencil-editor.constants', [])
    .constant('API', {
        BASE_PATH: '/ng-stencil-editor',
        CONFIG_PATH: '/config',
        SCHEMA_PATH: '/schema',
        SET_VARIATION_NAME_PATH: '/config/variation-name',
        VARIATION_PATH: '/config/variation',
        VARIATION_NAME_PATH: '/config/variation-name'
    });
