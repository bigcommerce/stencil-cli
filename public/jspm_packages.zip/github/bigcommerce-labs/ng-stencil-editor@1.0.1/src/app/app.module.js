import './templates.js';
import appStateConfig from './app.state-config.js';
import appRun from './app.run.js';
import appConstantsModule from './app.constants.js';

import stencilEditorModule from './stencil-editor/stencil-editor.module.js';
import servicesModule from './services/services.module.js';
import directivesModule from './directives/directives.module.js';

export default angular.module('ng-stencil-editor', [
    //app dependencies
    'ng-common',
    'bcapp-pattern-lab',
    'ng-stencil-editor.templates',

    //third-party dependencies
    'formly',
    'gettext',
    'ui.router',
    'ngCookies',

    //child modules
    stencilEditorModule.name,

    //directives
    directivesModule.name,

    //services
    servicesModule.name,

    //constants
    appConstantsModule.name
])
    .config(appStateConfig)
    .run(appRun);
