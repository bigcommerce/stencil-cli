import 'angular';
import 'angular-mocks';

import constantsModule from 'src/app/app.constants.js';
import configMockModule from 'tests/mocks/stencil-config.mock.js';
import servicesModule from './services.module.js';

describe('StencilConfigService: ', () => {
    let $httpBackend,
        API,
        configMockData,
        stencilConfig;

    beforeEach(module(constantsModule.name));
    beforeEach(module(configMockModule.name));
    beforeEach(module(servicesModule.name));

    beforeEach(inject(function ($injector) {
        $httpBackend = $injector.get('$httpBackend');
        API = $injector.get('API');
        stencilConfig = $injector.get('stencilConfig');
        configMockData = $injector.get('mockConfig');
    }));

    describe('reset() method', () => {
        beforeEach(() => {
            $httpBackend.expectGET(API.BASE_PATH + API.CONFIG_PATH).respond(200, configMockData);
        });

        afterEach(() => {
            $httpBackend.verifyNoOutstandingExpectation();
            $httpBackend.verifyNoOutstandingRequest();
        });

        it('should restore config from backed up settings', () => {
            stencilConfig.fetch().then(() => {
                let config = stencilConfig.getConfig(),
                    originalSettings = _.cloneDeep(config.settings);

                config.settings.color = '#000000';

                expect(stencilConfig.getConfig().settings).toEqual(config.settings);
                expect(originalSettings).toEqual(stencilConfig._configSettingsBackup);

                stencilConfig.reset();

                expect(originalSettings).toEqual(stencilConfig.getConfig().settings);
            });

            $httpBackend.flush();
        });
    });

    describe('commit() method', () => {
        it('should call save() method with the commit param', () => {
            var config = { testConfig: 123 };

            spyOn(stencilConfig, 'save');

            stencilConfig.commit(config);

            expect(stencilConfig.save).toHaveBeenCalledWith(config, { params: { commit: true } });
        });

        it('should return the results from calling save()', () => {
            var response = 'Test Response';

            spyOn(stencilConfig, 'save').and.returnValue(response);

            expect(stencilConfig.commit({})).toBe(response);
        });
    });

    describe('publish() method', () => {
        it('should call save() method with the publish param and commit param', () => {
            var config = { testConfig: 123 };

            spyOn(stencilConfig, 'save');

            stencilConfig.publish(config);

            expect(stencilConfig.save).toHaveBeenCalledWith(config, { params: { commit: true, publish: true } });
        });

        it('should return the results from calling save()', () => {
            var response = 'Test Response';

            spyOn(stencilConfig, 'save').and.returnValue(response);

            expect(stencilConfig.publish({})).toBe(response);
        });
    });

    describe('save() method', () => {
        const config = {
            settings: 'Test Settings'
        };

        beforeEach(() => {
            $httpBackend.expectPOST(API.BASE_PATH + API.CONFIG_PATH, config.settings).respond(200, configMockData);
        });

        afterEach(() => {
            $httpBackend.verifyNoOutstandingExpectation();
            $httpBackend.verifyNoOutstandingRequest();
        });

        it('should call requiresRefresh()', () => {
            spyOn(stencilConfig, 'requiresRefresh');

            stencilConfig.save(config);

            $httpBackend.flush();

            expect(stencilConfig.requiresRefresh).toHaveBeenCalled();
        });

        it('should broadcast a configSaved event with the response data', () => {
            const $rootScope = stencilConfig._$rootScope;

            spyOn($rootScope, '$broadcast');

            stencilConfig.save(config);

            $httpBackend.flush();

            expect($rootScope.$broadcast).toHaveBeenCalledWith('configSaved', configMockData);
        });
    });

    describe('saveNative() method', () => {
        it('should make a native POST with the resetted config', () => {
            const fakeConfig = { mock: 'Test Config' };

            spyOn(stencilConfig, 'getConfig').and.returnValue(fakeConfig);

            spyOn(XMLHttpRequest.prototype, 'open').and.callThrough();
            spyOn(XMLHttpRequest.prototype, 'send');

            stencilConfig.saveNative();

            expect(XMLHttpRequest.prototype.open).toHaveBeenCalledWith(
                'POST',
                API.BASE_PATH + API.CONFIG_PATH,
                true
            );

            expect(XMLHttpRequest.prototype.send).toHaveBeenCalledWith(fakeConfig);
        });
    });
});
