import 'angular';
import 'angular-mocks';

import Fonts from './fonts.service.js';

describe('Fonts Service: ', () =>  {
    let $rootScope = jasmine.createSpyObj('$rootScope', [
            '$emit'
        ]),
        stencilConfig = jasmine.createSpyObj('stencilConfig', [
            'getConfig'
        ]);

    beforeEach(() => {
        stencilConfig.getConfig.and.returnValue({
            settings: {
                'body-font': 'Open Sans',
                'headings-font': 'Karla_700'
            }
        });
    });

    function createService() {
        return new Fonts($rootScope, stencilConfig);
    }

    describe('emitInjectFont method', () => {
        it('should emit a proper themeRelay event', () => {
            const fonts = createService();
            const fontUrl = 'TestFontUrl';

            fonts.emitInjectFont(fontUrl);

            expect($rootScope.$emit).toHaveBeenCalledWith(
                'themeRelay',
                {
                    method: 'add-font',
                    params: {
                        fontUrl: fontUrl
                    }
                }
            );
        });
    });

    describe('setInitialFonts method', () => {
        it('should read the fonts from the config and populate the loadedFonts object', () => {
            const fonts = createService();

            fonts.setInitialFonts();

            expect(fonts._loadedFonts).toEqual({
                'Open Sans': true,
                'Karla_700': true
            });
        });
    });

    describe('addFont method', () => {
        it('should add the font to _loadedFonts', () => {
            stencilConfig.getConfig.and.returnValue({});

            const fonts = createService();

            expect(fonts._loadedFonts).toEqual({});

            fonts.addFont('Google_Open+Sans');
            expect(fonts._loadedFonts).toEqual({ 'Google_Open+Sans': true });
        });

        it('if its a new font it should call emitInjectFont and parseFont', () => {
            stencilConfig.getConfig.and.returnValue({});

            const fonts = createService();
            const testFont = 'testFont';

            spyOn(fonts, 'emitInjectFont');
            spyOn(fonts, 'parseFont');

            fonts.addFont(testFont);

            expect(fonts.parseFont).toHaveBeenCalledWith(testFont);
            expect(fonts.emitInjectFont).toHaveBeenCalled();
        });
    });

    describe('formatGoogleFont method', () => {
        it('should accept fonts without weight', () => {
            const fonts = createService();

            const fontUrl = fonts.parseGoogleFont('Google_Karla');

            expect(fontUrl).toEqual('//fonts.googleapis.com/css?family=Karla|');
        });

        it('should accept fonts with weight', () => {
            const fonts = createService();

            const fontUrl = fonts.parseGoogleFont('Google_Karla_700');

            expect(fontUrl).toEqual('//fonts.googleapis.com/css?family=Karla:700|');
        });

        it('should accept fonts with multiple words separated by +', () => {
            const fonts = createService();

            const fontUrl = fonts.parseGoogleFont('Google_Open+Sans_400');

            expect(fontUrl).toEqual('//fonts.googleapis.com/css?family=Open+Sans:400|');
        });

        it('should accept fonts with _something after weight for Shopify compatibility', () => {
            const fonts = createService();

            const fontUrl = fonts.parseGoogleFont('Google_Open+Sans_400_sans');

            expect(fontUrl).toEqual('//fonts.googleapis.com/css?family=Open+Sans:400|');
        });

        it('should accept fonts with multiple weight for Shopify compatibility', () => {
            const fonts = createService();

            let fontUrl = fonts.parseGoogleFont('Google_Open+Sans_400,700_sans');
            expect(fontUrl).toEqual('//fonts.googleapis.com/css?family=Open+Sans:400|');

            fontUrl = fonts.parseGoogleFont('Google_Open+Sans_400,700');
            expect(fontUrl).toEqual('//fonts.googleapis.com/css?family=Open+Sans:400|');
        });
    });
});
