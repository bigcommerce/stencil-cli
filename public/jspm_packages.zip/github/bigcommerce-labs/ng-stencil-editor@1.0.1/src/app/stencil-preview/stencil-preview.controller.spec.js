import 'angular';
import 'angular-mocks';

import StencilPreviewCtrl from './stencil-preview.controller.js';

describe('StencilPreviewCtrl: ', () =>  {
    var $controller,
        $rootScope,
        $scope,
        controller,
        stencilConfig = {
            requiresRefresh: angular.noop
        };

    function createController($scope) {
        return $controller(StencilPreviewCtrl, {
            $scope: $scope,
            configResolve: {},
            previewControls: {},
            stencilConfig: stencilConfig
        });
    }

    beforeEach(inject(($injector) => {
        $rootScope = $injector.get('$rootScope');
        $scope = $rootScope.$new();
        $controller = $injector.get('$controller');
    }));

    describe('constructor $scope events', () => {
        it('should $emit a themeRelay "reload-stylesheets" event when receiving configSaved event without a forceReload', () => {
            const stylesheets = ['foo.css'];

            spyOn($scope, '$emit');

            controller = createController($scope);

            $rootScope.$broadcast('configSaved', {forceReload: false, stylesheets: stylesheets});

            expect($scope.$emit).toHaveBeenCalledWith('themeRelay', {
                method: 'reload-stylesheets',
                params: stylesheets
            });
        });

        it('should not $emit a themeRelay "reload-stylesheets" event when receiving configSaved event with a forceReload', () => {
            spyOn($scope, '$emit');

            controller = createController($scope);

            $rootScope.$broadcast('configSaved', {forceReload: true});

            expect($scope.$emit).not.toHaveBeenCalledWith('themeRelay');
        });

        it('should trigger refreshIframe() method if receiving variationChanged event', () => {
            controller = createController($scope);

            spyOn(controller, 'refreshIframe');

            $rootScope.$broadcast('variationChanged');

            expect(controller.refreshIframe).toHaveBeenCalled();
        });
    });

    describe('refreshIframe() method', () => {
        it('should $emit a themeRelay "reload-page" event when triggered', () => {
            spyOn($scope, '$emit');

            controller = createController($scope);

            controller.refreshIframe();

            expect($scope.$emit).toHaveBeenCalledWith('themeRelay', {
                method: 'reload-page'
            });
        });

        it('should call stencilConfig.requiresRefresh() with false when triggered', () => {
            spyOn(stencilConfig, 'requiresRefresh');

            controller = createController($scope);

            controller.refreshIframe();

            expect(stencilConfig.requiresRefresh).toHaveBeenCalledWith(false);
        });
    });
});
