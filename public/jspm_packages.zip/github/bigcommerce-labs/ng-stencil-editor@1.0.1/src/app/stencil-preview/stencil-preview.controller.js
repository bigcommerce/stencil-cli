export default class StencilPreviewCtrl {
    /*@ngInject*/
    constructor ($scope, configResolve, previewControls, stencilConfig) {
        this._$scope = $scope;
        this._stencilConfig = stencilConfig;
        this._previewControls = previewControls;

        this.config = configResolve;

        this._$scope.$on('configSaved', (event, data) => {
            if (! data.forceReload) {
                this._$scope.$emit('themeRelay', {
                    method: 'reload-stylesheets',
                    params: data.stylesheets
                });
            }
        });

        this._$scope.$on('variationChanged', () => {
            this.refreshIframe();
        });
    }

    refreshIframe() {
        this._$scope.$emit('themeRelay', {
            method: 'reload-page'
        });
        this._stencilConfig.requiresRefresh(false);
    }

    getSize() {
        return this._previewControls.getSize();
    }

    getStoreUrl() {
        return this._stencilConfig.getStoreUrl();
    }

    isFlipped() {
        return this._previewControls.isFlipped();
    }

    requiresRefresh() {
        return this._stencilConfig.requiresRefresh();
    }
}
