import previewControlsDirective from 'src/app/directives/preview-controls/preview-controls.directive.js';
import previewControlsService from 'src/app/directives/preview-controls/preview-controls.service.js';

export default angular.module('ng-stencil-editor.directives.preview-controls', [])
    .directive('previewControls', previewControlsDirective)
    .service('previewControls', previewControlsService);
