import editorHeaderModule from 'src/app/directives/editor-header/editor-header.module.js';
import previewControlsModule from 'src/app/directives/preview-controls/preview-controls.module.js';
import themeRelayModule from 'src/app/directives/theme-relay/theme-relay.module.js';
import variationSelectModule from 'src/app/directives/variation-select/variation-select.module.js';

export default angular.module('ng-stencil-editor.directives', [
    editorHeaderModule.name,
    previewControlsModule.name,
    themeRelayModule.name,
    variationSelectModule.name
]);
