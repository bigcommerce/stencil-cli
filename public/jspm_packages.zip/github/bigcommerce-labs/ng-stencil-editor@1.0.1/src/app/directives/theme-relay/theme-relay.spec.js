import 'angular';
import 'angular-mocks';

import ThemeRelayCtrl from './theme-relay.controller.js';

describe('ThemeRelay Ctrl: ', () => {
    let stencilConfig = jasmine.createSpyObj('stencilConfig', [
            'getEditorToken'
        ]),
        $controller,
        $rootScope,
        $scope,
        controller;

    function createController($scope) {
        return $controller(ThemeRelayCtrl, {
            $scope: $scope,
            stencilConfig: stencilConfig
        });
    }

    beforeEach(inject(($injector) => {
        $rootScope = $injector.get('$rootScope');
        $scope = $rootScope.$new();
        $controller = $injector.get('$controller');
    }));

    describe('constructor', () => {
        it('should listen to themeRelay events', () => {
            spyOn($rootScope, '$on');

            controller = createController($scope);

            expect($rootScope.$on).toHaveBeenCalledWith('themeRelay', jasmine.any(Function));
        });
    });

    describe('sendMessage() method', () => {
        it('should do a chan call with the the stringified data and correct method', () => {
            spyOn($rootScope, '$on');

            controller = createController($scope);
            controller.chan = jasmine.createSpyObj('chan', ['call']);

            const data = {
                method: 'testMethod',
                params: {
                    testParam: 'testParam'
                }
            };

            controller.sendMessage(null, data);

            data.success = angular.noop;
            data.params = JSON.stringify(data.params);

            expect(controller.chan.call).toHaveBeenCalledWith(data);
        });
    });

    describe('channelReady() method', () => {
        it('should send an on-ready message with the editor token', () => {
            const token = 'testToken';

            controller = createController($scope);

            spyOn(controller, 'sendMessage');
            controller._stencilConfig.getEditorToken.and.returnValue(token);

            controller.channelReady();

            expect(controller.sendMessage).toHaveBeenCalledWith(null, {
                method: 'on-ready',
                params: {
                    token: token
                }
            });
        });
    });
});
