import EditorHeaderController from 'src/app/directives/editor-header/editor-header.controller.js';

class EditorHeader {
    constructor() {
        this.controller = EditorHeaderController;
        this.controllerAs = 'editorHeaderCtrl';
        this.restrict = 'AE';
        this.templateUrl = 'app/directives/editor-header/editor-header.tpl.html';
    }

    static directiveFactory() {
        return new EditorHeader();
    }
}

EditorHeader.directiveFactory.$inject = [];

export default EditorHeader.directiveFactory;
