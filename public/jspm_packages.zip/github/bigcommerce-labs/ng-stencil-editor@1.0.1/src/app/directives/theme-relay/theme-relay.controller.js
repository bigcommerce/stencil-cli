export default class {
    /*@ngInject*/
    constructor ($rootScope, stencilConfig) {
        this._$rootScope = $rootScope;
        this._stencilConfig = stencilConfig;

        $rootScope.$on('themeRelay', _.bind(this.sendMessage, this));
    }

    sendMessage(event, data) {
        this.chan.call({
            method: data.method,
            params: JSON.stringify(data.params || {}),
            success: angular.noop
        });
    }

    channelReady() {
        const token = this._stencilConfig.getEditorToken();

        this.sendMessage(null, {
            method: 'on-ready',
            params: {
                token: token
            }
        });
    }
}
