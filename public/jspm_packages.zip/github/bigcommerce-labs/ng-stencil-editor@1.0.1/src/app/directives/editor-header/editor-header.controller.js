import ThemeInfoModalCtrl from 'src/app/modals/theme-info-modal/theme-info-modal.controller.js';

export default class {
    /*@ngInject*/
    constructor($modal, stencilConfig) {
        this._$modal = $modal;
        this._stencilConfig = stencilConfig;
    }

    info($event) {
        $event.preventDefault();

        this._$modal.open({
            controller: ThemeInfoModalCtrl,
            controllerAs: 'themeInfoModalCtrl',
            templateUrl: 'app/modals/theme-info-modal/theme-info-modal.tpl.html',
            windowClass: 'modal--small'
        });
    }

    getName() {
        return this._stencilConfig.getConfig().name;
    }

    getVersion() {
        return this._stencilConfig.getConfig().version;
    }
}
