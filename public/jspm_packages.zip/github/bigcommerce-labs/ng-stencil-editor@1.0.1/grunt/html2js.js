// Angular template compilation
module.exports = {
    "build": {
        options: {
            fileFooterString: 'export default {};'
        }
    }
};
