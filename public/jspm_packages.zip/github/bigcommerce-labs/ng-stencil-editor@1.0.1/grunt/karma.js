var _ = require('lodash'),
    testFiles = [
        'node_modules/phantomjs-polyfill/bind-polyfill.js',
        'build/**/*.js',
        'build/*.js',
        'tests/**/*.js',
        'tests/*.js',
    ];

module.exports = function(grunt, options) {
    var baseFilesMap = options.karmaVendorsMap || {};

    return {
        deploy: {
            options: {
                files: testFiles
            }
        },
        options: {
            frameworks: [
                'systemjs',
                'jasmine',
                'es6-shim'
            ],
            plugins: [
                'karma-es6-shim',
                'karma-systemjs',
                'karma-jasmine',
                'karma-firefox-launcher',
                'karma-chrome-launcher',
                'karma-phantomjs-launcher',
                'karma-babel-preprocessor',
                'karma-coffee-preprocessor',
                'karma-coverage',
                'karma-growl-reporter',
                'karma-html-reporter'
            ],
            files: testFiles,
            systemjs: {
                serveFiles: _.values(baseFilesMap),
                config: {
                    transpiler: 'babel',
                    paths: baseFilesMap,
                    testFileSuffix: '.spec.js'
                }
            },
            babelPreprocessor: {
                options: {
                    modules: 'system'
                }
            }
        }
    };
};
