import PaletteProvider from './palette.provider.js';

export default angular.module('ng-stencil-editor.providers', [])
    .provider('palette', PaletteProvider);
