export default class PaletteProvider {
    constructor() {
        this._palette = [];
    }

    $get(newPalette) {
        if (Array.isArray(newPalette)) {
            this._palette = newPalette;
        }

        return this._palette;
    }
}
