export default angular.module('ng-stencil-editor.api', [])
    .provider('API', function APIProvider(BC_SEED_DATA) {
        this.$get = function getAPI(_) {
            const API = {
                CONFIG_PATH: '/configurations',
                VARIATION_PATH: '/variations',
                VERSION_PATH: '/versions',
            };

            return _.mapValues(API, api => {
                return BC_SEED_DATA.basePath + api;
            });
        };
    });
