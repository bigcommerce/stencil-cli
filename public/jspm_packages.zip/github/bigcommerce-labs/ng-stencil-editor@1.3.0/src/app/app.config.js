import AppCtrl from 'src/app/app.controller.js';
import StencilEditorCtrl from 'src/app/stencil-editor/stencil-editor.controller.js';
import StencilPreviewCtrl from 'src/app/stencil-preview/stencil-preview.controller.js';

export default function config($httpProvider, $locationProvider, $stateProvider, $urlRouterProvider, BC_APP_CONFIG, BC_SEED_DATA, svgRootPathProvider) {
    'ngInject';

    $httpProvider.interceptors.push('ajaxRequestStatus');

    $urlRouterProvider.deferIntercept();

    $locationProvider.html5Mode(true);

    $stateProvider.state('ng-stencil-editor', {
        url: '/theme-editor/{versionId}/{variationId}/{configurationId}',
        params: {
            configurationId: { value: '1' },
            variationId: { value: '1' },
            versionId: { value: 'theme' },
        },
        resolve: {
            /*@ngInject*/
            configResolve: ($stateParams, configService) => {
                return configService.fetchConfig($stateParams.configurationId);
            },

            /*@ngInject*/
            variationResolve: ($stateParams, variationService) => {
                return variationService.fetchVariation($stateParams.variationId);
            },

            /*@ngInject*/
            versionResolve: ($stateParams, versionService) => {
                return versionService.fetchVersion($stateParams.versionId);
            }
        },
        views: {
            '@': {
                controller: AppCtrl,
                controllerAs: 'appCtrl',
                templateUrl: 'app/app.tpl.html'
            },

            'editor@ng-stencil-editor': {
                controller: StencilEditorCtrl,
                controllerAs: 'stencilEditorCtrl',
                templateUrl: 'app/stencil-editor/stencil-editor.tpl.html'
            },

            'preview@ng-stencil-editor': {
                controller: StencilPreviewCtrl,
                controllerAs: 'stencilPreviewCtrl',
                templateUrl: 'app/stencil-preview/stencil-preview.tpl.html'
            }
        }

    });

    svgRootPathProvider.setRootPath(BC_APP_CONFIG.cdnPath + BC_SEED_DATA.svgPath);
}
