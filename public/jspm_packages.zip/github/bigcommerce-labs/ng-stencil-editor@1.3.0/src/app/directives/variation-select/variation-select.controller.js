import LostChangesModalCtrl from 'src/app/modals/lost-changes-modal/lost-changes-modal.controller.js';

export default class VariationSelectCtrl {
    /*@ngInject*/
    constructor($modal, $q, $state, channelService, variationService) {
        this._$modal = $modal;
        this._$q = $q;
        this._$state = $state;
        this._channelService = channelService;

        this.activeVariation = variationService.activeVariation.bind(variationService);
        this.currentVariation = variationService.currentVariation.bind(variationService);
        this.getVariations = variationService.getVariations.bind(variationService);
        this.variationChange = this.variationChange || _.noop;
        this.variationChanging = this.variationChanging || _.noop;
    }

    isActiveVariation(variation) {
        return this.activeVariation().id === variation.id;
    }

    isCurrentVariation(variation) {
        return this.currentVariation().id === variation.id;
    }

    confirm($event, variation) {
        $event.preventDefault();

        return this
            .warn($event, variation)
            .then(() => this.variationChanging(variation))
            .then(() => this.navigate(variation))
            .then(() => this.emitSetCookie(variation))
            .then(() => this.activeVariation(variation))
            .then(() => this.variationChange(variation));
    }

    emitSetCookie(variation) {
        return this._channelService.emit('set-cookie', {
            data: { configurationId: variation.configurationId }
        });
    }

    navigate(variation) {
        return this._$state.go('.', { configurationId: variation.configurationId, variationId: variation.id }, { notify: false });
    }

    warn(variation) {
        if (this.editorForm.$dirty) {
            return this._$modal
                .open({
                    controller: LostChangesModalCtrl,
                    controllerAs: 'lostChangesModalCtrl',
                    resolve: { variation: () => variation },
                    templateUrl: 'app/modals/lost-changes-modal/lost-changes-modal.tpl.html',
                    windowClass: 'modal'
                })
                .result;
        } else {
            return this._$q.when(variation);
        }
    }
}
