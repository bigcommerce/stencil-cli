import 'angular';
import 'angular-mocks';

import VariationSelectCtrl from 'src/app/directives/variation-select/variation-select.controller.js';

describe('Variation select directive: ', () => {
    const mockEvent = jasmine.createSpyObj('$event', [
        'preventDefault',
    ]);
    const channelService = jasmine.createSpyObj('channelService', [
        'emit',
    ]);
    const mockVariation = { configurationId: 1 };
    const variationService = jasmine.createSpyObj('variationService', [
        'activeVariation',
        'currentVariation',
        'getVariations'
    ]);
    const $modal = jasmine.createSpyObj('$modal', [
        'open',
        'close',
    ]);
    const $state = jasmine.createSpyObj('$state', [
        'go'
    ]);

    let $controller;
    let $q;
    let $rootScope;
    let $scope;
    let controller;

    function createController($scope) {
        return $controller(VariationSelectCtrl, {
            $scope: $scope,
            $modal: $modal,
            $state: $state,
            channelService: channelService,
            variationService: variationService
        });
    }

    beforeEach(() => {
        angular.mock.module(function($provide) {
            $provide.value('variationService', variationService);
        });

        variationService.activeVariation.and.returnValue(mockVariation);
    });

    beforeEach(inject(($injector) => {
        $controller = $injector.get('$controller');
        $q = $injector.get('$q');
        $rootScope = $injector.get('$rootScope');
        $scope = $rootScope.$new();
    }));

    describe('isActiveVariation() method', () => {
        beforeEach(() => {
            controller = createController($scope);
        });

        it('should return true when variation id matches the current variation id', () => {
            expect(controller.isActiveVariation(mockVariation)).toEqual(true);
        });

        it('should return false when variation id does not match the current variation id', () => {
            variationService.activeVariation.and.returnValue({ id: 2 });

            expect(controller.isActiveVariation(mockVariation)).toEqual(false);
        });
    });

    describe('confirm() method', () => {
        beforeEach(() => {
            controller = createController($scope);
            controller.variationChange = _.noop;
        });

        it('should set a new variation name with a clean form', () => {
            controller.editorForm = {
                $dirty: false
            };
            controller.confirm(mockEvent, mockVariation);

            $scope.$digest();

            expect(variationService.activeVariation).toHaveBeenCalledWith(mockVariation);
        });

        it('should warn the user before switching the variation with a dirty form', () => {
            spyOn(controller, 'warn').and.returnValue($q.when());

            controller.editorForm = {
                $dirty: true
            };
            controller.confirm(mockEvent, mockVariation);

            expect(controller.warn).toHaveBeenCalledWith(mockEvent, mockVariation);
        });

        it('should emit a set-cookie event with the new configurationId', () => {
            spyOn(controller, 'warn').and.returnValue($q.when());

            controller.editorForm = {
                $dirty: true
            };
            controller.confirm(mockEvent, mockVariation);

            expect(channelService.emit).toHaveBeenCalledWith(
                'set-cookie',
                {
                    data: { configurationId: mockVariation.configurationId }
                }
            );
        });
    });

    describe('warn() method', () => {
        beforeEach(() => {
            $modal.open.and.returnValue({
                result: $q.when(),
                close: angular.noop,
            });

            controller = createController($scope);
            controller.variationChange = _.noop;
            controller.editorForm = {
                $dirty: true
            };
            controller.confirm(mockEvent, mockVariation);
        });

        it('should open a modal to warn the user of unsaved changes', () => {
            expect(mockEvent.preventDefault).toHaveBeenCalled();
            expect(controller._$modal.open).toHaveBeenCalled();
        });

        it('should set a new variation name when the modal is closed', () => {
            controller._$modal.open().close(mockVariation);

            expect(variationService.activeVariation).toHaveBeenCalledWith(mockVariation);
        });

    });

});
