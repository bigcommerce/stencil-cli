import 'angular';
import 'angular-mocks';

import apiModule from 'src/app/app.api.js';
import ConfigService from './config.service.js';
import servicesModule from './services.module.js';

describe('ConfigService: ', () => {
    let $http;
    let $httpBackend;
    let $location;
    let $q;
    let $rootScope;
    let $state;
    let $stateParams;
    let API;
    let BC_APP_CONFIG;
    let configService;
    let channelService = jasmine.createSpyObj('channelService', [
        'createChannel',
        'emit',
    ]);

    beforeEach(module(apiModule.name));
    beforeEach(module(servicesModule.name));

    beforeEach(inject(function ($injector) {
        $http = $injector.get('$http');
        $httpBackend = $injector.get('$httpBackend');
        $location = $injector.get('$location');
        $q = $injector.get('$q');
        $rootScope = $injector.get('$rootScope');
        $state = $injector.get('$state');
        $stateParams = {};
        API = $injector.get('API');
        BC_APP_CONFIG = $injector.get('BC_APP_CONFIG');

        configService = new ConfigService(
            $http,
            $q,
            $state,
            API,
            BC_APP_CONFIG,
            $location,
            $stateParams,
            channelService
        );

        spyOn(configService._$state, 'go').and.returnValue($q.when());
    }));

    describe('reset() method', () => {
        // TODO: Rewrite to avoid throwing digest-in-progress error
        //beforeEach(() => {
        //    $httpBackend.expectGET(API.CONFIG_PATH).respond(200, configMockData);
        //});
        //
        //afterEach(() => {
        //    $httpBackend.verifyNoOutstandingExpectation();
        //    $httpBackend.verifyNoOutstandingRequest();
        //});

        //it('should restore config from backed up settings', () => {
        //    configService.fetchConfig().then(() => {
        //        let config = configService.getConfig();
        //        let originalSettings = _.cloneDeep(config.settings);
        //
        //        config.settings['color-primary'] = '#000000';
        //
        //        expect(configService.getConfig().settings).toEqual(config.settings);
        //        expect(originalSettings).toEqual(configService._configSettingsBackup);
        //    });
        //
        //    $httpBackend.flush();
        //});
    });

    describe('refreshIframe() method', () => {
        it('should call emit "reload-page" event when triggered', () => {
            configService.refreshIframe();

            expect(channelService.emit).toHaveBeenCalledWith('reload-page');
        });

        it('should call configService.requiresRefresh() with false when triggered', () => {
            spyOn(configService, 'requiresRefresh');

            configService.refreshIframe();

            expect(configService.requiresRefresh).toHaveBeenCalledWith(false);
        });
    });

    describe('navigate() method', () => {
        it('should return a promise that resolves in passed params', done => {
            const params = { configurationId: 12345 };

            configService.navigate(params)
                .then(data => {
                    expect(data).toBe(params);
                    done();
                });

            $rootScope.$digest();
        });

        it('it should set isManuallyNavigating to true', () => {
            const params = { configurationId: 12345 };

            expect(configService._isManuallyNavigating).toBe(false);

            configService.navigate(params);

            expect(configService._isManuallyNavigating).toBe(true);

        });
    });

    describe('publish() method', () => {
        it('should call save() method with the publish option', () => {
            let config = { testConfig: 123 };

            spyOn(configService, 'save');

            configService.publish(config);

            expect(configService.save).toHaveBeenCalledWith(config, { publish: true });
        });
    });

    describe('save() method', () => {
        const config = {};
        const response = {
            data: {
                configurationId: 'newConfigurationId'
            }
        };

        beforeEach(() => {
            config.id = '1';
            config.settings = {
                test: 'test settings'
            };
            config.variationId = '1';
        });

        afterEach(() => {
            $httpBackend.verifyNoOutstandingExpectation();
            $httpBackend.verifyNoOutstandingRequest();
        });

        it('should update the config id', () => {
            $httpBackend.expectPOST(API.CONFIG_PATH).respond(200, response);

            expect(config.id).toBe('1');

            configService.save(config);
            $httpBackend.flush();

            expect(config.id).toBe('newConfigurationId');
        });

        it('should not send publish=true by default', () => {
            $httpBackend.expectPOST(API.CONFIG_PATH, postData => {
                const resp = JSON.parse(postData);

                expect(resp.publish).toBe(false);

                return true;
            }).respond(200, response);

            configService.save(config);
            $httpBackend.flush();
        });

        it('should send publish true with the payload if specified in options', () => {
            $httpBackend.expectPOST(API.CONFIG_PATH, postData => {
                const resp = JSON.parse(postData);

                expect(resp.publish).toBe(true);

                return true;
            }).respond(200, response);

            configService.save(config, { publish: true });
            $httpBackend.flush();
        });

        it('should call requiresRefresh if option is passed', () => {
            spyOn(configService, 'requiresRefresh');

            $httpBackend.expectPOST(API.CONFIG_PATH).respond(200, response);

            configService.save(config, {
                requiresRefresh: true
            });

            $httpBackend.flush();

            expect(configService.requiresRefresh).toHaveBeenCalledWith(true);
        });

        it('should send preview true as part of the data to the ajax request', () => {
            $httpBackend.expectPOST(API.CONFIG_PATH, postData => {
                const resp = JSON.parse(postData);

                expect(resp.preview).toBe(true);

                return true;
            }).respond(200, response);

            configService.save(config, {
                preview: true
            });

            $httpBackend.flush();
        });
    });

    describe('preview() method', () => {
        it('should call save() with preview option', () => {
            spyOn(configService, 'save');

            configService.preview({});

            expect(configService.save).toHaveBeenCalledWith({}, {
                preview: true
            });
        });
    });

    // This test may cause "full page reload" errors in PhantonJS
    describe('saveNative() method', () => {
        it('should make a native POST with the resetted config', () => {
            const fakeConfig = { mock: 'Test Config' };

            spyOn(configService, 'getConfig').and.returnValue(fakeConfig);

            spyOn(XMLHttpRequest.prototype, 'open').and.callThrough();
            spyOn(XMLHttpRequest.prototype, 'send');

            configService.saveNative();

            expect(XMLHttpRequest.prototype.open).toHaveBeenCalledWith(
                'POST',
                API.CONFIG_PATH,
                true
            );

            expect(XMLHttpRequest.prototype.send).toHaveBeenCalledWith(fakeConfig);
        });
    });
});
