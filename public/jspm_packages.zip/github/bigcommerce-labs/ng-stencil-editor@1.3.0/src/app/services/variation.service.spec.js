import 'angular';
import 'angular-mocks';

import apiModule from 'src/app/app.api.js';
import servicesModule from './services.module.js';
import variationMock from 'tests/mocks/variation.mock.js';

describe('VariationService: ', () => {
    let $httpBackend;
    let API;
    let variationService;

    beforeEach(module(apiModule.name));
    beforeEach(module(servicesModule.name));

    beforeEach(inject(function ($injector) {
        $httpBackend = $injector.get('$httpBackend');
        API = $injector.get('API');
        variationService = $injector.get('variationService');
    }));

    describe('fetchVariation() method', () => {
        const variationId = 1;

        beforeEach(() => {
            $httpBackend.expectGET(API.VARIATION_PATH + '/' + variationId).respond(200, { data: variationMock });
        });

        afterEach(() => {
            $httpBackend.verifyNoOutstandingExpectation();
            $httpBackend.verifyNoOutstandingRequest();
        });

        it('should fetch the specified version', () => {
            variationService.fetchVariation(variationId);

            $httpBackend.flush();
        });

        it('should call activeVariation with the variation object', () => {
            spyOn(variationService, 'activeVariation').and.callThrough();

            variationService.fetchVariation(variationId);

            $httpBackend.flush();

            expect(variationService.activeVariation).toHaveBeenCalledWith(variationMock);
        });

        it('should call setVariations with the relatedVariations object', () => {
            spyOn(variationService, 'setVariations').and.callThrough();

            variationService.fetchVariation(variationId);

            $httpBackend.flush();

            expect(variationService.setVariations).toHaveBeenCalledWith(variationMock.relatedVariations);
        });

        it('should call findCurrentVariation with the relatedVariations object', () => {
            spyOn(variationService, 'findCurrentVariation').and.callThrough();

            variationService.fetchVariation(variationId);

            $httpBackend.flush();

            expect(variationService.findCurrentVariation).toHaveBeenCalledWith(variationMock.relatedVariations);
        });

        it('should call currentVariation with the isCurrent object', () => {
            spyOn(variationService, 'currentVariation').and.callThrough();

            variationService.fetchVariation(variationId);

            $httpBackend.flush();

            expect(variationService.currentVariation).toHaveBeenCalledWith(variationMock.relatedVariations[0]);
        });
    });

    describe('fetchVariations() method', () => {
        beforeEach(() => {
            $httpBackend.expectGET(API.VARIATION_PATH).respond(200, { data: [variationMock] });
        });

        afterEach(() => {
            $httpBackend.verifyNoOutstandingExpectation();
            $httpBackend.verifyNoOutstandingRequest();
        });

        it('should fetch the specified version', () => {
            variationService.fetchVariations();

            $httpBackend.flush();
        });

        it('shoould call setVariations', () => {
            spyOn(variationService, 'setVariations').and.callThrough();

            variationService.fetchVariations();

            $httpBackend.flush();

            expect(variationService.setVariations).toHaveBeenCalledWith([variationMock]);
        });
    });

    describe('activeVariation() method', () => {
        it('should set _activeVariation if an argument is passed', () => {
            const testVariation = { test: 'variation' };

            variationService.activeVariation(testVariation);

            expect(variationService._activeVariation).toBe(testVariation);
        });

        it('should return the activeVariation', () => {
            const testVariation = { test: 'variation' };

            variationService.activeVariation(testVariation);

            expect(variationService.activeVariation()).toBe(testVariation);
        });
    });

    describe('currentVariation() method', () => {
        it('should set _currentVariation if an argument is passed', () => {
            const currentVariation = { test: 'variation' };

            variationService.currentVariation(currentVariation);

            expect(variationService._currentVariation).toBe(currentVariation);
        });

        it('should return the currentVariation', () => {
            const currentVariation = { test: 'variation' };

            variationService.currentVariation(currentVariation);

            expect(variationService.currentVariation()).toBe(currentVariation);
        });
    });

    describe('findCurrentVariation() method', () => {
        it('should find the isCurrent variation', () => {
            const relatedVariations = [
                {
                    id: 1,
                    isCurrent: true
                },
                {
                    id: 2,
                    isCurrent: false
                }
            ];

            expect(variationService.findCurrentVariation(relatedVariations)).toEqual({
                id: 1,
                isCurrent: true
            });
        });

        it('should return an empty object if isCurrent is not present in any variation', () => {
            expect(variationService.findCurrentVariation([])).toEqual({});
        });
    });

    describe('getVariations() method', () => {
        it('should return _variations', () => {
            const variations = [{ test: 'variation' }];

            variationService._variations = variations;

            expect(variationService.getVariations()).toBe(variations);
        });
    });

    describe('setVariations() method', () => {
        it('should set _variations', () => {
            const variations = [{ test: 'variation' }];

            variationService.setVariations(variations);

            expect(variationService._variations).toBe(variations);
        });
    });
});
