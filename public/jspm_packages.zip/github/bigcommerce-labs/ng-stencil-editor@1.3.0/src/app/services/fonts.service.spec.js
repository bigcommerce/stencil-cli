import 'angular';
import 'angular-mocks';

import FontsService from './fonts.service.js';

describe('Fonts Service: ', () =>  {
    const fontsMock = {
        'body-font': 'Open Sans',
        'headings-font': 'Karla_700'
    };

    let channelService = jasmine.createSpyObj('channelService', [
            'emit'
        ]);

    function createService() {
        return new FontsService(channelService);
    }

    describe('emitInjectFont method', () => {
        it('should emit a proper themeRelay event', () => {
            const fonts = createService();
            const fontUrl = 'TestFontUrl';

            fonts.emitInjectFont(fontUrl);

            expect(channelService.emit).toHaveBeenCalledWith('add-font', {
                data: { fontUrl }
            });
        });
    });

    describe('setInitialFonts method', () => {
        it('should read the fonts from the config and populate the loadedFonts object', () => {
            const fonts = createService();

            fonts.setInitialFonts(fontsMock);

            expect(fonts._loadedFonts).toEqual({
                'Open Sans': true,
                'Karla_700': true
            });
        });
    });

    describe('addFont method', () => {
        it('should add the font to _loadedFonts', () => {
            const fonts = createService();

            fonts._loadedFonts = {};

            fonts.addFont('Google_Open+Sans');
            expect(fonts._loadedFonts).toEqual({ 'Google_Open+Sans': true });
        });

        it('if its a new font it should call emitInjectFont and parseFont', () => {
            const fonts = createService();
            const testFont = 'testFont';

            spyOn(fonts, 'emitInjectFont');
            spyOn(fonts, 'parseFont');

            fonts.addFont(testFont);

            expect(fonts.parseFont).toHaveBeenCalledWith(testFont);
            expect(fonts.emitInjectFont).toHaveBeenCalled();
        });
    });

    describe('formatGoogleFont method', () => {
        it('should accept fonts without weight', () => {
            const fonts = createService();

            const fontUrl = fonts.parseGoogleFont('Google_Karla');

            expect(fontUrl).toEqual('//fonts.googleapis.com/css?family=Karla|');
        });

        it('should accept fonts with weight', () => {
            const fonts = createService();

            const fontUrl = fonts.parseGoogleFont('Google_Karla_700');

            expect(fontUrl).toEqual('//fonts.googleapis.com/css?family=Karla:700|');
        });

        it('should accept fonts with multiple words separated by +', () => {
            const fonts = createService();

            const fontUrl = fonts.parseGoogleFont('Google_Open+Sans_400');

            expect(fontUrl).toEqual('//fonts.googleapis.com/css?family=Open+Sans:400|');
        });

        it('should accept fonts with _something after weight for Shopify compatibility', () => {
            const fonts = createService();

            const fontUrl = fonts.parseGoogleFont('Google_Open+Sans_400_sans');

            expect(fontUrl).toEqual('//fonts.googleapis.com/css?family=Open+Sans:400|');
        });

        it('should accept fonts with multiple weight for Shopify compatibility', () => {
            const fonts = createService();

            let fontUrl = fonts.parseGoogleFont('Google_Open+Sans_400,700_sans');
            expect(fontUrl).toEqual('//fonts.googleapis.com/css?family=Open+Sans:400|');

            fontUrl = fonts.parseGoogleFont('Google_Open+Sans_400,700');
            expect(fontUrl).toEqual('//fonts.googleapis.com/css?family=Open+Sans:400|');
        });
    });
});
