export default [
    {
        "name": "Colors",
        "settings": [
            {
                "type": "heading",
                "content": "General"
            },
            {
                "type": "color",
                "label": "Text Color",
                "id": "body-font-color"
            },
            {
                "type": "color",
                "label": "Link Color",
                "id": "color-textLink"
            },
            {
                "type": "color",
                "label": "Heading Text Color",
                "id": "header-font-color"
            },
            {
                "type": "heading",
                "content": "Buttons"
            },
            {
                "type": "color",
                "label": "Primary Button Background Color",
                "id": "buttonStyle-primary-backgroundColor"
            },
            {
                "type": "color",
                "label": "Secondary Button Text Color",
                "id": "buttonStyle-default-color"
            },
            {
                "type": "color",
                "label": "Secondary Button Background Color",
                "id": "buttonStyle-default-backgroundColor"
            },
            {
                "type": "heading",
                "content": "Forms"
            },
            {
                "type": "color",
                "label": "Border Color",
                "id": " input-background-color"
            },
            {
                "type": "color",
                "label": "Text Color",
                "id": "input-font-color"
            },
            {
                "type": "heading",
                "content": "Lines"
            },
            {
                "type": "heading",
                "content": "Panels"
            },
            {
                "type": "color",
                "label": "Border Color",
                "id": "container-border-global-color-dark"
            }
        ]
    },
    {
        "name": "Typography",
        "settings": [
            {
                "type": "heading",
                "content": "Base typeface"
            },
            {
                "type": "font",
                "label": "Font Family",
                "id": "body-font",
                "options": [
                    {
                        "group": "Open Sans",
                        "label": "Open Sans",
                        "value": "Google_Open+Sans"
                    },
                    {
                        "group": "Open Sans",
                        "label": "Open Sans Bold",
                        "value": "Google_Open+Sans_700"
                    },
                    {
                        "group": "Karla",
                        "label": "Karla",
                        "value": "Google_Karla"
                    }
                ]
            },
            {
                "type": "select",
                "label": "Font Size",
                "id": "fontSize-base",
                "options": [
                    {
                        "value": 10,
                        "label": "10px"
                    },
                    {
                        "value": 11,
                        "label": "11px"
                    },
                    {
                        "value": 12,
                        "label": "12px"
                    },
                    {
                        "value": 13,
                        "label": "13px"
                    },
                    {
                        "value": 14,
                        "label": "14px"
                    },
                    {
                        "value": 15,
                        "label": "15px"
                    },
                    {
                        "value": 16,
                        "label": "16px"
                    }
                ]
            },
            {
                "type": "heading",
                "content": "Heading typeface"
            },
            {
                "type": "font",
                "label": "Font Family",
                "id": "headings-font",
                "options": [
                    {
                        "group": "Open Sans",
                        "label": "Open Sans",
                        "value": "Google_Open+Sans"
                    },
                    {
                        "group": "Open Sans",
                        "label": "Open Sans Bold",
                        "value": "Google_Open+Sans_700"
                    },
                    {
                        "group": "Karla",
                        "label": "Karla",
                        "value": "Google_Karla"
                    }
                ]
            },
            {
                "type": "select",
                "label": "Font Size (H1)",
                "id": "fontSize-h1",
                "options": [
                    {
                        "value": 10,
                        "label": "10px"
                    },
                    {
                        "value": 11,
                        "label": "11px"
                    },
                    {
                        "value": 12,
                        "label": "12px"
                    },
                    {
                        "value": 14,
                        "label": "14px"
                    },
                    {
                        "value": 16,
                        "label": "16px"
                    },
                    {
                        "value": 18,
                        "label": "18px"
                    },
                    {
                        "value": 21,
                        "label": "21px"
                    },
                    {
                        "value": 24,
                        "label": "24px"
                    },
                    {
                        "value": 26,
                        "label": "26px"
                    },
                    {
                        "value": 28,
                        "label": "28px"
                    }
                ]
            },
            {
                "type": "select",
                "label": "Font Size (H2)",
                "id": "fontSize-h2",
                "options": [
                    {
                        "value": 10,
                        "label": "10px"
                    },
                    {
                        "value": 11,
                        "label": "11px"
                    },
                    {
                        "value": 12,
                        "label": "12px"
                    },
                    {
                        "value": 14,
                        "label": "14px"
                    },
                    {
                        "value": 16,
                        "label": "16px"
                    },
                    {
                        "value": 18,
                        "label": "18px"
                    },
                    {
                        "value": 21,
                        "label": "21px"
                    },
                    {
                        "value": 24,
                        "label": "24px"
                    },
                    {
                        "value": 26,
                        "label": "26px"
                    },
                    {
                        "value": 28,
                        "label": "28px"
                    }
                ]
            },
            {
                "type": "select",
                "label": "Font Size (H3)",
                "id": "fontSize-h3",
                "options": [
                    {
                        "value": 10,
                        "label": "10px"
                    },
                    {
                        "value": 11,
                        "label": "11px"
                    },
                    {
                        "value": 12,
                        "label": "12px"
                    },
                    {
                        "value": 14,
                        "label": "14px"
                    },
                    {
                        "value": 16,
                        "label": "16px"
                    },
                    {
                        "value": 18,
                        "label": "18px"
                    },
                    {
                        "value": 21,
                        "label": "21px"
                    },
                    {
                        "value": 24,
                        "label": "24px"
                    },
                    {
                        "value": 26,
                        "label": "26px"
                    },
                    {
                        "value": 28,
                        "label": "28px"
                    }
                ]
            },
            {
                "type": "select",
                "label": "Font Size (H4)",
                "id": "fontSize-h4",
                "options": [
                    {
                        "value": 10,
                        "label": "10px"
                    },
                    {
                        "value": 11,
                        "label": "11px"
                    },
                    {
                        "value": 12,
                        "label": "12px"
                    },
                    {
                        "value": 14,
                        "label": "14px"
                    },
                    {
                        "value": 16,
                        "label": "16px"
                    },
                    {
                        "value": 18,
                        "label": "18px"
                    },
                    {
                        "value": 21,
                        "label": "21px"
                    },
                    {
                        "value": 24,
                        "label": "24px"
                    },
                    {
                        "value": 26,
                        "label": "26px"
                    },
                    {
                        "value": 28,
                        "label": "28px"
                    }
                ]
            },
            {
                "type": "select",
                "label": "Font Size (H5)",
                "id": "fontSize-h5",
                "options": [
                    {
                        "value": 10,
                        "label": "10px"
                    },
                    {
                        "value": 11,
                        "label": "11px"
                    },
                    {
                        "value": 12,
                        "label": "12px"
                    },
                    {
                        "value": 14,
                        "label": "14px"
                    },
                    {
                        "value": 16,
                        "label": "16px"
                    },
                    {
                        "value": 18,
                        "label": "18px"
                    },
                    {
                        "value": 21,
                        "label": "21px"
                    },
                    {
                        "value": 24,
                        "label": "24px"
                    },
                    {
                        "value": 26,
                        "label": "26px"
                    },
                    {
                        "value": 28,
                        "label": "28px"
                    }
                ]
            },
            {
                "type": "select",
                "label": "Font Size (H6)",
                "id": "fontSize-h6",
                "options": [
                    {
                        "value": 10,
                        "label": "10px"
                    },
                    {
                        "value": 11,
                        "label": "11px"
                    },
                    {
                        "value": 12,
                        "label": "12px"
                    },
                    {
                        "value": 14,
                        "label": "14px"
                    },
                    {
                        "value": 16,
                        "label": "16px"
                    },
                    {
                        "value": 18,
                        "label": "18px"
                    },
                    {
                        "value": 21,
                        "label": "21px"
                    },
                    {
                        "value": 24,
                        "label": "24px"
                    },
                    {
                        "value": 26,
                        "label": "26px"
                    },
                    {
                        "value": 28,
                        "label": "28px"
                    }
                ]
            }
        ]
    },
    {
        "name": "Home page",
        "settings": [
            {
                "type": "select",
                "label": "Number of Featured Products",
                "id": "homepage_featured_products_count",
                "force_reload": true,
                "options": [
                    {
                        "value": 0,
                        "label": "Disable"
                    },
                    {
                        "value": 1,
                        "label": "1"
                    },
                    {
                        "value": 2,
                        "label": "2"
                    },
                    {
                        "value": 3,
                        "label": "3"
                    },
                    {
                        "value": 4,
                        "label": "4"
                    },
                    {
                        "value": 5,
                        "label": "5"
                    },
                    {
                        "value": 6,
                        "label": "6"
                    },
                    {
                        "value": 7,
                        "label": "7"
                    },
                    {
                        "value": 8,
                        "label": "8"
                    },
                    {
                        "value": 9,
                        "label": "9"
                    },
                    {
                        "value": 10,
                        "label": "10"
                    },
                    {
                        "value": 11,
                        "label": "11"
                    },
                    {
                        "value": 12,
                        "label": "12"
                    }
                ]
            },
            {
                "type": "select",
                "label": "Number of Most Popular Products",
                "id": "homepage_top_products_count",
                "force_reload": true,
                "options": [
                    {
                        "value": 0,
                        "label": "Disable"
                    },
                    {
                        "value": 1,
                        "label": "1"
                    },
                    {
                        "value": 2,
                        "label": "2"
                    },
                    {
                        "value": 3,
                        "label": "3"
                    },
                    {
                        "value": 4,
                        "label": "4"
                    },
                    {
                        "value": 5,
                        "label": "5"
                    },
                    {
                        "value": 6,
                        "label": "6"
                    },
                    {
                        "value": 7,
                        "label": "7"
                    },
                    {
                        "value": 8,
                        "label": "8"
                    },
                    {
                        "value": 9,
                        "label": "9"
                    },
                    {
                        "value": 10,
                        "label": "10"
                    },
                    {
                        "value": 11,
                        "label": "11"
                    },
                    {
                        "value": 12,
                        "label": "12"
                    }
                ]
            },
            {
                "type": "select",
                "label": "Number of New Products",
                "id": "homepage_new_products_count",
                "force_reload": true,
                "options": [
                    {
                        "value": 0,
                        "label": "Disable"
                    },
                    {
                        "value": 1,
                        "label": "1"
                    },
                    {
                        "value": 2,
                        "label": "2"
                    },
                    {
                        "value": 3,
                        "label": "3"
                    },
                    {
                        "value": 4,
                        "label": "4"
                    },
                    {
                        "value": 5,
                        "label": "5"
                    },
                    {
                        "value": 6,
                        "label": "6"
                    },
                    {
                        "value": 7,
                        "label": "7"
                    },
                    {
                        "value": 8,
                        "label": "8"
                    },
                    {
                        "value": 9,
                        "label": "9"
                    },
                    {
                        "value": 10,
                        "label": "10"
                    },
                    {
                        "value": 11,
                        "label": "11"
                    },
                    {
                        "value": 12,
                        "label": "12"
                    }
                ]
            },
            {
                "type": "select",
                "label": "Number of Blog Posts",
                "id": "homepage_blog_posts_count",
                "force_reload": true,
                "options": [
                    {
                        "value": 0,
                        "label": "Disable"
                    },
                    {
                        "value": 1,
                        "label": "1"
                    },
                    {
                        "value": 2,
                        "label": "2"
                    },
                    {
                        "value": 3,
                        "label": "3"
                    },
                    {
                        "value": 4,
                        "label": "4"
                    },
                    {
                        "value": 5,
                        "label": "5"
                    },
                    {
                        "value": 6,
                        "label": "6"
                    },
                    {
                        "value": 7,
                        "label": "7"
                    },
                    {
                        "value": 8,
                        "label": "8"
                    },
                    {
                        "value": 9,
                        "label": "9"
                    },
                    {
                        "value": 10,
                        "label": "10"
                    },
                    {
                        "value": 11,
                        "label": "11"
                    },
                    {
                        "value": 12,
                        "label": "12"
                    }
                ]
            }
        ]
    },
    {
        "name": "Product page",
        "settings": [
            {
                "type": "select",
                "label": "Number of Product Reviews",
                "id": "productpage_reviews_count",
                "force_reload": true,
                "options": [
                    {
                        "value": 0,
                        "label": "Disable"
                    },
                    {
                        "value": 1,
                        "label": "1"
                    },
                    {
                        "value": 2,
                        "label": "2"
                    },
                    {
                        "value": 3,
                        "label": "3"
                    },
                    {
                        "value": 4,
                        "label": "4"
                    },
                    {
                        "value": 5,
                        "label": "5"
                    },
                    {
                        "value": 6,
                        "label": "6"
                    },
                    {
                        "value": 7,
                        "label": "7"
                    },
                    {
                        "value": 8,
                        "label": "8"
                    },
                    {
                        "value": 9,
                        "label": "9"
                    },
                    {
                        "value": 10,
                        "label": "10"
                    },
                    {
                        "value": 11,
                        "label": "11"
                    },
                    {
                        "value": 12,
                        "label": "12"
                    }
                ]
            },
            {
                "type": "select",
                "label": "Number of Related Products",
                "id": "productpage_related_products_count",
                "force_reload": true,
                "options": [
                    {
                        "value": 0,
                        "label": "Disable"
                    },
                    {
                        "value": 1,
                        "label": "1"
                    },
                    {
                        "value": 2,
                        "label": "2"
                    },
                    {
                        "value": 3,
                        "label": "3"
                    },
                    {
                        "value": 4,
                        "label": "4"
                    },
                    {
                        "value": 5,
                        "label": "5"
                    },
                    {
                        "value": 6,
                        "label": "6"
                    },
                    {
                        "value": 7,
                        "label": "7"
                    },
                    {
                        "value": 8,
                        "label": "8"
                    },
                    {
                        "value": 9,
                        "label": "9"
                    },
                    {
                        "value": 10,
                        "label": "10"
                    },
                    {
                        "value": 11,
                        "label": "11"
                    },
                    {
                        "value": 12,
                        "label": "12"
                    }
                ]
            },
            {
                "type": "select",
                "label": "Number of Customers Also Viewed Products",
                "id": "productpage_similar_by_views_count",
                "force_reload": true,
                "options": [
                    {
                        "value": 0,
                        "label": "Disable"
                    },
                    {
                        "value": 1,
                        "label": "1"
                    },
                    {
                        "value": 2,
                        "label": "2"
                    },
                    {
                        "value": 3,
                        "label": "3"
                    },
                    {
                        "value": 4,
                        "label": "4"
                    },
                    {
                        "value": 5,
                        "label": "5"
                    },
                    {
                        "value": 6,
                        "label": "6"
                    },
                    {
                        "value": 7,
                        "label": "7"
                    },
                    {
                        "value": 8,
                        "label": "8"
                    },
                    {
                        "value": 9,
                        "label": "9"
                    },
                    {
                        "value": 10,
                        "label": "10"
                    },
                    {
                        "value": 11,
                        "label": "11"
                    },
                    {
                        "value": 12,
                        "label": "12"
                    }
                ]
            }
        ]
    },
    {
        "name": "Header",
        "settings": [
            {
                "type": "color",
                "label": "Background Color",
                "id": "header-backgroundColor"
            },
            {
                "type": "color",
                "label": "Store Name Text Color",
                "id": "storeName-fontColor"
            },
            {
                "type": "heading",
                "content": "Navigation"
            },
            {
                "type": "color",
                "label": "Dropdown Background Color",
                "id": "navPage-subMenu-backgroundColor"
            },
            {
                "type": "color",
                "label": "Dropdown Text Color",
                "id": "navPage-subMenu-fontColor"
            }
        ]
    },
    {
        "name": "Footer",
        "settings": [
            {
                "type": "color",
                "label": "Background Color",
                "id": "footer-backgroundColor"
            },
            {
                "type": "color",
                "label": "Column Header Text",
                "id": "footer-heading-fontColor"
            }
        ]
    }
]
;
