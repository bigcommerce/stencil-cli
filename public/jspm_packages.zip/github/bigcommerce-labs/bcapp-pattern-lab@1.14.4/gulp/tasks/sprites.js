/* */ 
"format global";
var gulp = require('gulp'),
    config = require('../config'),
    handleErrors = require('../util/handleErrors'),
    merge = require('merge-stream'),
    spritesmith = require('gulp.spritesmith');

function images() {

    var spriteData, imgStream, cssStream;

    spriteData = gulp.src(config.spriteImages.src + '/**/*.png')
        .pipe(spritesmith({
            // This will filter out `fork@2x.png`, `github@2x.png`, ... for our retina spritesheet
            // The normal spritesheet will now receive `fork.png`, `github.png`, ...
            retinaSrcFilter: [config.spriteImages.src + '/**/*@2x.png'],
            imgName: 'design-icons-sprite.png',
            imgPath: '../images/design-icons-sprite.png',
            retinaImgName: 'design-icons-sprite@2x.png',
            retinaImgPath: '../images/design-icons-sprite@2x.png',
            cssName: '_design-icons.scss'
        }))
        .on('error', handleErrors);

    imgStream = spriteData.img
        .pipe(gulp.dest(config.images.src));

    cssStream = spriteData.css
        .pipe(gulp.dest(config.css.src + '/sprites/design-icons/'));

    return merge(imgStream, cssStream);

}

gulp.task('sprites', images);
