/* */ 
angular.module('website.bc-server-table.state', [
    'ui.router',
    'website.bc-server-table.constants',
    'website.bc-server-table.controller',
    'website.bc-server-table.sample-data.service'
])

    .config(function($stateProvider) {
        $stateProvider
            .state('components.bc-server-table', {
                controller: 'BcServerTableDemoCtrl as bcServerTableDemoCtrl',
                resolve: {
                    dataTable: function dataTableResolve($stateParams, bcServerTableFactory, DEMO_TABLE_CONFIG, DEMO_TABLE_ID, sampleData) {
                        return bcServerTableFactory
                            .create(DEMO_TABLE_ID, DEMO_TABLE_CONFIG)
                            .init({
                                stateParams: $stateParams,
                                resourceCallback: sampleData.getSampleData
                            });
                    }
                },
                templateUrl: 'src/website/js/examples/bc-server-table/bc-server-table.tpl.html',
                url: '/bc-server-table?sort-order&sort-by&page&limit&time&name'
            });
    });
