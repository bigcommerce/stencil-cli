/* */ 
angular.module('website.tabs.state', [
    'ui.router',
    'website.tabs.controller'
])

    .config(function($stateProvider) {
        $stateProvider
            .state('components.tabs', {
                url: '/tabs',
                templateUrl: 'src/website/js/examples/tabs/tabs.tpl.html',
                controller: 'TabsCtrl as tabsCtrl'
            });
    });
