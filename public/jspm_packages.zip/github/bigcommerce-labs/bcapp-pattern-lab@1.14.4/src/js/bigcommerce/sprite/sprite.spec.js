/* */ 
describe('Directive: Sprite', function() {
    var $compile,
        $scope;

    beforeEach(module('bcapp-pattern-lab-templates'));
    beforeEach(module('bcapp-pattern-lab.sprite'));

    beforeEach(inject(function($injector) {
        $compile = $injector.get('$compile');
        $scope = $injector.get('$rootScope').$new();
    }));

    function compileDirective(scope) {
        var element = angular.element('<sprite glyph="ic-icon"></sprite>');

        return $compile(element)(scope);
    }

    describe('Element', function() {

        it('should set the css class to "sprite" and "sprite--ic-icon"', function() {
            var element = compileDirective($scope);
            $scope.$digest();
            expect(element.attr('class')).toContain('sprite');
            expect(element.attr('class')).toContain('sprite--ic-icon');
        });

        it('should set aria-hidden to true"', function() {
            var element = compileDirective($scope);
            $scope.$digest();
            expect(element.attr('aria-hidden')).toBe('true');
        });

    });
});
