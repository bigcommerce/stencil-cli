/* */ 
angular.module('bcapp-pattern-lab.credit-card-types.controller', [
    'bcapp-pattern-lab.credit-card-types.constant',
])
    .controller('CreditCardTypesCtrl', function CreditCardTypesCtrl($element, CC_TYPES) {
        const ctrl = this;

        ctrl.hasSelectedType = hasSelectedType;
        ctrl.isSelectedType = isSelectedType;
        ctrl.mapToSvg = mapToSvg;

        init();

        function init() {
            $element.addClass('creditCardTypes');
        }

        /**
         * Checks whether a type has been selected (or detected by the credit-card component)
         * @return {Boolean}
         */
        function hasSelectedType() {
            return !_.isEmpty(ctrl.getSelectedType());
        }

        /**
         * Checks if the passed in ccType is the same as the selected ccType
         * @param ccType {String}
         * @return {Boolean}
         */
        function isSelectedType(ccType) {
            return ccType === ctrl.getSelectedType();
        }

        /**
         * Map the ccType to a corresponding svg name
         * @param ccType {String}
         * @return {String}
         */
        function mapToSvg(ccType) {
            return CC_TYPES[ccType];
        }
    });
