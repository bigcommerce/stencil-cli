/* */ 
describe('form-field directive', function() {
    var $compile,
        $rootScope,
        element,
        formCtrl,
        formField,
        formFieldElement;

    beforeEach(module('bcapp-pattern-lab-templates'));
    beforeEach(module('bcapp-pattern-lab.form-field'));

    beforeEach(inject(function ($injector) {
        $compile = $injector.get('$compile');
        $rootScope = $injector.get('$rootScope');
    }));

    function compileDirective(scope) {
        var tpl = angular.element(
            '<form>' +
                '<form-field property="username">' +
                    '<input name="username" ng-model="username" required />' +
                '</form-field>' +
                '<button type="submit">Submit</button>' +
            '</form>'
        );


        scope = scope || $rootScope.$new();
        element = $compile(tpl)(scope);

        scope.$digest();

        formCtrl = element.controller('form');
        formFieldElement = element.find('form-field');
        formField = formCtrl[formFieldElement.scope().property];

        return scope;
    }

    describe('form-field element', function() {
        beforeEach(function() {
            compileDirective();
        });

        it('should include the standard class', function() {
            expect(formFieldElement.hasClass('form-field')).toBe(true);
        });
    });

    describe('form controller', function() {
        it('should set the property attribute on the local scope', function() {
            compileDirective();

            expect(formFieldElement.scope().property).toEqual('username');
        });
    });

    describe('submit', function() {
        it('should automatically mark an empty required field as invalid', function() {
            compileDirective();

            element.find('button')[0].click();

            expect(formFieldElement.hasClass('form-field--error')).toBe(true);
        });

        it('should not mark a valid field as invalid', function() {
            var scope;

            scope = $rootScope.$new();
            scope.username = 'username';
            compileDirective(scope);

            element.find('button')[0].click();

            expect(formFieldElement.hasClass('form-field--error')).toBe(false);
        });
    });
});
