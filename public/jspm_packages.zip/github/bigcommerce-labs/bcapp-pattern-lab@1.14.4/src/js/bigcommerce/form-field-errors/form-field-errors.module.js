/* */ 
angular.module('bcapp-pattern-lab.form-field-errors', [
    'bcapp-pattern-lab.form-field-errors.directive'
]);
