/**
 * @name cc-expiry directive
 * @description A directive following angular-credit-card's approach to validating/formatting credit card expiration date.
 * Expect the cc-expiry ngModel to be in the format of `{ month: '05', year: '2017'}`.
 */
angular.module('bcapp-pattern-lab.credit-card.cc-expiry.directive', [])
    .directive('ccExpiry', function ccExpDirective($filter) {
        return {
            compile: function (tElem, tAttr) {
                const EXPIRATION_MAX_LENGTH = 7; // length of `MM / yy`

                tAttr.$set('autocomplete', 'cc-exp');
                tAttr.$set('maxlength', EXPIRATION_MAX_LENGTH);
                tAttr.$set('pattern', '[0-9]*'); // for mobile keyboard display

                return function ccExpiryLink(scope, tElem, tAttr, ngModelCtrl) {
                    init();

                    function init() {
                        ngModelCtrl.$parsers.unshift(parser);
                        ngModelCtrl.$formatters.push(formatter);
                        ngModelCtrl.$validators.validFutureDate = validFutureDate;

                        scope.$watch(getViewValue, renderFormattedView);
                    }

                    /**
                     * get the input's view value
                     */
                    function getViewValue() {
                        return ngModelCtrl.$viewValue;
                    }

                    /**
                     * formats the input view value to be the format `MM / yy` and re-renders view
                     */
                    function renderFormattedView(viewValue, prevViewValue) {
                        if (!viewValue) {
                            return;
                        }

                        // a new value is added (as opposed to pressing backspace)
                        const isAddition = viewValue.length > prevViewValue.length;

                        ngModelCtrl.$setViewValue(format(viewValue, isAddition));
                        ngModelCtrl.$render();
                    }

                    /**
                     * Validates whether the entered expiration date is valid
                     */
                    function validFutureDate(modelValue) {
                        const {month, year} = modelValue;

                        return isValidDate(month, year) && !isPast(month, year);
                    }

                    /**
                     * Validates whether the given month and year are number strings with length of 2 and 4 respectively
                     */
                    function isValidDate(month, year) {
                        const monthRegex = /^[0-9]{2}$/;
                        const yearRegex = /^[0-9]{4}$/;

                        return _.isString(month) &&
                               _.isString(year) &&
                               monthRegex.test(month) &&
                               yearRegex.test(year) &&
                               isValidMonth(month);
                    }

                    /**
                     * Checks whether the month is valid
                     */
                    function isValidMonth(month) {
                        month = _.parseInt(month);

                        return month > 0 && month < 13;
                    }

                    /**
                     * Checks whether the given month and date is in the past
                     */
                    function isPast(month, year) {
                        return getCurrMonthDate() > new Date(year, month - 1);
                    }

                    /**
                     * Get the date object based on current month and year
                     */
                    function getCurrMonthDate() {
                        const date = new Date();

                        return new Date(date.getFullYear(), date.getMonth());
                    }

                    /**
                     * Uses angular date filter to format date model to corresponding view format
                     */
                    function formatter(exp = {}) {
                        const month = exp.month;
                        const year = exp.year;

                        if (_.isEmpty(month) && _.isEmpty(year)) {
                            return '';
                        }

                        return $filter('date')(new Date(year, month - 1), 'MM / yy');
                    }

                    /**
                     * Parses the formatted view values to model. Converts 2 digit year to full 4 digit year
                     * @param expiration {object} The expiration object {month, year}
                     */
                    function parser(expiration) {
                        const baseYear = new Date().getFullYear().toString().slice(0, 2); // `'20'`
                        const values = expiration.split('/');
                        const month = values[0] ? values[0].trim() : '';
                        const year = values[1] ? baseYear + values[1].trim() : '';

                        return { month, year };
                    }

                    /**
                     * formats the view value to the form 'MM / yy'
                     */
                    function format(expStr, isAddition) {
                        const values = expStr.split('/');
                        const month = values[0] ? values[0].trim() : '';
                        const year = values[1] ? values[1].trim().slice(-2) : '';

                        // don't add slash
                        if ((!isAddition && !year) || month.length < 2) {
                            return month;
                        }

                        // add slash in the right spot
                        if (isAddition && !year && month.length > 2) {
                            return `${month.slice(0, 2)} / ${month.slice(2)}`;
                        }

                        return `${month} / ${year}`;
                    }
                };
            },
            require: 'ngModel',
            restrict: 'A',
        };
    });
