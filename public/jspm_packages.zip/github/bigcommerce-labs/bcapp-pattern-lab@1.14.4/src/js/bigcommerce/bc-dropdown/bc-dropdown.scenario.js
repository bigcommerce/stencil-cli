/* */ 
describe('bc-dropdown', function() {

    beforeEach(function () {
        browser.get('/js-components.html#/components/bc-dropdown');
    });

    describe('clicking the dropdown toggle element', function () {
        function testDropdown(dd) {
            dd = dd.getWebElement();
            dd.findElement(by.css('[dropdown-toggle]')).click();
            expect(dd.findElement(by.css('[bc-dropdown-menu]')).getCssValue('left')).not.toBe('-9999px');
            dd.findElement(by.css('[dropdown-toggle]')).click();
            expect(dd.findElement(by.css('[bc-dropdown-menu]')).getCssValue('display')).toBe('none');
        }

        it('should show and hide the menu when the toggle is clicked (standard dropdowns)', function () {
            testDropdown(element(by.css('#dropdown-standard')));
        });

        it('should show and hide the menu when the toggle is clicked (image with dropdown)', function () {
            testDropdown(element(by.css('#dropdown-image')));
        });

        it('should show and hide the menu when the toggle is clicked (split button dropdowns)', function () {
            testDropdown(element(by.css('#dropdown-splitButton')));
        });
    });
});
