/**
 * @description Used to create a toggle switch for forms
 * @example
    <switch ng-model="ctrl.switchModel1"></switch>

    <switch
        toggle-off-text="Off"
        toggle-on-text="On"
        ng-model="ctrl.switchModel2">
    </switch>

    <switch
        has-icon
        ng-model="ctrl.switchModel3">
    </switch>

    <switch
        is-important
        left-label="Down for Maintenance"
        right-label="Open"
        ng-model="ctrl.switchModel4">
    </switch>
 */
angular.module('bcapp-pattern-lab.switch.directive', [])
    .directive('switch', function switchDirective() {

        function getUniqueID(idPrefix) {
            return _.uniqueId(idPrefix);
        }

        return {
            restrict: 'E',
            templateUrl: 'src/js/bigcommerce/switch/switch.tpl.html',
            require: 'ngModel',
            scope: {
                ariaDescription: '@',
                labelText: '@',
                leftDescription: '@',
                ngFalseValue: '@',
                ngTrueValue: '@',
                rightDescription: '@',
                toggleOffLabel: '@',
                toggleOnLabel: '@',
                uniqueId: '@'
            },
            bindToController: true,
            controllerAs: 'switchCtrl',
            compile: function switchDirectiveCompile(tElem, tAttrs) {
                var checkboxElem = tElem.find('input');

                if (tAttrs.ngFalseValue) {
                    checkboxElem.attr('ng-false-value', tAttrs.ngFalseValue);
                }

                if (tAttrs.ngTrueValue) {
                    checkboxElem.attr('ng-true-value', tAttrs.ngTrueValue);
                }

                return function switchDirectivePostLink(scope, element, attrs, ngModelCtrl) {
                    scope.switchCtrl.init(ngModelCtrl);
                };
            },
            controller: function switchDirectiveCtrl($scope, $element, $attrs) {
                var ctrl = this;

                // state
                ctrl.isImportant = angular.isDefined($attrs.isImportant) && $attrs.isImportant !== 'false';
                ctrl.hasIcon = angular.isDefined($attrs.hasIcon) && $attrs.hasIcon !== 'false';

                // labels
                ctrl.labelText = $attrs.toggleOffLabel;

                // ids
                ctrl.uniqueId = getUniqueID('switch-');
                ctrl.ariaDescriptionID = getUniqueID('switch-ariaDescription-');

                ctrl.init = init;
                ctrl.updateModel = updateModel;

                function init(ngModelCtrl) {
                    ctrl.ngModelCtrl = ngModelCtrl;
                    ctrl.value = ctrl.ngModelCtrl.$modelValue;

                    $scope.$watch('switchCtrl.ngModelCtrl.$modelValue', function switchValueChanged(newValue) {
                        ctrl.value = newValue;

                        ctrl.isChecked = _.isString(newValue) ? "'" + newValue + "'" === ctrl.ngTrueValue : newValue;
                        ctrl.labelText = !!ctrl.isChecked ? ctrl.toggleOnLabel: ctrl.toggleOffLabel;
                    });
                }

                function updateModel() {
                    ctrl.ngModelCtrl.$setViewValue(ctrl.value);
                }

            }
        };
    });
