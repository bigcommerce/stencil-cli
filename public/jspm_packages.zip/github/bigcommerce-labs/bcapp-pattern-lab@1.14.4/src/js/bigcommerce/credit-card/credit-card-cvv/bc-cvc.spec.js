/* */ 
describe('bcCvc directive', function() {
    var directiveHtml = '<input cc-cvc bc-cvc ng-model="cvv" ng-required="isRequired"/>',
        $compile,
        scope,
        element;

    beforeEach(module('bcapp-pattern-lab.credit-card.bc-cvc'));

    beforeEach(inject(function($injector) {
        $compile = $injector.get('$compile');
        scope = $injector.get('$rootScope').$new();
    }));

    function compileDirective(scope, tpl) {
        var element = angular.element(tpl || directiveHtml),
            compiledElement = $compile(element)(scope);

        scope.$digest();

        return compiledElement;
    }

    describe('the compiled html', function() {
        it('should not validate for ccCvc if ng-required is false', function() {
            scope.isRequired = false;
            element = compileDirective(scope);

            expect(element.hasClass('ng-invalid-cc-cvc')).toBe(false);
        });

        it('should validate for ccCvc if ng-required is true', function() {
            scope.isRequired = true;
            element = compileDirective(scope);

            expect(element.hasClass('ng-invalid-cc-cvc')).toBe(true);
        });
    });
});
