/* */ 
angular.module('bcapp-pattern-lab.checkbox-list.directive', [
    'bcapp-pattern-lab.checkbox-list.controller'
])

    /**
     * A directive for collating values from an array of checkboxes.
     *
     * @require ngModel
     * @param {Array.<string|number|Object>} checkboxList - Array to hold selected values
     * @param {*} value - Value to add to checkboxList
     * @param {function(selectedValues, oldSelectedValues} [checkboxListChange] - Optional onChange callback
     *
     * @example:
     * ```html
     * <div ng-repeat="option in options">
     *     <input type="checkbox" 
     *         name="option{{ option.id }}"
     *         value="option.id" 
     *         checkbox-list="selectedValues" 
     *         checkbox-list-change="onChange(selectedValues)" 
     *         ng-model="option.checked"
     *     />
     * </div>
     * ```
     * 
     * ```js
     * scope.selectedValues = [];
     * scope.options = [
     *     {
     *         id: 1,
     *         label: 'Option 1'
     *     },
     *     {
     *         id: 2,
     *         label: 'Option 2'
     *     },
     *     {
     *         id: 3,
     *         label: 'Option 3'
     *     }
     * ];
     * 
     * scope.onChange = function onChange(selectedValues) {
     *     console.log(selectedValues);
     * };
     * ```
     * 
     * When options[0] and options[1] are checked, selectedValues should be [1, 2]
     * and onChange will be evoked. This directive also works with an array of primitive values.
     * i.e.: scope.options = ["a", "b", "c"].
     */

    .directive('checkboxList', function checkboxListDirective() {
        return {
            restrict: 'A',
            require: 'ngModel',
            controller: 'CheckboxListCtrl',
            controllerAs: 'checkboxListCtrl',
            bindToController: true,
            scope: {
                onChange: '&checkboxListChange',
                selectedValues: '=checkboxList',
                value: '=',
                ngValue: '='
            }
        };
    });
