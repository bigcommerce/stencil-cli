/* */ 
describe('bc-dropdown directive', function () {
    var $compile,
        $scope;

    beforeEach(module('mm.foundation'));
    beforeEach(module('bcapp-pattern-lab.bc-dropdown'));

    beforeEach(inject(function ($injector) {
        $compile = $injector.get('$compile');
        $scope = $injector.get('$rootScope').$new();
    }));

    function compileDirective(scope, tpl) {
        tpl = tpl || ([
            '<div bc-dropdown>',
            '    <a bc-dropdown-toggle>Click here for a dropdown<\/a>',
            '    <ul bc-dropdown-menu>',
            '        <li>One<\/li>',
            '        <li>Two<\/li>',
            '        <li>Three<\/li>',
            '    <\/ul>',
            '<\/div>'
        ]).join('');

        var element = angular.element(tpl);

        return $compile(element)(scope);
    }

    describe('getUniqueId method', function () {
        it('should be exposed on the controller', function () {
            var element = compileDirective($scope);
            $scope.$digest();
            expect(element.controller('bcDropdown').getUniqueId).toBeDefined();
        });

        it('should return the same id each time it is called', function () {
            var element = compileDirective($scope),
                ctrl,
                id1,
                id2,
                id3;
            $scope.$digest();
            ctrl = element.controller('bcDropdown');

            id1 = ctrl.getUniqueId();
            id2 = ctrl.getUniqueId();
            id3 = ctrl.getUniqueId();

            expect([id1, id2, id3]).toEqual([id1, id1, id1]);
        });

        it('should create differerent ids for each instance of the directive', function () {
            var e1 = compileDirective($scope),
                e2 = compileDirective($scope),
                id1,
                id2,
                ctrl1,
                ctrl2;

            $scope.$digest();
            ctrl1 = e1.controller('bcDropdown');
            ctrl2 = e2.controller('bcDropdown');

            id1 = ctrl1.getUniqueId();
            id2 = ctrl2.getUniqueId();


            expect(id1).not.toEqual(id2);
        });
    });

    describe('bc-dropdown-toggle', function() {
        var element, toggle;
        beforeEach(function() {
            element = compileDirective($scope);
            $scope.$digest();
            toggle = element.find('a');
        });

        it('should remove the bc-dropdown-toggle attribute from the element', function() {
            expect(toggle.attr('bc-dropdown-toggle')).toBeUndefined();
        });

        it('should add the dropdown-toggle directive to the element with the proper selector', function() {
            var sel = '#' + element.controller('bcDropdown').getUniqueId();
            expect(toggle.attr('dropdown-toggle')).toEqual(sel);
        });

        it('should compile the dropdown-toggle angular-foundation directive', function() {
            var toggleCtrl = toggle.controller('dropdownToggle');
            expect(toggleCtrl).toBeDefined();
        });
    });

    describe('bc-dropdown-menu', function() {
        var element, menu;
        beforeEach(function() {
            element = compileDirective($scope);
            $scope.$digest();
            menu = element.find('ul');
        });

        it('should add the dropdown-menu class', function() {
            expect(menu.hasClass('dropdown-menu')).toBe(true);
        });

        it('should add the unique id to the element', function() {
            var id = element.controller('bcDropdown').getUniqueId();
            expect(menu.attr('id')).toEqual(id);
        });
    });

});
