/* */ 
angular.module('bcapp-pattern-lab.icon', [
    'bcapp-pattern-lab.icon.directive'
]);
