/* */ 
'use strict';

angular.module('bcapp-pattern-lab', ['gettext', 'ngAnimate', 'ngMessages', 'mm.foundation', 'bcapp-pattern-lab-templates', 'bcapp-pattern-lab.bc-datepicker', 'bcapp-pattern-lab.bc-dropdown', 'bcapp-pattern-lab.bc-modal', 'bcapp-pattern-lab.bc-pagination', 'bcapp-pattern-lab.bc-server-table', 'bcapp-pattern-lab.checkbox-list', 'bcapp-pattern-lab.credit-card', 'bcapp-pattern-lab.credit-card-types', 'bcapp-pattern-lab.form', 'bcapp-pattern-lab.form-field', 'bcapp-pattern-lab.icon', 'bcapp-pattern-lab.loading-notification', 'bcapp-pattern-lab.loading-overlay', 'bcapp-pattern-lab.sprite', 'bcapp-pattern-lab.switch', 'bcapp-pattern-lab.util']);
/* globals moment */
'use strict';

angular.module('bcapp-pattern-lab.bc-datepicker.constants', []).constant('BC_DATEPICKER_DEFAULTS', {
    dayFormat: 'D',
    inputFormat: moment.localeData().longDateFormat('L'),
    styles: {
        back: 'datepicker-back',
        container: 'datepicker',
        date: 'datepicker-date',
        dayBody: 'datepicker-days-body',
        dayBodyElem: 'datepicker-day',
        dayConcealed: 'datepicker-day-concealed',
        dayDisabled: 'is-disabled',
        dayHead: 'datepicker-days-head',
        dayHeadElem: 'datepicker-day-name',
        dayPrevMonth: 'datepicker-day-prev-month',
        dayNextMonth: 'datepicker-day-next-month',
        dayRow: 'datepicker-days-row',
        dayTable: 'datepicker-days',
        month: 'datepicker-month',
        monthLabel: 'datepicker-month',
        next: 'datepicker-next',
        positioned: 'datepicker-attachment',
        selectedDay: 'is-selected',
        selectedTime: 'datepicker-time-selected',
        time: 'datepicker-time',
        timeList: 'datepicker-time-list',
        timeOption: 'datepicker-time-option'
    },
    time: false,
    weekdayFormat: 'short'
});
/* globals rome */
'use strict';

angular.module('bcapp-pattern-lab.bc-datepicker.directive', ['bcapp-pattern-lab.bc-datepicker.constants']).directive('bcDatepicker', function bcDatepickerDirective(BC_DATEPICKER_DEFAULTS) {
    return {
        restrict: 'A',
        require: 'ngModel',
        scope: {
            options: '=?'
        },

        link: function datepickerLinkFunction(scope, element, attrs, ngModel) {
            if (scope.options === undefined) {
                scope.options = {};
            }

            // Add defaults to the options object
            _.defaults(scope.options, BC_DATEPICKER_DEFAULTS);

            // Create a new rome (calendar) instance
            scope.calendar = rome(element[0], scope.options);

            // On 'data' event set ngModel to the passed value
            scope.calendar.on('data', function onData(value) {
                ngModel.$setViewValue(value);
                scope.$apply();
            });

            scope.calendar.on('ready', function onReady(options) {
                if (attrs.placeholder === undefined) {
                    attrs.$set('placeholder', options.inputFormat);
                }
            });

            // Removing calendar event listeners
            element.on('$destroy', function onDestroy() {
                scope.calendar.destroy();
            });
        }
    };
});
'use strict';

angular.module('bcapp-pattern-lab.bc-datepicker', ['bcapp-pattern-lab.bc-datepicker.directive']);
'use strict';

angular.module('bcapp-pattern-lab.bc-dropdown-menu.directive', []).directive('bcDropdownMenu', function bcDropdownMenuDirective() {
    return {
        restrict: 'A',
        require: '^bcDropdown',
        compile: function bcDropdownMenuDirectiveCompile(tElement) {
            tElement.addClass('dropdown-menu');

            return function bcDropdownMenuDirectiveLink(scope, element, attrs, bcDropdownCtrl) {
                element.attr('id', bcDropdownCtrl.getUniqueId());
            };
        }
    };
});
'use strict';

angular.module('bcapp-pattern-lab.bc-dropdown-toggle.directive', []).directive('bcDropdownToggle', function bcDropdownToggleDirective($compile) {
    return {
        restrict: 'A',
        terminal: true,
        priority: 1001, // set higher than ng-repeat to prevent double compilation
        require: '^bcDropdown',
        compile: function bcDropdownToggleDirectiveCompile(tElement) {
            tElement.removeAttr('bc-dropdown-toggle');

            return function bcDropdownToggleDirectiveLink(scope, element, attrs, bcDropdownCtrl) {
                element.attr('dropdown-toggle', '#' + bcDropdownCtrl.getUniqueId());
                $compile(element)(scope);
            };
        }
    };
});
'use strict';

angular.module('bcapp-pattern-lab.bc-dropdown.directive', []).directive('bcDropdown', function bcDropdownDirective() {
    return {
        restrict: 'EA',
        controller: function bcDropdownDirectiveController() {
            var ctrl = this,
                uniqueId;

            ctrl.getUniqueId = getUniqueId;

            function getUniqueId() {
                if (!uniqueId) {
                    uniqueId = _.uniqueId('bc-dropdown-');
                }
                return uniqueId;
            }
        }
    };
});
'use strict';

angular.module('bcapp-pattern-lab.bc-dropdown', ['bcapp-pattern-lab.bc-dropdown.directive', 'bcapp-pattern-lab.bc-dropdown-toggle.directive', 'bcapp-pattern-lab.bc-dropdown-menu.directive']);
'use strict';

angular.module('bcapp-pattern-lab.bc-pagination.directive', []).directive('bcPagination', function bcPaginationDirective($parse) {
    return {
        restrict: 'E',
        scope: true,
        templateUrl: 'src/js/bigcommerce/bc-pagination/bc-pagination.tpl.html',

        compile: function bcPaginationCompile(tElement, tAttrs) {
            var attrObj = {};

            // Since this is a wrapper of angular-foundation's pagination directive we need to copy all
            // of the attributes passed to our directive and store them in the attrObj.
            _.each(tAttrs.$attr, function (key) {
                if (key !== 'class') {
                    attrObj[key] = tElement.attr(key);
                }
            });

            // Adding our custom callback to the attrObj, angular-foundation will call this function
            // when a page number is clicked in the pagination.
            attrObj['on-select-page'] = 'paginationCallback(page)';

            // Add all the attributes to angular-foundation's pagination directive
            tElement.find('pagination').attr(attrObj);

            return function bcPaginationLink($scope, element, attrs) {
                var onChangeParseGetter = $parse(attrs.onChange),
                    defaultLimits = [10, 20, 30, 50, 100];

                $scope.setLimit = function (limit, event) {
                    event.preventDefault();
                    limit = _.parseInt(limit);
                    $parse(attrs.itemsPerPage).assign($scope.$parent, limit);
                    $scope.paginationCallback(1, limit);
                };

                $scope.getCurrentPage = function () {
                    return $parse(attrs.page)($scope.$parent);
                };

                $scope.getCurrentLimit = function () {
                    return $parse(attrs.itemsPerPage)($scope.$parent);
                };

                $scope.getItemsPerPage = function () {
                    return $parse(attrs.itemsPerPage)($scope.$parent) || 0;
                };

                $scope.getTotalItems = function () {
                    return $parse(attrs.totalItems)($scope.$parent) || 0;
                };

                $scope.show = function () {
                    return $scope.getTotalItems() > $scope.getItemsPerPage();
                };

                $scope.showLimits = function () {
                    return $scope.show() && $parse(attrs.showLimits)($scope.$parent) !== false;
                };

                $scope.getLimits = function () {
                    var limits = $parse(attrs.limits)($scope.$parent);

                    if (!Array.isArray(limits)) {
                        return defaultLimits;
                    }

                    return limits;
                };

                $scope.paginationCallback = function (page, limit) {
                    var additionalScopeProperties = {
                        limit: limit || $scope.getCurrentLimit(),
                        page: page
                    },
                        onChangeParseResult;

                    $parse(attrs.page).assign($scope.$parent, page);

                    onChangeParseResult = onChangeParseGetter($scope, additionalScopeProperties);

                    // if the onChange string is a function and not an expression: call it with the additionalScopeProperties obj (for backwards compatability)
                    // else the expression has already been ran: do nothing
                    if (typeof onChangeParseResult === 'function') {
                        onChangeParseResult(additionalScopeProperties);
                    }
                };
            };
        }
    };
});
'use strict';

angular.module('bcapp-pattern-lab.bc-pagination', ['bcapp-pattern-lab.bc-pagination.directive']);
'use strict';

angular.module('bcapp-pattern-lab.bc-server-table.controller', ['bcapp-pattern-lab.bc-server-table.service']).controller('BcServerTableCtrl', function BcServerTableCtrl($attrs, $log, $parse, $scope, BcServerTable) {
    var ctrl = this,
        bcServerTablePrototype = BcServerTable.prototype;

    // Call the BcServerTable constructor on the controller
    // in order to set all the controller properties directly.
    // This is here for backwards compatability purposes.
    BcServerTable.call(ctrl, null, $parse($attrs.tableConfig)($scope));

    // controller functions
    ctrl.createParamsObject = bcServerTablePrototype.createParamsObject;
    ctrl.fetchResource = bcServerTablePrototype.fetchResource;
    ctrl.getSelectedRows = bcServerTablePrototype.getSelectedRows;
    ctrl.init = bcServerTablePrototype.init;
    ctrl.isRowSelected = bcServerTablePrototype.isRowSelected;
    ctrl.loadStateParams = bcServerTablePrototype.loadStateParams;
    ctrl.selectAllRows = bcServerTablePrototype.selectAllRows;
    ctrl.setPaginationValues = bcServerTablePrototype.setPaginationValues;
    ctrl.setRows = bcServerTablePrototype.setRows;
    ctrl.setSortingValues = bcServerTablePrototype.setSortingValues;
    ctrl.updatePage = _.bind(bcServerTablePrototype.updatePage, ctrl);
    ctrl.updateSort = bcServerTablePrototype.updateSort;
    ctrl.updateTable = bcServerTablePrototype.updateTable;
    ctrl.validateResource = bcServerTablePrototype.validateResource;

    init();

    function init() {
        var resourceCallback;

        resourceCallback = $parse($attrs.resourceCallback)($scope);
        if (!_.isFunction(resourceCallback)) {
            $log.error('bc-server-table directive: resource-callback must be a function.');
            return;
        }
        ctrl.resourceCallback = resourceCallback;

        ctrl.init();
    }
});
'use strict';

angular.module('bcapp-pattern-lab.bc-server-table.directive', ['bcapp-pattern-lab.bc-server-table.controller', 'bcapp-pattern-lab.bc-server-table.sort-by.directive', 'ui.router'])
/**
 * The bc-server-table directive creates a data table that handles
 * server side pagination, sorting, and filtering. It exposes a few scope variables,
 * that can be used to display the table content with custom markup (see example
 * in the pattern lab for an actual implementation of the bc-server-table).
 *
 * The following attributes can be passed in order to configure the bc-server-table:
 * - resource-callback (required)
 * - tableConfig (optional)
 *
 * - resource-callback - a function that returns a promise which is resovled
 * with an object of the following format:
 *      {
 *          rows: Array,
 *          pagination: {
 *              page: Number,
 *              limit: Number,
 *              total: Number
 *          }
 *      }
 *
 * This directive exposes a scope variable called bcServerTable that
 * can be used to display content, and implement additional functionality
 * to the table (such as pagination, sorting, and selection logic).
 *
 * - bcServerTable.rows
 *      - Can be used with ng-repeat to display the data
 * - bcServerTable.filters
 *      - Can be used to change/update filters. These filters must appear
 *        in the state definition in order to work correctly.
 * - bcServerTable.updateTable()
 *      - Perform a state transistion with the current table info
 * - bcServerTable.pagination
 *      - exposes page, limit, and total
 * - bcServerTable.setPaginationValues(pagination)
 *      - convenience method for setting pagination values at once.
 *
 * - bcServerTable.selectedRows
 *      - an map object with unique id's as keys and boolean values as the selected state
 * - bcServerTable.allSelected
 *      - a boolean value used to determine if all rows were selected or cleared
 * - bcServerTable.selectAllRows()
 *      - toggle all rows selection state
 * - bcServerTable.isRowSelected(row)
 *      - helper function to determine if a row is selected
 * - bcServerTable.getSelectedRows()
 *      - function that returns an array of row objects that are currently selected
 *
 */
.directive('bcServerTable', function bcServerTableDirective($parse) {
    var directive = {
        restrict: 'EA',
        controller: 'BcServerTableCtrl as bcServerTable',
        link: function bcServerTableLink($scope, element, attrs, bcServerTableCtrl) {
            if (attrs.tableController) {
                // expose bcServerTableCtrl to tableController if it exists
                $parse(attrs.tableController).assign($scope, bcServerTableCtrl);
            }
        }
    };

    return directive;
});
'use strict';

angular.module('bcapp-pattern-lab.bc-server-table', ['bcapp-pattern-lab.bc-server-table.directive', 'bcapp-pattern-lab.bc-server-table.sort-by.directive', 'bcapp-pattern-lab.bc-server-table-factory.service']);
'use strict';

angular.module('bcapp-pattern-lab.bc-server-table.sort-by.directive', ['bcapp-pattern-lab.bc-server-table-factory.service']).directive('bcSortBy', function bcSortByDirective($log, bcServerTableFactory) {
    var directive = {
        templateUrl: 'src/js/bigcommerce/bc-server-table/bc-sort-by.tpl.html',
        restrict: 'E',
        transclude: true,
        scope: {
            sortValue: '@',
            columnName: '@',
            tableId: '@'
        },
        require: '?^^bcServerTable',
        link: bcSortByDirectiveLink
    };

    function bcSortByDirectiveLink(scope, element, attrs, bcServerTableCtrl) {
        var bcServerTable, sortDirValues;

        if (scope.tableId) {
            bcServerTable = bcServerTableFactory.get(scope.tableId);
        } else if (bcServerTableCtrl) {
            bcServerTable = bcServerTableCtrl;
        } else {
            $log.error('bc-sort-by directive requires a table-id, or a parent bcServerTableCtrl directive.');
        }

        sortDirValues = bcServerTable.tableConfig.sortDirValues;

        scope.asc = sortDirValues.asc;
        scope.desc = sortDirValues.desc;
        scope.sortBy = bcServerTable.sortBy;
        scope.sortDir = bcServerTable.sortDir;
        scope.sort = sort;

        function sort($event) {
            var sortBy, sortDir;

            if ($event) {
                $event.preventDefault();
            }

            if (bcServerTable.sortBy === scope.sortValue) {
                sortBy = bcServerTable.sortBy;
                sortDir = bcServerTable.sortDir === scope.asc ? scope.desc : scope.asc;
            } else {
                sortBy = scope.sortValue;
                sortDir = scope.asc;
            }

            bcServerTable.updateSort(sortBy, sortDir);
        }
    }

    return directive;
});
'use strict';

angular.module('bcapp-pattern-lab.checkbox-list.controller', []).controller('CheckboxListCtrl', function CheckboxListCtrl($attrs, $element, $log, $parse, $scope) {
    var ctrl = this,
        falseValue = $parse($attrs.ngFalseValue)(ctrl) || false,
        trueValue = $parse($attrs.ngTrueValue)(ctrl) || true,
        ngModel = $element.controller('ngModel');

    init();

    // Getters
    function getModelValue() {
        return ngModel.$modelValue;
    }

    function getValue() {
        return ctrl.value || ctrl.ngValue;
    }

    function getSelectedValues() {
        return ctrl.selectedValues;
    }

    // Setters
    function updateModelValue(modelValue) {
        ngModel.$setViewValue(modelValue);
        ngModel.$commitViewValue();
        ngModel.$render();
    }

    function updateSelectedValues(modelValue) {
        if (modelValue === trueValue) {
            addToSelectedValues();
        } else if (modelValue === falseValue) {
            removeFromSelectedValues();
        }
    }

    function addToSelectedValues() {
        var isIncluded = _.include(ctrl.selectedValues, getValue());

        if (!isIncluded) {
            ctrl.selectedValues.push(getValue());
        }
    }

    function removeFromSelectedValues() {
        var index = _.indexOf(ctrl.selectedValues, getValue());

        if (index !== -1) {
            ctrl.selectedValues.splice(index, 1);
        }
    }

    // Watchers
    function modelValueWatch(modelValue, oldModelValue) {
        var oldSelectedValues, selectedValuesChanged;

        // When ngModel value changes
        if (_.isUndefined(modelValue) || modelValue === oldModelValue) {
            return;
        }

        // Retain a shallow copy of selectedValues before update
        oldSelectedValues = ctrl.selectedValues.slice();

        // Update selectedValues
        updateSelectedValues(modelValue);

        // Determine if selectedValues array has changed
        selectedValuesChanged = !!_.xor(ctrl.selectedValues, oldSelectedValues).length;

        // If changed, evoke delegate method (if defined)
        if (ctrl.onChange && selectedValuesChanged) {
            ctrl.onChange({
                selectedValues: ctrl.selectedValues,
                oldSelectedValues: oldSelectedValues
            });
        }
    }

    function selectedValuesWatch(selectedValues) {
        // When selectedValues collection changes
        var isIncluded = _.include(selectedValues, getValue()),
            modelValue = getModelValue();

        if (isIncluded && modelValue !== trueValue) {
            updateModelValue(trueValue);
        } else if (!isIncluded && modelValue !== falseValue) {
            updateModelValue(falseValue);
        }
    }

    // Initializer
    function init() {
        if ($attrs.type !== 'checkbox') {
            $log.error('checkbox-list directive: element must be <input type="checkbox">');

            return;
        }

        $scope.$watch(getModelValue, modelValueWatch);
        $scope.$watchCollection(getSelectedValues, selectedValuesWatch);
    }
});
'use strict';

angular.module('bcapp-pattern-lab.checkbox-list.directive', ['bcapp-pattern-lab.checkbox-list.controller'])

/**
 * A directive for collating values from an array of checkboxes.
 *
 * @require ngModel
 * @param {Array.<string|number|Object>} checkboxList - Array to hold selected values
 * @param {*} value - Value to add to checkboxList
 * @param {function(selectedValues, oldSelectedValues} [checkboxListChange] - Optional onChange callback
 *
 * @example:
 * ```html
 * <div ng-repeat="option in options">
 *     <input type="checkbox" 
 *         name="option{{ option.id }}"
 *         value="option.id" 
 *         checkbox-list="selectedValues" 
 *         checkbox-list-change="onChange(selectedValues)" 
 *         ng-model="option.checked"
 *     />
 * </div>
 * ```
 * 
 * ```js
 * scope.selectedValues = [];
 * scope.options = [
 *     {
 *         id: 1,
 *         label: 'Option 1'
 *     },
 *     {
 *         id: 2,
 *         label: 'Option 2'
 *     },
 *     {
 *         id: 3,
 *         label: 'Option 3'
 *     }
 * ];
 * 
 * scope.onChange = function onChange(selectedValues) {
 *     console.log(selectedValues);
 * };
 * ```
 * 
 * When options[0] and options[1] are checked, selectedValues should be [1, 2]
 * and onChange will be evoked. This directive also works with an array of primitive values.
 * i.e.: scope.options = ["a", "b", "c"].
 */

.directive('checkboxList', function checkboxListDirective() {
    return {
        restrict: 'A',
        require: 'ngModel',
        controller: 'CheckboxListCtrl',
        controllerAs: 'checkboxListCtrl',
        bindToController: true,
        scope: {
            onChange: '&checkboxListChange',
            selectedValues: '=checkboxList',
            value: '=',
            ngValue: '='
        }
    };
});
'use strict';

angular.module('bcapp-pattern-lab.checkbox-list', ['bcapp-pattern-lab.checkbox-list.directive']);
/**
 * @name credit-card directive
 * @description Component containing cc number, cvc, name, and expiry. Has an isolated scope with no controller.
 * @require form
 *
 * @param ccData {object} Contains ccNumber, ccType, ccExpiry, and ccName
 * @param ccConfig {object} The configuration object. Currently supporting `cardCode` and `fullName`, both boolean to indicate
 * whether the respective fields should be shown. Another field `cardCodeRequired` determines whether the cvc field is required.
 * This only matters when cardCode is set to true.
 */
'use strict';

angular.module('bcapp-pattern-lab.credit-card.directive', ['bcapp-pattern-lab.icon']).directive('creditCard', function creditCardDirective($compile, $templateCache) {
    var cvvTooltipTemplate = $templateCache.get('src/js/bigcommerce/credit-card/credit-card-cvv/tooltip.tpl.html');

    return {
        link: function creditCardLink(scope, elem, attr, formCtrl) {
            var cvvTooltipElement = $compile(cvvTooltipTemplate)(scope);
            var defaultConfig = {
                cardCode: true,
                cardCodeRequired: true,
                fullName: true
            };

            scope.ccConfig = _.defaults(scope.ccConfig, defaultConfig);
            scope.getCvvTooltipHtml = getCvvTooltipHtml;

            /**
             * Return the html for the tooltip. Using outerHTML to also include the root element
             * @return {String} Html string for the cvv tooltip template
             */
            function getCvvTooltipHtml() {
                return cvvTooltipElement[0].outerHTML;
            }

            /**
             * The credit card type is deduced by the `ccNumber` directive. This is in turn exposed
             * as `$ccEagerType` on the input control element. Watch for changes and bind the type to the corresponding
             * value on ccData.
             */
            scope.$watch(getCcType, setCcType);

            scope.formCtrl = formCtrl;

            function getCcType() {
                return formCtrl.ccNumber.$ccEagerType;
            }

            function setCcType(type) {
                scope.ccData.ccType = type;
            }
        },
        require: '^form',
        restrict: 'EA',
        scope: {
            ccData: '=',
            ccConfig: '='
        },
        templateUrl: 'src/js/bigcommerce/credit-card/credit-card.tpl.html'
    };
});
'use strict';

angular.module('bcapp-pattern-lab.credit-card', ['credit-cards', 'bcapp-pattern-lab.credit-card.bc-cvc', 'bcapp-pattern-lab.credit-card.cc-expiry', 'bcapp-pattern-lab.credit-card.directive', 'gettext']);
'use strict';

angular.module('bcapp-pattern-lab.credit-card-types.constant', []).constant('CC_TYPES', {
    'American Express': 'amex',
    'Diners Club': 'dinersclub',
    'Discover': 'discover',
    'MasterCard': 'mastercard',
    'Visa': 'visa'
});
'use strict';

angular.module('bcapp-pattern-lab.credit-card-types.controller', ['bcapp-pattern-lab.credit-card-types.constant']).controller('CreditCardTypesCtrl', function CreditCardTypesCtrl($element, CC_TYPES) {
    var ctrl = this;

    ctrl.hasSelectedType = hasSelectedType;
    ctrl.isSelectedType = isSelectedType;
    ctrl.mapToSvg = mapToSvg;

    init();

    function init() {
        $element.addClass('creditCardTypes');
    }

    /**
     * Checks whether a type has been selected (or detected by the credit-card component)
     * @return {Boolean}
     */
    function hasSelectedType() {
        return !_.isEmpty(ctrl.getSelectedType());
    }

    /**
     * Checks if the passed in ccType is the same as the selected ccType
     * @param ccType {String}
     * @return {Boolean}
     */
    function isSelectedType(ccType) {
        return ccType === ctrl.getSelectedType();
    }

    /**
     * Map the ccType to a corresponding svg name
     * @param ccType {String}
     * @return {String}
     */
    function mapToSvg(ccType) {
        return CC_TYPES[ccType];
    }
});
/**
 * @name credit-card-types directive
 * @description Component displaying and greying out credit card type icons based on the selected credit card type.
 * `.is-active` is added to the corresponding selected credit card type. `.not-active` is added for the other
 * types. If no credit card types has been selected, then neither `.is-active` and `.not-active` will be added at all.
 *
 * @param selectedType {String} Credit card type. Valid types are 'Visa', 'MasterCard', 'Diners Club', 'Discover', and 'American Express'
 * @param supportedTypes {Array} Array of credit card types to display. The card types use the same strings: 'American Express', 'Discover', 'MasterCard', 'Visa'
 */
'use strict';

angular.module('bcapp-pattern-lab.credit-card-types.directive', ['bcapp-pattern-lab.credit-card-types.controller']).directive('creditCardTypes', function creditCardTypesDirective() {
    return {
        bindToController: true,
        controller: 'CreditCardTypesCtrl as creditCardTypesCtrl',
        restrict: 'E',
        scope: {
            getSelectedType: '&selectedType',
            getSupportedTypes: '&supportedTypes'
        },
        templateUrl: 'src/js/bigcommerce/credit-card-types/credit-card-types.tpl.html'
    };
});
'use strict';

angular.module('bcapp-pattern-lab.credit-card-types', ['bcapp-pattern-lab.credit-card-types.constant', 'bcapp-pattern-lab.credit-card-types.controller', 'bcapp-pattern-lab.credit-card-types.directive']);
'use strict';

angular.module('bcapp-pattern-lab.form.directive', []).directive('form', function formDirective() {
    return {
        restrict: 'E',
        link: function formLink(scope, element, attrs) {
            element.addClass('form');
            element.attr('novalidate', '');

            // Use disable-auto-focus="true" to turn off automatic error focusing
            if (!attrs.disableAutoFocus) {
                element.on('submit', function formAutoFocusSubmitHandler() {
                    var invalidField = element[0].querySelector('.ng-invalid');

                    if (invalidField) {
                        invalidField.focus();

                        // Auto-select existing text for fields that support it (text, email, password, etc.)
                        if (invalidField.select) {
                            invalidField.select();
                        }
                    }
                });
            }
        }
    };
});
'use strict';

angular.module('bcapp-pattern-lab.form', ['bcapp-pattern-lab.form.directive']);
'use strict';

angular.module('bcapp-pattern-lab.form-field.directive', []).directive('formField', function formFieldDirective($log) {
    return {
        require: '^form',
        restrict: 'EA',
        scope: true,
        link: {
            pre: function formFieldLink(scope, element, attrs) {
                // Inherited by the form-field-errors directive to avoid redeclaration
                scope.property = attrs.property;
            },

            post: function formFieldLink(scope, element, attrs, formCtrl) {
                // Locates and watches the matching input/select/etc (based on its name attribute) in the parent form
                var property = attrs.property,
                    propertyValidFn = function propertyValidFn() {
                    return formCtrl[property].$valid;
                },
                    formSubmittedFn = function formSubmittedFn() {
                    return formCtrl.$submitted;
                };

                element.addClass('form-field');

                // If a property wasn't provided, we can't do much else
                if (!property) {
                    return;
                }

                // If a property was provided, but no ng-model was defined for the field, validation won't work
                if (!formCtrl[property]) {
                    return $log.info('Form fields containing inputs without an ng-model property will not be validated');
                }

                init();

                function init() {
                    // Update the interface if the form is submitted or the property's validity state changes
                    scope.$watch(formSubmittedFn, checkValidity);
                    scope.$watch(propertyValidFn, checkValidity);
                }

                function checkValidity() {
                    // Only show an error if the user has already attempted to submit the form
                    element.toggleClass('form-field--error', formCtrl.$submitted && formCtrl[property].$invalid);
                }
            }
        }
    };
});
'use strict';

angular.module('bcapp-pattern-lab.form-field', ['bcapp-pattern-lab.form-field.directive', 'bcapp-pattern-lab.form-field-error', 'bcapp-pattern-lab.form-field-errors']);
'use strict';

angular.module('bcapp-pattern-lab.form-field-error.directive', []).directive('formFieldError', function formFieldErrorDirective($compile) {
    return {
        priority: 10,
        replace: true,
        restrict: 'EA',
        templateUrl: 'src/js/bigcommerce/form-field-error/form-field-error.tpl.html',
        terminal: true,
        transclude: true,
        compile: function formFieldErrorCompile(tElement, tAttrs) {
            // The translate property wipes out our ng-message logic in the post link function
            // The priority and terminal properties above ensure this check occurs
            if (tElement.attr('translate') !== undefined) {
                throw new SyntaxError('The translate attribute cannot be used with the form-field-error directive. ' + 'Use the translate filter instead (example: {{ "my error message" | translate }}). ' + 'Validator: ' + tAttrs.validate);
            }

            return {
                post: function formFieldErrorPostLink(scope, element, attrs, controllers, transclude) {
                    scope.property = scope.property || attrs.property;

                    transclude(function formFieldErrorTransclude(errorClone) {
                        var labelElement = angular.element('<label>');

                        // ngMessage doesn't play well with dynamic message insertion, translation, or
                        // message expressions, so we build its element up here and inject it into the DOM
                        labelElement.attr('for', scope.property);
                        labelElement.attr('ng-message', attrs.validate);
                        labelElement.attr('role', 'alert');
                        labelElement.addClass('form-inlineMessage');

                        // The error span should already have a translation watcher on it by now, using a filter
                        labelElement.append(errorClone);

                        element.append(labelElement);

                        $compile(element)(scope);
                    });
                }
            };
        }
    };
});
'use strict';

angular.module('bcapp-pattern-lab.form-field-error', ['bcapp-pattern-lab.form-field-error.directive']);
'use strict';

angular.module('bcapp-pattern-lab.form-field-errors.directive', []).directive('formFieldErrors', function formFieldErrorsDirective() {
    return {
        replace: true,
        require: '^form',
        restrict: 'EA',
        templateUrl: 'src/js/bigcommerce/form-field-errors/form-field-errors.tpl.html',
        transclude: true,
        link: {
            // Pre-link is required, as we have to inject our scope properties before the child
            // form-field-error directive (and its internal ng-message directive's) post-link functions
            pre: function formFieldErrorsPreLink(scope, element, attrs, formCtrl) {
                // Property name can be inherited from parent scope, such as from the form-field directive
                var property = scope.property || attrs.property,
                    propertyField = formCtrl[property];

                // Inherited by form-field-error directive. Lives directly on scope because the require
                // property does not work well with directive controller instances
                scope.formCtrl = formCtrl;
                scope.property = property;
                scope.propertyField = propertyField;
            }
        }
    };
});
'use strict';

angular.module('bcapp-pattern-lab.form-field-errors', ['bcapp-pattern-lab.form-field-errors.directive']);
'use strict';

angular.module('bcapp-pattern-lab.icon.controller', ['bcapp-pattern-lab.icon.svgRootPath']).controller('IconCtrl', function iconDirectiveController($http, $templateCache, svgRootPath) {
    var ctrl = this;

    ctrl.updateGlyph = updateGlyph;

    function updateGlyph(glyph) {
        var fullSvgPath = svgRootPath + glyph + '.svg';

        return $http.get(fullSvgPath, { cache: $templateCache }).then(function iconDirectiveHttpSuccess(response) {
            return response.data;
        });
    }
});
/**
 * @description Icon directive used to load an inline svg icon, simliar to icon
 *              font methods of past <i class="icon-foo-bar"></i>
 * @example
 * <icon glyph="ic-add-circle"></icon>
 */
'use strict';

angular.module('bcapp-pattern-lab.icon.directive', ['bcapp-pattern-lab.icon.controller']).directive('icon', function iconDirective() {
    return {
        bindToController: true,
        controller: 'IconCtrl as iconCtrl',
        restrict: 'E',
        scope: {
            glyph: '@'
        },
        compile: function iconDirectiveCompile(tElement) {
            tElement.addClass('icon');
            tElement.attr('aria-hidden', true);

            return function iconDirectiveLink($scope, element, attrs, ctrl) {
                $scope.$watch('iconCtrl.glyph', function iconDirectiveLinkWatch(newValue) {
                    ctrl.updateGlyph(newValue).then(function iconUpdateGlyphThen(svg) {
                        element.html(svg);
                    });
                });
            };
        }
    };
});
'use strict';

angular.module('bcapp-pattern-lab.icon', ['bcapp-pattern-lab.icon.directive']);
'use strict';

angular.module('bcapp-pattern-lab.icon.svgRootPath', []).provider('svgRootPath', function svgRootPathProviderConfig() {
    this.setRootPath = setRootPath;
    this.$get = function svgRootPathProviderGet($log) {
        if (this.svgRootPath === undefined) {
            $log.error('No svgRootPath provided. Please configure this using the svgRootPathProvider');
        }

        return this.svgRootPath;
    };

    function setRootPath(newRootPath) {
        this.svgRootPath = newRootPath;
    }
});
'use strict';

angular.module('bcapp-pattern-lab.loading-notification.directive', []).directive('loadingNotification', function loadingNotificationDirective($rootScope) {
    return {
        restrict: 'E',
        templateUrl: 'src/js/bigcommerce/loading-notification/loading-notification.tpl.html',

        link: function link(scope) {
            $rootScope.$on('ajaxRequestRunning', function (event, val) {
                scope.requestInProgress = val;
            });
        }
    };
});
'use strict';

angular.module('bcapp-pattern-lab.loading-notification', ['bcapp-pattern-lab.loading-notification.directive']);
'use strict';

angular.module('bcapp-pattern-lab.loading-overlay.controller', []).controller('LoadingOverlayCtrl', function LoadingOverlayCtrl($rootScope, $timeout) {
    var ctrl = this,
        defaultDebounce = 100,
        timeout;

    if (ctrl.debounce === undefined) {
        ctrl.debounce = defaultDebounce;
    }

    if (ctrl.useUiRouter) {
        $rootScope.$on('$stateChangeStart', startLoading);
        $rootScope.$on('$stateChangeSuccess', stopLoading);
        $rootScope.$on('$stateChangeError', stopLoading);
    }

    function startLoading(event) {
        if (event.defaultPrevented) {
            return;
        }

        timeout = $timeout(function startLoadingTimer() {
            ctrl.loading = true;
        }, ctrl.debounce);
    }

    function stopLoading(event) {
        if (event.defaultPrevented) {
            return;
        }

        $timeout.cancel(timeout);
        ctrl.loading = false;
    }
});
'use strict';

angular.module('bcapp-pattern-lab.loading-overlay.directive', ['bcapp-pattern-lab.loading-overlay.controller']).directive('loadingOverlay', function loadingOverlay($compile) {
    return {
        bindToController: true,
        controller: 'LoadingOverlayCtrl as loadingOverlayCtrl',
        restrict: 'A',
        scope: {
            debounce: '=?',
            loading: '=?loadingOverlay',
            useUiRouter: '=?'
        },
        compile: function loadingOverlayCompile(element) {
            element.addClass('loadingOverlay-container');

            return function loadingOverlayLink(scope, element) {
                var overlay = $compile('<div class="loadingOverlay" ng-if="loadingOverlayCtrl.loading"></div>')(scope);
                element.append(overlay);
            };
        }
    };
});
'use strict';

angular.module('bcapp-pattern-lab.loading-overlay', ['bcapp-pattern-lab.loading-overlay.directive']);
/*
 * Override angular foundation's $modalStack service to remove the `top` css property.
 * cannot use a decorator because the `open` relies on closures and does not return the compiled element.
 * Changes are between `// Changes` comments
*/
'use strict';

angular.module('bcapp-pattern-lab.bc-modal.modalStack.service', []).factory('$modalStack', ['$window', '$transition', '$timeout', '$document', '$compile', '$rootScope', '$$stackedMap', function ($window, $transition, $timeout, $document, $compile, $rootScope, $$stackedMap) {
  // Changes: change from `modal-open` to `has-activeModal`
  var OPENED_MODAL_CLASS = 'has-activeModal';
  // Changes

  var backdropDomEl, backdropScope;
  var openedWindows = $$stackedMap.createNew();
  var $modalStack = {};

  function backdropIndex() {
    var topBackdropIndex = -1;
    var opened = openedWindows.keys();
    for (var i = 0; i < opened.length; i++) {
      if (openedWindows.get(opened[i]).value.backdrop) {
        topBackdropIndex = i;
      }
    }
    return topBackdropIndex;
  }

  $rootScope.$watch(backdropIndex, function (newBackdropIndex) {
    if (backdropScope) {
      backdropScope.index = newBackdropIndex;
    }
  });

  function removeModalWindow(modalInstance) {
    var body = $document.find('body').eq(0);
    var modalWindow = openedWindows.get(modalInstance).value;

    //clean up the stack
    openedWindows.remove(modalInstance);

    //remove window DOM element
    removeAfterAnimate(modalWindow.modalDomEl, modalWindow.modalScope, 300, function () {
      modalWindow.modalScope.$destroy();
      body.toggleClass(OPENED_MODAL_CLASS, openedWindows.length() > 0);
      checkRemoveBackdrop();
    });
  }

  function checkRemoveBackdrop() {
    //remove backdrop if no longer needed
    if (backdropDomEl && backdropIndex() == -1) {
      var backdropScopeRef = backdropScope;
      removeAfterAnimate(backdropDomEl, backdropScope, 150, function () {
        backdropScopeRef.$destroy();
        backdropScopeRef = null;
      });
      backdropDomEl = undefined;
      backdropScope = undefined;
    }
  }

  function removeAfterAnimate(domEl, scope, emulateTime, done) {
    // Closing animation
    scope.animate = false;

    var transitionEndEventName = $transition.transitionEndEventName;
    if (transitionEndEventName) {
      // transition out
      var timeout = $timeout(afterAnimating, emulateTime);

      domEl.bind(transitionEndEventName, function () {
        $timeout.cancel(timeout);
        afterAnimating();
        scope.$apply();
      });
    } else {
      // Ensure this call is async
      $timeout(afterAnimating, 0);
    }

    function afterAnimating() {
      if (afterAnimating.done) {
        return;
      }
      afterAnimating.done = true;

      domEl.remove();
      if (done) {
        done();
      }
    }
  }

  $document.bind('keydown', function (evt) {
    var modal;

    if (evt.which === 27) {
      modal = openedWindows.top();
      if (modal && modal.value.keyboard) {
        $rootScope.$apply(function () {
          $modalStack.dismiss(modal.key);
        });
      }
    }
  });

  $modalStack.open = function (modalInstance, modal) {

    openedWindows.add(modalInstance, {
      deferred: modal.deferred,
      modalScope: modal.scope,
      backdrop: modal.backdrop,
      keyboard: modal.keyboard
    });

    var body = $document.find('body').eq(0),
        currBackdropIndex = backdropIndex();

    if (currBackdropIndex >= 0 && !backdropDomEl) {
      backdropScope = $rootScope.$new(true);
      backdropScope.index = currBackdropIndex;
      backdropDomEl = $compile('<div modal-backdrop></div>')(backdropScope);
      body.append(backdropDomEl);
    }

    // Changes: deletion of css top property calculation
    var angularDomEl = angular.element('<div modal-window style="visibility: visible; display: block"></div>');
    angularDomEl.attr('window-class', modal.windowClass);
    angularDomEl.attr('index', openedWindows.length() - 1);
    angularDomEl.attr('animate', 'animate');
    angularDomEl.html(modal.content);

    var modalDomEl = $compile(angularDomEl)(modal.scope);
    openedWindows.top().value.modalDomEl = modalDomEl;
    body.append(modalDomEl);
    body.addClass(OPENED_MODAL_CLASS);
  };

  $modalStack.close = function (modalInstance, result) {
    var modalWindow = openedWindows.get(modalInstance).value;
    if (modalWindow) {
      modalWindow.deferred.resolve(result);
      removeModalWindow(modalInstance);
    }
  };

  $modalStack.dismiss = function (modalInstance, reason) {
    var modalWindow = openedWindows.get(modalInstance).value;
    if (modalWindow) {
      modalWindow.deferred.reject(reason);
      removeModalWindow(modalInstance);
    }
  };

  $modalStack.dismissAll = function (reason) {
    var topModal = this.getTop();
    while (topModal) {
      this.dismiss(topModal.key, reason);
      topModal = this.getTop();
    }
  };

  $modalStack.getTop = function () {
    return openedWindows.top();
  };

  return $modalStack;
}]);
/*
 * This module modifies angular foundation's modal implementation. This does not create a new modal service/directive.
 * 
*/
'use strict';

angular.module('bcapp-pattern-lab.bc-modal', ['bcapp-pattern-lab.bc-modal.modalStack.service']);
/**
 * @description Sprite directive used to load an icon from an image sprite,
 *              simliar to the icon directive but less SVG
 * @example
 * <sprite glyph="ic-amex"></sprite>
 */

'use strict';

angular.module('bcapp-pattern-lab.sprite.directive', []).directive('sprite', function spriteDirective() {
    return {
        restrict: 'E',
        scope: {
            glyph: '@'
        },
        compile: spriteDirectiveCompile
    };

    function spriteDirectiveCompile(tElement) {
        tElement.addClass('sprite');
        tElement.attr('aria-hidden', true);

        return function spriteDirectiveLink($scope, element, attrs) {
            attrs.$observe('glyph', function (newValue) {
                element.attr('class', 'sprite sprite--' + newValue);
            });
        };
    }
});
'use strict';

angular.module('bcapp-pattern-lab.sprite', ['bcapp-pattern-lab.sprite.directive']);
/**
 * @description Used to create a toggle switch for forms
 * @example
    <switch ng-model="ctrl.switchModel1"></switch>

    <switch
        toggle-off-text="Off"
        toggle-on-text="On"
        ng-model="ctrl.switchModel2">
    </switch>

    <switch
        has-icon
        ng-model="ctrl.switchModel3">
    </switch>

    <switch
        is-important
        left-label="Down for Maintenance"
        right-label="Open"
        ng-model="ctrl.switchModel4">
    </switch>
 */
'use strict';

angular.module('bcapp-pattern-lab.switch.directive', []).directive('switch', function switchDirective() {

    function getUniqueID(idPrefix) {
        return _.uniqueId(idPrefix);
    }

    return {
        restrict: 'E',
        templateUrl: 'src/js/bigcommerce/switch/switch.tpl.html',
        require: 'ngModel',
        scope: {
            ariaDescription: '@',
            labelText: '@',
            leftDescription: '@',
            ngFalseValue: '@',
            ngTrueValue: '@',
            rightDescription: '@',
            toggleOffLabel: '@',
            toggleOnLabel: '@',
            uniqueId: '@'
        },
        bindToController: true,
        controllerAs: 'switchCtrl',
        compile: function switchDirectiveCompile(tElem, tAttrs) {
            var checkboxElem = tElem.find('input');

            if (tAttrs.ngFalseValue) {
                checkboxElem.attr('ng-false-value', tAttrs.ngFalseValue);
            }

            if (tAttrs.ngTrueValue) {
                checkboxElem.attr('ng-true-value', tAttrs.ngTrueValue);
            }

            return function switchDirectivePostLink(scope, element, attrs, ngModelCtrl) {
                scope.switchCtrl.init(ngModelCtrl);
            };
        },
        controller: function switchDirectiveCtrl($scope, $element, $attrs) {
            var ctrl = this;

            // state
            ctrl.isImportant = angular.isDefined($attrs.isImportant) && $attrs.isImportant !== 'false';
            ctrl.hasIcon = angular.isDefined($attrs.hasIcon) && $attrs.hasIcon !== 'false';

            // labels
            ctrl.labelText = $attrs.toggleOffLabel;

            // ids
            ctrl.uniqueId = getUniqueID('switch-');
            ctrl.ariaDescriptionID = getUniqueID('switch-ariaDescription-');

            ctrl.init = init;
            ctrl.updateModel = updateModel;

            function init(ngModelCtrl) {
                ctrl.ngModelCtrl = ngModelCtrl;
                ctrl.value = ctrl.ngModelCtrl.$modelValue;

                $scope.$watch('switchCtrl.ngModelCtrl.$modelValue', function switchValueChanged(newValue) {
                    ctrl.value = newValue;

                    ctrl.isChecked = _.isString(newValue) ? "'" + newValue + "'" === ctrl.ngTrueValue : newValue;
                    ctrl.labelText = !!ctrl.isChecked ? ctrl.toggleOnLabel : ctrl.toggleOffLabel;
                });
            }

            function updateModel() {
                ctrl.ngModelCtrl.$setViewValue(ctrl.value);
            }
        }
    };
});
'use strict';

angular.module('bcapp-pattern-lab.switch', ['bcapp-pattern-lab.switch.directive']);
'use strict';

angular.module('bcapp-pattern-lab.util', ['bcapp-pattern-lab.util.trustAsHtml']);
'use strict';

angular.module('bcapp-pattern-lab.bc-server-table.service', ['ui.router']).factory('BcServerTable', function bcServerTable($log, $q, $state, $stateParams) {
    var defaultTableConfig = {
        filters: [],
        queryKeys: {
            page: 'page',
            limit: 'limit',
            sortBy: 'sort-by',
            sortDir: 'sort-order'
        },
        rowIdKey: 'id',
        sortDirValues: {
            asc: 'asc',
            desc: 'desc'
        }
    };

    function ServerTable(tableId, tableConfig) {
        this.allSelected = false;
        this.filters = {};
        this.id = tableId;
        this.pagination = {
            page: null,
            limit: null,
            total: null
        };
        this.pendingRequest = false;
        this.resourceCallback = angular.noop;
        this.rows = [];
        this.selectedRows = {};
        this.sortBy = '';
        this.sortDir = '';

        this.tableConfig = _.isObject(tableConfig) ? tableConfig : {};
        this.tableConfig = _.defaults(this.tableConfig, defaultTableConfig);
    }

    ServerTable.prototype = {
        createParamsObject: createParamsObject,
        fetchResource: fetchResource,
        getSelectedRows: getSelectedRows,
        init: init,
        isRowSelected: isRowSelected,
        loadStateParams: loadStateParams,
        selectAllRows: selectAllRows,
        setPaginationValues: setPaginationValues,
        setRows: setRows,
        setSortingValues: setSortingValues,
        updatePage: updatePage,
        updateSort: updateSort,
        updateTable: updateTable,
        validateResource: validateResource
    };

    function createParamsObject() {
        var params = {},
            queryKeys = this.tableConfig.queryKeys,
            queryParamMap = [{
            queryKey: queryKeys.page,
            value: this.pagination.page
        }, {
            queryKey: queryKeys.limit,
            value: this.pagination.limit
        }, {
            queryKey: queryKeys.sortBy,
            value: this.sortBy
        }, {
            queryKey: queryKeys.sortDir,
            value: this.sortDir
        }];

        _.each(queryParamMap, function queryParamMapEach(param) {
            if (param.queryKey !== undefined) {
                params[param.queryKey] = param.value;
            }
        });

        _.extend(params, this.filters);

        return params;
    }

    function fetchResource() {
        var _this = this;

        this.pendingRequest = true;
        return this.resourceCallback(this.createParamsObject()).then(function resourceCallbackThen(resource) {
            if (_this.validateResource(resource)) {
                _this.setRows(resource.rows);
                _this.setPaginationValues(resource.pagination);
            }

            return _this;
        })['catch'](function resourceCallbackCatch(error) {
            $log.error('bc-server-table directive: failed to fetch resource');

            return $q.reject(error);
        })['finally'](function resourceCallbackFinally() {
            _this.pendingRequest = false;
        });
    }

    function getSelectedRows() {
        var _this = this;

        return _.filter(this.rows, function getSelectedRowsFilter(row) {
            return _this.isRowSelected(row);
        });
    }

    function init(config) {
        if (!_.isObject(config)) {
            config = {};
        }

        if (_.isFunction(config.resourceCallback)) {
            this.resourceCallback = config.resourceCallback;
        }

        return this.loadStateParams(config.stateParams).fetchResource();
    }

    function isRowSelected(row) {
        return this.selectedRows[row[this.tableConfig.rowIdKey]];
    }

    function loadStateParams(stateParams) {
        var queryKeys = this.tableConfig.queryKeys,
            _this = this;

        stateParams = stateParams || $stateParams;

        this.setPaginationValues({
            page: stateParams[queryKeys.page],
            limit: stateParams[queryKeys.limit]
        });

        this.setSortingValues(stateParams[queryKeys.sortBy], stateParams[queryKeys.sortDir]);

        // set filters from query params
        _.each(this.tableConfig.filters, function setFiltersEach(value) {
            _this.filters[value] = stateParams[value];
        });

        return this;
    }

    function selectAllRows() {
        var _this = this;

        this.allSelected = !this.allSelected;
        _.each(this.selectedRows, function selectAllRowsEach(value, key) {
            _this.selectedRows[key] = _this.allSelected;
        });

        return this;
    }

    function setPaginationValues(pagination) {
        this.pagination = this.pagination || {};
        _.extend(this.pagination, pagination);

        return this;
    }

    function setRows(rows) {
        var _this = this;

        this.rows = rows;
        this.selectedRows = _.reduce(rows, function initializeSelectedRowsObject(accum, row) {
            accum[row[_this.tableConfig.rowIdKey]] = false;
            return accum;
        }, {});

        return this;
    }

    function setSortingValues(sortBy, sortDir) {
        this.sortBy = sortBy || this.sortBy;
        this.sortDir = sortDir || this.sortDir;

        return this;
    }

    function updatePage(page, limit, total) {
        return this.setPaginationValues(page, limit, total).updateTable();
    }

    function updateSort(sortBy, sortDir) {
        return this.setSortingValues(sortBy, sortDir).setPaginationValues({
            page: 1
        }).updateTable();
    }

    function updateTable() {
        if (!this.pendingRequest) {
            $state.go($state.current.name, this.createParamsObject());
        }

        return this;
    }

    function validateResource(resource) {
        if (!_.isObject(resource)) {
            $log.error('bc-server-table directive: Resource callback must return an object');
            return false;
        }

        if (!_.isArray(resource.rows)) {
            $log.error('bc-server-table directive: returned object must contain a rows property that is an array.');
            return false;
        }

        if (!_.isObject(resource.pagination)) {
            $log.error('bc-server-table directive: returned object must contain a pagination property that is an object.');
            return false;
        }

        return true;
    }

    return ServerTable;
});
'use strict';

angular.module('bcapp-pattern-lab.bc-server-table-factory.service', ['bcapp-pattern-lab.bc-server-table.service']).factory('bcServerTableFactory', function bcServerTableFactory($log, BcServerTable) {
    var tables = {},
        service = {
        create: create,
        get: get,
        remove: remove
    };

    function create(tableId, tableConfig) {
        if (tableId in tables) {
            return service.get(tableId);
        }

        if (!tableId) {
            tableId = _.uniqueId('bc-server-table-instance-');
        }

        tables[tableId] = new BcServerTable(tableId, tableConfig);

        return tables[tableId];
    }

    function get(tableId) {
        return tables[tableId];
    }

    function remove(tableId) {
        delete tables[tableId];
    }

    return service;
});
/**
 * @name cc-expiry directive
 * @description A directive following angular-credit-card's approach to validating/formatting credit card expiration date.
 * Expect the cc-expiry ngModel to be in the format of `{ month: '05', year: '2017'}`.
 */
'use strict';

angular.module('bcapp-pattern-lab.credit-card.cc-expiry.directive', []).directive('ccExpiry', function ccExpDirective($filter) {
    return {
        compile: function compile(tElem, tAttr) {
            var EXPIRATION_MAX_LENGTH = 7; // length of `MM / yy`

            tAttr.$set('autocomplete', 'cc-exp');
            tAttr.$set('maxlength', EXPIRATION_MAX_LENGTH);
            tAttr.$set('pattern', '[0-9]*'); // for mobile keyboard display

            return function ccExpiryLink(scope, tElem, tAttr, ngModelCtrl) {
                init();

                function init() {
                    ngModelCtrl.$parsers.unshift(parser);
                    ngModelCtrl.$formatters.push(formatter);
                    ngModelCtrl.$validators.validFutureDate = validFutureDate;

                    scope.$watch(getViewValue, renderFormattedView);
                }

                /**
                 * get the input's view value
                 */
                function getViewValue() {
                    return ngModelCtrl.$viewValue;
                }

                /**
                 * formats the input view value to be the format `MM / yy` and re-renders view
                 */
                function renderFormattedView(viewValue, prevViewValue) {
                    if (!viewValue) {
                        return;
                    }

                    // a new value is added (as opposed to pressing backspace)
                    var isAddition = viewValue.length > prevViewValue.length;

                    ngModelCtrl.$setViewValue(format(viewValue, isAddition));
                    ngModelCtrl.$render();
                }

                /**
                 * Validates whether the entered expiration date is valid
                 */
                function validFutureDate(modelValue) {
                    var month = modelValue.month;
                    var year = modelValue.year;

                    return isValidDate(month, year) && !isPast(month, year);
                }

                /**
                 * Validates whether the given month and year are number strings with length of 2 and 4 respectively
                 */
                function isValidDate(month, year) {
                    var monthRegex = /^[0-9]{2}$/;
                    var yearRegex = /^[0-9]{4}$/;

                    return _.isString(month) && _.isString(year) && monthRegex.test(month) && yearRegex.test(year) && isValidMonth(month);
                }

                /**
                 * Checks whether the month is valid
                 */
                function isValidMonth(month) {
                    month = _.parseInt(month);

                    return month > 0 && month < 13;
                }

                /**
                 * Checks whether the given month and date is in the past
                 */
                function isPast(month, year) {
                    return getCurrMonthDate() > new Date(year, month - 1);
                }

                /**
                 * Get the date object based on current month and year
                 */
                function getCurrMonthDate() {
                    var date = new Date();

                    return new Date(date.getFullYear(), date.getMonth());
                }

                /**
                 * Uses angular date filter to format date model to corresponding view format
                 */
                function formatter() {
                    var exp = arguments.length <= 0 || arguments[0] === undefined ? {} : arguments[0];

                    var month = exp.month;
                    var year = exp.year;

                    if (_.isEmpty(month) && _.isEmpty(year)) {
                        return '';
                    }

                    return $filter('date')(new Date(year, month - 1), 'MM / yy');
                }

                /**
                 * Parses the formatted view values to model. Converts 2 digit year to full 4 digit year
                 * @param expiration {object} The expiration object {month, year}
                 */
                function parser(expiration) {
                    var baseYear = new Date().getFullYear().toString().slice(0, 2); // `'20'`
                    var values = expiration.split('/');
                    var month = values[0] ? values[0].trim() : '';
                    var year = values[1] ? baseYear + values[1].trim() : '';

                    return { month: month, year: year };
                }

                /**
                 * formats the view value to the form 'MM / yy'
                 */
                function format(expStr, isAddition) {
                    var values = expStr.split('/');
                    var month = values[0] ? values[0].trim() : '';
                    var year = values[1] ? values[1].trim().slice(-2) : '';

                    // don't add slash
                    if (!isAddition && !year || month.length < 2) {
                        return month;
                    }

                    // add slash in the right spot
                    if (isAddition && !year && month.length > 2) {
                        return month.slice(0, 2) + ' / ' + month.slice(2);
                    }

                    return month + ' / ' + year;
                }
            };
        },
        require: 'ngModel',
        restrict: 'A'
    };
});
'use strict';

angular.module('bcapp-pattern-lab.credit-card.cc-expiry', ['bcapp-pattern-lab.credit-card.cc-expiry.directive']);
/**
 * @name bc-cvc directive
 * @description A custom complementary directive to angular-credit-card's `ccCvc` directive.
 * To support allowing an optional cvc field (i.e. Securenet), this directive must override
 * the validation provided by ccCvc directive.
 */
'use strict';

angular.module('bcapp-pattern-lab.credit-card.bc-cvc', ['credit-cards']).directive('bcCvc', function bcCvcDirective($parse) {
    return {
        link: function bcCvcLink(scope, element, attributes, ngModel) {
            // override the validation to always return valid
            // if cvc is not required
            if (!$parse(attributes.ngRequired)(scope)) {
                ngModel.$validators.ccCvc = function () {
                    return true;
                };
            }
        },
        priority: 5, // higher priority to ensure ccCvc's link is ran first
        require: 'ngModel',
        restrict: 'A'
    };
});
/**
 * @name trustAsHtml
 * @description Simple utility filter to run the given html string through angular's $sce.trustAsHtml function.
 *
 * @param {String} text The html string to trust
 * @return {String} An angular-trusted object containing the html
 *
 * @example `<p ng-bind-html="rawHtml | trustAsHtml"></p>`
 */
'use strict';

angular.module('bcapp-pattern-lab.util.trustAsHtml', []).filter('trustAsHtml', function trustAsHtml($sce) {
    return function (text) {
        return $sce.trustAsHtml(text);
    };
});
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImJpZ2NvbW1lcmNlL2JjYXBwLXBhdHRlcm4tbGFiLm1vZHVsZS5qcyIsImJpZ2NvbW1lcmNlL2JjLWRhdGVwaWNrZXIvYmMtZGF0ZXBpY2tlci5jb25zdGFudHMuanMiLCJiaWdjb21tZXJjZS9iYy1kYXRlcGlja2VyL2JjLWRhdGVwaWNrZXIuZGlyZWN0aXZlLmpzIiwiYmlnY29tbWVyY2UvYmMtZGF0ZXBpY2tlci9iYy1kYXRlcGlja2VyLmpzIiwiYmlnY29tbWVyY2UvYmMtZHJvcGRvd24vYmMtZHJvcGRvd24tbWVudS5kaXJlY3RpdmUuanMiLCJiaWdjb21tZXJjZS9iYy1kcm9wZG93bi9iYy1kcm9wZG93bi10b2dnbGUuZGlyZWN0aXZlLmpzIiwiYmlnY29tbWVyY2UvYmMtZHJvcGRvd24vYmMtZHJvcGRvd24uZGlyZWN0aXZlLmpzIiwiYmlnY29tbWVyY2UvYmMtZHJvcGRvd24vYmMtZHJvcGRvd24ubW9kdWxlLmpzIiwiYmlnY29tbWVyY2UvYmMtcGFnaW5hdGlvbi9iYy1wYWdpbmF0aW9uLmRpcmVjdGl2ZS5qcyIsImJpZ2NvbW1lcmNlL2JjLXBhZ2luYXRpb24vYmMtcGFnaW5hdGlvbi5tb2R1bGUuanMiLCJiaWdjb21tZXJjZS9iYy1zZXJ2ZXItdGFibGUvYmMtc2VydmVyLXRhYmxlLmNvbnRyb2xsZXIuanMiLCJiaWdjb21tZXJjZS9iYy1zZXJ2ZXItdGFibGUvYmMtc2VydmVyLXRhYmxlLmRpcmVjdGl2ZS5qcyIsImJpZ2NvbW1lcmNlL2JjLXNlcnZlci10YWJsZS9iYy1zZXJ2ZXItdGFibGUubW9kdWxlLmpzIiwiYmlnY29tbWVyY2UvYmMtc2VydmVyLXRhYmxlL2JjLXNvcnQtYnkuZGlyZWN0aXZlLmpzIiwiYmlnY29tbWVyY2UvY2hlY2tib3gtbGlzdC9jaGVja2JveC1saXN0LmNvbnRyb2xsZXIuanMiLCJiaWdjb21tZXJjZS9jaGVja2JveC1saXN0L2NoZWNrYm94LWxpc3QuZGlyZWN0aXZlLmpzIiwiYmlnY29tbWVyY2UvY2hlY2tib3gtbGlzdC9jaGVja2JveC1saXN0Lm1vZHVsZS5qcyIsImJpZ2NvbW1lcmNlL2NyZWRpdC1jYXJkL2NyZWRpdC1jYXJkLmRpcmVjdGl2ZS5qcyIsImJpZ2NvbW1lcmNlL2NyZWRpdC1jYXJkL2NyZWRpdC1jYXJkLm1vZHVsZS5qcyIsImJpZ2NvbW1lcmNlL2NyZWRpdC1jYXJkLXR5cGVzL2NyZWRpdC1jYXJkLXR5cGVzLmNvbnN0YW50LmpzIiwiYmlnY29tbWVyY2UvY3JlZGl0LWNhcmQtdHlwZXMvY3JlZGl0LWNhcmQtdHlwZXMuY29udHJvbGxlci5qcyIsImJpZ2NvbW1lcmNlL2NyZWRpdC1jYXJkLXR5cGVzL2NyZWRpdC1jYXJkLXR5cGVzLmRpcmVjdGl2ZS5qcyIsImJpZ2NvbW1lcmNlL2NyZWRpdC1jYXJkLXR5cGVzL2NyZWRpdC1jYXJkLXR5cGVzLm1vZHVsZS5qcyIsImJpZ2NvbW1lcmNlL2Zvcm0vZm9ybS5kaXJlY3RpdmUuanMiLCJiaWdjb21tZXJjZS9mb3JtL2Zvcm0ubW9kdWxlLmpzIiwiYmlnY29tbWVyY2UvZm9ybS1maWVsZC9mb3JtLWZpZWxkLmRpcmVjdGl2ZS5qcyIsImJpZ2NvbW1lcmNlL2Zvcm0tZmllbGQvZm9ybS1maWVsZC5tb2R1bGUuanMiLCJiaWdjb21tZXJjZS9mb3JtLWZpZWxkLWVycm9yL2Zvcm0tZmllbGQtZXJyb3IuZGlyZWN0aXZlLmpzIiwiYmlnY29tbWVyY2UvZm9ybS1maWVsZC1lcnJvci9mb3JtLWZpZWxkLWVycm9yLm1vZHVsZS5qcyIsImJpZ2NvbW1lcmNlL2Zvcm0tZmllbGQtZXJyb3JzL2Zvcm0tZmllbGQtZXJyb3JzLmRpcmVjdGl2ZS5qcyIsImJpZ2NvbW1lcmNlL2Zvcm0tZmllbGQtZXJyb3JzL2Zvcm0tZmllbGQtZXJyb3JzLm1vZHVsZS5qcyIsImJpZ2NvbW1lcmNlL2ljb24vaWNvbi5jb250cm9sbGVyLmpzIiwiYmlnY29tbWVyY2UvaWNvbi9pY29uLmRpcmVjdGl2ZS5qcyIsImJpZ2NvbW1lcmNlL2ljb24vaWNvbi5qcyIsImJpZ2NvbW1lcmNlL2ljb24vaWNvbi5zdmdSb290UGF0aC5qcyIsImJpZ2NvbW1lcmNlL2xvYWRpbmctbm90aWZpY2F0aW9uL2xvYWRpbmctbm90aWZpY2F0aW9uLmRpcmVjdGl2ZS5qcyIsImJpZ2NvbW1lcmNlL2xvYWRpbmctbm90aWZpY2F0aW9uL2xvYWRpbmctbm90aWZpY2F0aW9uLmpzIiwiYmlnY29tbWVyY2UvbG9hZGluZy1vdmVybGF5L2xvYWRpbmctb3ZlcmxheS5jb250cm9sbGVyLmpzIiwiYmlnY29tbWVyY2UvbG9hZGluZy1vdmVybGF5L2xvYWRpbmctb3ZlcmxheS5kaXJlY3RpdmUuanMiLCJiaWdjb21tZXJjZS9sb2FkaW5nLW92ZXJsYXkvbG9hZGluZy1vdmVybGF5LmpzIiwiYmlnY29tbWVyY2UvbW9kYWwvYmMtbW9kYWwubW9kYWxTdGFjay5zZXJ2aWNlLmpzIiwiYmlnY29tbWVyY2UvbW9kYWwvYmMtbW9kYWwubW9kdWxlLmpzIiwiYmlnY29tbWVyY2Uvc3ByaXRlL3Nwcml0ZS5kaXJlY3RpdmUuanMiLCJiaWdjb21tZXJjZS9zcHJpdGUvc3ByaXRlLmpzIiwiYmlnY29tbWVyY2Uvc3dpdGNoL3N3aXRjaC5kaXJlY3RpdmUuanMiLCJiaWdjb21tZXJjZS9zd2l0Y2gvc3dpdGNoLm1vZHVsZS5qcyIsImJpZ2NvbW1lcmNlL3V0aWwvdXRpbC5tb2R1bGUuanMiLCJiaWdjb21tZXJjZS9iYy1zZXJ2ZXItdGFibGUvYmMtc2VydmVyLXRhYmxlL2JjLXNlcnZlci10YWJsZS5zZXJ2aWNlLmpzIiwiYmlnY29tbWVyY2UvYmMtc2VydmVyLXRhYmxlL2JjLXNlcnZlci10YWJsZS1mYWN0b3J5L2JjLXNlcnZlci10YWJsZS1mYWN0b3J5LnNlcnZpY2UuanMiLCJiaWdjb21tZXJjZS9jcmVkaXQtY2FyZC9jYy1leHBpcnkvY2MtZXhwaXJ5LmRpcmVjdGl2ZS5qcyIsImJpZ2NvbW1lcmNlL2NyZWRpdC1jYXJkL2NjLWV4cGlyeS9jYy1leHBpcnkubW9kdWxlLmpzIiwiYmlnY29tbWVyY2UvY3JlZGl0LWNhcmQvY3JlZGl0LWNhcmQtY3Z2L2JjLWN2Yy5kaXJlY3RpdmUuanMiLCJiaWdjb21tZXJjZS91dGlsL3RydXN0QXNIdG1sL3RydXN0QXNIdG1sLmZpbHRlci5qcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOztBQUFBLE9BQU8sQ0FBQyxNQUFNLENBQUMsbUJBQW1CLEVBQUUsQ0FDaEMsU0FBUyxFQUNULFdBQVcsRUFDWCxZQUFZLEVBQ1osZUFBZSxFQUNmLDZCQUE2QixFQUM3QixpQ0FBaUMsRUFDakMsK0JBQStCLEVBQy9CLDRCQUE0QixFQUM1QixpQ0FBaUMsRUFDakMsbUNBQW1DLEVBQ25DLGlDQUFpQyxFQUNqQywrQkFBK0IsRUFDL0IscUNBQXFDLEVBQ3JDLHdCQUF3QixFQUN4Qiw4QkFBOEIsRUFDOUIsd0JBQXdCLEVBQ3hCLHdDQUF3QyxFQUN4QyxtQ0FBbUMsRUFDbkMsMEJBQTBCLEVBQzFCLDBCQUEwQixFQUMxQix3QkFBd0IsQ0FDM0IsQ0FBQyxDQUFDOzs7O0FDckJILE9BQU8sQ0FBQyxNQUFNLENBQUMsMkNBQTJDLEVBQUUsRUFBRSxDQUFDLENBQzFELFFBQVEsQ0FBQyx3QkFBd0IsRUFBRTtBQUNoQyxhQUFTLEVBQUUsR0FBRztBQUNkLGVBQVcsRUFBRSxNQUFNLENBQUMsVUFBVSxFQUFFLENBQUMsY0FBYyxDQUFDLEdBQUcsQ0FBQztBQUNwRCxVQUFNLEVBQUU7QUFDSixZQUFJLEVBQUUsaUJBQWlCO0FBQ3ZCLGlCQUFTLEVBQUUsWUFBWTtBQUN2QixZQUFJLEVBQUUsaUJBQWlCO0FBQ3ZCLGVBQU8sRUFBRSxzQkFBc0I7QUFDL0IsbUJBQVcsRUFBRSxnQkFBZ0I7QUFDN0Isb0JBQVksRUFBRSwwQkFBMEI7QUFDeEMsbUJBQVcsRUFBRSxhQUFhO0FBQzFCLGVBQU8sRUFBRSxzQkFBc0I7QUFDL0IsbUJBQVcsRUFBRSxxQkFBcUI7QUFDbEMsb0JBQVksRUFBRSwyQkFBMkI7QUFDekMsb0JBQVksRUFBRSwyQkFBMkI7QUFDekMsY0FBTSxFQUFFLHFCQUFxQjtBQUM3QixnQkFBUSxFQUFFLGlCQUFpQjtBQUMzQixhQUFLLEVBQUUsa0JBQWtCO0FBQ3pCLGtCQUFVLEVBQUUsa0JBQWtCO0FBQzlCLFlBQUksRUFBRSxpQkFBaUI7QUFDdkIsa0JBQVUsRUFBRSx1QkFBdUI7QUFDbkMsbUJBQVcsRUFBRSxhQUFhO0FBQzFCLG9CQUFZLEVBQUUsMEJBQTBCO0FBQ3hDLFlBQUksRUFBRSxpQkFBaUI7QUFDdkIsZ0JBQVEsRUFBRSxzQkFBc0I7QUFDaEMsa0JBQVUsRUFBRSx3QkFBd0I7S0FDdkM7QUFDRCxRQUFJLEVBQUUsS0FBSztBQUNYLGlCQUFhLEVBQUUsT0FBTztDQUN6QixDQUFDLENBQUM7Ozs7QUM5QlAsT0FBTyxDQUFDLE1BQU0sQ0FBQywyQ0FBMkMsRUFBRSxDQUN4RCwyQ0FBMkMsQ0FDOUMsQ0FBQyxDQUNHLFNBQVMsQ0FBQyxjQUFjLEVBQUUsU0FBUyxxQkFBcUIsQ0FBQyxzQkFBc0IsRUFBRTtBQUM5RSxXQUFPO0FBQ0gsZ0JBQVEsRUFBRSxHQUFHO0FBQ2IsZUFBTyxFQUFFLFNBQVM7QUFDbEIsYUFBSyxFQUFFO0FBQ0gsbUJBQU8sRUFBRSxJQUFJO1NBQ2hCOztBQUVELFlBQUksRUFBRSxTQUFTLHNCQUFzQixDQUFDLEtBQUssRUFBRSxPQUFPLEVBQUUsS0FBSyxFQUFFLE9BQU8sRUFBRTtBQUNsRSxnQkFBSSxLQUFLLENBQUMsT0FBTyxLQUFLLFNBQVMsRUFBRTtBQUM3QixxQkFBSyxDQUFDLE9BQU8sR0FBRyxFQUFFLENBQUM7YUFDdEI7OztBQUdELGFBQUMsQ0FBQyxRQUFRLENBQUMsS0FBSyxDQUFDLE9BQU8sRUFBRSxzQkFBc0IsQ0FBQyxDQUFDOzs7QUFHbEQsaUJBQUssQ0FBQyxRQUFRLEdBQUcsSUFBSSxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsRUFBRSxLQUFLLENBQUMsT0FBTyxDQUFDLENBQUM7OztBQUdqRCxpQkFBSyxDQUFDLFFBQVEsQ0FBQyxFQUFFLENBQUMsTUFBTSxFQUFFLFNBQVMsTUFBTSxDQUFDLEtBQUssRUFBRTtBQUM3Qyx1QkFBTyxDQUFDLGFBQWEsQ0FBQyxLQUFLLENBQUMsQ0FBQztBQUM3QixxQkFBSyxDQUFDLE1BQU0sRUFBRSxDQUFDO2FBQ2xCLENBQUMsQ0FBQzs7QUFFSCxpQkFBSyxDQUFDLFFBQVEsQ0FBQyxFQUFFLENBQUMsT0FBTyxFQUFFLFNBQVMsT0FBTyxDQUFDLE9BQU8sRUFBRTtBQUNqRCxvQkFBSSxLQUFLLENBQUMsV0FBVyxLQUFLLFNBQVMsRUFBRTtBQUNqQyx5QkFBSyxDQUFDLElBQUksQ0FBQyxhQUFhLEVBQUUsT0FBTyxDQUFDLFdBQVcsQ0FBQyxDQUFDO2lCQUNsRDthQUNKLENBQUMsQ0FBQzs7O0FBR0gsbUJBQU8sQ0FBQyxFQUFFLENBQUMsVUFBVSxFQUFFLFNBQVMsU0FBUyxHQUFHO0FBQ3hDLHFCQUFLLENBQUMsUUFBUSxDQUFDLE9BQU8sRUFBRSxDQUFDO2FBQzVCLENBQUMsQ0FBQztTQUNOO0tBQ0osQ0FBQztDQUNMLENBQUMsQ0FBQzs7O0FDekNQLE9BQU8sQ0FBQyxNQUFNLENBQUMsaUNBQWlDLEVBQUUsQ0FDOUMsMkNBQTJDLENBQzlDLENBQUMsQ0FBQzs7O0FDRkgsT0FBTyxDQUFDLE1BQU0sQ0FBQyw4Q0FBOEMsRUFBRSxFQUFFLENBQUMsQ0FDN0QsU0FBUyxDQUFDLGdCQUFnQixFQUFFLFNBQVMsdUJBQXVCLEdBQUc7QUFDNUQsV0FBTztBQUNILGdCQUFRLEVBQUUsR0FBRztBQUNiLGVBQU8sRUFBRSxhQUFhO0FBQ3RCLGVBQU8sRUFBRSxTQUFTLDhCQUE4QixDQUFDLFFBQVEsRUFBRTtBQUN2RCxvQkFBUSxDQUFDLFFBQVEsQ0FBQyxlQUFlLENBQUMsQ0FBQzs7QUFFbkMsbUJBQU8sU0FBUywyQkFBMkIsQ0FBQyxLQUFLLEVBQUUsT0FBTyxFQUFFLEtBQUssRUFBRSxjQUFjLEVBQUU7QUFDL0UsdUJBQU8sQ0FBQyxJQUFJLENBQUMsSUFBSSxFQUFFLGNBQWMsQ0FBQyxXQUFXLEVBQUUsQ0FBQyxDQUFDO2FBQ3BELENBQUM7U0FDTDtLQUNKLENBQUM7Q0FDTCxDQUFDLENBQUM7OztBQ2JQLE9BQU8sQ0FBQyxNQUFNLENBQUMsZ0RBQWdELEVBQUUsRUFBRSxDQUFDLENBQy9ELFNBQVMsQ0FBQyxrQkFBa0IsRUFBRSxTQUFTLHlCQUF5QixDQUFDLFFBQVEsRUFBRTtBQUN4RSxXQUFPO0FBQ0gsZ0JBQVEsRUFBRSxHQUFHO0FBQ2IsZ0JBQVEsRUFBRSxJQUFJO0FBQ2QsZ0JBQVEsRUFBRSxJQUFJO0FBQ2QsZUFBTyxFQUFFLGFBQWE7QUFDdEIsZUFBTyxFQUFFLFNBQVMsZ0NBQWdDLENBQUMsUUFBUSxFQUFFO0FBQ3pELG9CQUFRLENBQUMsVUFBVSxDQUFDLG9CQUFvQixDQUFDLENBQUM7O0FBRTFDLG1CQUFPLFNBQVMsNkJBQTZCLENBQUMsS0FBSyxFQUFFLE9BQU8sRUFBRSxLQUFLLEVBQUUsY0FBYyxFQUFFO0FBQ2pGLHVCQUFPLENBQUMsSUFBSSxDQUFDLGlCQUFpQixFQUFFLEdBQUcsR0FBRyxjQUFjLENBQUMsV0FBVyxFQUFFLENBQUMsQ0FBQztBQUNwRSx3QkFBUSxDQUFDLE9BQU8sQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDO2FBQzVCLENBQUM7U0FDTDtLQUNKLENBQUM7Q0FDTCxDQUFDLENBQUM7OztBQ2hCUCxPQUFPLENBQUMsTUFBTSxDQUFDLHlDQUF5QyxFQUFFLEVBQUUsQ0FBQyxDQUN4RCxTQUFTLENBQUMsWUFBWSxFQUFFLFNBQVMsbUJBQW1CLEdBQUc7QUFDcEQsV0FBTztBQUNILGdCQUFRLEVBQUUsSUFBSTtBQUNkLGtCQUFVLEVBQUUsU0FBUyw2QkFBNkIsR0FBRztBQUNqRCxnQkFBSSxJQUFJLEdBQUcsSUFBSTtnQkFDWCxRQUFRLENBQUM7O0FBRWIsZ0JBQUksQ0FBQyxXQUFXLEdBQUcsV0FBVyxDQUFDOztBQUUvQixxQkFBUyxXQUFXLEdBQUc7QUFDbkIsb0JBQUksQ0FBQyxRQUFRLEVBQUU7QUFDWCw0QkFBUSxHQUFHLENBQUMsQ0FBQyxRQUFRLENBQUMsY0FBYyxDQUFDLENBQUM7aUJBQ3pDO0FBQ0QsdUJBQU8sUUFBUSxDQUFDO2FBQ25CO1NBQ0o7S0FDSixDQUFDO0NBQ0wsQ0FBQyxDQUFDOzs7QUNsQlAsT0FBTyxDQUFDLE1BQU0sQ0FBQywrQkFBK0IsRUFBRSxDQUM1Qyx5Q0FBeUMsRUFDekMsZ0RBQWdELEVBQ2hELDhDQUE4QyxDQUNqRCxDQUFDLENBQUM7OztBQ0pILE9BQU8sQ0FBQyxNQUFNLENBQUMsMkNBQTJDLEVBQUUsRUFBRSxDQUFDLENBQzFELFNBQVMsQ0FBQyxjQUFjLEVBQUUsU0FBUyxxQkFBcUIsQ0FBQyxNQUFNLEVBQUU7QUFDOUQsV0FBTztBQUNILGdCQUFRLEVBQUUsR0FBRztBQUNiLGFBQUssRUFBRSxJQUFJO0FBQ1gsbUJBQVcsRUFBRSx5REFBeUQ7O0FBRXRFLGVBQU8sRUFBRSxTQUFTLG1CQUFtQixDQUFDLFFBQVEsRUFBRSxNQUFNLEVBQUU7QUFDcEQsZ0JBQUksT0FBTyxHQUFHLEVBQUUsQ0FBQzs7OztBQUlqQixhQUFDLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxLQUFLLEVBQUUsVUFBUyxHQUFHLEVBQUU7QUFDL0Isb0JBQUksR0FBRyxLQUFLLE9BQU8sRUFBRTtBQUNqQiwyQkFBTyxDQUFDLEdBQUcsQ0FBQyxHQUFHLFFBQVEsQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLENBQUM7aUJBQ3JDO2FBQ0osQ0FBQyxDQUFDOzs7O0FBSUgsbUJBQU8sQ0FBQyxnQkFBZ0IsQ0FBQyxHQUFHLDBCQUEwQixDQUFDOzs7QUFHdkQsb0JBQVEsQ0FBQyxJQUFJLENBQUMsWUFBWSxDQUFDLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxDQUFDOztBQUUxQyxtQkFBTyxTQUFTLGdCQUFnQixDQUFDLE1BQU0sRUFBRSxPQUFPLEVBQUUsS0FBSyxFQUFFO0FBQ3JELG9CQUFJLG1CQUFtQixHQUFHLE1BQU0sQ0FBQyxLQUFLLENBQUMsUUFBUSxDQUFDO29CQUM1QyxhQUFhLEdBQUcsQ0FBQyxFQUFFLEVBQUUsRUFBRSxFQUFFLEVBQUUsRUFBRSxFQUFFLEVBQUUsR0FBRyxDQUFDLENBQUM7O0FBRTFDLHNCQUFNLENBQUMsUUFBUSxHQUFHLFVBQVMsS0FBSyxFQUFFLEtBQUssRUFBRTtBQUNyQyx5QkFBSyxDQUFDLGNBQWMsRUFBRSxDQUFDO0FBQ3ZCLHlCQUFLLEdBQUcsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxLQUFLLENBQUMsQ0FBQztBQUMxQiwwQkFBTSxDQUFDLEtBQUssQ0FBQyxZQUFZLENBQUMsQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDLE9BQU8sRUFBRSxLQUFLLENBQUMsQ0FBQztBQUN6RCwwQkFBTSxDQUFDLGtCQUFrQixDQUFDLENBQUMsRUFBRSxLQUFLLENBQUMsQ0FBQztpQkFDdkMsQ0FBQzs7QUFFRixzQkFBTSxDQUFDLGNBQWMsR0FBRyxZQUFXO0FBQy9CLDJCQUFPLE1BQU0sQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLENBQUMsTUFBTSxDQUFDLE9BQU8sQ0FBQyxDQUFDO2lCQUM3QyxDQUFDOztBQUVGLHNCQUFNLENBQUMsZUFBZSxHQUFHLFlBQVc7QUFDaEMsMkJBQU8sTUFBTSxDQUFDLEtBQUssQ0FBQyxZQUFZLENBQUMsQ0FBQyxNQUFNLENBQUMsT0FBTyxDQUFDLENBQUM7aUJBQ3JELENBQUM7O0FBRUYsc0JBQU0sQ0FBQyxlQUFlLEdBQUcsWUFBVztBQUNoQywyQkFBTyxNQUFNLENBQUMsS0FBSyxDQUFDLFlBQVksQ0FBQyxDQUFDLE1BQU0sQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLENBQUM7aUJBQzFELENBQUM7O0FBRUYsc0JBQU0sQ0FBQyxhQUFhLEdBQUcsWUFBVztBQUM5QiwyQkFBTyxNQUFNLENBQUMsS0FBSyxDQUFDLFVBQVUsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLENBQUM7aUJBQ3hELENBQUM7O0FBRUYsc0JBQU0sQ0FBQyxJQUFJLEdBQUcsWUFBVztBQUNyQiwyQkFBTyxNQUFNLENBQUMsYUFBYSxFQUFFLEdBQUcsTUFBTSxDQUFDLGVBQWUsRUFBRSxDQUFDO2lCQUM1RCxDQUFDOztBQUVGLHNCQUFNLENBQUMsVUFBVSxHQUFHLFlBQVc7QUFDM0IsMkJBQU8sTUFBTSxDQUFDLElBQUksRUFBRSxJQUFJLE1BQU0sQ0FBQyxLQUFLLENBQUMsVUFBVSxDQUFDLENBQUMsTUFBTSxDQUFDLE9BQU8sQ0FBQyxLQUFLLEtBQUssQ0FBQztpQkFDOUUsQ0FBQzs7QUFFRixzQkFBTSxDQUFDLFNBQVMsR0FBRyxZQUFXO0FBQzFCLHdCQUFJLE1BQU0sR0FBRyxNQUFNLENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQyxDQUFDLE1BQU0sQ0FBQyxPQUFPLENBQUMsQ0FBQzs7QUFFbEQsd0JBQUksQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLE1BQU0sQ0FBQyxFQUFFO0FBQ3hCLCtCQUFPLGFBQWEsQ0FBQztxQkFDeEI7O0FBRUQsMkJBQU8sTUFBTSxDQUFDO2lCQUNqQixDQUFDOztBQUVGLHNCQUFNLENBQUMsa0JBQWtCLEdBQUcsVUFBUyxJQUFJLEVBQUUsS0FBSyxFQUFFO0FBQzlDLHdCQUFJLHlCQUF5QixHQUFHO0FBQ3hCLDZCQUFLLEVBQUUsS0FBSyxJQUFJLE1BQU0sQ0FBQyxlQUFlLEVBQUU7QUFDeEMsNEJBQUksRUFBRSxJQUFJO3FCQUNiO3dCQUNELG1CQUFtQixDQUFDOztBQUV4QiwwQkFBTSxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDLE9BQU8sRUFBRSxJQUFJLENBQUMsQ0FBQzs7QUFFaEQsdUNBQW1CLEdBQUcsbUJBQW1CLENBQUMsTUFBTSxFQUFFLHlCQUF5QixDQUFDLENBQUM7Ozs7QUFJN0Usd0JBQUksT0FBTyxtQkFBbUIsS0FBSyxVQUFVLEVBQUU7QUFDM0MsMkNBQW1CLENBQUMseUJBQXlCLENBQUMsQ0FBQztxQkFDbEQ7aUJBQ0osQ0FBQzthQUNMLENBQUM7U0FDTDtLQUNKLENBQUM7Q0FDTCxDQUFDLENBQUM7OztBQzFGUCxPQUFPLENBQUMsTUFBTSxDQUFDLGlDQUFpQyxFQUFFLENBQzlDLDJDQUEyQyxDQUM5QyxDQUFDLENBQUM7OztBQ0ZILE9BQU8sQ0FBQyxNQUFNLENBQUMsOENBQThDLEVBQUUsQ0FDM0QsMkNBQTJDLENBQzlDLENBQUMsQ0FFRyxVQUFVLENBQUMsbUJBQW1CLEVBQUUsU0FBUyxpQkFBaUIsQ0FBQyxNQUFNLEVBQUUsSUFBSSxFQUFFLE1BQU0sRUFBRSxNQUFNLEVBQUUsYUFBYSxFQUFFO0FBQ3JHLFFBQUksSUFBSSxHQUFHLElBQUk7UUFDWCxzQkFBc0IsR0FBRyxhQUFhLENBQUMsU0FBUyxDQUFDOzs7OztBQUtyRCxpQkFBYSxDQUFDLElBQUksQ0FBQyxJQUFJLEVBQUUsSUFBSSxFQUFHLE1BQU0sQ0FBQyxNQUFNLENBQUMsV0FBVyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUUsQ0FBQzs7O0FBR3JFLFFBQUksQ0FBQyxrQkFBa0IsR0FBRyxzQkFBc0IsQ0FBQyxrQkFBa0IsQ0FBQztBQUNwRSxRQUFJLENBQUMsYUFBYSxHQUFHLHNCQUFzQixDQUFDLGFBQWEsQ0FBQztBQUMxRCxRQUFJLENBQUMsZUFBZSxHQUFHLHNCQUFzQixDQUFDLGVBQWUsQ0FBQztBQUM5RCxRQUFJLENBQUMsSUFBSSxHQUFHLHNCQUFzQixDQUFDLElBQUksQ0FBQztBQUN4QyxRQUFJLENBQUMsYUFBYSxHQUFHLHNCQUFzQixDQUFDLGFBQWEsQ0FBQztBQUMxRCxRQUFJLENBQUMsZUFBZSxHQUFHLHNCQUFzQixDQUFDLGVBQWUsQ0FBQztBQUM5RCxRQUFJLENBQUMsYUFBYSxHQUFHLHNCQUFzQixDQUFDLGFBQWEsQ0FBQztBQUMxRCxRQUFJLENBQUMsbUJBQW1CLEdBQUcsc0JBQXNCLENBQUMsbUJBQW1CLENBQUM7QUFDdEUsUUFBSSxDQUFDLE9BQU8sR0FBRyxzQkFBc0IsQ0FBQyxPQUFPLENBQUM7QUFDOUMsUUFBSSxDQUFDLGdCQUFnQixHQUFHLHNCQUFzQixDQUFDLGdCQUFnQixDQUFDO0FBQ2hFLFFBQUksQ0FBQyxVQUFVLEdBQUcsQ0FBQyxDQUFDLElBQUksQ0FBQyxzQkFBc0IsQ0FBQyxVQUFVLEVBQUUsSUFBSSxDQUFDLENBQUM7QUFDbEUsUUFBSSxDQUFDLFVBQVUsR0FBRyxzQkFBc0IsQ0FBQyxVQUFVLENBQUM7QUFDcEQsUUFBSSxDQUFDLFdBQVcsR0FBRyxzQkFBc0IsQ0FBQyxXQUFXLENBQUM7QUFDdEQsUUFBSSxDQUFDLGdCQUFnQixHQUFHLHNCQUFzQixDQUFDLGdCQUFnQixDQUFDOztBQUVoRSxRQUFJLEVBQUUsQ0FBQzs7QUFFUCxhQUFTLElBQUksR0FBRztBQUNaLFlBQUksZ0JBQWdCLENBQUM7O0FBRXJCLHdCQUFnQixHQUFHLE1BQU0sQ0FBQyxNQUFNLENBQUMsZ0JBQWdCLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQztBQUMzRCxZQUFJLENBQUMsQ0FBQyxDQUFDLFVBQVUsQ0FBQyxnQkFBZ0IsQ0FBQyxFQUFFO0FBQ2pDLGdCQUFJLENBQUMsS0FBSyxDQUFDLGtFQUFrRSxDQUFDLENBQUM7QUFDL0UsbUJBQU87U0FDVjtBQUNELFlBQUksQ0FBQyxnQkFBZ0IsR0FBRyxnQkFBZ0IsQ0FBQzs7QUFFekMsWUFBSSxDQUFDLElBQUksRUFBRSxDQUFDO0tBQ2Y7Q0FDSixDQUFDLENBQUM7OztBQzNDUCxPQUFPLENBQUMsTUFBTSxDQUFDLDZDQUE2QyxFQUFFLENBQzFELDhDQUE4QyxFQUM5QyxxREFBcUQsRUFDckQsV0FBVyxDQUNkLENBQUM7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0NBa0RHLFNBQVMsQ0FBQyxlQUFlLEVBQUUsU0FBUyxzQkFBc0IsQ0FBQyxNQUFNLEVBQUU7QUFDaEUsUUFBSSxTQUFTLEdBQUc7QUFDWixnQkFBUSxFQUFFLElBQUk7QUFDZCxrQkFBVSxFQUFFLG9DQUFvQztBQUNoRCxZQUFJLEVBQUUsU0FBUyxpQkFBaUIsQ0FBQyxNQUFNLEVBQUUsT0FBTyxFQUFFLEtBQUssRUFBRSxpQkFBaUIsRUFBRTtBQUN4RSxnQkFBSSxLQUFLLENBQUMsZUFBZSxFQUFFOztBQUV2QixzQkFBTSxDQUFDLEtBQUssQ0FBQyxlQUFlLENBQUMsQ0FBQyxNQUFNLENBQUMsTUFBTSxFQUFFLGlCQUFpQixDQUFDLENBQUM7YUFDbkU7U0FDSjtLQUNKLENBQUM7O0FBRUYsV0FBTyxTQUFTLENBQUM7Q0FDcEIsQ0FBQyxDQUFDOzs7QUNuRVAsT0FBTyxDQUFDLE1BQU0sQ0FBQyxtQ0FBbUMsRUFBRSxDQUNoRCw2Q0FBNkMsRUFDN0MscURBQXFELEVBQ3JELG1EQUFtRCxDQUN0RCxDQUFDLENBQUM7OztBQ0pILE9BQU8sQ0FBQyxNQUFNLENBQUMscURBQXFELEVBQUUsQ0FDbEUsbURBQW1ELENBQ3RELENBQUMsQ0FDRyxTQUFTLENBQUMsVUFBVSxFQUFFLFNBQVMsaUJBQWlCLENBQUMsSUFBSSxFQUFFLG9CQUFvQixFQUFFO0FBQzFFLFFBQUksU0FBUyxHQUFHO0FBQ1osbUJBQVcsRUFBRSx3REFBd0Q7QUFDckUsZ0JBQVEsRUFBRSxHQUFHO0FBQ2Isa0JBQVUsRUFBRSxJQUFJO0FBQ2hCLGFBQUssRUFBRTtBQUNILHFCQUFTLEVBQUUsR0FBRztBQUNkLHNCQUFVLEVBQUUsR0FBRztBQUNmLG1CQUFPLEVBQUUsR0FBRztTQUNmO0FBQ0QsZUFBTyxFQUFFLGtCQUFrQjtBQUMzQixZQUFJLEVBQUUscUJBQXFCO0tBQzlCLENBQUM7O0FBRUYsYUFBUyxxQkFBcUIsQ0FBQyxLQUFLLEVBQUUsT0FBTyxFQUFFLEtBQUssRUFBRSxpQkFBaUIsRUFBRTtBQUNyRSxZQUFJLGFBQWEsRUFDYixhQUFhLENBQUM7O0FBRWxCLFlBQUksS0FBSyxDQUFDLE9BQU8sRUFBRTtBQUNmLHlCQUFhLEdBQUcsb0JBQW9CLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsQ0FBQztTQUMzRCxNQUFNLElBQUksaUJBQWlCLEVBQUU7QUFDMUIseUJBQWEsR0FBRyxpQkFBaUIsQ0FBQztTQUNyQyxNQUFNO0FBQ0gsZ0JBQUksQ0FBQyxLQUFLLENBQUMsb0ZBQW9GLENBQUMsQ0FBQztTQUNwRzs7QUFFRCxxQkFBYSxHQUFHLGFBQWEsQ0FBQyxXQUFXLENBQUMsYUFBYSxDQUFDOztBQUV4RCxhQUFLLENBQUMsR0FBRyxHQUFHLGFBQWEsQ0FBQyxHQUFHLENBQUM7QUFDOUIsYUFBSyxDQUFDLElBQUksR0FBRyxhQUFhLENBQUMsSUFBSSxDQUFDO0FBQ2hDLGFBQUssQ0FBQyxNQUFNLEdBQUcsYUFBYSxDQUFDLE1BQU0sQ0FBQztBQUNwQyxhQUFLLENBQUMsT0FBTyxHQUFHLGFBQWEsQ0FBQyxPQUFPLENBQUM7QUFDdEMsYUFBSyxDQUFDLElBQUksR0FBRyxJQUFJLENBQUM7O0FBRWxCLGlCQUFTLElBQUksQ0FBQyxNQUFNLEVBQUU7QUFDbEIsZ0JBQUksTUFBTSxFQUNOLE9BQU8sQ0FBQzs7QUFFWixnQkFBSSxNQUFNLEVBQUU7QUFDUixzQkFBTSxDQUFDLGNBQWMsRUFBRSxDQUFDO2FBQzNCOztBQUVELGdCQUFJLGFBQWEsQ0FBQyxNQUFNLEtBQUssS0FBSyxDQUFDLFNBQVMsRUFBRTtBQUMxQyxzQkFBTSxHQUFHLGFBQWEsQ0FBQyxNQUFNLENBQUM7QUFDOUIsdUJBQU8sR0FBRyxhQUFhLENBQUMsT0FBTyxLQUFLLEtBQUssQ0FBQyxHQUFHLEdBQUcsS0FBSyxDQUFDLElBQUksR0FBRyxLQUFLLENBQUMsR0FBRyxDQUFDO2FBQzFFLE1BQU07QUFDSCxzQkFBTSxHQUFHLEtBQUssQ0FBQyxTQUFTLENBQUM7QUFDekIsdUJBQU8sR0FBRyxLQUFLLENBQUMsR0FBRyxDQUFDO2FBQ3ZCOztBQUVELHlCQUFhLENBQUMsVUFBVSxDQUFDLE1BQU0sRUFBRSxPQUFPLENBQUMsQ0FBQztTQUM3QztLQUNKOztBQUVELFdBQU8sU0FBUyxDQUFDO0NBQ3BCLENBQUMsQ0FBQzs7O0FDMURQLE9BQU8sQ0FBQyxNQUFNLENBQUMsNENBQTRDLEVBQUUsRUFBRSxDQUFDLENBQzNELFVBQVUsQ0FBQyxrQkFBa0IsRUFBRSxTQUFTLGdCQUFnQixDQUFDLE1BQU0sRUFBRSxRQUFRLEVBQUUsSUFBSSxFQUFFLE1BQU0sRUFBRSxNQUFNLEVBQUU7QUFDOUYsUUFBSSxJQUFJLEdBQUcsSUFBSTtRQUNYLFVBQVUsR0FBRyxNQUFNLENBQUMsTUFBTSxDQUFDLFlBQVksQ0FBQyxDQUFDLElBQUksQ0FBQyxJQUFJLEtBQUs7UUFDdkQsU0FBUyxHQUFHLE1BQU0sQ0FBQyxNQUFNLENBQUMsV0FBVyxDQUFDLENBQUMsSUFBSSxDQUFDLElBQUksSUFBSTtRQUNwRCxPQUFPLEdBQUcsUUFBUSxDQUFDLFVBQVUsQ0FBQyxTQUFTLENBQUMsQ0FBQzs7QUFFN0MsUUFBSSxFQUFFLENBQUM7OztBQUdQLGFBQVMsYUFBYSxHQUFHO0FBQ3JCLGVBQU8sT0FBTyxDQUFDLFdBQVcsQ0FBQztLQUM5Qjs7QUFFRCxhQUFTLFFBQVEsR0FBRztBQUNoQixlQUFPLElBQUksQ0FBQyxLQUFLLElBQUksSUFBSSxDQUFDLE9BQU8sQ0FBQztLQUNyQzs7QUFFRCxhQUFTLGlCQUFpQixHQUFHO0FBQ3pCLGVBQU8sSUFBSSxDQUFDLGNBQWMsQ0FBQztLQUM5Qjs7O0FBR0QsYUFBUyxnQkFBZ0IsQ0FBQyxVQUFVLEVBQUU7QUFDbEMsZUFBTyxDQUFDLGFBQWEsQ0FBQyxVQUFVLENBQUMsQ0FBQztBQUNsQyxlQUFPLENBQUMsZ0JBQWdCLEVBQUUsQ0FBQztBQUMzQixlQUFPLENBQUMsT0FBTyxFQUFFLENBQUM7S0FDckI7O0FBRUQsYUFBUyxvQkFBb0IsQ0FBQyxVQUFVLEVBQUU7QUFDdEMsWUFBSSxVQUFVLEtBQUssU0FBUyxFQUFFO0FBQzFCLCtCQUFtQixFQUFFLENBQUM7U0FDekIsTUFBTSxJQUFJLFVBQVUsS0FBSyxVQUFVLEVBQUU7QUFDbEMsb0NBQXdCLEVBQUUsQ0FBQztTQUM5QjtLQUNKOztBQUVELGFBQVMsbUJBQW1CLEdBQUc7QUFDM0IsWUFBSSxVQUFVLEdBQUcsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsY0FBYyxFQUFFLFFBQVEsRUFBRSxDQUFDLENBQUM7O0FBRTVELFlBQUksQ0FBQyxVQUFVLEVBQUU7QUFDYixnQkFBSSxDQUFDLGNBQWMsQ0FBQyxJQUFJLENBQUMsUUFBUSxFQUFFLENBQUMsQ0FBQztTQUN4QztLQUNKOztBQUVELGFBQVMsd0JBQXdCLEdBQUc7QUFDaEMsWUFBSSxLQUFLLEdBQUcsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsY0FBYyxFQUFFLFFBQVEsRUFBRSxDQUFDLENBQUM7O0FBRXZELFlBQUksS0FBSyxLQUFLLENBQUMsQ0FBQyxFQUFFO0FBQ2QsZ0JBQUksQ0FBQyxjQUFjLENBQUMsTUFBTSxDQUFDLEtBQUssRUFBRSxDQUFDLENBQUMsQ0FBQztTQUN4QztLQUNKOzs7QUFHRCxhQUFTLGVBQWUsQ0FBQyxVQUFVLEVBQUUsYUFBYSxFQUFFO0FBQ2hELFlBQUksaUJBQWlCLEVBQ2pCLHFCQUFxQixDQUFDOzs7QUFHMUIsWUFBSSxDQUFDLENBQUMsV0FBVyxDQUFDLFVBQVUsQ0FBQyxJQUFJLFVBQVUsS0FBSyxhQUFhLEVBQUU7QUFDM0QsbUJBQU87U0FDVjs7O0FBR0QseUJBQWlCLEdBQUcsSUFBSSxDQUFDLGNBQWMsQ0FBQyxLQUFLLEVBQUUsQ0FBQzs7O0FBR2hELDRCQUFvQixDQUFDLFVBQVUsQ0FBQyxDQUFDOzs7QUFHakMsNkJBQXFCLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLGNBQWMsRUFBRSxpQkFBaUIsQ0FBQyxDQUFDLE1BQU0sQ0FBQzs7O0FBRy9FLFlBQUksSUFBSSxDQUFDLFFBQVEsSUFBSSxxQkFBcUIsRUFBRTtBQUN4QyxnQkFBSSxDQUFDLFFBQVEsQ0FBQztBQUNWLDhCQUFjLEVBQUUsSUFBSSxDQUFDLGNBQWM7QUFDbkMsaUNBQWlCLEVBQUUsaUJBQWlCO2FBQ3ZDLENBQUMsQ0FBQztTQUNOO0tBQ0o7O0FBRUQsYUFBUyxtQkFBbUIsQ0FBQyxjQUFjLEVBQUU7O0FBRXpDLFlBQUksVUFBVSxHQUFHLENBQUMsQ0FBQyxPQUFPLENBQUMsY0FBYyxFQUFFLFFBQVEsRUFBRSxDQUFDO1lBQ2xELFVBQVUsR0FBRyxhQUFhLEVBQUUsQ0FBQzs7QUFFakMsWUFBSSxVQUFVLElBQUksVUFBVSxLQUFLLFNBQVMsRUFBRTtBQUN4Qyw0QkFBZ0IsQ0FBQyxTQUFTLENBQUMsQ0FBQztTQUMvQixNQUFNLElBQUksQ0FBQyxVQUFVLElBQUksVUFBVSxLQUFLLFVBQVUsRUFBRTtBQUNqRCw0QkFBZ0IsQ0FBQyxVQUFVLENBQUMsQ0FBQztTQUNoQztLQUNKOzs7QUFHRCxhQUFTLElBQUksR0FBRztBQUNaLFlBQUksTUFBTSxDQUFDLElBQUksS0FBSyxVQUFVLEVBQUU7QUFDNUIsZ0JBQUksQ0FBQyxLQUFLLENBQUMsa0VBQWtFLENBQUMsQ0FBQzs7QUFFL0UsbUJBQU87U0FDVjs7QUFFRCxjQUFNLENBQUMsTUFBTSxDQUFDLGFBQWEsRUFBRSxlQUFlLENBQUMsQ0FBQztBQUM5QyxjQUFNLENBQUMsZ0JBQWdCLENBQUMsaUJBQWlCLEVBQUUsbUJBQW1CLENBQUMsQ0FBQztLQUNuRTtDQUNKLENBQUMsQ0FBQzs7O0FDeEdQLE9BQU8sQ0FBQyxNQUFNLENBQUMsMkNBQTJDLEVBQUUsQ0FDeEQsNENBQTRDLENBQy9DLENBQUM7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0NBa0RHLFNBQVMsQ0FBQyxjQUFjLEVBQUUsU0FBUyxxQkFBcUIsR0FBRztBQUN4RCxXQUFPO0FBQ0gsZ0JBQVEsRUFBRSxHQUFHO0FBQ2IsZUFBTyxFQUFFLFNBQVM7QUFDbEIsa0JBQVUsRUFBRSxrQkFBa0I7QUFDOUIsb0JBQVksRUFBRSxrQkFBa0I7QUFDaEMsd0JBQWdCLEVBQUUsSUFBSTtBQUN0QixhQUFLLEVBQUU7QUFDSCxvQkFBUSxFQUFFLHFCQUFxQjtBQUMvQiwwQkFBYyxFQUFFLGVBQWU7QUFDL0IsaUJBQUssRUFBRSxHQUFHO0FBQ1YsbUJBQU8sRUFBRSxHQUFHO1NBQ2Y7S0FDSixDQUFDO0NBQ0wsQ0FBQyxDQUFDOzs7QUNsRVAsT0FBTyxDQUFDLE1BQU0sQ0FBQyxpQ0FBaUMsRUFBRSxDQUM5QywyQ0FBMkMsQ0FDOUMsQ0FBQyxDQUFDOzs7Ozs7Ozs7Ozs7O0FDUUgsT0FBTyxDQUFDLE1BQU0sQ0FBQyx5Q0FBeUMsRUFBRSxDQUN0RCx3QkFBd0IsQ0FDM0IsQ0FBQyxDQUNHLFNBQVMsQ0FBQyxZQUFZLEVBQUUsU0FBUyxtQkFBbUIsQ0FBQyxRQUFRLEVBQUUsY0FBYyxFQUFFO0FBQzVFLFFBQU0sa0JBQWtCLEdBQUcsY0FBYyxDQUFDLEdBQUcsQ0FBQyxpRUFBaUUsQ0FBQyxDQUFDOztBQUVqSCxXQUFPO0FBQ0gsWUFBSSxFQUFFLFNBQVMsY0FBYyxDQUFDLEtBQUssRUFBRSxJQUFJLEVBQUUsSUFBSSxFQUFFLFFBQVEsRUFBRTtBQUN2RCxnQkFBTSxpQkFBaUIsR0FBRyxRQUFRLENBQUMsa0JBQWtCLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQztBQUM5RCxnQkFBTSxhQUFhLEdBQUc7QUFDbEIsd0JBQVEsRUFBRSxJQUFJO0FBQ2QsZ0NBQWdCLEVBQUUsSUFBSTtBQUN0Qix3QkFBUSxFQUFFLElBQUk7YUFDakIsQ0FBQzs7QUFFRixpQkFBSyxDQUFDLFFBQVEsR0FBRyxDQUFDLENBQUMsUUFBUSxDQUFDLEtBQUssQ0FBQyxRQUFRLEVBQUUsYUFBYSxDQUFDLENBQUM7QUFDM0QsaUJBQUssQ0FBQyxpQkFBaUIsR0FBRyxpQkFBaUIsQ0FBQzs7Ozs7O0FBTTVDLHFCQUFTLGlCQUFpQixHQUFHO0FBQ3pCLHVCQUFPLGlCQUFpQixDQUFDLENBQUMsQ0FBQyxDQUFDLFNBQVMsQ0FBQzthQUN6Qzs7Ozs7OztBQU9ELGlCQUFLLENBQUMsTUFBTSxDQUFDLFNBQVMsRUFBRSxTQUFTLENBQUMsQ0FBQzs7QUFFbkMsaUJBQUssQ0FBQyxRQUFRLEdBQUcsUUFBUSxDQUFDOztBQUUxQixxQkFBUyxTQUFTLEdBQUc7QUFDakIsdUJBQU8sUUFBUSxDQUFDLFFBQVEsQ0FBQyxZQUFZLENBQUM7YUFDekM7O0FBRUQscUJBQVMsU0FBUyxDQUFDLElBQUksRUFBRTtBQUNyQixxQkFBSyxDQUFDLE1BQU0sQ0FBQyxNQUFNLEdBQUcsSUFBSSxDQUFDO2FBQzlCO1NBQ0o7QUFDRCxlQUFPLEVBQUUsT0FBTztBQUNoQixnQkFBUSxFQUFFLElBQUk7QUFDZCxhQUFLLEVBQUU7QUFDSCxrQkFBTSxFQUFFLEdBQUc7QUFDWCxvQkFBUSxFQUFFLEdBQUc7U0FDaEI7QUFDRCxtQkFBVyxFQUFFLHFEQUFxRDtLQUNyRSxDQUFDO0NBQ0wsQ0FBQyxDQUFDOzs7QUM3RFAsT0FBTyxDQUFDLE1BQU0sQ0FBQywrQkFBK0IsRUFBRSxDQUM1QyxjQUFjLEVBQ2Qsc0NBQXNDLEVBQ3RDLHlDQUF5QyxFQUN6Qyx5Q0FBeUMsRUFDekMsU0FBUyxDQUNaLENBQUMsQ0FBQzs7O0FDTkgsT0FBTyxDQUFDLE1BQU0sQ0FBQyw4Q0FBOEMsRUFBRSxFQUFFLENBQUMsQ0FDN0QsUUFBUSxDQUFDLFVBQVUsRUFBRTtBQUNsQixzQkFBa0IsRUFBRSxNQUFNO0FBQzFCLGlCQUFhLEVBQUUsWUFBWTtBQUMzQixjQUFVLEVBQUUsVUFBVTtBQUN0QixnQkFBWSxFQUFFLFlBQVk7QUFDMUIsVUFBTSxFQUFFLE1BQU07Q0FDakIsQ0FBQyxDQUFDOzs7QUNQUCxPQUFPLENBQUMsTUFBTSxDQUFDLGdEQUFnRCxFQUFFLENBQzdELDhDQUE4QyxDQUNqRCxDQUFDLENBQ0csVUFBVSxDQUFDLHFCQUFxQixFQUFFLFNBQVMsbUJBQW1CLENBQUMsUUFBUSxFQUFFLFFBQVEsRUFBRTtBQUNoRixRQUFNLElBQUksR0FBRyxJQUFJLENBQUM7O0FBRWxCLFFBQUksQ0FBQyxlQUFlLEdBQUcsZUFBZSxDQUFDO0FBQ3ZDLFFBQUksQ0FBQyxjQUFjLEdBQUcsY0FBYyxDQUFDO0FBQ3JDLFFBQUksQ0FBQyxRQUFRLEdBQUcsUUFBUSxDQUFDOztBQUV6QixRQUFJLEVBQUUsQ0FBQzs7QUFFUCxhQUFTLElBQUksR0FBRztBQUNaLGdCQUFRLENBQUMsUUFBUSxDQUFDLGlCQUFpQixDQUFDLENBQUM7S0FDeEM7Ozs7OztBQU1ELGFBQVMsZUFBZSxHQUFHO0FBQ3ZCLGVBQU8sQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxlQUFlLEVBQUUsQ0FBQyxDQUFDO0tBQzdDOzs7Ozs7O0FBT0QsYUFBUyxjQUFjLENBQUMsTUFBTSxFQUFFO0FBQzVCLGVBQU8sTUFBTSxLQUFLLElBQUksQ0FBQyxlQUFlLEVBQUUsQ0FBQztLQUM1Qzs7Ozs7OztBQU9ELGFBQVMsUUFBUSxDQUFDLE1BQU0sRUFBRTtBQUN0QixlQUFPLFFBQVEsQ0FBQyxNQUFNLENBQUMsQ0FBQztLQUMzQjtDQUNKLENBQUMsQ0FBQzs7Ozs7Ozs7Ozs7O0FDaENQLE9BQU8sQ0FBQyxNQUFNLENBQUMsK0NBQStDLEVBQUUsQ0FDNUQsZ0RBQWdELENBQ25ELENBQUMsQ0FDRyxTQUFTLENBQUMsaUJBQWlCLEVBQUUsU0FBUyx3QkFBd0IsR0FBRztBQUM5RCxXQUFPO0FBQ0gsd0JBQWdCLEVBQUUsSUFBSTtBQUN0QixrQkFBVSxFQUFFLDRDQUE0QztBQUN4RCxnQkFBUSxFQUFFLEdBQUc7QUFDYixhQUFLLEVBQUU7QUFDSCwyQkFBZSxFQUFFLGVBQWU7QUFDaEMsNkJBQWlCLEVBQUUsaUJBQWlCO1NBQ3ZDO0FBQ0QsbUJBQVcsRUFBRSxpRUFBaUU7S0FDakYsQ0FBQztDQUNMLENBQUMsQ0FBQzs7O0FDdkJQLE9BQU8sQ0FBQyxNQUFNLENBQUMscUNBQXFDLEVBQUUsQ0FDbEQsOENBQThDLEVBQzlDLGdEQUFnRCxFQUNoRCwrQ0FBK0MsQ0FDbEQsQ0FBQyxDQUFDOzs7QUNKSCxPQUFPLENBQUMsTUFBTSxDQUFDLGtDQUFrQyxFQUFFLEVBQUUsQ0FBQyxDQUNqRCxTQUFTLENBQUMsTUFBTSxFQUFFLFNBQVMsYUFBYSxHQUFHO0FBQ3hDLFdBQU87QUFDSCxnQkFBUSxFQUFFLEdBQUc7QUFDYixZQUFJLEVBQUUsU0FBUyxRQUFRLENBQUMsS0FBSyxFQUFFLE9BQU8sRUFBRSxLQUFLLEVBQUU7QUFDM0MsbUJBQU8sQ0FBQyxRQUFRLENBQUMsTUFBTSxDQUFDLENBQUM7QUFDekIsbUJBQU8sQ0FBQyxJQUFJLENBQUMsWUFBWSxFQUFFLEVBQUUsQ0FBQyxDQUFDOzs7QUFHL0IsZ0JBQUksQ0FBQyxLQUFLLENBQUMsZ0JBQWdCLEVBQUU7QUFDekIsdUJBQU8sQ0FBQyxFQUFFLENBQUMsUUFBUSxFQUFFLFNBQVMsMEJBQTBCLEdBQUc7QUFDdkQsd0JBQUksWUFBWSxHQUFHLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQyxhQUFhLENBQUMsYUFBYSxDQUFDLENBQUM7O0FBRTNELHdCQUFJLFlBQVksRUFBRTtBQUNkLG9DQUFZLENBQUMsS0FBSyxFQUFFLENBQUM7OztBQUdyQiw0QkFBSSxZQUFZLENBQUMsTUFBTSxFQUFFO0FBQ3JCLHdDQUFZLENBQUMsTUFBTSxFQUFFLENBQUM7eUJBQ3pCO3FCQUNKO2lCQUNKLENBQUMsQ0FBQzthQUNOO1NBQ0o7S0FDSixDQUFDO0NBQ0wsQ0FBQyxDQUFDOzs7QUN6QlAsT0FBTyxDQUFDLE1BQU0sQ0FBQyx3QkFBd0IsRUFBRSxDQUNyQyxrQ0FBa0MsQ0FDckMsQ0FBQyxDQUFDOzs7QUNGSCxPQUFPLENBQUMsTUFBTSxDQUFDLHdDQUF3QyxFQUFFLEVBQUUsQ0FBQyxDQUN2RCxTQUFTLENBQUMsV0FBVyxFQUFFLFNBQVMsa0JBQWtCLENBQUMsSUFBSSxFQUFFO0FBQ3RELFdBQU87QUFDSCxlQUFPLEVBQUUsT0FBTztBQUNoQixnQkFBUSxFQUFFLElBQUk7QUFDZCxhQUFLLEVBQUUsSUFBSTtBQUNYLFlBQUksRUFBRTtBQUNGLGVBQUcsRUFBRSxTQUFTLGFBQWEsQ0FBQyxLQUFLLEVBQUUsT0FBTyxFQUFFLEtBQUssRUFBRTs7QUFFL0MscUJBQUssQ0FBQyxRQUFRLEdBQUcsS0FBSyxDQUFDLFFBQVEsQ0FBQzthQUNuQzs7QUFFRCxnQkFBSSxFQUFFLFNBQVMsYUFBYSxDQUFDLEtBQUssRUFBRSxPQUFPLEVBQUUsS0FBSyxFQUFFLFFBQVEsRUFBRTs7QUFFMUQsb0JBQUksUUFBUSxHQUFHLEtBQUssQ0FBQyxRQUFRO29CQUN6QixlQUFlLEdBQUcsU0FBUyxlQUFlLEdBQUc7QUFBRSwyQkFBTyxRQUFRLENBQUMsUUFBUSxDQUFDLENBQUMsTUFBTSxDQUFDO2lCQUFFO29CQUNsRixlQUFlLEdBQUcsU0FBUyxlQUFlLEdBQUc7QUFBRSwyQkFBTyxRQUFRLENBQUMsVUFBVSxDQUFDO2lCQUFFLENBQUM7O0FBRWpGLHVCQUFPLENBQUMsUUFBUSxDQUFDLFlBQVksQ0FBQyxDQUFDOzs7QUFHL0Isb0JBQUksQ0FBQyxRQUFRLEVBQUU7QUFDWCwyQkFBTztpQkFDVjs7O0FBR0Qsb0JBQUksQ0FBQyxRQUFRLENBQUMsUUFBUSxDQUFDLEVBQUU7QUFDckIsMkJBQU8sSUFBSSxDQUFDLElBQUksQ0FBQyxrRkFBa0YsQ0FBQyxDQUFDO2lCQUN4Rzs7QUFFRCxvQkFBSSxFQUFFLENBQUM7O0FBRVAseUJBQVMsSUFBSSxHQUFHOztBQUVaLHlCQUFLLENBQUMsTUFBTSxDQUFDLGVBQWUsRUFBRSxhQUFhLENBQUMsQ0FBQztBQUM3Qyx5QkFBSyxDQUFDLE1BQU0sQ0FBQyxlQUFlLEVBQUUsYUFBYSxDQUFDLENBQUM7aUJBQ2hEOztBQUVELHlCQUFTLGFBQWEsR0FBRzs7QUFFckIsMkJBQU8sQ0FBQyxXQUFXLENBQUMsbUJBQW1CLEVBQUUsUUFBUSxDQUFDLFVBQVUsSUFBSSxRQUFRLENBQUMsUUFBUSxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUM7aUJBQ2hHO2FBQ0o7U0FDSjtLQUNKLENBQUM7Q0FDTCxDQUFDLENBQUM7OztBQzdDUCxPQUFPLENBQUMsTUFBTSxDQUFDLDhCQUE4QixFQUFFLENBQzNDLHdDQUF3QyxFQUN4QyxvQ0FBb0MsRUFDcEMscUNBQXFDLENBQ3hDLENBQUMsQ0FBQzs7O0FDSkgsT0FBTyxDQUFDLE1BQU0sQ0FBQyw4Q0FBOEMsRUFBRSxFQUFFLENBQUMsQ0FDN0QsU0FBUyxDQUFDLGdCQUFnQixFQUFFLFNBQVMsdUJBQXVCLENBQUMsUUFBUSxFQUFFO0FBQ3BFLFdBQU87QUFDSCxnQkFBUSxFQUFFLEVBQUU7QUFDWixlQUFPLEVBQUUsSUFBSTtBQUNiLGdCQUFRLEVBQUUsSUFBSTtBQUNkLG1CQUFXLEVBQUUsK0RBQStEO0FBQzVFLGdCQUFRLEVBQUUsSUFBSTtBQUNkLGtCQUFVLEVBQUUsSUFBSTtBQUNoQixlQUFPLEVBQUUsU0FBUyxxQkFBcUIsQ0FBQyxRQUFRLEVBQUUsTUFBTSxFQUFFOzs7QUFHdEQsZ0JBQUksUUFBUSxDQUFDLElBQUksQ0FBQyxXQUFXLENBQUMsS0FBSyxTQUFTLEVBQUU7QUFDMUMsc0JBQU0sSUFBSSxXQUFXLENBQ2pCLDhFQUE4RSxHQUM5RSxvRkFBb0YsR0FDcEYsYUFBYSxHQUFHLE1BQU0sQ0FBQyxRQUFRLENBQ2xDLENBQUM7YUFDTDs7QUFFRCxtQkFBTztBQUNILG9CQUFJLEVBQUUsU0FBUyxzQkFBc0IsQ0FBQyxLQUFLLEVBQUUsT0FBTyxFQUFFLEtBQUssRUFBRSxXQUFXLEVBQUUsVUFBVSxFQUFFO0FBQ2xGLHlCQUFLLENBQUMsUUFBUSxHQUFHLEtBQUssQ0FBQyxRQUFRLElBQUksS0FBSyxDQUFDLFFBQVEsQ0FBQzs7QUFFbEQsOEJBQVUsQ0FBQyxTQUFTLHdCQUF3QixDQUFDLFVBQVUsRUFBRTtBQUNyRCw0QkFBSSxZQUFZLEdBQUcsT0FBTyxDQUFDLE9BQU8sQ0FBQyxTQUFTLENBQUMsQ0FBQzs7OztBQUk5QyxvQ0FBWSxDQUFDLElBQUksQ0FBQyxLQUFLLEVBQUUsS0FBSyxDQUFDLFFBQVEsQ0FBQyxDQUFDO0FBQ3pDLG9DQUFZLENBQUMsSUFBSSxDQUFDLFlBQVksRUFBRSxLQUFLLENBQUMsUUFBUSxDQUFDLENBQUM7QUFDaEQsb0NBQVksQ0FBQyxJQUFJLENBQUMsTUFBTSxFQUFFLE9BQU8sQ0FBQyxDQUFDO0FBQ25DLG9DQUFZLENBQUMsUUFBUSxDQUFDLG9CQUFvQixDQUFDLENBQUM7OztBQUc1QyxvQ0FBWSxDQUFDLE1BQU0sQ0FBQyxVQUFVLENBQUMsQ0FBQzs7QUFFaEMsK0JBQU8sQ0FBQyxNQUFNLENBQUMsWUFBWSxDQUFDLENBQUM7O0FBRTdCLGdDQUFRLENBQUMsT0FBTyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUM7cUJBQzVCLENBQUMsQ0FBQztpQkFDTjthQUNKLENBQUM7U0FDTDtLQUNKLENBQUM7Q0FDTCxDQUFDLENBQUM7OztBQzdDUCxPQUFPLENBQUMsTUFBTSxDQUFDLG9DQUFvQyxFQUFFLENBQ2pELDhDQUE4QyxDQUNqRCxDQUFDLENBQUM7OztBQ0ZILE9BQU8sQ0FBQyxNQUFNLENBQUMsK0NBQStDLEVBQUUsRUFBRSxDQUFDLENBQzlELFNBQVMsQ0FBQyxpQkFBaUIsRUFBRSxTQUFTLHdCQUF3QixHQUFHO0FBQzlELFdBQU87QUFDSCxlQUFPLEVBQUUsSUFBSTtBQUNiLGVBQU8sRUFBRSxPQUFPO0FBQ2hCLGdCQUFRLEVBQUUsSUFBSTtBQUNkLG1CQUFXLEVBQUUsaUVBQWlFO0FBQzlFLGtCQUFVLEVBQUUsSUFBSTtBQUNoQixZQUFJLEVBQUU7OztBQUdGLGVBQUcsRUFBRSxTQUFTLHNCQUFzQixDQUFDLEtBQUssRUFBRSxPQUFPLEVBQUUsS0FBSyxFQUFFLFFBQVEsRUFBRTs7QUFFbEUsb0JBQUksUUFBUSxHQUFHLEtBQUssQ0FBQyxRQUFRLElBQUksS0FBSyxDQUFDLFFBQVE7b0JBQzNDLGFBQWEsR0FBRyxRQUFRLENBQUMsUUFBUSxDQUFDLENBQUM7Ozs7QUFJdkMscUJBQUssQ0FBQyxRQUFRLEdBQUcsUUFBUSxDQUFDO0FBQzFCLHFCQUFLLENBQUMsUUFBUSxHQUFHLFFBQVEsQ0FBQztBQUMxQixxQkFBSyxDQUFDLGFBQWEsR0FBRyxhQUFhLENBQUM7YUFDdkM7U0FDSjtLQUNKLENBQUM7Q0FDTCxDQUFDLENBQUM7OztBQ3hCUCxPQUFPLENBQUMsTUFBTSxDQUFDLHFDQUFxQyxFQUFFLENBQ2xELCtDQUErQyxDQUNsRCxDQUFDLENBQUM7OztBQ0ZILE9BQU8sQ0FBQyxNQUFNLENBQUMsbUNBQW1DLEVBQUUsQ0FDaEQsb0NBQW9DLENBQ3ZDLENBQUMsQ0FDRyxVQUFVLENBQUMsVUFBVSxFQUFFLFNBQVMsdUJBQXVCLENBQUMsS0FBSyxFQUFFLGNBQWMsRUFBRSxXQUFXLEVBQUU7QUFDekYsUUFBSSxJQUFJLEdBQUcsSUFBSSxDQUFDOztBQUVoQixRQUFJLENBQUMsV0FBVyxHQUFHLFdBQVcsQ0FBQzs7QUFFL0IsYUFBUyxXQUFXLENBQUMsS0FBSyxFQUFFO0FBQ3hCLFlBQUksV0FBVyxHQUFHLFdBQVcsR0FBRyxLQUFLLEdBQUcsTUFBTSxDQUFDOztBQUUvQyxlQUFPLEtBQUssQ0FBQyxHQUFHLENBQUMsV0FBVyxFQUFFLEVBQUUsS0FBSyxFQUFFLGNBQWMsRUFBRSxDQUFDLENBQ25ELElBQUksQ0FBQyxTQUFTLHdCQUF3QixDQUFDLFFBQVEsRUFBRTtBQUM5QyxtQkFBTyxRQUFRLENBQUMsSUFBSSxDQUFDO1NBQ3hCLENBQUMsQ0FBQztLQUNWO0NBQ0osQ0FBQyxDQUFDOzs7Ozs7Ozs7QUNWUCxPQUFPLENBQUMsTUFBTSxDQUFDLGtDQUFrQyxFQUFFLENBQy9DLG1DQUFtQyxDQUN0QyxDQUFDLENBQ0csU0FBUyxDQUFDLE1BQU0sRUFBRSxTQUFTLGFBQWEsR0FBRztBQUN4QyxXQUFPO0FBQ0gsd0JBQWdCLEVBQUUsSUFBSTtBQUN0QixrQkFBVSxFQUFFLHNCQUFzQjtBQUNsQyxnQkFBUSxFQUFFLEdBQUc7QUFDYixhQUFLLEVBQUU7QUFDSCxpQkFBSyxFQUFFLEdBQUc7U0FDYjtBQUNELGVBQU8sRUFBRSxTQUFTLG9CQUFvQixDQUFDLFFBQVEsRUFBRTtBQUM3QyxvQkFBUSxDQUFDLFFBQVEsQ0FBQyxNQUFNLENBQUMsQ0FBQztBQUMxQixvQkFBUSxDQUFDLElBQUksQ0FBQyxhQUFhLEVBQUUsSUFBSSxDQUFDLENBQUM7O0FBRW5DLG1CQUFPLFNBQVMsaUJBQWlCLENBQUMsTUFBTSxFQUFFLE9BQU8sRUFBRSxLQUFLLEVBQUUsSUFBSSxFQUFFO0FBQzVELHNCQUFNLENBQUMsTUFBTSxDQUFDLGdCQUFnQixFQUFFLFNBQVMsc0JBQXNCLENBQUMsUUFBUSxFQUFFO0FBQ3RFLHdCQUFJLENBQUMsV0FBVyxDQUFDLFFBQVEsQ0FBQyxDQUNyQixJQUFJLENBQUMsU0FBUyxtQkFBbUIsQ0FBQyxHQUFHLEVBQUU7QUFDcEMsK0JBQU8sQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLENBQUM7cUJBQ3JCLENBQUMsQ0FBQztpQkFDVixDQUFDLENBQUM7YUFDTixDQUFDO1NBQ0w7S0FDSixDQUFDO0NBQ0wsQ0FBQyxDQUFDOzs7QUMvQlAsT0FBTyxDQUFDLE1BQU0sQ0FBQyx3QkFBd0IsRUFBRSxDQUNyQyxrQ0FBa0MsQ0FDckMsQ0FBQyxDQUFDOzs7QUNGSCxPQUFPLENBQUMsTUFBTSxDQUFDLG9DQUFvQyxFQUFFLEVBQUUsQ0FBQyxDQUNuRCxRQUFRLENBQUMsYUFBYSxFQUFFLFNBQVMseUJBQXlCLEdBQUc7QUFDMUQsUUFBSSxDQUFDLFdBQVcsR0FBRyxXQUFXLENBQUM7QUFDL0IsUUFBSSxDQUFDLElBQUksR0FBRyxTQUFTLHNCQUFzQixDQUFDLElBQUksRUFBRTtBQUM5QyxZQUFJLElBQUksQ0FBQyxXQUFXLEtBQUssU0FBUyxFQUFFO0FBQ2hDLGdCQUFJLENBQUMsS0FBSyxDQUFDLDhFQUE4RSxDQUFDLENBQUM7U0FDOUY7O0FBRUQsZUFBTyxJQUFJLENBQUMsV0FBVyxDQUFDO0tBQzNCLENBQUM7O0FBRUYsYUFBUyxXQUFXLENBQUMsV0FBVyxFQUFFO0FBQzlCLFlBQUksQ0FBQyxXQUFXLEdBQUcsV0FBVyxDQUFDO0tBQ2xDO0NBQ0osQ0FBQyxDQUFDOzs7QUNkUCxPQUFPLENBQUMsTUFBTSxDQUFDLGtEQUFrRCxFQUFFLEVBQUUsQ0FBQyxDQUNqRSxTQUFTLENBQUMscUJBQXFCLEVBQUUsU0FBUyw0QkFBNEIsQ0FBQyxVQUFVLEVBQUU7QUFDaEYsV0FBTztBQUNILGdCQUFRLEVBQUUsR0FBRztBQUNiLG1CQUFXLEVBQUUsdUVBQXVFOztBQUVwRixZQUFJLEVBQUUsY0FBUyxLQUFLLEVBQUU7QUFDbEIsc0JBQVUsQ0FBQyxHQUFHLENBQUMsb0JBQW9CLEVBQUUsVUFBUyxLQUFLLEVBQUUsR0FBRyxFQUFFO0FBQ3RELHFCQUFLLENBQUMsaUJBQWlCLEdBQUcsR0FBRyxDQUFDO2FBQ2pDLENBQUMsQ0FBQztTQUNOO0tBQ0osQ0FBQztDQUNMLENBQUMsQ0FBQzs7O0FDWlAsT0FBTyxDQUFDLE1BQU0sQ0FBQyx3Q0FBd0MsRUFBRSxDQUNyRCxrREFBa0QsQ0FDckQsQ0FBQyxDQUFDOzs7QUNGSCxPQUFPLENBQUMsTUFBTSxDQUFDLDhDQUE4QyxFQUFFLEVBQUUsQ0FBQyxDQUM3RCxVQUFVLENBQUMsb0JBQW9CLEVBQUUsU0FBUyxrQkFBa0IsQ0FBQyxVQUFVLEVBQUUsUUFBUSxFQUFFO0FBQ2hGLFFBQUksSUFBSSxHQUFHLElBQUk7UUFDWCxlQUFlLEdBQUcsR0FBRztRQUNyQixPQUFPLENBQUM7O0FBRVosUUFBSSxJQUFJLENBQUMsUUFBUSxLQUFLLFNBQVMsRUFBRTtBQUM3QixZQUFJLENBQUMsUUFBUSxHQUFHLGVBQWUsQ0FBQztLQUNuQzs7QUFFRCxRQUFJLElBQUksQ0FBQyxXQUFXLEVBQUU7QUFDbEIsa0JBQVUsQ0FBQyxHQUFHLENBQUMsbUJBQW1CLEVBQUUsWUFBWSxDQUFDLENBQUM7QUFDbEQsa0JBQVUsQ0FBQyxHQUFHLENBQUMscUJBQXFCLEVBQUUsV0FBVyxDQUFDLENBQUM7QUFDbkQsa0JBQVUsQ0FBQyxHQUFHLENBQUMsbUJBQW1CLEVBQUUsV0FBVyxDQUFDLENBQUM7S0FDcEQ7O0FBRUQsYUFBUyxZQUFZLENBQUMsS0FBSyxFQUFFO0FBQ3pCLFlBQUksS0FBSyxDQUFDLGdCQUFnQixFQUFFO0FBQ3hCLG1CQUFPO1NBQ1Y7O0FBRUQsZUFBTyxHQUFHLFFBQVEsQ0FBQyxTQUFTLGlCQUFpQixHQUFHO0FBQzVDLGdCQUFJLENBQUMsT0FBTyxHQUFHLElBQUksQ0FBQztTQUN2QixFQUFFLElBQUksQ0FBQyxRQUFRLENBQUMsQ0FBQztLQUNyQjs7QUFFRCxhQUFTLFdBQVcsQ0FBQyxLQUFLLEVBQUU7QUFDeEIsWUFBSSxLQUFLLENBQUMsZ0JBQWdCLEVBQUU7QUFDeEIsbUJBQU87U0FDVjs7QUFFRCxnQkFBUSxDQUFDLE1BQU0sQ0FBQyxPQUFPLENBQUMsQ0FBQztBQUN6QixZQUFJLENBQUMsT0FBTyxHQUFHLEtBQUssQ0FBQztLQUN4QjtDQUNKLENBQUMsQ0FBQzs7O0FDbENQLE9BQU8sQ0FBQyxNQUFNLENBQUMsNkNBQTZDLEVBQUUsQ0FDMUQsOENBQThDLENBQ2pELENBQUMsQ0FDRyxTQUFTLENBQUMsZ0JBQWdCLEVBQUUsU0FBUyxjQUFjLENBQUMsUUFBUSxFQUFFO0FBQzNELFdBQU87QUFDSCx3QkFBZ0IsRUFBRSxJQUFJO0FBQ3RCLGtCQUFVLEVBQUUsMENBQTBDO0FBQ3RELGdCQUFRLEVBQUUsR0FBRztBQUNiLGFBQUssRUFBRTtBQUNILG9CQUFRLEVBQUUsSUFBSTtBQUNkLG1CQUFPLEVBQUUsa0JBQWtCO0FBQzNCLHVCQUFXLEVBQUUsSUFBSTtTQUNwQjtBQUNELGVBQU8sRUFBRSxTQUFTLHFCQUFxQixDQUFDLE9BQU8sRUFBRTtBQUM3QyxtQkFBTyxDQUFDLFFBQVEsQ0FBQywwQkFBMEIsQ0FBQyxDQUFDOztBQUU3QyxtQkFBTyxTQUFTLGtCQUFrQixDQUFDLEtBQUssRUFBRSxPQUFPLEVBQUU7QUFDL0Msb0JBQU0sT0FBTyxHQUFHLFFBQVEsQ0FBQyx1RUFBdUUsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDO0FBQ3pHLHVCQUFPLENBQUMsTUFBTSxDQUFDLE9BQU8sQ0FBQyxDQUFDO2FBQzNCLENBQUM7U0FDTDtLQUNKLENBQUM7Q0FDTCxDQUFDLENBQUM7OztBQ3RCUCxPQUFPLENBQUMsTUFBTSxDQUFDLG1DQUFtQyxFQUFFLENBQ2hELDZDQUE2QyxDQUNoRCxDQUFDLENBQUM7Ozs7Ozs7O0FDR0gsT0FBTyxDQUFDLE1BQU0sQ0FBQywrQ0FBK0MsRUFBRSxFQUUvRCxDQUFDLENBQ0MsT0FBTyxDQUFDLGFBQWEsRUFBRSxDQUFDLFNBQVMsRUFBRSxhQUFhLEVBQUUsVUFBVSxFQUFFLFdBQVcsRUFBRSxVQUFVLEVBQUUsWUFBWSxFQUFFLGNBQWMsRUFDbEgsVUFBVSxPQUFPLEVBQUUsV0FBVyxFQUFFLFFBQVEsRUFBRSxTQUFTLEVBQUUsUUFBUSxFQUFFLFVBQVUsRUFBRSxZQUFZLEVBQUU7O0FBRXZGLE1BQUksa0JBQWtCLEdBQUcsaUJBQWlCLENBQUM7OztBQUczQyxNQUFJLGFBQWEsRUFBRSxhQUFhLENBQUM7QUFDakMsTUFBSSxhQUFhLEdBQUcsWUFBWSxDQUFDLFNBQVMsRUFBRSxDQUFDO0FBQzdDLE1BQUksV0FBVyxHQUFHLEVBQUUsQ0FBQzs7QUFFckIsV0FBUyxhQUFhLEdBQUc7QUFDdkIsUUFBSSxnQkFBZ0IsR0FBRyxDQUFDLENBQUMsQ0FBQztBQUMxQixRQUFJLE1BQU0sR0FBRyxhQUFhLENBQUMsSUFBSSxFQUFFLENBQUM7QUFDbEMsU0FBSyxJQUFJLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxHQUFHLE1BQU0sQ0FBQyxNQUFNLEVBQUUsQ0FBQyxFQUFFLEVBQUU7QUFDdEMsVUFBSSxhQUFhLENBQUMsR0FBRyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxRQUFRLEVBQUU7QUFDL0Msd0JBQWdCLEdBQUcsQ0FBQyxDQUFDO09BQ3RCO0tBQ0Y7QUFDRCxXQUFPLGdCQUFnQixDQUFDO0dBQ3pCOztBQUVELFlBQVUsQ0FBQyxNQUFNLENBQUMsYUFBYSxFQUFFLFVBQVMsZ0JBQWdCLEVBQUM7QUFDekQsUUFBSSxhQUFhLEVBQUU7QUFDakIsbUJBQWEsQ0FBQyxLQUFLLEdBQUcsZ0JBQWdCLENBQUM7S0FDeEM7R0FDRixDQUFDLENBQUM7O0FBRUgsV0FBUyxpQkFBaUIsQ0FBQyxhQUFhLEVBQUU7QUFDeEMsUUFBSSxJQUFJLEdBQUcsU0FBUyxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDeEMsUUFBSSxXQUFXLEdBQUcsYUFBYSxDQUFDLEdBQUcsQ0FBQyxhQUFhLENBQUMsQ0FBQyxLQUFLLENBQUM7OztBQUd6RCxpQkFBYSxDQUFDLE1BQU0sQ0FBQyxhQUFhLENBQUMsQ0FBQzs7O0FBR3BDLHNCQUFrQixDQUFDLFdBQVcsQ0FBQyxVQUFVLEVBQUUsV0FBVyxDQUFDLFVBQVUsRUFBRSxHQUFHLEVBQUUsWUFBVztBQUNqRixpQkFBVyxDQUFDLFVBQVUsQ0FBQyxRQUFRLEVBQUUsQ0FBQztBQUNsQyxVQUFJLENBQUMsV0FBVyxDQUFDLGtCQUFrQixFQUFFLGFBQWEsQ0FBQyxNQUFNLEVBQUUsR0FBRyxDQUFDLENBQUMsQ0FBQztBQUNqRSx5QkFBbUIsRUFBRSxDQUFDO0tBQ3ZCLENBQUMsQ0FBQztHQUNKOztBQUVELFdBQVMsbUJBQW1CLEdBQUc7O0FBRTdCLFFBQUksYUFBYSxJQUFJLGFBQWEsRUFBRSxJQUFJLENBQUMsQ0FBQyxFQUFFO0FBQzFDLFVBQUksZ0JBQWdCLEdBQUcsYUFBYSxDQUFDO0FBQ3JDLHdCQUFrQixDQUFDLGFBQWEsRUFBRSxhQUFhLEVBQUUsR0FBRyxFQUFFLFlBQVk7QUFDaEUsd0JBQWdCLENBQUMsUUFBUSxFQUFFLENBQUM7QUFDNUIsd0JBQWdCLEdBQUcsSUFBSSxDQUFDO09BQ3pCLENBQUMsQ0FBQztBQUNILG1CQUFhLEdBQUcsU0FBUyxDQUFDO0FBQzFCLG1CQUFhLEdBQUcsU0FBUyxDQUFDO0tBQzNCO0dBQ0Y7O0FBRUQsV0FBUyxrQkFBa0IsQ0FBQyxLQUFLLEVBQUUsS0FBSyxFQUFFLFdBQVcsRUFBRSxJQUFJLEVBQUU7O0FBRTNELFNBQUssQ0FBQyxPQUFPLEdBQUcsS0FBSyxDQUFDOztBQUV0QixRQUFJLHNCQUFzQixHQUFHLFdBQVcsQ0FBQyxzQkFBc0IsQ0FBQztBQUNoRSxRQUFJLHNCQUFzQixFQUFFOztBQUUxQixVQUFJLE9BQU8sR0FBRyxRQUFRLENBQUMsY0FBYyxFQUFFLFdBQVcsQ0FBQyxDQUFDOztBQUVwRCxXQUFLLENBQUMsSUFBSSxDQUFDLHNCQUFzQixFQUFFLFlBQVk7QUFDN0MsZ0JBQVEsQ0FBQyxNQUFNLENBQUMsT0FBTyxDQUFDLENBQUM7QUFDekIsc0JBQWMsRUFBRSxDQUFDO0FBQ2pCLGFBQUssQ0FBQyxNQUFNLEVBQUUsQ0FBQztPQUNoQixDQUFDLENBQUM7S0FDSixNQUFNOztBQUVMLGNBQVEsQ0FBQyxjQUFjLEVBQUUsQ0FBQyxDQUFDLENBQUM7S0FDN0I7O0FBRUQsYUFBUyxjQUFjLEdBQUc7QUFDeEIsVUFBSSxjQUFjLENBQUMsSUFBSSxFQUFFO0FBQ3ZCLGVBQU87T0FDUjtBQUNELG9CQUFjLENBQUMsSUFBSSxHQUFHLElBQUksQ0FBQzs7QUFFM0IsV0FBSyxDQUFDLE1BQU0sRUFBRSxDQUFDO0FBQ2YsVUFBSSxJQUFJLEVBQUU7QUFDUixZQUFJLEVBQUUsQ0FBQztPQUNSO0tBQ0Y7R0FDRjs7QUFFRCxXQUFTLENBQUMsSUFBSSxDQUFDLFNBQVMsRUFBRSxVQUFVLEdBQUcsRUFBRTtBQUN2QyxRQUFJLEtBQUssQ0FBQzs7QUFFVixRQUFJLEdBQUcsQ0FBQyxLQUFLLEtBQUssRUFBRSxFQUFFO0FBQ3BCLFdBQUssR0FBRyxhQUFhLENBQUMsR0FBRyxFQUFFLENBQUM7QUFDNUIsVUFBSSxLQUFLLElBQUksS0FBSyxDQUFDLEtBQUssQ0FBQyxRQUFRLEVBQUU7QUFDakMsa0JBQVUsQ0FBQyxNQUFNLENBQUMsWUFBWTtBQUM1QixxQkFBVyxDQUFDLE9BQU8sQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLENBQUM7U0FDaEMsQ0FBQyxDQUFDO09BQ0o7S0FDRjtHQUNGLENBQUMsQ0FBQzs7QUFFSCxhQUFXLENBQUMsSUFBSSxHQUFHLFVBQVUsYUFBYSxFQUFFLEtBQUssRUFBRTs7QUFFakQsaUJBQWEsQ0FBQyxHQUFHLENBQUMsYUFBYSxFQUFFO0FBQy9CLGNBQVEsRUFBRSxLQUFLLENBQUMsUUFBUTtBQUN4QixnQkFBVSxFQUFFLEtBQUssQ0FBQyxLQUFLO0FBQ3ZCLGNBQVEsRUFBRSxLQUFLLENBQUMsUUFBUTtBQUN4QixjQUFRLEVBQUUsS0FBSyxDQUFDLFFBQVE7S0FDekIsQ0FBQyxDQUFDOztBQUVILFFBQUksSUFBSSxHQUFHLFNBQVMsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQztRQUNuQyxpQkFBaUIsR0FBRyxhQUFhLEVBQUUsQ0FBQzs7QUFFeEMsUUFBSSxpQkFBaUIsSUFBSSxDQUFDLElBQUksQ0FBQyxhQUFhLEVBQUU7QUFDNUMsbUJBQWEsR0FBRyxVQUFVLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDO0FBQ3RDLG1CQUFhLENBQUMsS0FBSyxHQUFHLGlCQUFpQixDQUFDO0FBQ3hDLG1CQUFhLEdBQUcsUUFBUSxDQUFDLDRCQUE0QixDQUFDLENBQUMsYUFBYSxDQUFDLENBQUM7QUFDdEUsVUFBSSxDQUFDLE1BQU0sQ0FBQyxhQUFhLENBQUMsQ0FBQztLQUM1Qjs7O0FBR0QsUUFBSSxZQUFZLEdBQUcsT0FBTyxDQUFDLE9BQU8sQ0FBQyxzRUFBc0UsQ0FBQyxDQUFDO0FBQzNHLGdCQUFZLENBQUMsSUFBSSxDQUFDLGNBQWMsRUFBRSxLQUFLLENBQUMsV0FBVyxDQUFDLENBQUM7QUFDckQsZ0JBQVksQ0FBQyxJQUFJLENBQUMsT0FBTyxFQUFFLGFBQWEsQ0FBQyxNQUFNLEVBQUUsR0FBRyxDQUFDLENBQUMsQ0FBQztBQUN2RCxnQkFBWSxDQUFDLElBQUksQ0FBQyxTQUFTLEVBQUUsU0FBUyxDQUFDLENBQUM7QUFDeEMsZ0JBQVksQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyxDQUFDOztBQUVqQyxRQUFJLFVBQVUsR0FBRyxRQUFRLENBQUMsWUFBWSxDQUFDLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxDQUFDO0FBQ3JELGlCQUFhLENBQUMsR0FBRyxFQUFFLENBQUMsS0FBSyxDQUFDLFVBQVUsR0FBRyxVQUFVLENBQUM7QUFDbEQsUUFBSSxDQUFDLE1BQU0sQ0FBQyxVQUFVLENBQUMsQ0FBQztBQUN4QixRQUFJLENBQUMsUUFBUSxDQUFDLGtCQUFrQixDQUFDLENBQUM7R0FDbkMsQ0FBQzs7QUFFRixhQUFXLENBQUMsS0FBSyxHQUFHLFVBQVUsYUFBYSxFQUFFLE1BQU0sRUFBRTtBQUNuRCxRQUFJLFdBQVcsR0FBRyxhQUFhLENBQUMsR0FBRyxDQUFDLGFBQWEsQ0FBQyxDQUFDLEtBQUssQ0FBQztBQUN6RCxRQUFJLFdBQVcsRUFBRTtBQUNmLGlCQUFXLENBQUMsUUFBUSxDQUFDLE9BQU8sQ0FBQyxNQUFNLENBQUMsQ0FBQztBQUNyQyx1QkFBaUIsQ0FBQyxhQUFhLENBQUMsQ0FBQztLQUNsQztHQUNGLENBQUM7O0FBRUYsYUFBVyxDQUFDLE9BQU8sR0FBRyxVQUFVLGFBQWEsRUFBRSxNQUFNLEVBQUU7QUFDckQsUUFBSSxXQUFXLEdBQUcsYUFBYSxDQUFDLEdBQUcsQ0FBQyxhQUFhLENBQUMsQ0FBQyxLQUFLLENBQUM7QUFDekQsUUFBSSxXQUFXLEVBQUU7QUFDZixpQkFBVyxDQUFDLFFBQVEsQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDLENBQUM7QUFDcEMsdUJBQWlCLENBQUMsYUFBYSxDQUFDLENBQUM7S0FDbEM7R0FDRixDQUFDOztBQUVGLGFBQVcsQ0FBQyxVQUFVLEdBQUcsVUFBVSxNQUFNLEVBQUU7QUFDekMsUUFBSSxRQUFRLEdBQUcsSUFBSSxDQUFDLE1BQU0sRUFBRSxDQUFDO0FBQzdCLFdBQU8sUUFBUSxFQUFFO0FBQ2YsVUFBSSxDQUFDLE9BQU8sQ0FBQyxRQUFRLENBQUMsR0FBRyxFQUFFLE1BQU0sQ0FBQyxDQUFDO0FBQ25DLGNBQVEsR0FBRyxJQUFJLENBQUMsTUFBTSxFQUFFLENBQUM7S0FDMUI7R0FDRixDQUFDOztBQUVGLGFBQVcsQ0FBQyxNQUFNLEdBQUcsWUFBWTtBQUMvQixXQUFPLGFBQWEsQ0FBQyxHQUFHLEVBQUUsQ0FBQztHQUM1QixDQUFDOztBQUVGLFNBQU8sV0FBVyxDQUFDO0NBQ3BCLENBQUMsQ0FBQyxDQUFDOzs7Ozs7O0FDcktSLE9BQU8sQ0FBQyxNQUFNLENBQUMsNEJBQTRCLEVBQUUsQ0FDekMsK0NBQStDLENBQ2xELENBQUMsQ0FBQzs7Ozs7Ozs7OztBQ0NILE9BQU8sQ0FBQyxNQUFNLENBQUMsb0NBQW9DLEVBQUUsRUFBRSxDQUFDLENBQ25ELFNBQVMsQ0FBQyxRQUFRLEVBQUUsU0FBUyxlQUFlLEdBQUc7QUFDNUMsV0FBTztBQUNILGdCQUFRLEVBQUUsR0FBRztBQUNiLGFBQUssRUFBRTtBQUNILGlCQUFLLEVBQUUsR0FBRztTQUNiO0FBQ0QsZUFBTyxFQUFFLHNCQUFzQjtLQUNsQyxDQUFDOztBQUVGLGFBQVMsc0JBQXNCLENBQUMsUUFBUSxFQUFFO0FBQ3RDLGdCQUFRLENBQUMsUUFBUSxDQUFDLFFBQVEsQ0FBQyxDQUFDO0FBQzVCLGdCQUFRLENBQUMsSUFBSSxDQUFDLGFBQWEsRUFBRSxJQUFJLENBQUMsQ0FBQzs7QUFFbkMsZUFBTyxTQUFTLG1CQUFtQixDQUFDLE1BQU0sRUFBRSxPQUFPLEVBQUUsS0FBSyxFQUFFO0FBQ3hELGlCQUFLLENBQUMsUUFBUSxDQUFDLE9BQU8sRUFBRSxVQUFDLFFBQVEsRUFBSztBQUNsQyx1QkFBTyxDQUFDLElBQUksQ0FBQyxPQUFPLEVBQUUsaUJBQWlCLEdBQUcsUUFBUSxDQUFDLENBQUM7YUFDdkQsQ0FBQyxDQUFDO1NBQ04sQ0FBQztLQUNMO0NBQ0osQ0FBQyxDQUFDOzs7QUMzQlAsT0FBTyxDQUFDLE1BQU0sQ0FBQywwQkFBMEIsRUFBRSxDQUN2QyxvQ0FBb0MsQ0FDdkMsQ0FBQyxDQUFDOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ3FCSCxPQUFPLENBQUMsTUFBTSxDQUFDLG9DQUFvQyxFQUFFLEVBQUUsQ0FBQyxDQUNuRCxTQUFTLENBQUMsUUFBUSxFQUFFLFNBQVMsZUFBZSxHQUFHOztBQUU1QyxhQUFTLFdBQVcsQ0FBQyxRQUFRLEVBQUU7QUFDM0IsZUFBTyxDQUFDLENBQUMsUUFBUSxDQUFDLFFBQVEsQ0FBQyxDQUFDO0tBQy9COztBQUVELFdBQU87QUFDSCxnQkFBUSxFQUFFLEdBQUc7QUFDYixtQkFBVyxFQUFFLDJDQUEyQztBQUN4RCxlQUFPLEVBQUUsU0FBUztBQUNsQixhQUFLLEVBQUU7QUFDSCwyQkFBZSxFQUFFLEdBQUc7QUFDcEIscUJBQVMsRUFBRSxHQUFHO0FBQ2QsMkJBQWUsRUFBRSxHQUFHO0FBQ3BCLHdCQUFZLEVBQUUsR0FBRztBQUNqQix1QkFBVyxFQUFFLEdBQUc7QUFDaEIsNEJBQWdCLEVBQUUsR0FBRztBQUNyQiwwQkFBYyxFQUFFLEdBQUc7QUFDbkIseUJBQWEsRUFBRSxHQUFHO0FBQ2xCLG9CQUFRLEVBQUUsR0FBRztTQUNoQjtBQUNELHdCQUFnQixFQUFFLElBQUk7QUFDdEIsb0JBQVksRUFBRSxZQUFZO0FBQzFCLGVBQU8sRUFBRSxTQUFTLHNCQUFzQixDQUFDLEtBQUssRUFBRSxNQUFNLEVBQUU7QUFDcEQsZ0JBQUksWUFBWSxHQUFHLEtBQUssQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLENBQUM7O0FBRXZDLGdCQUFJLE1BQU0sQ0FBQyxZQUFZLEVBQUU7QUFDckIsNEJBQVksQ0FBQyxJQUFJLENBQUMsZ0JBQWdCLEVBQUUsTUFBTSxDQUFDLFlBQVksQ0FBQyxDQUFDO2FBQzVEOztBQUVELGdCQUFJLE1BQU0sQ0FBQyxXQUFXLEVBQUU7QUFDcEIsNEJBQVksQ0FBQyxJQUFJLENBQUMsZUFBZSxFQUFFLE1BQU0sQ0FBQyxXQUFXLENBQUMsQ0FBQzthQUMxRDs7QUFFRCxtQkFBTyxTQUFTLHVCQUF1QixDQUFDLEtBQUssRUFBRSxPQUFPLEVBQUUsS0FBSyxFQUFFLFdBQVcsRUFBRTtBQUN4RSxxQkFBSyxDQUFDLFVBQVUsQ0FBQyxJQUFJLENBQUMsV0FBVyxDQUFDLENBQUM7YUFDdEMsQ0FBQztTQUNMO0FBQ0Qsa0JBQVUsRUFBRSxTQUFTLG1CQUFtQixDQUFDLE1BQU0sRUFBRSxRQUFRLEVBQUUsTUFBTSxFQUFFO0FBQy9ELGdCQUFJLElBQUksR0FBRyxJQUFJLENBQUM7OztBQUdoQixnQkFBSSxDQUFDLFdBQVcsR0FBRyxPQUFPLENBQUMsU0FBUyxDQUFDLE1BQU0sQ0FBQyxXQUFXLENBQUMsSUFBSSxNQUFNLENBQUMsV0FBVyxLQUFLLE9BQU8sQ0FBQztBQUMzRixnQkFBSSxDQUFDLE9BQU8sR0FBRyxPQUFPLENBQUMsU0FBUyxDQUFDLE1BQU0sQ0FBQyxPQUFPLENBQUMsSUFBSSxNQUFNLENBQUMsT0FBTyxLQUFLLE9BQU8sQ0FBQzs7O0FBRy9FLGdCQUFJLENBQUMsU0FBUyxHQUFHLE1BQU0sQ0FBQyxjQUFjLENBQUM7OztBQUd2QyxnQkFBSSxDQUFDLFFBQVEsR0FBRyxXQUFXLENBQUMsU0FBUyxDQUFDLENBQUM7QUFDdkMsZ0JBQUksQ0FBQyxpQkFBaUIsR0FBRyxXQUFXLENBQUMseUJBQXlCLENBQUMsQ0FBQzs7QUFFaEUsZ0JBQUksQ0FBQyxJQUFJLEdBQUcsSUFBSSxDQUFDO0FBQ2pCLGdCQUFJLENBQUMsV0FBVyxHQUFHLFdBQVcsQ0FBQzs7QUFFL0IscUJBQVMsSUFBSSxDQUFDLFdBQVcsRUFBRTtBQUN2QixvQkFBSSxDQUFDLFdBQVcsR0FBRyxXQUFXLENBQUM7QUFDL0Isb0JBQUksQ0FBQyxLQUFLLEdBQUcsSUFBSSxDQUFDLFdBQVcsQ0FBQyxXQUFXLENBQUM7O0FBRTFDLHNCQUFNLENBQUMsTUFBTSxDQUFDLG9DQUFvQyxFQUFFLFNBQVMsa0JBQWtCLENBQUMsUUFBUSxFQUFFO0FBQ3RGLHdCQUFJLENBQUMsS0FBSyxHQUFHLFFBQVEsQ0FBQzs7QUFFdEIsd0JBQUksQ0FBQyxTQUFTLEdBQUcsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxRQUFRLENBQUMsR0FBRyxHQUFHLEdBQUcsUUFBUSxHQUFHLEdBQUcsS0FBSyxJQUFJLENBQUMsV0FBVyxHQUFHLFFBQVEsQ0FBQztBQUM3Rix3QkFBSSxDQUFDLFNBQVMsR0FBRyxDQUFDLENBQUMsSUFBSSxDQUFDLFNBQVMsR0FBRyxJQUFJLENBQUMsYUFBYSxHQUFFLElBQUksQ0FBQyxjQUFjLENBQUM7aUJBQy9FLENBQUMsQ0FBQzthQUNOOztBQUVELHFCQUFTLFdBQVcsR0FBRztBQUNuQixvQkFBSSxDQUFDLFdBQVcsQ0FBQyxhQUFhLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxDQUFDO2FBQzlDO1NBRUo7S0FDSixDQUFDO0NBQ0wsQ0FBQyxDQUFDOzs7QUNqR1AsT0FBTyxDQUFDLE1BQU0sQ0FBQywwQkFBMEIsRUFBRSxDQUN2QyxvQ0FBb0MsQ0FDdkMsQ0FBQyxDQUFDOzs7QUNGSCxPQUFPLENBQUMsTUFBTSxDQUFDLHdCQUF3QixFQUFFLENBQ3JDLG9DQUFvQyxDQUN2QyxDQUFDLENBQUM7OztBQ0ZILE9BQU8sQ0FBQyxNQUFNLENBQUMsMkNBQTJDLEVBQUUsQ0FDeEQsV0FBVyxDQUNkLENBQUMsQ0FDRyxPQUFPLENBQUMsZUFBZSxFQUFFLFNBQVMsYUFBYSxDQUFDLElBQUksRUFBRSxFQUFFLEVBQUUsTUFBTSxFQUFFLFlBQVksRUFBRTtBQUM3RSxRQUFJLGtCQUFrQixHQUFHO0FBQ3JCLGVBQU8sRUFBRSxFQUFFO0FBQ1gsaUJBQVMsRUFBRTtBQUNQLGdCQUFJLEVBQUUsTUFBTTtBQUNaLGlCQUFLLEVBQUUsT0FBTztBQUNkLGtCQUFNLEVBQUUsU0FBUztBQUNqQixtQkFBTyxFQUFFLFlBQVk7U0FDeEI7QUFDRCxnQkFBUSxFQUFFLElBQUk7QUFDZCxxQkFBYSxFQUFFO0FBQ1gsZUFBRyxFQUFFLEtBQUs7QUFDVixnQkFBSSxFQUFFLE1BQU07U0FDZjtLQUNKLENBQUM7O0FBRUYsYUFBUyxXQUFXLENBQUMsT0FBTyxFQUFFLFdBQVcsRUFBRTtBQUN2QyxZQUFJLENBQUMsV0FBVyxHQUFHLEtBQUssQ0FBQztBQUN6QixZQUFJLENBQUMsT0FBTyxHQUFHLEVBQUUsQ0FBQztBQUNsQixZQUFJLENBQUMsRUFBRSxHQUFHLE9BQU8sQ0FBQztBQUNsQixZQUFJLENBQUMsVUFBVSxHQUFHO0FBQ2QsZ0JBQUksRUFBRSxJQUFJO0FBQ1YsaUJBQUssRUFBRSxJQUFJO0FBQ1gsaUJBQUssRUFBRSxJQUFJO1NBQ2QsQ0FBQztBQUNGLFlBQUksQ0FBQyxjQUFjLEdBQUcsS0FBSyxDQUFDO0FBQzVCLFlBQUksQ0FBQyxnQkFBZ0IsR0FBRyxPQUFPLENBQUMsSUFBSSxDQUFDO0FBQ3JDLFlBQUksQ0FBQyxJQUFJLEdBQUcsRUFBRSxDQUFDO0FBQ2YsWUFBSSxDQUFDLFlBQVksR0FBRyxFQUFFLENBQUM7QUFDdkIsWUFBSSxDQUFDLE1BQU0sR0FBRyxFQUFFLENBQUM7QUFDakIsWUFBSSxDQUFDLE9BQU8sR0FBRyxFQUFFLENBQUM7O0FBRWxCLFlBQUksQ0FBQyxXQUFXLEdBQUcsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxXQUFXLENBQUMsR0FBRyxXQUFXLEdBQUcsRUFBRSxDQUFDO0FBQzlELFlBQUksQ0FBQyxXQUFXLEdBQUcsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsV0FBVyxFQUFFLGtCQUFrQixDQUFDLENBQUM7S0FDdkU7O0FBRUQsZUFBVyxDQUFDLFNBQVMsR0FBRztBQUNwQiwwQkFBa0IsRUFBRSxrQkFBa0I7QUFDdEMscUJBQWEsRUFBRSxhQUFhO0FBQzVCLHVCQUFlLEVBQUUsZUFBZTtBQUNoQyxZQUFJLEVBQUUsSUFBSTtBQUNWLHFCQUFhLEVBQUUsYUFBYTtBQUM1Qix1QkFBZSxFQUFFLGVBQWU7QUFDaEMscUJBQWEsRUFBRSxhQUFhO0FBQzVCLDJCQUFtQixFQUFFLG1CQUFtQjtBQUN4QyxlQUFPLEVBQUUsT0FBTztBQUNoQix3QkFBZ0IsRUFBRSxnQkFBZ0I7QUFDbEMsa0JBQVUsRUFBRSxVQUFVO0FBQ3RCLGtCQUFVLEVBQUUsVUFBVTtBQUN0QixtQkFBVyxFQUFFLFdBQVc7QUFDeEIsd0JBQWdCLEVBQUUsZ0JBQWdCO0tBQ3JDLENBQUM7O0FBRUYsYUFBUyxrQkFBa0IsR0FBRztBQUMxQixZQUFJLE1BQU0sR0FBRyxFQUFFO1lBQ1gsU0FBUyxHQUFHLElBQUksQ0FBQyxXQUFXLENBQUMsU0FBUztZQUN0QyxhQUFhLEdBQUcsQ0FBQztBQUNULG9CQUFRLEVBQUUsU0FBUyxDQUFDLElBQUk7QUFDeEIsaUJBQUssRUFBRSxJQUFJLENBQUMsVUFBVSxDQUFDLElBQUk7U0FDOUIsRUFBRTtBQUNDLG9CQUFRLEVBQUUsU0FBUyxDQUFDLEtBQUs7QUFDekIsaUJBQUssRUFBRSxJQUFJLENBQUMsVUFBVSxDQUFDLEtBQUs7U0FDL0IsRUFBRTtBQUNDLG9CQUFRLEVBQUUsU0FBUyxDQUFDLE1BQU07QUFDMUIsaUJBQUssRUFBRSxJQUFJLENBQUMsTUFBTTtTQUNyQixFQUFFO0FBQ0Msb0JBQVEsRUFBRSxTQUFTLENBQUMsT0FBTztBQUMzQixpQkFBSyxFQUFFLElBQUksQ0FBQyxPQUFPO1NBQ3RCLENBQUMsQ0FBQzs7QUFFWCxTQUFDLENBQUMsSUFBSSxDQUFDLGFBQWEsRUFBRSxTQUFTLGlCQUFpQixDQUFDLEtBQUssRUFBRTtBQUNwRCxnQkFBSSxLQUFLLENBQUMsUUFBUSxLQUFLLFNBQVMsRUFBRTtBQUM5QixzQkFBTSxDQUFDLEtBQUssQ0FBQyxRQUFRLENBQUMsR0FBRyxLQUFLLENBQUMsS0FBSyxDQUFDO2FBQ3hDO1NBQ0osQ0FBQyxDQUFDOztBQUVILFNBQUMsQ0FBQyxNQUFNLENBQUMsTUFBTSxFQUFFLElBQUksQ0FBQyxPQUFPLENBQUMsQ0FBQzs7QUFFL0IsZUFBTyxNQUFNLENBQUM7S0FDakI7O0FBRUQsYUFBUyxhQUFhLEdBQUc7QUFDckIsWUFBSSxLQUFLLEdBQUcsSUFBSSxDQUFDOztBQUVqQixZQUFJLENBQUMsY0FBYyxHQUFHLElBQUksQ0FBQztBQUMzQixlQUFPLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxJQUFJLENBQUMsa0JBQWtCLEVBQUUsQ0FBQyxDQUNsRCxJQUFJLENBQUMsU0FBUyxvQkFBb0IsQ0FBQyxRQUFRLEVBQUU7QUFDMUMsZ0JBQUksS0FBSyxDQUFDLGdCQUFnQixDQUFDLFFBQVEsQ0FBQyxFQUFFO0FBQ2xDLHFCQUFLLENBQUMsT0FBTyxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsQ0FBQztBQUM3QixxQkFBSyxDQUFDLG1CQUFtQixDQUFDLFFBQVEsQ0FBQyxVQUFVLENBQUMsQ0FBQzthQUNsRDs7QUFFRCxtQkFBTyxLQUFLLENBQUM7U0FDaEIsQ0FBQyxTQUNJLENBQUMsU0FBUyxxQkFBcUIsQ0FBQyxLQUFLLEVBQUU7QUFDekMsZ0JBQUksQ0FBQyxLQUFLLENBQUMscURBQXFELENBQUMsQ0FBQzs7QUFFbEUsbUJBQU8sRUFBRSxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsQ0FBQztTQUMzQixDQUFDLFdBQ00sQ0FBQyxTQUFTLHVCQUF1QixHQUFHO0FBQ3hDLGlCQUFLLENBQUMsY0FBYyxHQUFHLEtBQUssQ0FBQztTQUNoQyxDQUFDLENBQUM7S0FDVjs7QUFFRCxhQUFTLGVBQWUsR0FBRztBQUN2QixZQUFJLEtBQUssR0FBRyxJQUFJLENBQUM7O0FBRWpCLGVBQU8sQ0FBQyxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsSUFBSSxFQUFFLFNBQVMscUJBQXFCLENBQUMsR0FBRyxFQUFFO0FBQzNELG1CQUFPLEtBQUssQ0FBQyxhQUFhLENBQUMsR0FBRyxDQUFDLENBQUM7U0FDbkMsQ0FBQyxDQUFDO0tBQ047O0FBRUQsYUFBUyxJQUFJLENBQUMsTUFBTSxFQUFFO0FBQ2xCLFlBQUksQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLE1BQU0sQ0FBQyxFQUFFO0FBQ3JCLGtCQUFNLEdBQUcsRUFBRSxDQUFDO1NBQ2Y7O0FBRUQsWUFBSSxDQUFDLENBQUMsVUFBVSxDQUFDLE1BQU0sQ0FBQyxnQkFBZ0IsQ0FBQyxFQUFFO0FBQ3ZDLGdCQUFJLENBQUMsZ0JBQWdCLEdBQUcsTUFBTSxDQUFDLGdCQUFnQixDQUFDO1NBQ25EOztBQUVELGVBQU8sSUFBSSxDQUNOLGVBQWUsQ0FBQyxNQUFNLENBQUMsV0FBVyxDQUFDLENBQ25DLGFBQWEsRUFBRSxDQUFDO0tBQ3hCOztBQUVELGFBQVMsYUFBYSxDQUFDLEdBQUcsRUFBRTtBQUN4QixlQUFPLElBQUksQ0FBQyxZQUFZLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxXQUFXLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQztLQUM1RDs7QUFFRCxhQUFTLGVBQWUsQ0FBQyxXQUFXLEVBQUU7QUFDbEMsWUFBSSxTQUFTLEdBQUcsSUFBSSxDQUFDLFdBQVcsQ0FBQyxTQUFTO1lBQ3RDLEtBQUssR0FBRyxJQUFJLENBQUM7O0FBRWpCLG1CQUFXLEdBQUcsV0FBVyxJQUFJLFlBQVksQ0FBQzs7QUFFMUMsWUFBSSxDQUFDLG1CQUFtQixDQUFDO0FBQ3JCLGdCQUFJLEVBQUUsV0FBVyxDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUM7QUFDakMsaUJBQUssRUFBRSxXQUFXLENBQUMsU0FBUyxDQUFDLEtBQUssQ0FBQztTQUN0QyxDQUFDLENBQUM7O0FBRUgsWUFBSSxDQUFDLGdCQUFnQixDQUFDLFdBQVcsQ0FBQyxTQUFTLENBQUMsTUFBTSxDQUFDLEVBQUUsV0FBVyxDQUFDLFNBQVMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDOzs7QUFHckYsU0FBQyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsV0FBVyxDQUFDLE9BQU8sRUFBRSxTQUFTLGNBQWMsQ0FBQyxLQUFLLEVBQUU7QUFDNUQsaUJBQUssQ0FBQyxPQUFPLENBQUMsS0FBSyxDQUFDLEdBQUcsV0FBVyxDQUFDLEtBQUssQ0FBQyxDQUFDO1NBQzdDLENBQUMsQ0FBQzs7QUFFSCxlQUFPLElBQUksQ0FBQztLQUNmOztBQUVELGFBQVMsYUFBYSxHQUFHO0FBQ3JCLFlBQUksS0FBSyxHQUFHLElBQUksQ0FBQzs7QUFFakIsWUFBSSxDQUFDLFdBQVcsR0FBRyxDQUFDLElBQUksQ0FBQyxXQUFXLENBQUM7QUFDckMsU0FBQyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsWUFBWSxFQUFFLFNBQVMsaUJBQWlCLENBQUMsS0FBSyxFQUFFLEdBQUcsRUFBRTtBQUM3RCxpQkFBSyxDQUFDLFlBQVksQ0FBQyxHQUFHLENBQUMsR0FBRyxLQUFLLENBQUMsV0FBVyxDQUFDO1NBQy9DLENBQUMsQ0FBQzs7QUFFSCxlQUFPLElBQUksQ0FBQztLQUNmOztBQUVELGFBQVMsbUJBQW1CLENBQUMsVUFBVSxFQUFFO0FBQ3JDLFlBQUksQ0FBQyxVQUFVLEdBQUcsSUFBSSxDQUFDLFVBQVUsSUFBSSxFQUFFLENBQUM7QUFDeEMsU0FBQyxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsVUFBVSxFQUFFLFVBQVUsQ0FBQyxDQUFDOztBQUV0QyxlQUFPLElBQUksQ0FBQztLQUNmOztBQUVELGFBQVMsT0FBTyxDQUFDLElBQUksRUFBRTtBQUNuQixZQUFJLEtBQUssR0FBRyxJQUFJLENBQUM7O0FBRWpCLFlBQUksQ0FBQyxJQUFJLEdBQUcsSUFBSSxDQUFDO0FBQ2pCLFlBQUksQ0FBQyxZQUFZLEdBQUcsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxJQUFJLEVBQUUsU0FBUyw0QkFBNEIsQ0FBQyxLQUFLLEVBQUUsR0FBRyxFQUFFO0FBQ2pGLGlCQUFLLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxXQUFXLENBQUMsUUFBUSxDQUFDLENBQUMsR0FBRyxLQUFLLENBQUM7QUFDL0MsbUJBQU8sS0FBSyxDQUFDO1NBQ2hCLEVBQUUsRUFBRSxDQUFDLENBQUM7O0FBRVAsZUFBTyxJQUFJLENBQUM7S0FDZjs7QUFFRCxhQUFTLGdCQUFnQixDQUFDLE1BQU0sRUFBRSxPQUFPLEVBQUU7QUFDdkMsWUFBSSxDQUFDLE1BQU0sR0FBRyxNQUFNLElBQUksSUFBSSxDQUFDLE1BQU0sQ0FBQztBQUNwQyxZQUFJLENBQUMsT0FBTyxHQUFHLE9BQU8sSUFBSSxJQUFJLENBQUMsT0FBTyxDQUFDOztBQUV2QyxlQUFPLElBQUksQ0FBQztLQUNmOztBQUVELGFBQVMsVUFBVSxDQUFDLElBQUksRUFBRSxLQUFLLEVBQUUsS0FBSyxFQUFFO0FBQ3BDLGVBQU8sSUFBSSxDQUNOLG1CQUFtQixDQUFDLElBQUksRUFBRSxLQUFLLEVBQUUsS0FBSyxDQUFDLENBQ3ZDLFdBQVcsRUFBRSxDQUFDO0tBQ3RCOztBQUVELGFBQVMsVUFBVSxDQUFDLE1BQU0sRUFBRSxPQUFPLEVBQUU7QUFDakMsZUFBTyxJQUFJLENBQ04sZ0JBQWdCLENBQUMsTUFBTSxFQUFFLE9BQU8sQ0FBQyxDQUNqQyxtQkFBbUIsQ0FBQztBQUNqQixnQkFBSSxFQUFFLENBQUM7U0FDVixDQUFDLENBQ0QsV0FBVyxFQUFFLENBQUM7S0FDdEI7O0FBRUQsYUFBUyxXQUFXLEdBQUc7QUFDbkIsWUFBSSxDQUFDLElBQUksQ0FBQyxjQUFjLEVBQUU7QUFDdEIsa0JBQU0sQ0FBQyxFQUFFLENBQUMsTUFBTSxDQUFDLE9BQU8sQ0FBQyxJQUFJLEVBQUUsSUFBSSxDQUFDLGtCQUFrQixFQUFFLENBQUMsQ0FBQztTQUM3RDs7QUFFRCxlQUFPLElBQUksQ0FBQztLQUNmOztBQUVELGFBQVMsZ0JBQWdCLENBQUMsUUFBUSxFQUFFO0FBQ2hDLFlBQUksQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLFFBQVEsQ0FBQyxFQUFFO0FBQ3ZCLGdCQUFJLENBQUMsS0FBSyxDQUFDLG9FQUFvRSxDQUFDLENBQUM7QUFDakYsbUJBQU8sS0FBSyxDQUFDO1NBQ2hCOztBQUVELFlBQUksQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsRUFBRTtBQUMzQixnQkFBSSxDQUFDLEtBQUssQ0FBQywyRkFBMkYsQ0FBQyxDQUFDO0FBQ3hHLG1CQUFPLEtBQUssQ0FBQztTQUNoQjs7QUFFRCxZQUFJLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxRQUFRLENBQUMsVUFBVSxDQUFDLEVBQUU7QUFDbEMsZ0JBQUksQ0FBQyxLQUFLLENBQUMsa0dBQWtHLENBQUMsQ0FBQztBQUMvRyxtQkFBTyxLQUFLLENBQUM7U0FDaEI7O0FBRUQsZUFBTyxJQUFJLENBQUM7S0FDZjs7QUFFRCxXQUFPLFdBQVcsQ0FBQztDQUN0QixDQUFDLENBQUM7OztBQzFPUCxPQUFPLENBQUMsTUFBTSxDQUFDLG1EQUFtRCxFQUFFLENBQ2hFLDJDQUEyQyxDQUM5QyxDQUFDLENBQ0csT0FBTyxDQUFDLHNCQUFzQixFQUFFLFNBQVMsb0JBQW9CLENBQUMsSUFBSSxFQUFFLGFBQWEsRUFBRTtBQUNoRixRQUFJLE1BQU0sR0FBRyxFQUFFO1FBQ1gsT0FBTyxHQUFHO0FBQ04sY0FBTSxFQUFFLE1BQU07QUFDZCxXQUFHLEVBQUUsR0FBRztBQUNSLGNBQU0sRUFBRSxNQUFNO0tBQ2pCLENBQUM7O0FBRU4sYUFBUyxNQUFNLENBQUMsT0FBTyxFQUFFLFdBQVcsRUFBRTtBQUNsQyxZQUFJLE9BQU8sSUFBSSxNQUFNLEVBQUU7QUFDbkIsbUJBQU8sT0FBTyxDQUFDLEdBQUcsQ0FBQyxPQUFPLENBQUMsQ0FBQztTQUMvQjs7QUFFRCxZQUFJLENBQUMsT0FBTyxFQUFFO0FBQ1YsbUJBQU8sR0FBRyxDQUFDLENBQUMsUUFBUSxDQUFDLDJCQUEyQixDQUFDLENBQUM7U0FDckQ7O0FBRUQsY0FBTSxDQUFDLE9BQU8sQ0FBQyxHQUFHLElBQUksYUFBYSxDQUFDLE9BQU8sRUFBRSxXQUFXLENBQUMsQ0FBQzs7QUFFMUQsZUFBTyxNQUFNLENBQUMsT0FBTyxDQUFDLENBQUM7S0FDMUI7O0FBRUQsYUFBUyxHQUFHLENBQUMsT0FBTyxFQUFFO0FBQ2xCLGVBQU8sTUFBTSxDQUFDLE9BQU8sQ0FBQyxDQUFDO0tBQzFCOztBQUVELGFBQVMsTUFBTSxDQUFDLE9BQU8sRUFBRTtBQUNyQixlQUFPLE1BQU0sQ0FBQyxPQUFPLENBQUMsQ0FBQztLQUMxQjs7QUFFRCxXQUFPLE9BQU8sQ0FBQztDQUNsQixDQUFDLENBQUM7Ozs7Ozs7O0FDN0JQLE9BQU8sQ0FBQyxNQUFNLENBQUMsbURBQW1ELEVBQUUsRUFBRSxDQUFDLENBQ2xFLFNBQVMsQ0FBQyxVQUFVLEVBQUUsU0FBUyxjQUFjLENBQUMsT0FBTyxFQUFFO0FBQ3BELFdBQU87QUFDSCxlQUFPLEVBQUUsaUJBQVUsS0FBSyxFQUFFLEtBQUssRUFBRTtBQUM3QixnQkFBTSxxQkFBcUIsR0FBRyxDQUFDLENBQUM7O0FBRWhDLGlCQUFLLENBQUMsSUFBSSxDQUFDLGNBQWMsRUFBRSxRQUFRLENBQUMsQ0FBQztBQUNyQyxpQkFBSyxDQUFDLElBQUksQ0FBQyxXQUFXLEVBQUUscUJBQXFCLENBQUMsQ0FBQztBQUMvQyxpQkFBSyxDQUFDLElBQUksQ0FBQyxTQUFTLEVBQUUsUUFBUSxDQUFDLENBQUM7O0FBRWhDLG1CQUFPLFNBQVMsWUFBWSxDQUFDLEtBQUssRUFBRSxLQUFLLEVBQUUsS0FBSyxFQUFFLFdBQVcsRUFBRTtBQUMzRCxvQkFBSSxFQUFFLENBQUM7O0FBRVAseUJBQVMsSUFBSSxHQUFHO0FBQ1osK0JBQVcsQ0FBQyxRQUFRLENBQUMsT0FBTyxDQUFDLE1BQU0sQ0FBQyxDQUFDO0FBQ3JDLCtCQUFXLENBQUMsV0FBVyxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsQ0FBQztBQUN4QywrQkFBVyxDQUFDLFdBQVcsQ0FBQyxlQUFlLEdBQUcsZUFBZSxDQUFDOztBQUUxRCx5QkFBSyxDQUFDLE1BQU0sQ0FBQyxZQUFZLEVBQUUsbUJBQW1CLENBQUMsQ0FBQztpQkFDbkQ7Ozs7O0FBS0QseUJBQVMsWUFBWSxHQUFHO0FBQ3BCLDJCQUFPLFdBQVcsQ0FBQyxVQUFVLENBQUM7aUJBQ2pDOzs7OztBQUtELHlCQUFTLG1CQUFtQixDQUFDLFNBQVMsRUFBRSxhQUFhLEVBQUU7QUFDbkQsd0JBQUksQ0FBQyxTQUFTLEVBQUU7QUFDWiwrQkFBTztxQkFDVjs7O0FBR0Qsd0JBQU0sVUFBVSxHQUFHLFNBQVMsQ0FBQyxNQUFNLEdBQUcsYUFBYSxDQUFDLE1BQU0sQ0FBQzs7QUFFM0QsK0JBQVcsQ0FBQyxhQUFhLENBQUMsTUFBTSxDQUFDLFNBQVMsRUFBRSxVQUFVLENBQUMsQ0FBQyxDQUFDO0FBQ3pELCtCQUFXLENBQUMsT0FBTyxFQUFFLENBQUM7aUJBQ3pCOzs7OztBQUtELHlCQUFTLGVBQWUsQ0FBQyxVQUFVLEVBQUU7d0JBQzFCLEtBQUssR0FBVSxVQUFVLENBQXpCLEtBQUs7d0JBQUUsSUFBSSxHQUFJLFVBQVUsQ0FBbEIsSUFBSTs7QUFFbEIsMkJBQU8sV0FBVyxDQUFDLEtBQUssRUFBRSxJQUFJLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxLQUFLLEVBQUUsSUFBSSxDQUFDLENBQUM7aUJBQzNEOzs7OztBQUtELHlCQUFTLFdBQVcsQ0FBQyxLQUFLLEVBQUUsSUFBSSxFQUFFO0FBQzlCLHdCQUFNLFVBQVUsR0FBRyxZQUFZLENBQUM7QUFDaEMsd0JBQU0sU0FBUyxHQUFHLFlBQVksQ0FBQzs7QUFFL0IsMkJBQU8sQ0FBQyxDQUFDLFFBQVEsQ0FBQyxLQUFLLENBQUMsSUFDakIsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsSUFDaEIsVUFBVSxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsSUFDdEIsU0FBUyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsSUFDcEIsWUFBWSxDQUFDLEtBQUssQ0FBQyxDQUFDO2lCQUM5Qjs7Ozs7QUFLRCx5QkFBUyxZQUFZLENBQUMsS0FBSyxFQUFFO0FBQ3pCLHlCQUFLLEdBQUcsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxLQUFLLENBQUMsQ0FBQzs7QUFFMUIsMkJBQU8sS0FBSyxHQUFHLENBQUMsSUFBSSxLQUFLLEdBQUcsRUFBRSxDQUFDO2lCQUNsQzs7Ozs7QUFLRCx5QkFBUyxNQUFNLENBQUMsS0FBSyxFQUFFLElBQUksRUFBRTtBQUN6QiwyQkFBTyxnQkFBZ0IsRUFBRSxHQUFHLElBQUksSUFBSSxDQUFDLElBQUksRUFBRSxLQUFLLEdBQUcsQ0FBQyxDQUFDLENBQUM7aUJBQ3pEOzs7OztBQUtELHlCQUFTLGdCQUFnQixHQUFHO0FBQ3hCLHdCQUFNLElBQUksR0FBRyxJQUFJLElBQUksRUFBRSxDQUFDOztBQUV4QiwyQkFBTyxJQUFJLElBQUksQ0FBQyxJQUFJLENBQUMsV0FBVyxFQUFFLEVBQUUsSUFBSSxDQUFDLFFBQVEsRUFBRSxDQUFDLENBQUM7aUJBQ3hEOzs7OztBQUtELHlCQUFTLFNBQVMsR0FBVzt3QkFBVixHQUFHLHlEQUFHLEVBQUU7O0FBQ3ZCLHdCQUFNLEtBQUssR0FBRyxHQUFHLENBQUMsS0FBSyxDQUFDO0FBQ3hCLHdCQUFNLElBQUksR0FBRyxHQUFHLENBQUMsSUFBSSxDQUFDOztBQUV0Qix3QkFBSSxDQUFDLENBQUMsT0FBTyxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLEVBQUU7QUFDckMsK0JBQU8sRUFBRSxDQUFDO3FCQUNiOztBQUVELDJCQUFPLE9BQU8sQ0FBQyxNQUFNLENBQUMsQ0FBQyxJQUFJLElBQUksQ0FBQyxJQUFJLEVBQUUsS0FBSyxHQUFHLENBQUMsQ0FBQyxFQUFFLFNBQVMsQ0FBQyxDQUFDO2lCQUNoRTs7Ozs7O0FBTUQseUJBQVMsTUFBTSxDQUFDLFVBQVUsRUFBRTtBQUN4Qix3QkFBTSxRQUFRLEdBQUcsSUFBSSxJQUFJLEVBQUUsQ0FBQyxXQUFXLEVBQUUsQ0FBQyxRQUFRLEVBQUUsQ0FBQyxLQUFLLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDO0FBQ2pFLHdCQUFNLE1BQU0sR0FBRyxVQUFVLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxDQUFDO0FBQ3JDLHdCQUFNLEtBQUssR0FBRyxNQUFNLENBQUMsQ0FBQyxDQUFDLEdBQUcsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksRUFBRSxHQUFHLEVBQUUsQ0FBQztBQUNoRCx3QkFBTSxJQUFJLEdBQUcsTUFBTSxDQUFDLENBQUMsQ0FBQyxHQUFHLFFBQVEsR0FBRyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxFQUFFLEdBQUcsRUFBRSxDQUFDOztBQUUxRCwyQkFBTyxFQUFFLEtBQUssRUFBTCxLQUFLLEVBQUUsSUFBSSxFQUFKLElBQUksRUFBRSxDQUFDO2lCQUMxQjs7Ozs7QUFLRCx5QkFBUyxNQUFNLENBQUMsTUFBTSxFQUFFLFVBQVUsRUFBRTtBQUNoQyx3QkFBTSxNQUFNLEdBQUcsTUFBTSxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsQ0FBQztBQUNqQyx3QkFBTSxLQUFLLEdBQUcsTUFBTSxDQUFDLENBQUMsQ0FBQyxHQUFHLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLEVBQUUsR0FBRyxFQUFFLENBQUM7QUFDaEQsd0JBQU0sSUFBSSxHQUFHLE1BQU0sQ0FBQyxDQUFDLENBQUMsR0FBRyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxFQUFFLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsRUFBRSxDQUFDOzs7QUFHekQsd0JBQUksQUFBQyxDQUFDLFVBQVUsSUFBSSxDQUFDLElBQUksSUFBSyxLQUFLLENBQUMsTUFBTSxHQUFHLENBQUMsRUFBRTtBQUM1QywrQkFBTyxLQUFLLENBQUM7cUJBQ2hCOzs7QUFHRCx3QkFBSSxVQUFVLElBQUksQ0FBQyxJQUFJLElBQUksS0FBSyxDQUFDLE1BQU0sR0FBRyxDQUFDLEVBQUU7QUFDekMsK0JBQVUsS0FBSyxDQUFDLEtBQUssQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLFdBQU0sS0FBSyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBRztxQkFDckQ7O0FBRUQsMkJBQVUsS0FBSyxXQUFNLElBQUksQ0FBRztpQkFDL0I7YUFDSixDQUFDO1NBQ0w7QUFDRCxlQUFPLEVBQUUsU0FBUztBQUNsQixnQkFBUSxFQUFFLEdBQUc7S0FDaEIsQ0FBQztDQUNMLENBQUMsQ0FBQzs7O0FDcEpQLE9BQU8sQ0FBQyxNQUFNLENBQUMseUNBQXlDLEVBQUUsQ0FDdEQsbURBQW1ELENBQ3RELENBQUMsQ0FBQzs7Ozs7Ozs7O0FDSUgsT0FBTyxDQUFDLE1BQU0sQ0FBQyxzQ0FBc0MsRUFBRSxDQUNuRCxjQUFjLENBQ2pCLENBQUMsQ0FDRyxTQUFTLENBQUMsT0FBTyxFQUFFLFNBQVMsY0FBYyxDQUFDLE1BQU0sRUFBRTtBQUNoRCxXQUFPO0FBQ0gsWUFBSSxFQUFFLFNBQVMsU0FBUyxDQUFDLEtBQUssRUFBRSxPQUFPLEVBQUUsVUFBVSxFQUFFLE9BQU8sRUFBRTs7O0FBRzFELGdCQUFJLENBQUMsTUFBTSxDQUFDLFVBQVUsQ0FBQyxVQUFVLENBQUMsQ0FBQyxLQUFLLENBQUMsRUFBRTtBQUN2Qyx1QkFBTyxDQUFDLFdBQVcsQ0FBQyxLQUFLLEdBQUc7MkJBQU0sSUFBSTtpQkFBQSxDQUFDO2FBQzFDO1NBQ0o7QUFDRCxnQkFBUSxFQUFFLENBQUM7QUFDWCxlQUFPLEVBQUUsU0FBUztBQUNsQixnQkFBUSxFQUFFLEdBQUc7S0FDaEIsQ0FBQztDQUNMLENBQUMsQ0FBQzs7Ozs7Ozs7Ozs7O0FDYlAsT0FBTyxDQUFDLE1BQU0sQ0FBQyxvQ0FBb0MsRUFBRSxFQUFFLENBQUMsQ0FDbkQsTUFBTSxDQUFDLGFBQWEsRUFBRSxTQUFTLFdBQVcsQ0FBQyxJQUFJLEVBQUM7QUFDN0MsV0FBTyxVQUFTLElBQUksRUFBRTtBQUNsQixlQUFPLElBQUksQ0FBQyxXQUFXLENBQUMsSUFBSSxDQUFDLENBQUM7S0FDakMsQ0FBQztDQUNMLENBQUMsQ0FBQyIsImZpbGUiOiJiY2FwcC1wYXR0ZXJuLWxhYi1jb21wb25lbnRzLmpzIiwic291cmNlc0NvbnRlbnQiOlsiYW5ndWxhci5tb2R1bGUoJ2JjYXBwLXBhdHRlcm4tbGFiJywgW1xuICAgICdnZXR0ZXh0JyxcbiAgICAnbmdBbmltYXRlJyxcbiAgICAnbmdNZXNzYWdlcycsXG4gICAgJ21tLmZvdW5kYXRpb24nLFxuICAgICdiY2FwcC1wYXR0ZXJuLWxhYi10ZW1wbGF0ZXMnLFxuICAgICdiY2FwcC1wYXR0ZXJuLWxhYi5iYy1kYXRlcGlja2VyJyxcbiAgICAnYmNhcHAtcGF0dGVybi1sYWIuYmMtZHJvcGRvd24nLFxuICAgICdiY2FwcC1wYXR0ZXJuLWxhYi5iYy1tb2RhbCcsXG4gICAgJ2JjYXBwLXBhdHRlcm4tbGFiLmJjLXBhZ2luYXRpb24nLFxuICAgICdiY2FwcC1wYXR0ZXJuLWxhYi5iYy1zZXJ2ZXItdGFibGUnLFxuICAgICdiY2FwcC1wYXR0ZXJuLWxhYi5jaGVja2JveC1saXN0JyxcbiAgICAnYmNhcHAtcGF0dGVybi1sYWIuY3JlZGl0LWNhcmQnLFxuICAgICdiY2FwcC1wYXR0ZXJuLWxhYi5jcmVkaXQtY2FyZC10eXBlcycsXG4gICAgJ2JjYXBwLXBhdHRlcm4tbGFiLmZvcm0nLFxuICAgICdiY2FwcC1wYXR0ZXJuLWxhYi5mb3JtLWZpZWxkJyxcbiAgICAnYmNhcHAtcGF0dGVybi1sYWIuaWNvbicsXG4gICAgJ2JjYXBwLXBhdHRlcm4tbGFiLmxvYWRpbmctbm90aWZpY2F0aW9uJyxcbiAgICAnYmNhcHAtcGF0dGVybi1sYWIubG9hZGluZy1vdmVybGF5JyxcbiAgICAnYmNhcHAtcGF0dGVybi1sYWIuc3ByaXRlJyxcbiAgICAnYmNhcHAtcGF0dGVybi1sYWIuc3dpdGNoJyxcbiAgICAnYmNhcHAtcGF0dGVybi1sYWIudXRpbCdcbl0pO1xuIiwiLyogZ2xvYmFscyBtb21lbnQgKi9cbmFuZ3VsYXIubW9kdWxlKCdiY2FwcC1wYXR0ZXJuLWxhYi5iYy1kYXRlcGlja2VyLmNvbnN0YW50cycsIFtdKVxuICAgIC5jb25zdGFudCgnQkNfREFURVBJQ0tFUl9ERUZBVUxUUycsIHtcbiAgICAgICAgZGF5Rm9ybWF0OiAnRCcsXG4gICAgICAgIGlucHV0Rm9ybWF0OiBtb21lbnQubG9jYWxlRGF0YSgpLmxvbmdEYXRlRm9ybWF0KCdMJyksXG4gICAgICAgIHN0eWxlczoge1xuICAgICAgICAgICAgYmFjazogJ2RhdGVwaWNrZXItYmFjaycsXG4gICAgICAgICAgICBjb250YWluZXI6ICdkYXRlcGlja2VyJyxcbiAgICAgICAgICAgIGRhdGU6ICdkYXRlcGlja2VyLWRhdGUnLFxuICAgICAgICAgICAgZGF5Qm9keTogJ2RhdGVwaWNrZXItZGF5cy1ib2R5JyxcbiAgICAgICAgICAgIGRheUJvZHlFbGVtOiAnZGF0ZXBpY2tlci1kYXknLFxuICAgICAgICAgICAgZGF5Q29uY2VhbGVkOiAnZGF0ZXBpY2tlci1kYXktY29uY2VhbGVkJyxcbiAgICAgICAgICAgIGRheURpc2FibGVkOiAnaXMtZGlzYWJsZWQnLFxuICAgICAgICAgICAgZGF5SGVhZDogJ2RhdGVwaWNrZXItZGF5cy1oZWFkJyxcbiAgICAgICAgICAgIGRheUhlYWRFbGVtOiAnZGF0ZXBpY2tlci1kYXktbmFtZScsXG4gICAgICAgICAgICBkYXlQcmV2TW9udGg6ICdkYXRlcGlja2VyLWRheS1wcmV2LW1vbnRoJyxcbiAgICAgICAgICAgIGRheU5leHRNb250aDogJ2RhdGVwaWNrZXItZGF5LW5leHQtbW9udGgnLFxuICAgICAgICAgICAgZGF5Um93OiAnZGF0ZXBpY2tlci1kYXlzLXJvdycsXG4gICAgICAgICAgICBkYXlUYWJsZTogJ2RhdGVwaWNrZXItZGF5cycsXG4gICAgICAgICAgICBtb250aDogJ2RhdGVwaWNrZXItbW9udGgnLFxuICAgICAgICAgICAgbW9udGhMYWJlbDogJ2RhdGVwaWNrZXItbW9udGgnLFxuICAgICAgICAgICAgbmV4dDogJ2RhdGVwaWNrZXItbmV4dCcsXG4gICAgICAgICAgICBwb3NpdGlvbmVkOiAnZGF0ZXBpY2tlci1hdHRhY2htZW50JyxcbiAgICAgICAgICAgIHNlbGVjdGVkRGF5OiAnaXMtc2VsZWN0ZWQnLFxuICAgICAgICAgICAgc2VsZWN0ZWRUaW1lOiAnZGF0ZXBpY2tlci10aW1lLXNlbGVjdGVkJyxcbiAgICAgICAgICAgIHRpbWU6ICdkYXRlcGlja2VyLXRpbWUnLFxuICAgICAgICAgICAgdGltZUxpc3Q6ICdkYXRlcGlja2VyLXRpbWUtbGlzdCcsXG4gICAgICAgICAgICB0aW1lT3B0aW9uOiAnZGF0ZXBpY2tlci10aW1lLW9wdGlvbidcbiAgICAgICAgfSxcbiAgICAgICAgdGltZTogZmFsc2UsXG4gICAgICAgIHdlZWtkYXlGb3JtYXQ6ICdzaG9ydCdcbiAgICB9KTtcbiIsIi8qIGdsb2JhbHMgcm9tZSAqL1xuYW5ndWxhci5tb2R1bGUoJ2JjYXBwLXBhdHRlcm4tbGFiLmJjLWRhdGVwaWNrZXIuZGlyZWN0aXZlJywgW1xuICAgICdiY2FwcC1wYXR0ZXJuLWxhYi5iYy1kYXRlcGlja2VyLmNvbnN0YW50cydcbl0pXG4gICAgLmRpcmVjdGl2ZSgnYmNEYXRlcGlja2VyJywgZnVuY3Rpb24gYmNEYXRlcGlja2VyRGlyZWN0aXZlKEJDX0RBVEVQSUNLRVJfREVGQVVMVFMpIHtcbiAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICAgIHJlc3RyaWN0OiAnQScsXG4gICAgICAgICAgICByZXF1aXJlOiAnbmdNb2RlbCcsXG4gICAgICAgICAgICBzY29wZToge1xuICAgICAgICAgICAgICAgIG9wdGlvbnM6ICc9PydcbiAgICAgICAgICAgIH0sXG5cbiAgICAgICAgICAgIGxpbms6IGZ1bmN0aW9uIGRhdGVwaWNrZXJMaW5rRnVuY3Rpb24oc2NvcGUsIGVsZW1lbnQsIGF0dHJzLCBuZ01vZGVsKSB7XG4gICAgICAgICAgICAgICAgaWYgKHNjb3BlLm9wdGlvbnMgPT09IHVuZGVmaW5lZCkge1xuICAgICAgICAgICAgICAgICAgICBzY29wZS5vcHRpb25zID0ge307XG4gICAgICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAgICAgLy8gQWRkIGRlZmF1bHRzIHRvIHRoZSBvcHRpb25zIG9iamVjdFxuICAgICAgICAgICAgICAgIF8uZGVmYXVsdHMoc2NvcGUub3B0aW9ucywgQkNfREFURVBJQ0tFUl9ERUZBVUxUUyk7XG5cbiAgICAgICAgICAgICAgICAvLyBDcmVhdGUgYSBuZXcgcm9tZSAoY2FsZW5kYXIpIGluc3RhbmNlXG4gICAgICAgICAgICAgICAgc2NvcGUuY2FsZW5kYXIgPSByb21lKGVsZW1lbnRbMF0sIHNjb3BlLm9wdGlvbnMpO1xuXG4gICAgICAgICAgICAgICAgLy8gT24gJ2RhdGEnIGV2ZW50IHNldCBuZ01vZGVsIHRvIHRoZSBwYXNzZWQgdmFsdWVcbiAgICAgICAgICAgICAgICBzY29wZS5jYWxlbmRhci5vbignZGF0YScsIGZ1bmN0aW9uIG9uRGF0YSh2YWx1ZSkge1xuICAgICAgICAgICAgICAgICAgICBuZ01vZGVsLiRzZXRWaWV3VmFsdWUodmFsdWUpO1xuICAgICAgICAgICAgICAgICAgICBzY29wZS4kYXBwbHkoKTtcbiAgICAgICAgICAgICAgICB9KTtcblxuICAgICAgICAgICAgICAgIHNjb3BlLmNhbGVuZGFyLm9uKCdyZWFkeScsIGZ1bmN0aW9uIG9uUmVhZHkob3B0aW9ucykge1xuICAgICAgICAgICAgICAgICAgICBpZiAoYXR0cnMucGxhY2Vob2xkZXIgPT09IHVuZGVmaW5lZCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgYXR0cnMuJHNldCgncGxhY2Vob2xkZXInLCBvcHRpb25zLmlucHV0Rm9ybWF0KTtcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIH0pO1xuXG4gICAgICAgICAgICAgICAgLy8gUmVtb3ZpbmcgY2FsZW5kYXIgZXZlbnQgbGlzdGVuZXJzXG4gICAgICAgICAgICAgICAgZWxlbWVudC5vbignJGRlc3Ryb3knLCBmdW5jdGlvbiBvbkRlc3Ryb3koKSB7XG4gICAgICAgICAgICAgICAgICAgIHNjb3BlLmNhbGVuZGFyLmRlc3Ryb3koKTtcbiAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfTtcbiAgICB9KTtcbiIsImFuZ3VsYXIubW9kdWxlKCdiY2FwcC1wYXR0ZXJuLWxhYi5iYy1kYXRlcGlja2VyJywgW1xuICAgICdiY2FwcC1wYXR0ZXJuLWxhYi5iYy1kYXRlcGlja2VyLmRpcmVjdGl2ZSdcbl0pO1xuIiwiYW5ndWxhci5tb2R1bGUoJ2JjYXBwLXBhdHRlcm4tbGFiLmJjLWRyb3Bkb3duLW1lbnUuZGlyZWN0aXZlJywgW10pXG4gICAgLmRpcmVjdGl2ZSgnYmNEcm9wZG93bk1lbnUnLCBmdW5jdGlvbiBiY0Ryb3Bkb3duTWVudURpcmVjdGl2ZSgpIHtcbiAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICAgIHJlc3RyaWN0OiAnQScsXG4gICAgICAgICAgICByZXF1aXJlOiAnXmJjRHJvcGRvd24nLFxuICAgICAgICAgICAgY29tcGlsZTogZnVuY3Rpb24gYmNEcm9wZG93bk1lbnVEaXJlY3RpdmVDb21waWxlKHRFbGVtZW50KSB7XG4gICAgICAgICAgICAgICAgdEVsZW1lbnQuYWRkQ2xhc3MoJ2Ryb3Bkb3duLW1lbnUnKTtcblxuICAgICAgICAgICAgICAgIHJldHVybiBmdW5jdGlvbiBiY0Ryb3Bkb3duTWVudURpcmVjdGl2ZUxpbmsoc2NvcGUsIGVsZW1lbnQsIGF0dHJzLCBiY0Ryb3Bkb3duQ3RybCkge1xuICAgICAgICAgICAgICAgICAgICBlbGVtZW50LmF0dHIoJ2lkJywgYmNEcm9wZG93bkN0cmwuZ2V0VW5pcXVlSWQoKSk7XG4gICAgICAgICAgICAgICAgfTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfTtcbiAgICB9KTtcbiIsImFuZ3VsYXIubW9kdWxlKCdiY2FwcC1wYXR0ZXJuLWxhYi5iYy1kcm9wZG93bi10b2dnbGUuZGlyZWN0aXZlJywgW10pXG4gICAgLmRpcmVjdGl2ZSgnYmNEcm9wZG93blRvZ2dsZScsIGZ1bmN0aW9uIGJjRHJvcGRvd25Ub2dnbGVEaXJlY3RpdmUoJGNvbXBpbGUpIHtcbiAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICAgIHJlc3RyaWN0OiAnQScsXG4gICAgICAgICAgICB0ZXJtaW5hbDogdHJ1ZSxcbiAgICAgICAgICAgIHByaW9yaXR5OiAxMDAxLCAvLyBzZXQgaGlnaGVyIHRoYW4gbmctcmVwZWF0IHRvIHByZXZlbnQgZG91YmxlIGNvbXBpbGF0aW9uXG4gICAgICAgICAgICByZXF1aXJlOiAnXmJjRHJvcGRvd24nLFxuICAgICAgICAgICAgY29tcGlsZTogZnVuY3Rpb24gYmNEcm9wZG93blRvZ2dsZURpcmVjdGl2ZUNvbXBpbGUodEVsZW1lbnQpIHtcbiAgICAgICAgICAgICAgICB0RWxlbWVudC5yZW1vdmVBdHRyKCdiYy1kcm9wZG93bi10b2dnbGUnKTtcblxuICAgICAgICAgICAgICAgIHJldHVybiBmdW5jdGlvbiBiY0Ryb3Bkb3duVG9nZ2xlRGlyZWN0aXZlTGluayhzY29wZSwgZWxlbWVudCwgYXR0cnMsIGJjRHJvcGRvd25DdHJsKSB7XG4gICAgICAgICAgICAgICAgICAgIGVsZW1lbnQuYXR0cignZHJvcGRvd24tdG9nZ2xlJywgJyMnICsgYmNEcm9wZG93bkN0cmwuZ2V0VW5pcXVlSWQoKSk7XG4gICAgICAgICAgICAgICAgICAgICRjb21waWxlKGVsZW1lbnQpKHNjb3BlKTtcbiAgICAgICAgICAgICAgICB9O1xuICAgICAgICAgICAgfVxuICAgICAgICB9O1xuICAgIH0pO1xuIiwiYW5ndWxhci5tb2R1bGUoJ2JjYXBwLXBhdHRlcm4tbGFiLmJjLWRyb3Bkb3duLmRpcmVjdGl2ZScsIFtdKVxuICAgIC5kaXJlY3RpdmUoJ2JjRHJvcGRvd24nLCBmdW5jdGlvbiBiY0Ryb3Bkb3duRGlyZWN0aXZlKCkge1xuICAgICAgICByZXR1cm4ge1xuICAgICAgICAgICAgcmVzdHJpY3Q6ICdFQScsXG4gICAgICAgICAgICBjb250cm9sbGVyOiBmdW5jdGlvbiBiY0Ryb3Bkb3duRGlyZWN0aXZlQ29udHJvbGxlcigpIHtcbiAgICAgICAgICAgICAgICB2YXIgY3RybCA9IHRoaXMsXG4gICAgICAgICAgICAgICAgICAgIHVuaXF1ZUlkO1xuXG4gICAgICAgICAgICAgICAgY3RybC5nZXRVbmlxdWVJZCA9IGdldFVuaXF1ZUlkO1xuXG4gICAgICAgICAgICAgICAgZnVuY3Rpb24gZ2V0VW5pcXVlSWQoKSB7XG4gICAgICAgICAgICAgICAgICAgIGlmICghdW5pcXVlSWQpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHVuaXF1ZUlkID0gXy51bmlxdWVJZCgnYmMtZHJvcGRvd24tJyk7XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIHVuaXF1ZUlkO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgfTtcbiAgICB9KTtcbiIsImFuZ3VsYXIubW9kdWxlKCdiY2FwcC1wYXR0ZXJuLWxhYi5iYy1kcm9wZG93bicsIFtcbiAgICAnYmNhcHAtcGF0dGVybi1sYWIuYmMtZHJvcGRvd24uZGlyZWN0aXZlJyxcbiAgICAnYmNhcHAtcGF0dGVybi1sYWIuYmMtZHJvcGRvd24tdG9nZ2xlLmRpcmVjdGl2ZScsXG4gICAgJ2JjYXBwLXBhdHRlcm4tbGFiLmJjLWRyb3Bkb3duLW1lbnUuZGlyZWN0aXZlJ1xuXSk7XG4iLCJhbmd1bGFyLm1vZHVsZSgnYmNhcHAtcGF0dGVybi1sYWIuYmMtcGFnaW5hdGlvbi5kaXJlY3RpdmUnLCBbXSlcbiAgICAuZGlyZWN0aXZlKCdiY1BhZ2luYXRpb24nLCBmdW5jdGlvbiBiY1BhZ2luYXRpb25EaXJlY3RpdmUoJHBhcnNlKSB7XG4gICAgICAgIHJldHVybiB7XG4gICAgICAgICAgICByZXN0cmljdDogJ0UnLFxuICAgICAgICAgICAgc2NvcGU6IHRydWUsXG4gICAgICAgICAgICB0ZW1wbGF0ZVVybDogJ3NyYy9qcy9iaWdjb21tZXJjZS9iYy1wYWdpbmF0aW9uL2JjLXBhZ2luYXRpb24udHBsLmh0bWwnLFxuXG4gICAgICAgICAgICBjb21waWxlOiBmdW5jdGlvbiBiY1BhZ2luYXRpb25Db21waWxlKHRFbGVtZW50LCB0QXR0cnMpIHtcbiAgICAgICAgICAgICAgICB2YXIgYXR0ck9iaiA9IHt9O1xuXG4gICAgICAgICAgICAgICAgLy8gU2luY2UgdGhpcyBpcyBhIHdyYXBwZXIgb2YgYW5ndWxhci1mb3VuZGF0aW9uJ3MgcGFnaW5hdGlvbiBkaXJlY3RpdmUgd2UgbmVlZCB0byBjb3B5IGFsbFxuICAgICAgICAgICAgICAgIC8vIG9mIHRoZSBhdHRyaWJ1dGVzIHBhc3NlZCB0byBvdXIgZGlyZWN0aXZlIGFuZCBzdG9yZSB0aGVtIGluIHRoZSBhdHRyT2JqLlxuICAgICAgICAgICAgICAgIF8uZWFjaCh0QXR0cnMuJGF0dHIsIGZ1bmN0aW9uKGtleSkge1xuICAgICAgICAgICAgICAgICAgICBpZiAoa2V5ICE9PSAnY2xhc3MnKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICBhdHRyT2JqW2tleV0gPSB0RWxlbWVudC5hdHRyKGtleSk7XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICB9KTtcblxuICAgICAgICAgICAgICAgIC8vIEFkZGluZyBvdXIgY3VzdG9tIGNhbGxiYWNrIHRvIHRoZSBhdHRyT2JqLCBhbmd1bGFyLWZvdW5kYXRpb24gd2lsbCBjYWxsIHRoaXMgZnVuY3Rpb25cbiAgICAgICAgICAgICAgICAvLyB3aGVuIGEgcGFnZSBudW1iZXIgaXMgY2xpY2tlZCBpbiB0aGUgcGFnaW5hdGlvbi5cbiAgICAgICAgICAgICAgICBhdHRyT2JqWydvbi1zZWxlY3QtcGFnZSddID0gJ3BhZ2luYXRpb25DYWxsYmFjayhwYWdlKSc7XG5cbiAgICAgICAgICAgICAgICAvLyBBZGQgYWxsIHRoZSBhdHRyaWJ1dGVzIHRvIGFuZ3VsYXItZm91bmRhdGlvbidzIHBhZ2luYXRpb24gZGlyZWN0aXZlXG4gICAgICAgICAgICAgICAgdEVsZW1lbnQuZmluZCgncGFnaW5hdGlvbicpLmF0dHIoYXR0ck9iaik7XG5cbiAgICAgICAgICAgICAgICByZXR1cm4gZnVuY3Rpb24gYmNQYWdpbmF0aW9uTGluaygkc2NvcGUsIGVsZW1lbnQsIGF0dHJzKSB7XG4gICAgICAgICAgICAgICAgICAgIHZhciBvbkNoYW5nZVBhcnNlR2V0dGVyID0gJHBhcnNlKGF0dHJzLm9uQ2hhbmdlKSxcbiAgICAgICAgICAgICAgICAgICAgICAgIGRlZmF1bHRMaW1pdHMgPSBbMTAsIDIwLCAzMCwgNTAsIDEwMF07XG5cbiAgICAgICAgICAgICAgICAgICAgJHNjb3BlLnNldExpbWl0ID0gZnVuY3Rpb24obGltaXQsIGV2ZW50KSB7XG4gICAgICAgICAgICAgICAgICAgICAgICBldmVudC5wcmV2ZW50RGVmYXVsdCgpO1xuICAgICAgICAgICAgICAgICAgICAgICAgbGltaXQgPSBfLnBhcnNlSW50KGxpbWl0KTtcbiAgICAgICAgICAgICAgICAgICAgICAgICRwYXJzZShhdHRycy5pdGVtc1BlclBhZ2UpLmFzc2lnbigkc2NvcGUuJHBhcmVudCwgbGltaXQpO1xuICAgICAgICAgICAgICAgICAgICAgICAgJHNjb3BlLnBhZ2luYXRpb25DYWxsYmFjaygxLCBsaW1pdCk7XG4gICAgICAgICAgICAgICAgICAgIH07XG5cbiAgICAgICAgICAgICAgICAgICAgJHNjb3BlLmdldEN1cnJlbnRQYWdlID0gZnVuY3Rpb24oKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gJHBhcnNlKGF0dHJzLnBhZ2UpKCRzY29wZS4kcGFyZW50KTtcbiAgICAgICAgICAgICAgICAgICAgfTtcblxuICAgICAgICAgICAgICAgICAgICAkc2NvcGUuZ2V0Q3VycmVudExpbWl0ID0gZnVuY3Rpb24oKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gJHBhcnNlKGF0dHJzLml0ZW1zUGVyUGFnZSkoJHNjb3BlLiRwYXJlbnQpO1xuICAgICAgICAgICAgICAgICAgICB9O1xuXG4gICAgICAgICAgICAgICAgICAgICRzY29wZS5nZXRJdGVtc1BlclBhZ2UgPSBmdW5jdGlvbigpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiAkcGFyc2UoYXR0cnMuaXRlbXNQZXJQYWdlKSgkc2NvcGUuJHBhcmVudCkgfHwgMDtcbiAgICAgICAgICAgICAgICAgICAgfTtcblxuICAgICAgICAgICAgICAgICAgICAkc2NvcGUuZ2V0VG90YWxJdGVtcyA9IGZ1bmN0aW9uKCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuICRwYXJzZShhdHRycy50b3RhbEl0ZW1zKSgkc2NvcGUuJHBhcmVudCkgfHwgMDtcbiAgICAgICAgICAgICAgICAgICAgfTtcblxuICAgICAgICAgICAgICAgICAgICAkc2NvcGUuc2hvdyA9IGZ1bmN0aW9uKCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuICRzY29wZS5nZXRUb3RhbEl0ZW1zKCkgPiAkc2NvcGUuZ2V0SXRlbXNQZXJQYWdlKCk7XG4gICAgICAgICAgICAgICAgICAgIH07XG5cbiAgICAgICAgICAgICAgICAgICAgJHNjb3BlLnNob3dMaW1pdHMgPSBmdW5jdGlvbigpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiAkc2NvcGUuc2hvdygpICYmICRwYXJzZShhdHRycy5zaG93TGltaXRzKSgkc2NvcGUuJHBhcmVudCkgIT09IGZhbHNlO1xuICAgICAgICAgICAgICAgICAgICB9O1xuXG4gICAgICAgICAgICAgICAgICAgICRzY29wZS5nZXRMaW1pdHMgPSBmdW5jdGlvbigpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHZhciBsaW1pdHMgPSAkcGFyc2UoYXR0cnMubGltaXRzKSgkc2NvcGUuJHBhcmVudCk7XG5cbiAgICAgICAgICAgICAgICAgICAgICAgIGlmICghQXJyYXkuaXNBcnJheShsaW1pdHMpKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIGRlZmF1bHRMaW1pdHM7XG4gICAgICAgICAgICAgICAgICAgICAgICB9XG5cbiAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiBsaW1pdHM7XG4gICAgICAgICAgICAgICAgICAgIH07XG5cbiAgICAgICAgICAgICAgICAgICAgJHNjb3BlLnBhZ2luYXRpb25DYWxsYmFjayA9IGZ1bmN0aW9uKHBhZ2UsIGxpbWl0KSB7XG4gICAgICAgICAgICAgICAgICAgICAgICB2YXIgYWRkaXRpb25hbFNjb3BlUHJvcGVydGllcyA9IHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbGltaXQ6IGxpbWl0IHx8ICRzY29wZS5nZXRDdXJyZW50TGltaXQoKSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcGFnZTogcGFnZVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2VQYXJzZVJlc3VsdDtcblxuICAgICAgICAgICAgICAgICAgICAgICAgJHBhcnNlKGF0dHJzLnBhZ2UpLmFzc2lnbigkc2NvcGUuJHBhcmVudCwgcGFnZSk7XG5cbiAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlUGFyc2VSZXN1bHQgPSBvbkNoYW5nZVBhcnNlR2V0dGVyKCRzY29wZSwgYWRkaXRpb25hbFNjb3BlUHJvcGVydGllcyk7XG5cbiAgICAgICAgICAgICAgICAgICAgICAgIC8vIGlmIHRoZSBvbkNoYW5nZSBzdHJpbmcgaXMgYSBmdW5jdGlvbiBhbmQgbm90IGFuIGV4cHJlc3Npb246IGNhbGwgaXQgd2l0aCB0aGUgYWRkaXRpb25hbFNjb3BlUHJvcGVydGllcyBvYmogKGZvciBiYWNrd2FyZHMgY29tcGF0YWJpbGl0eSlcbiAgICAgICAgICAgICAgICAgICAgICAgIC8vIGVsc2UgdGhlIGV4cHJlc3Npb24gaGFzIGFscmVhZHkgYmVlbiByYW46IGRvIG5vdGhpbmdcbiAgICAgICAgICAgICAgICAgICAgICAgIGlmICh0eXBlb2Ygb25DaGFuZ2VQYXJzZVJlc3VsdCA9PT0gJ2Z1bmN0aW9uJykge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlUGFyc2VSZXN1bHQoYWRkaXRpb25hbFNjb3BlUHJvcGVydGllcyk7XG4gICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIH07XG4gICAgICAgICAgICAgICAgfTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfTtcbiAgICB9KTtcbiIsImFuZ3VsYXIubW9kdWxlKCdiY2FwcC1wYXR0ZXJuLWxhYi5iYy1wYWdpbmF0aW9uJywgW1xuICAgICdiY2FwcC1wYXR0ZXJuLWxhYi5iYy1wYWdpbmF0aW9uLmRpcmVjdGl2ZSdcbl0pO1xuIiwiYW5ndWxhci5tb2R1bGUoJ2JjYXBwLXBhdHRlcm4tbGFiLmJjLXNlcnZlci10YWJsZS5jb250cm9sbGVyJywgW1xuICAgICdiY2FwcC1wYXR0ZXJuLWxhYi5iYy1zZXJ2ZXItdGFibGUuc2VydmljZSdcbl0pXG5cbiAgICAuY29udHJvbGxlcignQmNTZXJ2ZXJUYWJsZUN0cmwnLCBmdW5jdGlvbiBCY1NlcnZlclRhYmxlQ3RybCgkYXR0cnMsICRsb2csICRwYXJzZSwgJHNjb3BlLCBCY1NlcnZlclRhYmxlKSB7XG4gICAgICAgIHZhciBjdHJsID0gdGhpcyxcbiAgICAgICAgICAgIGJjU2VydmVyVGFibGVQcm90b3R5cGUgPSBCY1NlcnZlclRhYmxlLnByb3RvdHlwZTtcblxuICAgICAgICAvLyBDYWxsIHRoZSBCY1NlcnZlclRhYmxlIGNvbnN0cnVjdG9yIG9uIHRoZSBjb250cm9sbGVyXG4gICAgICAgIC8vIGluIG9yZGVyIHRvIHNldCBhbGwgdGhlIGNvbnRyb2xsZXIgcHJvcGVydGllcyBkaXJlY3RseS5cbiAgICAgICAgLy8gVGhpcyBpcyBoZXJlIGZvciBiYWNrd2FyZHMgY29tcGF0YWJpbGl0eSBwdXJwb3Nlcy5cbiAgICAgICAgQmNTZXJ2ZXJUYWJsZS5jYWxsKGN0cmwsIG51bGwsICgkcGFyc2UoJGF0dHJzLnRhYmxlQ29uZmlnKSgkc2NvcGUpKSk7XG5cbiAgICAgICAgLy8gY29udHJvbGxlciBmdW5jdGlvbnNcbiAgICAgICAgY3RybC5jcmVhdGVQYXJhbXNPYmplY3QgPSBiY1NlcnZlclRhYmxlUHJvdG90eXBlLmNyZWF0ZVBhcmFtc09iamVjdDtcbiAgICAgICAgY3RybC5mZXRjaFJlc291cmNlID0gYmNTZXJ2ZXJUYWJsZVByb3RvdHlwZS5mZXRjaFJlc291cmNlO1xuICAgICAgICBjdHJsLmdldFNlbGVjdGVkUm93cyA9IGJjU2VydmVyVGFibGVQcm90b3R5cGUuZ2V0U2VsZWN0ZWRSb3dzO1xuICAgICAgICBjdHJsLmluaXQgPSBiY1NlcnZlclRhYmxlUHJvdG90eXBlLmluaXQ7XG4gICAgICAgIGN0cmwuaXNSb3dTZWxlY3RlZCA9IGJjU2VydmVyVGFibGVQcm90b3R5cGUuaXNSb3dTZWxlY3RlZDtcbiAgICAgICAgY3RybC5sb2FkU3RhdGVQYXJhbXMgPSBiY1NlcnZlclRhYmxlUHJvdG90eXBlLmxvYWRTdGF0ZVBhcmFtcztcbiAgICAgICAgY3RybC5zZWxlY3RBbGxSb3dzID0gYmNTZXJ2ZXJUYWJsZVByb3RvdHlwZS5zZWxlY3RBbGxSb3dzO1xuICAgICAgICBjdHJsLnNldFBhZ2luYXRpb25WYWx1ZXMgPSBiY1NlcnZlclRhYmxlUHJvdG90eXBlLnNldFBhZ2luYXRpb25WYWx1ZXM7XG4gICAgICAgIGN0cmwuc2V0Um93cyA9IGJjU2VydmVyVGFibGVQcm90b3R5cGUuc2V0Um93cztcbiAgICAgICAgY3RybC5zZXRTb3J0aW5nVmFsdWVzID0gYmNTZXJ2ZXJUYWJsZVByb3RvdHlwZS5zZXRTb3J0aW5nVmFsdWVzO1xuICAgICAgICBjdHJsLnVwZGF0ZVBhZ2UgPSBfLmJpbmQoYmNTZXJ2ZXJUYWJsZVByb3RvdHlwZS51cGRhdGVQYWdlLCBjdHJsKTtcbiAgICAgICAgY3RybC51cGRhdGVTb3J0ID0gYmNTZXJ2ZXJUYWJsZVByb3RvdHlwZS51cGRhdGVTb3J0O1xuICAgICAgICBjdHJsLnVwZGF0ZVRhYmxlID0gYmNTZXJ2ZXJUYWJsZVByb3RvdHlwZS51cGRhdGVUYWJsZTtcbiAgICAgICAgY3RybC52YWxpZGF0ZVJlc291cmNlID0gYmNTZXJ2ZXJUYWJsZVByb3RvdHlwZS52YWxpZGF0ZVJlc291cmNlO1xuXG4gICAgICAgIGluaXQoKTtcblxuICAgICAgICBmdW5jdGlvbiBpbml0KCkge1xuICAgICAgICAgICAgdmFyIHJlc291cmNlQ2FsbGJhY2s7XG5cbiAgICAgICAgICAgIHJlc291cmNlQ2FsbGJhY2sgPSAkcGFyc2UoJGF0dHJzLnJlc291cmNlQ2FsbGJhY2spKCRzY29wZSk7XG4gICAgICAgICAgICBpZiAoIV8uaXNGdW5jdGlvbihyZXNvdXJjZUNhbGxiYWNrKSkge1xuICAgICAgICAgICAgICAgICRsb2cuZXJyb3IoJ2JjLXNlcnZlci10YWJsZSBkaXJlY3RpdmU6IHJlc291cmNlLWNhbGxiYWNrIG11c3QgYmUgYSBmdW5jdGlvbi4nKTtcbiAgICAgICAgICAgICAgICByZXR1cm47XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBjdHJsLnJlc291cmNlQ2FsbGJhY2sgPSByZXNvdXJjZUNhbGxiYWNrO1xuXG4gICAgICAgICAgICBjdHJsLmluaXQoKTtcbiAgICAgICAgfVxuICAgIH0pO1xuIiwiYW5ndWxhci5tb2R1bGUoJ2JjYXBwLXBhdHRlcm4tbGFiLmJjLXNlcnZlci10YWJsZS5kaXJlY3RpdmUnLCBbXG4gICAgJ2JjYXBwLXBhdHRlcm4tbGFiLmJjLXNlcnZlci10YWJsZS5jb250cm9sbGVyJyxcbiAgICAnYmNhcHAtcGF0dGVybi1sYWIuYmMtc2VydmVyLXRhYmxlLnNvcnQtYnkuZGlyZWN0aXZlJyxcbiAgICAndWkucm91dGVyJ1xuXSlcbiAgICAvKipcbiAgICAgKiBUaGUgYmMtc2VydmVyLXRhYmxlIGRpcmVjdGl2ZSBjcmVhdGVzIGEgZGF0YSB0YWJsZSB0aGF0IGhhbmRsZXNcbiAgICAgKiBzZXJ2ZXIgc2lkZSBwYWdpbmF0aW9uLCBzb3J0aW5nLCBhbmQgZmlsdGVyaW5nLiBJdCBleHBvc2VzIGEgZmV3IHNjb3BlIHZhcmlhYmxlcyxcbiAgICAgKiB0aGF0IGNhbiBiZSB1c2VkIHRvIGRpc3BsYXkgdGhlIHRhYmxlIGNvbnRlbnQgd2l0aCBjdXN0b20gbWFya3VwIChzZWUgZXhhbXBsZVxuICAgICAqIGluIHRoZSBwYXR0ZXJuIGxhYiBmb3IgYW4gYWN0dWFsIGltcGxlbWVudGF0aW9uIG9mIHRoZSBiYy1zZXJ2ZXItdGFibGUpLlxuICAgICAqXG4gICAgICogVGhlIGZvbGxvd2luZyBhdHRyaWJ1dGVzIGNhbiBiZSBwYXNzZWQgaW4gb3JkZXIgdG8gY29uZmlndXJlIHRoZSBiYy1zZXJ2ZXItdGFibGU6XG4gICAgICogLSByZXNvdXJjZS1jYWxsYmFjayAocmVxdWlyZWQpXG4gICAgICogLSB0YWJsZUNvbmZpZyAob3B0aW9uYWwpXG4gICAgICpcbiAgICAgKiAtIHJlc291cmNlLWNhbGxiYWNrIC0gYSBmdW5jdGlvbiB0aGF0IHJldHVybnMgYSBwcm9taXNlIHdoaWNoIGlzIHJlc292bGVkXG4gICAgICogd2l0aCBhbiBvYmplY3Qgb2YgdGhlIGZvbGxvd2luZyBmb3JtYXQ6XG4gICAgICogICAgICB7XG4gICAgICogICAgICAgICAgcm93czogQXJyYXksXG4gICAgICogICAgICAgICAgcGFnaW5hdGlvbjoge1xuICAgICAqICAgICAgICAgICAgICBwYWdlOiBOdW1iZXIsXG4gICAgICogICAgICAgICAgICAgIGxpbWl0OiBOdW1iZXIsXG4gICAgICogICAgICAgICAgICAgIHRvdGFsOiBOdW1iZXJcbiAgICAgKiAgICAgICAgICB9XG4gICAgICogICAgICB9XG4gICAgICpcbiAgICAgKiBUaGlzIGRpcmVjdGl2ZSBleHBvc2VzIGEgc2NvcGUgdmFyaWFibGUgY2FsbGVkIGJjU2VydmVyVGFibGUgdGhhdFxuICAgICAqIGNhbiBiZSB1c2VkIHRvIGRpc3BsYXkgY29udGVudCwgYW5kIGltcGxlbWVudCBhZGRpdGlvbmFsIGZ1bmN0aW9uYWxpdHlcbiAgICAgKiB0byB0aGUgdGFibGUgKHN1Y2ggYXMgcGFnaW5hdGlvbiwgc29ydGluZywgYW5kIHNlbGVjdGlvbiBsb2dpYykuXG4gICAgICpcbiAgICAgKiAtIGJjU2VydmVyVGFibGUucm93c1xuICAgICAqICAgICAgLSBDYW4gYmUgdXNlZCB3aXRoIG5nLXJlcGVhdCB0byBkaXNwbGF5IHRoZSBkYXRhXG4gICAgICogLSBiY1NlcnZlclRhYmxlLmZpbHRlcnNcbiAgICAgKiAgICAgIC0gQ2FuIGJlIHVzZWQgdG8gY2hhbmdlL3VwZGF0ZSBmaWx0ZXJzLiBUaGVzZSBmaWx0ZXJzIG11c3QgYXBwZWFyXG4gICAgICogICAgICAgIGluIHRoZSBzdGF0ZSBkZWZpbml0aW9uIGluIG9yZGVyIHRvIHdvcmsgY29ycmVjdGx5LlxuICAgICAqIC0gYmNTZXJ2ZXJUYWJsZS51cGRhdGVUYWJsZSgpXG4gICAgICogICAgICAtIFBlcmZvcm0gYSBzdGF0ZSB0cmFuc2lzdGlvbiB3aXRoIHRoZSBjdXJyZW50IHRhYmxlIGluZm9cbiAgICAgKiAtIGJjU2VydmVyVGFibGUucGFnaW5hdGlvblxuICAgICAqICAgICAgLSBleHBvc2VzIHBhZ2UsIGxpbWl0LCBhbmQgdG90YWxcbiAgICAgKiAtIGJjU2VydmVyVGFibGUuc2V0UGFnaW5hdGlvblZhbHVlcyhwYWdpbmF0aW9uKVxuICAgICAqICAgICAgLSBjb252ZW5pZW5jZSBtZXRob2QgZm9yIHNldHRpbmcgcGFnaW5hdGlvbiB2YWx1ZXMgYXQgb25jZS5cbiAgICAgKlxuICAgICAqIC0gYmNTZXJ2ZXJUYWJsZS5zZWxlY3RlZFJvd3NcbiAgICAgKiAgICAgIC0gYW4gbWFwIG9iamVjdCB3aXRoIHVuaXF1ZSBpZCdzIGFzIGtleXMgYW5kIGJvb2xlYW4gdmFsdWVzIGFzIHRoZSBzZWxlY3RlZCBzdGF0ZVxuICAgICAqIC0gYmNTZXJ2ZXJUYWJsZS5hbGxTZWxlY3RlZFxuICAgICAqICAgICAgLSBhIGJvb2xlYW4gdmFsdWUgdXNlZCB0byBkZXRlcm1pbmUgaWYgYWxsIHJvd3Mgd2VyZSBzZWxlY3RlZCBvciBjbGVhcmVkXG4gICAgICogLSBiY1NlcnZlclRhYmxlLnNlbGVjdEFsbFJvd3MoKVxuICAgICAqICAgICAgLSB0b2dnbGUgYWxsIHJvd3Mgc2VsZWN0aW9uIHN0YXRlXG4gICAgICogLSBiY1NlcnZlclRhYmxlLmlzUm93U2VsZWN0ZWQocm93KVxuICAgICAqICAgICAgLSBoZWxwZXIgZnVuY3Rpb24gdG8gZGV0ZXJtaW5lIGlmIGEgcm93IGlzIHNlbGVjdGVkXG4gICAgICogLSBiY1NlcnZlclRhYmxlLmdldFNlbGVjdGVkUm93cygpXG4gICAgICogICAgICAtIGZ1bmN0aW9uIHRoYXQgcmV0dXJucyBhbiBhcnJheSBvZiByb3cgb2JqZWN0cyB0aGF0IGFyZSBjdXJyZW50bHkgc2VsZWN0ZWRcbiAgICAgKlxuICAgICAqL1xuICAgIC5kaXJlY3RpdmUoJ2JjU2VydmVyVGFibGUnLCBmdW5jdGlvbiBiY1NlcnZlclRhYmxlRGlyZWN0aXZlKCRwYXJzZSkge1xuICAgICAgICB2YXIgZGlyZWN0aXZlID0ge1xuICAgICAgICAgICAgcmVzdHJpY3Q6ICdFQScsXG4gICAgICAgICAgICBjb250cm9sbGVyOiAnQmNTZXJ2ZXJUYWJsZUN0cmwgYXMgYmNTZXJ2ZXJUYWJsZScsXG4gICAgICAgICAgICBsaW5rOiBmdW5jdGlvbiBiY1NlcnZlclRhYmxlTGluaygkc2NvcGUsIGVsZW1lbnQsIGF0dHJzLCBiY1NlcnZlclRhYmxlQ3RybCkge1xuICAgICAgICAgICAgICAgIGlmIChhdHRycy50YWJsZUNvbnRyb2xsZXIpIHtcbiAgICAgICAgICAgICAgICAgICAgLy8gZXhwb3NlIGJjU2VydmVyVGFibGVDdHJsIHRvIHRhYmxlQ29udHJvbGxlciBpZiBpdCBleGlzdHNcbiAgICAgICAgICAgICAgICAgICAgJHBhcnNlKGF0dHJzLnRhYmxlQ29udHJvbGxlcikuYXNzaWduKCRzY29wZSwgYmNTZXJ2ZXJUYWJsZUN0cmwpO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgfTtcblxuICAgICAgICByZXR1cm4gZGlyZWN0aXZlO1xuICAgIH0pO1xuIiwiYW5ndWxhci5tb2R1bGUoJ2JjYXBwLXBhdHRlcm4tbGFiLmJjLXNlcnZlci10YWJsZScsIFtcbiAgICAnYmNhcHAtcGF0dGVybi1sYWIuYmMtc2VydmVyLXRhYmxlLmRpcmVjdGl2ZScsXG4gICAgJ2JjYXBwLXBhdHRlcm4tbGFiLmJjLXNlcnZlci10YWJsZS5zb3J0LWJ5LmRpcmVjdGl2ZScsXG4gICAgJ2JjYXBwLXBhdHRlcm4tbGFiLmJjLXNlcnZlci10YWJsZS1mYWN0b3J5LnNlcnZpY2UnXG5dKTtcbiIsImFuZ3VsYXIubW9kdWxlKCdiY2FwcC1wYXR0ZXJuLWxhYi5iYy1zZXJ2ZXItdGFibGUuc29ydC1ieS5kaXJlY3RpdmUnLCBbXG4gICAgJ2JjYXBwLXBhdHRlcm4tbGFiLmJjLXNlcnZlci10YWJsZS1mYWN0b3J5LnNlcnZpY2UnXG5dKVxuICAgIC5kaXJlY3RpdmUoJ2JjU29ydEJ5JywgZnVuY3Rpb24gYmNTb3J0QnlEaXJlY3RpdmUoJGxvZywgYmNTZXJ2ZXJUYWJsZUZhY3RvcnkpIHtcbiAgICAgICAgdmFyIGRpcmVjdGl2ZSA9IHtcbiAgICAgICAgICAgIHRlbXBsYXRlVXJsOiAnc3JjL2pzL2JpZ2NvbW1lcmNlL2JjLXNlcnZlci10YWJsZS9iYy1zb3J0LWJ5LnRwbC5odG1sJyxcbiAgICAgICAgICAgIHJlc3RyaWN0OiAnRScsXG4gICAgICAgICAgICB0cmFuc2NsdWRlOiB0cnVlLFxuICAgICAgICAgICAgc2NvcGU6IHtcbiAgICAgICAgICAgICAgICBzb3J0VmFsdWU6ICdAJyxcbiAgICAgICAgICAgICAgICBjb2x1bW5OYW1lOiAnQCcsXG4gICAgICAgICAgICAgICAgdGFibGVJZDogJ0AnXG4gICAgICAgICAgICB9LFxuICAgICAgICAgICAgcmVxdWlyZTogJz9eXmJjU2VydmVyVGFibGUnLFxuICAgICAgICAgICAgbGluazogYmNTb3J0QnlEaXJlY3RpdmVMaW5rXG4gICAgICAgIH07XG5cbiAgICAgICAgZnVuY3Rpb24gYmNTb3J0QnlEaXJlY3RpdmVMaW5rKHNjb3BlLCBlbGVtZW50LCBhdHRycywgYmNTZXJ2ZXJUYWJsZUN0cmwpIHtcbiAgICAgICAgICAgIHZhciBiY1NlcnZlclRhYmxlLFxuICAgICAgICAgICAgICAgIHNvcnREaXJWYWx1ZXM7XG5cbiAgICAgICAgICAgIGlmIChzY29wZS50YWJsZUlkKSB7XG4gICAgICAgICAgICAgICAgYmNTZXJ2ZXJUYWJsZSA9IGJjU2VydmVyVGFibGVGYWN0b3J5LmdldChzY29wZS50YWJsZUlkKTtcbiAgICAgICAgICAgIH0gZWxzZSBpZiAoYmNTZXJ2ZXJUYWJsZUN0cmwpIHtcbiAgICAgICAgICAgICAgICBiY1NlcnZlclRhYmxlID0gYmNTZXJ2ZXJUYWJsZUN0cmw7XG4gICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICAgICRsb2cuZXJyb3IoJ2JjLXNvcnQtYnkgZGlyZWN0aXZlIHJlcXVpcmVzIGEgdGFibGUtaWQsIG9yIGEgcGFyZW50IGJjU2VydmVyVGFibGVDdHJsIGRpcmVjdGl2ZS4nKTtcbiAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgc29ydERpclZhbHVlcyA9IGJjU2VydmVyVGFibGUudGFibGVDb25maWcuc29ydERpclZhbHVlcztcblxuICAgICAgICAgICAgc2NvcGUuYXNjID0gc29ydERpclZhbHVlcy5hc2M7XG4gICAgICAgICAgICBzY29wZS5kZXNjID0gc29ydERpclZhbHVlcy5kZXNjO1xuICAgICAgICAgICAgc2NvcGUuc29ydEJ5ID0gYmNTZXJ2ZXJUYWJsZS5zb3J0Qnk7XG4gICAgICAgICAgICBzY29wZS5zb3J0RGlyID0gYmNTZXJ2ZXJUYWJsZS5zb3J0RGlyO1xuICAgICAgICAgICAgc2NvcGUuc29ydCA9IHNvcnQ7XG5cbiAgICAgICAgICAgIGZ1bmN0aW9uIHNvcnQoJGV2ZW50KSB7XG4gICAgICAgICAgICAgICAgdmFyIHNvcnRCeSxcbiAgICAgICAgICAgICAgICAgICAgc29ydERpcjtcblxuICAgICAgICAgICAgICAgIGlmICgkZXZlbnQpIHtcbiAgICAgICAgICAgICAgICAgICAgJGV2ZW50LnByZXZlbnREZWZhdWx0KCk7XG4gICAgICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAgICAgaWYgKGJjU2VydmVyVGFibGUuc29ydEJ5ID09PSBzY29wZS5zb3J0VmFsdWUpIHtcbiAgICAgICAgICAgICAgICAgICAgc29ydEJ5ID0gYmNTZXJ2ZXJUYWJsZS5zb3J0Qnk7XG4gICAgICAgICAgICAgICAgICAgIHNvcnREaXIgPSBiY1NlcnZlclRhYmxlLnNvcnREaXIgPT09IHNjb3BlLmFzYyA/IHNjb3BlLmRlc2MgOiBzY29wZS5hc2M7XG4gICAgICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgICAgICAgc29ydEJ5ID0gc2NvcGUuc29ydFZhbHVlO1xuICAgICAgICAgICAgICAgICAgICBzb3J0RGlyID0gc2NvcGUuYXNjO1xuICAgICAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgICAgIGJjU2VydmVyVGFibGUudXBkYXRlU29ydChzb3J0QnksIHNvcnREaXIpO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG5cbiAgICAgICAgcmV0dXJuIGRpcmVjdGl2ZTtcbiAgICB9KTtcbiIsImFuZ3VsYXIubW9kdWxlKCdiY2FwcC1wYXR0ZXJuLWxhYi5jaGVja2JveC1saXN0LmNvbnRyb2xsZXInLCBbXSlcbiAgICAuY29udHJvbGxlcignQ2hlY2tib3hMaXN0Q3RybCcsIGZ1bmN0aW9uIENoZWNrYm94TGlzdEN0cmwoJGF0dHJzLCAkZWxlbWVudCwgJGxvZywgJHBhcnNlLCAkc2NvcGUpIHtcbiAgICAgICAgdmFyIGN0cmwgPSB0aGlzLFxuICAgICAgICAgICAgZmFsc2VWYWx1ZSA9ICRwYXJzZSgkYXR0cnMubmdGYWxzZVZhbHVlKShjdHJsKSB8fCBmYWxzZSxcbiAgICAgICAgICAgIHRydWVWYWx1ZSA9ICRwYXJzZSgkYXR0cnMubmdUcnVlVmFsdWUpKGN0cmwpIHx8IHRydWUsXG4gICAgICAgICAgICBuZ01vZGVsID0gJGVsZW1lbnQuY29udHJvbGxlcignbmdNb2RlbCcpO1xuXG4gICAgICAgIGluaXQoKTtcblxuICAgICAgICAvLyBHZXR0ZXJzXG4gICAgICAgIGZ1bmN0aW9uIGdldE1vZGVsVmFsdWUoKSB7XG4gICAgICAgICAgICByZXR1cm4gbmdNb2RlbC4kbW9kZWxWYWx1ZTtcbiAgICAgICAgfVxuXG4gICAgICAgIGZ1bmN0aW9uIGdldFZhbHVlKCkge1xuICAgICAgICAgICAgcmV0dXJuIGN0cmwudmFsdWUgfHwgY3RybC5uZ1ZhbHVlO1xuICAgICAgICB9XG5cbiAgICAgICAgZnVuY3Rpb24gZ2V0U2VsZWN0ZWRWYWx1ZXMoKSB7XG4gICAgICAgICAgICByZXR1cm4gY3RybC5zZWxlY3RlZFZhbHVlcztcbiAgICAgICAgfVxuXG4gICAgICAgIC8vIFNldHRlcnNcbiAgICAgICAgZnVuY3Rpb24gdXBkYXRlTW9kZWxWYWx1ZShtb2RlbFZhbHVlKSB7XG4gICAgICAgICAgICBuZ01vZGVsLiRzZXRWaWV3VmFsdWUobW9kZWxWYWx1ZSk7XG4gICAgICAgICAgICBuZ01vZGVsLiRjb21taXRWaWV3VmFsdWUoKTtcbiAgICAgICAgICAgIG5nTW9kZWwuJHJlbmRlcigpO1xuICAgICAgICB9XG5cbiAgICAgICAgZnVuY3Rpb24gdXBkYXRlU2VsZWN0ZWRWYWx1ZXMobW9kZWxWYWx1ZSkge1xuICAgICAgICAgICAgaWYgKG1vZGVsVmFsdWUgPT09IHRydWVWYWx1ZSkge1xuICAgICAgICAgICAgICAgIGFkZFRvU2VsZWN0ZWRWYWx1ZXMoKTtcbiAgICAgICAgICAgIH0gZWxzZSBpZiAobW9kZWxWYWx1ZSA9PT0gZmFsc2VWYWx1ZSkge1xuICAgICAgICAgICAgICAgIHJlbW92ZUZyb21TZWxlY3RlZFZhbHVlcygpO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG5cbiAgICAgICAgZnVuY3Rpb24gYWRkVG9TZWxlY3RlZFZhbHVlcygpIHtcbiAgICAgICAgICAgIHZhciBpc0luY2x1ZGVkID0gXy5pbmNsdWRlKGN0cmwuc2VsZWN0ZWRWYWx1ZXMsIGdldFZhbHVlKCkpO1xuXG4gICAgICAgICAgICBpZiAoIWlzSW5jbHVkZWQpIHtcbiAgICAgICAgICAgICAgICBjdHJsLnNlbGVjdGVkVmFsdWVzLnB1c2goZ2V0VmFsdWUoKSk7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cblxuICAgICAgICBmdW5jdGlvbiByZW1vdmVGcm9tU2VsZWN0ZWRWYWx1ZXMoKSB7XG4gICAgICAgICAgICB2YXIgaW5kZXggPSBfLmluZGV4T2YoY3RybC5zZWxlY3RlZFZhbHVlcywgZ2V0VmFsdWUoKSk7XG5cbiAgICAgICAgICAgIGlmIChpbmRleCAhPT0gLTEpIHtcbiAgICAgICAgICAgICAgICBjdHJsLnNlbGVjdGVkVmFsdWVzLnNwbGljZShpbmRleCwgMSk7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cblxuICAgICAgICAvLyBXYXRjaGVyc1xuICAgICAgICBmdW5jdGlvbiBtb2RlbFZhbHVlV2F0Y2gobW9kZWxWYWx1ZSwgb2xkTW9kZWxWYWx1ZSkge1xuICAgICAgICAgICAgdmFyIG9sZFNlbGVjdGVkVmFsdWVzLFxuICAgICAgICAgICAgICAgIHNlbGVjdGVkVmFsdWVzQ2hhbmdlZDtcblxuICAgICAgICAgICAgLy8gV2hlbiBuZ01vZGVsIHZhbHVlIGNoYW5nZXNcbiAgICAgICAgICAgIGlmIChfLmlzVW5kZWZpbmVkKG1vZGVsVmFsdWUpIHx8IG1vZGVsVmFsdWUgPT09IG9sZE1vZGVsVmFsdWUpIHtcbiAgICAgICAgICAgICAgICByZXR1cm47XG4gICAgICAgICAgICB9XG5cbiAgICAgICAgICAgIC8vIFJldGFpbiBhIHNoYWxsb3cgY29weSBvZiBzZWxlY3RlZFZhbHVlcyBiZWZvcmUgdXBkYXRlXG4gICAgICAgICAgICBvbGRTZWxlY3RlZFZhbHVlcyA9IGN0cmwuc2VsZWN0ZWRWYWx1ZXMuc2xpY2UoKTtcblxuICAgICAgICAgICAgLy8gVXBkYXRlIHNlbGVjdGVkVmFsdWVzXG4gICAgICAgICAgICB1cGRhdGVTZWxlY3RlZFZhbHVlcyhtb2RlbFZhbHVlKTtcblxuICAgICAgICAgICAgLy8gRGV0ZXJtaW5lIGlmIHNlbGVjdGVkVmFsdWVzIGFycmF5IGhhcyBjaGFuZ2VkXG4gICAgICAgICAgICBzZWxlY3RlZFZhbHVlc0NoYW5nZWQgPSAhIV8ueG9yKGN0cmwuc2VsZWN0ZWRWYWx1ZXMsIG9sZFNlbGVjdGVkVmFsdWVzKS5sZW5ndGg7XG5cbiAgICAgICAgICAgIC8vIElmIGNoYW5nZWQsIGV2b2tlIGRlbGVnYXRlIG1ldGhvZCAoaWYgZGVmaW5lZClcbiAgICAgICAgICAgIGlmIChjdHJsLm9uQ2hhbmdlICYmIHNlbGVjdGVkVmFsdWVzQ2hhbmdlZCkge1xuICAgICAgICAgICAgICAgIGN0cmwub25DaGFuZ2Uoe1xuICAgICAgICAgICAgICAgICAgICBzZWxlY3RlZFZhbHVlczogY3RybC5zZWxlY3RlZFZhbHVlcyxcbiAgICAgICAgICAgICAgICAgICAgb2xkU2VsZWN0ZWRWYWx1ZXM6IG9sZFNlbGVjdGVkVmFsdWVzXG4gICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cblxuICAgICAgICBmdW5jdGlvbiBzZWxlY3RlZFZhbHVlc1dhdGNoKHNlbGVjdGVkVmFsdWVzKSB7XG4gICAgICAgICAgICAvLyBXaGVuIHNlbGVjdGVkVmFsdWVzIGNvbGxlY3Rpb24gY2hhbmdlc1xuICAgICAgICAgICAgdmFyIGlzSW5jbHVkZWQgPSBfLmluY2x1ZGUoc2VsZWN0ZWRWYWx1ZXMsIGdldFZhbHVlKCkpLFxuICAgICAgICAgICAgICAgIG1vZGVsVmFsdWUgPSBnZXRNb2RlbFZhbHVlKCk7XG5cbiAgICAgICAgICAgIGlmIChpc0luY2x1ZGVkICYmIG1vZGVsVmFsdWUgIT09IHRydWVWYWx1ZSkge1xuICAgICAgICAgICAgICAgIHVwZGF0ZU1vZGVsVmFsdWUodHJ1ZVZhbHVlKTtcbiAgICAgICAgICAgIH0gZWxzZSBpZiAoIWlzSW5jbHVkZWQgJiYgbW9kZWxWYWx1ZSAhPT0gZmFsc2VWYWx1ZSkge1xuICAgICAgICAgICAgICAgIHVwZGF0ZU1vZGVsVmFsdWUoZmFsc2VWYWx1ZSk7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cblxuICAgICAgICAvLyBJbml0aWFsaXplclxuICAgICAgICBmdW5jdGlvbiBpbml0KCkge1xuICAgICAgICAgICAgaWYgKCRhdHRycy50eXBlICE9PSAnY2hlY2tib3gnKSB7XG4gICAgICAgICAgICAgICAgJGxvZy5lcnJvcignY2hlY2tib3gtbGlzdCBkaXJlY3RpdmU6IGVsZW1lbnQgbXVzdCBiZSA8aW5wdXQgdHlwZT1cImNoZWNrYm94XCI+Jyk7XG5cbiAgICAgICAgICAgICAgICByZXR1cm47XG4gICAgICAgICAgICB9XG5cbiAgICAgICAgICAgICRzY29wZS4kd2F0Y2goZ2V0TW9kZWxWYWx1ZSwgbW9kZWxWYWx1ZVdhdGNoKTtcbiAgICAgICAgICAgICRzY29wZS4kd2F0Y2hDb2xsZWN0aW9uKGdldFNlbGVjdGVkVmFsdWVzLCBzZWxlY3RlZFZhbHVlc1dhdGNoKTtcbiAgICAgICAgfVxuICAgIH0pO1xuIiwiYW5ndWxhci5tb2R1bGUoJ2JjYXBwLXBhdHRlcm4tbGFiLmNoZWNrYm94LWxpc3QuZGlyZWN0aXZlJywgW1xuICAgICdiY2FwcC1wYXR0ZXJuLWxhYi5jaGVja2JveC1saXN0LmNvbnRyb2xsZXInXG5dKVxuXG4gICAgLyoqXG4gICAgICogQSBkaXJlY3RpdmUgZm9yIGNvbGxhdGluZyB2YWx1ZXMgZnJvbSBhbiBhcnJheSBvZiBjaGVja2JveGVzLlxuICAgICAqXG4gICAgICogQHJlcXVpcmUgbmdNb2RlbFxuICAgICAqIEBwYXJhbSB7QXJyYXkuPHN0cmluZ3xudW1iZXJ8T2JqZWN0Pn0gY2hlY2tib3hMaXN0IC0gQXJyYXkgdG8gaG9sZCBzZWxlY3RlZCB2YWx1ZXNcbiAgICAgKiBAcGFyYW0geyp9IHZhbHVlIC0gVmFsdWUgdG8gYWRkIHRvIGNoZWNrYm94TGlzdFxuICAgICAqIEBwYXJhbSB7ZnVuY3Rpb24oc2VsZWN0ZWRWYWx1ZXMsIG9sZFNlbGVjdGVkVmFsdWVzfSBbY2hlY2tib3hMaXN0Q2hhbmdlXSAtIE9wdGlvbmFsIG9uQ2hhbmdlIGNhbGxiYWNrXG4gICAgICpcbiAgICAgKiBAZXhhbXBsZTpcbiAgICAgKiBgYGBodG1sXG4gICAgICogPGRpdiBuZy1yZXBlYXQ9XCJvcHRpb24gaW4gb3B0aW9uc1wiPlxuICAgICAqICAgICA8aW5wdXQgdHlwZT1cImNoZWNrYm94XCIgXG4gICAgICogICAgICAgICBuYW1lPVwib3B0aW9ue3sgb3B0aW9uLmlkIH19XCJcbiAgICAgKiAgICAgICAgIHZhbHVlPVwib3B0aW9uLmlkXCIgXG4gICAgICogICAgICAgICBjaGVja2JveC1saXN0PVwic2VsZWN0ZWRWYWx1ZXNcIiBcbiAgICAgKiAgICAgICAgIGNoZWNrYm94LWxpc3QtY2hhbmdlPVwib25DaGFuZ2Uoc2VsZWN0ZWRWYWx1ZXMpXCIgXG4gICAgICogICAgICAgICBuZy1tb2RlbD1cIm9wdGlvbi5jaGVja2VkXCJcbiAgICAgKiAgICAgLz5cbiAgICAgKiA8L2Rpdj5cbiAgICAgKiBgYGBcbiAgICAgKiBcbiAgICAgKiBgYGBqc1xuICAgICAqIHNjb3BlLnNlbGVjdGVkVmFsdWVzID0gW107XG4gICAgICogc2NvcGUub3B0aW9ucyA9IFtcbiAgICAgKiAgICAge1xuICAgICAqICAgICAgICAgaWQ6IDEsXG4gICAgICogICAgICAgICBsYWJlbDogJ09wdGlvbiAxJ1xuICAgICAqICAgICB9LFxuICAgICAqICAgICB7XG4gICAgICogICAgICAgICBpZDogMixcbiAgICAgKiAgICAgICAgIGxhYmVsOiAnT3B0aW9uIDInXG4gICAgICogICAgIH0sXG4gICAgICogICAgIHtcbiAgICAgKiAgICAgICAgIGlkOiAzLFxuICAgICAqICAgICAgICAgbGFiZWw6ICdPcHRpb24gMydcbiAgICAgKiAgICAgfVxuICAgICAqIF07XG4gICAgICogXG4gICAgICogc2NvcGUub25DaGFuZ2UgPSBmdW5jdGlvbiBvbkNoYW5nZShzZWxlY3RlZFZhbHVlcykge1xuICAgICAqICAgICBjb25zb2xlLmxvZyhzZWxlY3RlZFZhbHVlcyk7XG4gICAgICogfTtcbiAgICAgKiBgYGBcbiAgICAgKiBcbiAgICAgKiBXaGVuIG9wdGlvbnNbMF0gYW5kIG9wdGlvbnNbMV0gYXJlIGNoZWNrZWQsIHNlbGVjdGVkVmFsdWVzIHNob3VsZCBiZSBbMSwgMl1cbiAgICAgKiBhbmQgb25DaGFuZ2Ugd2lsbCBiZSBldm9rZWQuIFRoaXMgZGlyZWN0aXZlIGFsc28gd29ya3Mgd2l0aCBhbiBhcnJheSBvZiBwcmltaXRpdmUgdmFsdWVzLlxuICAgICAqIGkuZS46IHNjb3BlLm9wdGlvbnMgPSBbXCJhXCIsIFwiYlwiLCBcImNcIl0uXG4gICAgICovXG5cbiAgICAuZGlyZWN0aXZlKCdjaGVja2JveExpc3QnLCBmdW5jdGlvbiBjaGVja2JveExpc3REaXJlY3RpdmUoKSB7XG4gICAgICAgIHJldHVybiB7XG4gICAgICAgICAgICByZXN0cmljdDogJ0EnLFxuICAgICAgICAgICAgcmVxdWlyZTogJ25nTW9kZWwnLFxuICAgICAgICAgICAgY29udHJvbGxlcjogJ0NoZWNrYm94TGlzdEN0cmwnLFxuICAgICAgICAgICAgY29udHJvbGxlckFzOiAnY2hlY2tib3hMaXN0Q3RybCcsXG4gICAgICAgICAgICBiaW5kVG9Db250cm9sbGVyOiB0cnVlLFxuICAgICAgICAgICAgc2NvcGU6IHtcbiAgICAgICAgICAgICAgICBvbkNoYW5nZTogJyZjaGVja2JveExpc3RDaGFuZ2UnLFxuICAgICAgICAgICAgICAgIHNlbGVjdGVkVmFsdWVzOiAnPWNoZWNrYm94TGlzdCcsXG4gICAgICAgICAgICAgICAgdmFsdWU6ICc9JyxcbiAgICAgICAgICAgICAgICBuZ1ZhbHVlOiAnPSdcbiAgICAgICAgICAgIH1cbiAgICAgICAgfTtcbiAgICB9KTtcbiIsImFuZ3VsYXIubW9kdWxlKCdiY2FwcC1wYXR0ZXJuLWxhYi5jaGVja2JveC1saXN0JywgW1xuICAgICdiY2FwcC1wYXR0ZXJuLWxhYi5jaGVja2JveC1saXN0LmRpcmVjdGl2ZSdcbl0pO1xuIiwiLyoqXG4gKiBAbmFtZSBjcmVkaXQtY2FyZCBkaXJlY3RpdmVcbiAqIEBkZXNjcmlwdGlvbiBDb21wb25lbnQgY29udGFpbmluZyBjYyBudW1iZXIsIGN2YywgbmFtZSwgYW5kIGV4cGlyeS4gSGFzIGFuIGlzb2xhdGVkIHNjb3BlIHdpdGggbm8gY29udHJvbGxlci5cbiAqIEByZXF1aXJlIGZvcm1cbiAqXG4gKiBAcGFyYW0gY2NEYXRhIHtvYmplY3R9IENvbnRhaW5zIGNjTnVtYmVyLCBjY1R5cGUsIGNjRXhwaXJ5LCBhbmQgY2NOYW1lXG4gKiBAcGFyYW0gY2NDb25maWcge29iamVjdH0gVGhlIGNvbmZpZ3VyYXRpb24gb2JqZWN0LiBDdXJyZW50bHkgc3VwcG9ydGluZyBgY2FyZENvZGVgIGFuZCBgZnVsbE5hbWVgLCBib3RoIGJvb2xlYW4gdG8gaW5kaWNhdGVcbiAqIHdoZXRoZXIgdGhlIHJlc3BlY3RpdmUgZmllbGRzIHNob3VsZCBiZSBzaG93bi4gQW5vdGhlciBmaWVsZCBgY2FyZENvZGVSZXF1aXJlZGAgZGV0ZXJtaW5lcyB3aGV0aGVyIHRoZSBjdmMgZmllbGQgaXMgcmVxdWlyZWQuXG4gKiBUaGlzIG9ubHkgbWF0dGVycyB3aGVuIGNhcmRDb2RlIGlzIHNldCB0byB0cnVlLlxuICovXG5hbmd1bGFyLm1vZHVsZSgnYmNhcHAtcGF0dGVybi1sYWIuY3JlZGl0LWNhcmQuZGlyZWN0aXZlJywgW1xuICAgICdiY2FwcC1wYXR0ZXJuLWxhYi5pY29uJ1xuXSlcbiAgICAuZGlyZWN0aXZlKCdjcmVkaXRDYXJkJywgZnVuY3Rpb24gY3JlZGl0Q2FyZERpcmVjdGl2ZSgkY29tcGlsZSwgJHRlbXBsYXRlQ2FjaGUpIHtcbiAgICAgICAgY29uc3QgY3Z2VG9vbHRpcFRlbXBsYXRlID0gJHRlbXBsYXRlQ2FjaGUuZ2V0KCdzcmMvanMvYmlnY29tbWVyY2UvY3JlZGl0LWNhcmQvY3JlZGl0LWNhcmQtY3Z2L3Rvb2x0aXAudHBsLmh0bWwnKTtcblxuICAgICAgICByZXR1cm4ge1xuICAgICAgICAgICAgbGluazogZnVuY3Rpb24gY3JlZGl0Q2FyZExpbmsoc2NvcGUsIGVsZW0sIGF0dHIsIGZvcm1DdHJsKSB7XG4gICAgICAgICAgICAgICAgY29uc3QgY3Z2VG9vbHRpcEVsZW1lbnQgPSAkY29tcGlsZShjdnZUb29sdGlwVGVtcGxhdGUpKHNjb3BlKTtcbiAgICAgICAgICAgICAgICBjb25zdCBkZWZhdWx0Q29uZmlnID0ge1xuICAgICAgICAgICAgICAgICAgICBjYXJkQ29kZTogdHJ1ZSxcbiAgICAgICAgICAgICAgICAgICAgY2FyZENvZGVSZXF1aXJlZDogdHJ1ZSxcbiAgICAgICAgICAgICAgICAgICAgZnVsbE5hbWU6IHRydWUsXG4gICAgICAgICAgICAgICAgfTtcblxuICAgICAgICAgICAgICAgIHNjb3BlLmNjQ29uZmlnID0gXy5kZWZhdWx0cyhzY29wZS5jY0NvbmZpZywgZGVmYXVsdENvbmZpZyk7XG4gICAgICAgICAgICAgICAgc2NvcGUuZ2V0Q3Z2VG9vbHRpcEh0bWwgPSBnZXRDdnZUb29sdGlwSHRtbDtcblxuICAgICAgICAgICAgICAgIC8qKlxuICAgICAgICAgICAgICAgICAqIFJldHVybiB0aGUgaHRtbCBmb3IgdGhlIHRvb2x0aXAuIFVzaW5nIG91dGVySFRNTCB0byBhbHNvIGluY2x1ZGUgdGhlIHJvb3QgZWxlbWVudFxuICAgICAgICAgICAgICAgICAqIEByZXR1cm4ge1N0cmluZ30gSHRtbCBzdHJpbmcgZm9yIHRoZSBjdnYgdG9vbHRpcCB0ZW1wbGF0ZVxuICAgICAgICAgICAgICAgICAqL1xuICAgICAgICAgICAgICAgIGZ1bmN0aW9uIGdldEN2dlRvb2x0aXBIdG1sKCkge1xuICAgICAgICAgICAgICAgICAgICByZXR1cm4gY3Z2VG9vbHRpcEVsZW1lbnRbMF0ub3V0ZXJIVE1MO1xuICAgICAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgICAgIC8qKlxuICAgICAgICAgICAgICAgICAqIFRoZSBjcmVkaXQgY2FyZCB0eXBlIGlzIGRlZHVjZWQgYnkgdGhlIGBjY051bWJlcmAgZGlyZWN0aXZlLiBUaGlzIGlzIGluIHR1cm4gZXhwb3NlZFxuICAgICAgICAgICAgICAgICAqIGFzIGAkY2NFYWdlclR5cGVgIG9uIHRoZSBpbnB1dCBjb250cm9sIGVsZW1lbnQuIFdhdGNoIGZvciBjaGFuZ2VzIGFuZCBiaW5kIHRoZSB0eXBlIHRvIHRoZSBjb3JyZXNwb25kaW5nXG4gICAgICAgICAgICAgICAgICogdmFsdWUgb24gY2NEYXRhLlxuICAgICAgICAgICAgICAgICAqL1xuICAgICAgICAgICAgICAgIHNjb3BlLiR3YXRjaChnZXRDY1R5cGUsIHNldENjVHlwZSk7XG5cbiAgICAgICAgICAgICAgICBzY29wZS5mb3JtQ3RybCA9IGZvcm1DdHJsO1xuXG4gICAgICAgICAgICAgICAgZnVuY3Rpb24gZ2V0Q2NUeXBlKCkge1xuICAgICAgICAgICAgICAgICAgICByZXR1cm4gZm9ybUN0cmwuY2NOdW1iZXIuJGNjRWFnZXJUeXBlO1xuICAgICAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgICAgIGZ1bmN0aW9uIHNldENjVHlwZSh0eXBlKSB7XG4gICAgICAgICAgICAgICAgICAgIHNjb3BlLmNjRGF0YS5jY1R5cGUgPSB0eXBlO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICByZXF1aXJlOiAnXmZvcm0nLFxuICAgICAgICAgICAgcmVzdHJpY3Q6ICdFQScsXG4gICAgICAgICAgICBzY29wZToge1xuICAgICAgICAgICAgICAgIGNjRGF0YTogJz0nLFxuICAgICAgICAgICAgICAgIGNjQ29uZmlnOiAnPScsXG4gICAgICAgICAgICB9LFxuICAgICAgICAgICAgdGVtcGxhdGVVcmw6ICdzcmMvanMvYmlnY29tbWVyY2UvY3JlZGl0LWNhcmQvY3JlZGl0LWNhcmQudHBsLmh0bWwnXG4gICAgICAgIH07XG4gICAgfSk7XG4iLCJhbmd1bGFyLm1vZHVsZSgnYmNhcHAtcGF0dGVybi1sYWIuY3JlZGl0LWNhcmQnLCBbXG4gICAgJ2NyZWRpdC1jYXJkcycsXG4gICAgJ2JjYXBwLXBhdHRlcm4tbGFiLmNyZWRpdC1jYXJkLmJjLWN2YycsXG4gICAgJ2JjYXBwLXBhdHRlcm4tbGFiLmNyZWRpdC1jYXJkLmNjLWV4cGlyeScsXG4gICAgJ2JjYXBwLXBhdHRlcm4tbGFiLmNyZWRpdC1jYXJkLmRpcmVjdGl2ZScsXG4gICAgJ2dldHRleHQnLFxuXSk7XG4iLCJhbmd1bGFyLm1vZHVsZSgnYmNhcHAtcGF0dGVybi1sYWIuY3JlZGl0LWNhcmQtdHlwZXMuY29uc3RhbnQnLCBbXSlcbiAgICAuY29uc3RhbnQoJ0NDX1RZUEVTJywge1xuICAgICAgICAnQW1lcmljYW4gRXhwcmVzcyc6ICdhbWV4JyxcbiAgICAgICAgJ0RpbmVycyBDbHViJzogJ2RpbmVyc2NsdWInLFxuICAgICAgICAnRGlzY292ZXInOiAnZGlzY292ZXInLFxuICAgICAgICAnTWFzdGVyQ2FyZCc6ICdtYXN0ZXJjYXJkJyxcbiAgICAgICAgJ1Zpc2EnOiAndmlzYScsXG4gICAgfSk7XG4iLCJhbmd1bGFyLm1vZHVsZSgnYmNhcHAtcGF0dGVybi1sYWIuY3JlZGl0LWNhcmQtdHlwZXMuY29udHJvbGxlcicsIFtcbiAgICAnYmNhcHAtcGF0dGVybi1sYWIuY3JlZGl0LWNhcmQtdHlwZXMuY29uc3RhbnQnLFxuXSlcbiAgICAuY29udHJvbGxlcignQ3JlZGl0Q2FyZFR5cGVzQ3RybCcsIGZ1bmN0aW9uIENyZWRpdENhcmRUeXBlc0N0cmwoJGVsZW1lbnQsIENDX1RZUEVTKSB7XG4gICAgICAgIGNvbnN0IGN0cmwgPSB0aGlzO1xuXG4gICAgICAgIGN0cmwuaGFzU2VsZWN0ZWRUeXBlID0gaGFzU2VsZWN0ZWRUeXBlO1xuICAgICAgICBjdHJsLmlzU2VsZWN0ZWRUeXBlID0gaXNTZWxlY3RlZFR5cGU7XG4gICAgICAgIGN0cmwubWFwVG9TdmcgPSBtYXBUb1N2ZztcblxuICAgICAgICBpbml0KCk7XG5cbiAgICAgICAgZnVuY3Rpb24gaW5pdCgpIHtcbiAgICAgICAgICAgICRlbGVtZW50LmFkZENsYXNzKCdjcmVkaXRDYXJkVHlwZXMnKTtcbiAgICAgICAgfVxuXG4gICAgICAgIC8qKlxuICAgICAgICAgKiBDaGVja3Mgd2hldGhlciBhIHR5cGUgaGFzIGJlZW4gc2VsZWN0ZWQgKG9yIGRldGVjdGVkIGJ5IHRoZSBjcmVkaXQtY2FyZCBjb21wb25lbnQpXG4gICAgICAgICAqIEByZXR1cm4ge0Jvb2xlYW59XG4gICAgICAgICAqL1xuICAgICAgICBmdW5jdGlvbiBoYXNTZWxlY3RlZFR5cGUoKSB7XG4gICAgICAgICAgICByZXR1cm4gIV8uaXNFbXB0eShjdHJsLmdldFNlbGVjdGVkVHlwZSgpKTtcbiAgICAgICAgfVxuXG4gICAgICAgIC8qKlxuICAgICAgICAgKiBDaGVja3MgaWYgdGhlIHBhc3NlZCBpbiBjY1R5cGUgaXMgdGhlIHNhbWUgYXMgdGhlIHNlbGVjdGVkIGNjVHlwZVxuICAgICAgICAgKiBAcGFyYW0gY2NUeXBlIHtTdHJpbmd9XG4gICAgICAgICAqIEByZXR1cm4ge0Jvb2xlYW59XG4gICAgICAgICAqL1xuICAgICAgICBmdW5jdGlvbiBpc1NlbGVjdGVkVHlwZShjY1R5cGUpIHtcbiAgICAgICAgICAgIHJldHVybiBjY1R5cGUgPT09IGN0cmwuZ2V0U2VsZWN0ZWRUeXBlKCk7XG4gICAgICAgIH1cblxuICAgICAgICAvKipcbiAgICAgICAgICogTWFwIHRoZSBjY1R5cGUgdG8gYSBjb3JyZXNwb25kaW5nIHN2ZyBuYW1lXG4gICAgICAgICAqIEBwYXJhbSBjY1R5cGUge1N0cmluZ31cbiAgICAgICAgICogQHJldHVybiB7U3RyaW5nfVxuICAgICAgICAgKi9cbiAgICAgICAgZnVuY3Rpb24gbWFwVG9TdmcoY2NUeXBlKSB7XG4gICAgICAgICAgICByZXR1cm4gQ0NfVFlQRVNbY2NUeXBlXTtcbiAgICAgICAgfVxuICAgIH0pO1xuIiwiLyoqXG4gKiBAbmFtZSBjcmVkaXQtY2FyZC10eXBlcyBkaXJlY3RpdmVcbiAqIEBkZXNjcmlwdGlvbiBDb21wb25lbnQgZGlzcGxheWluZyBhbmQgZ3JleWluZyBvdXQgY3JlZGl0IGNhcmQgdHlwZSBpY29ucyBiYXNlZCBvbiB0aGUgc2VsZWN0ZWQgY3JlZGl0IGNhcmQgdHlwZS5cbiAqIGAuaXMtYWN0aXZlYCBpcyBhZGRlZCB0byB0aGUgY29ycmVzcG9uZGluZyBzZWxlY3RlZCBjcmVkaXQgY2FyZCB0eXBlLiBgLm5vdC1hY3RpdmVgIGlzIGFkZGVkIGZvciB0aGUgb3RoZXJcbiAqIHR5cGVzLiBJZiBubyBjcmVkaXQgY2FyZCB0eXBlcyBoYXMgYmVlbiBzZWxlY3RlZCwgdGhlbiBuZWl0aGVyIGAuaXMtYWN0aXZlYCBhbmQgYC5ub3QtYWN0aXZlYCB3aWxsIGJlIGFkZGVkIGF0IGFsbC5cbiAqXG4gKiBAcGFyYW0gc2VsZWN0ZWRUeXBlIHtTdHJpbmd9IENyZWRpdCBjYXJkIHR5cGUuIFZhbGlkIHR5cGVzIGFyZSAnVmlzYScsICdNYXN0ZXJDYXJkJywgJ0RpbmVycyBDbHViJywgJ0Rpc2NvdmVyJywgYW5kICdBbWVyaWNhbiBFeHByZXNzJ1xuICogQHBhcmFtIHN1cHBvcnRlZFR5cGVzIHtBcnJheX0gQXJyYXkgb2YgY3JlZGl0IGNhcmQgdHlwZXMgdG8gZGlzcGxheS4gVGhlIGNhcmQgdHlwZXMgdXNlIHRoZSBzYW1lIHN0cmluZ3M6ICdBbWVyaWNhbiBFeHByZXNzJywgJ0Rpc2NvdmVyJywgJ01hc3RlckNhcmQnLCAnVmlzYSdcbiAqL1xuYW5ndWxhci5tb2R1bGUoJ2JjYXBwLXBhdHRlcm4tbGFiLmNyZWRpdC1jYXJkLXR5cGVzLmRpcmVjdGl2ZScsIFtcbiAgICAnYmNhcHAtcGF0dGVybi1sYWIuY3JlZGl0LWNhcmQtdHlwZXMuY29udHJvbGxlcicsXG5dKVxuICAgIC5kaXJlY3RpdmUoJ2NyZWRpdENhcmRUeXBlcycsIGZ1bmN0aW9uIGNyZWRpdENhcmRUeXBlc0RpcmVjdGl2ZSgpIHtcbiAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICAgIGJpbmRUb0NvbnRyb2xsZXI6IHRydWUsXG4gICAgICAgICAgICBjb250cm9sbGVyOiAnQ3JlZGl0Q2FyZFR5cGVzQ3RybCBhcyBjcmVkaXRDYXJkVHlwZXNDdHJsJyxcbiAgICAgICAgICAgIHJlc3RyaWN0OiAnRScsXG4gICAgICAgICAgICBzY29wZToge1xuICAgICAgICAgICAgICAgIGdldFNlbGVjdGVkVHlwZTogJyZzZWxlY3RlZFR5cGUnLFxuICAgICAgICAgICAgICAgIGdldFN1cHBvcnRlZFR5cGVzOiAnJnN1cHBvcnRlZFR5cGVzJ1xuICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIHRlbXBsYXRlVXJsOiAnc3JjL2pzL2JpZ2NvbW1lcmNlL2NyZWRpdC1jYXJkLXR5cGVzL2NyZWRpdC1jYXJkLXR5cGVzLnRwbC5odG1sJ1xuICAgICAgICB9O1xuICAgIH0pO1xuIiwiYW5ndWxhci5tb2R1bGUoJ2JjYXBwLXBhdHRlcm4tbGFiLmNyZWRpdC1jYXJkLXR5cGVzJywgW1xuICAgICdiY2FwcC1wYXR0ZXJuLWxhYi5jcmVkaXQtY2FyZC10eXBlcy5jb25zdGFudCcsXG4gICAgJ2JjYXBwLXBhdHRlcm4tbGFiLmNyZWRpdC1jYXJkLXR5cGVzLmNvbnRyb2xsZXInLFxuICAgICdiY2FwcC1wYXR0ZXJuLWxhYi5jcmVkaXQtY2FyZC10eXBlcy5kaXJlY3RpdmUnLFxuXSk7XG4iLCJhbmd1bGFyLm1vZHVsZSgnYmNhcHAtcGF0dGVybi1sYWIuZm9ybS5kaXJlY3RpdmUnLCBbXSlcbiAgICAuZGlyZWN0aXZlKCdmb3JtJywgZnVuY3Rpb24gZm9ybURpcmVjdGl2ZSgpIHtcbiAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICAgIHJlc3RyaWN0OiAnRScsXG4gICAgICAgICAgICBsaW5rOiBmdW5jdGlvbiBmb3JtTGluayhzY29wZSwgZWxlbWVudCwgYXR0cnMpIHtcbiAgICAgICAgICAgICAgICBlbGVtZW50LmFkZENsYXNzKCdmb3JtJyk7XG4gICAgICAgICAgICAgICAgZWxlbWVudC5hdHRyKCdub3ZhbGlkYXRlJywgJycpO1xuXG4gICAgICAgICAgICAgICAgLy8gVXNlIGRpc2FibGUtYXV0by1mb2N1cz1cInRydWVcIiB0byB0dXJuIG9mZiBhdXRvbWF0aWMgZXJyb3IgZm9jdXNpbmdcbiAgICAgICAgICAgICAgICBpZiAoIWF0dHJzLmRpc2FibGVBdXRvRm9jdXMpIHtcbiAgICAgICAgICAgICAgICAgICAgZWxlbWVudC5vbignc3VibWl0JywgZnVuY3Rpb24gZm9ybUF1dG9Gb2N1c1N1Ym1pdEhhbmRsZXIoKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICB2YXIgaW52YWxpZEZpZWxkID0gZWxlbWVudFswXS5xdWVyeVNlbGVjdG9yKCcubmctaW52YWxpZCcpO1xuXG4gICAgICAgICAgICAgICAgICAgICAgICBpZiAoaW52YWxpZEZpZWxkKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaW52YWxpZEZpZWxkLmZvY3VzKCk7XG5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAvLyBBdXRvLXNlbGVjdCBleGlzdGluZyB0ZXh0IGZvciBmaWVsZHMgdGhhdCBzdXBwb3J0IGl0ICh0ZXh0LCBlbWFpbCwgcGFzc3dvcmQsIGV0Yy4pXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKGludmFsaWRGaWVsZC5zZWxlY3QpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaW52YWxpZEZpZWxkLnNlbGVjdCgpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICB9O1xuICAgIH0pO1xuIiwiYW5ndWxhci5tb2R1bGUoJ2JjYXBwLXBhdHRlcm4tbGFiLmZvcm0nLCBbXG4gICAgJ2JjYXBwLXBhdHRlcm4tbGFiLmZvcm0uZGlyZWN0aXZlJ1xuXSk7XG4iLCJhbmd1bGFyLm1vZHVsZSgnYmNhcHAtcGF0dGVybi1sYWIuZm9ybS1maWVsZC5kaXJlY3RpdmUnLCBbXSlcbiAgICAuZGlyZWN0aXZlKCdmb3JtRmllbGQnLCBmdW5jdGlvbiBmb3JtRmllbGREaXJlY3RpdmUoJGxvZykge1xuICAgICAgICByZXR1cm4ge1xuICAgICAgICAgICAgcmVxdWlyZTogJ15mb3JtJyxcbiAgICAgICAgICAgIHJlc3RyaWN0OiAnRUEnLFxuICAgICAgICAgICAgc2NvcGU6IHRydWUsXG4gICAgICAgICAgICBsaW5rOiB7XG4gICAgICAgICAgICAgICAgcHJlOiBmdW5jdGlvbiBmb3JtRmllbGRMaW5rKHNjb3BlLCBlbGVtZW50LCBhdHRycykge1xuICAgICAgICAgICAgICAgICAgICAvLyBJbmhlcml0ZWQgYnkgdGhlIGZvcm0tZmllbGQtZXJyb3JzIGRpcmVjdGl2ZSB0byBhdm9pZCByZWRlY2xhcmF0aW9uXG4gICAgICAgICAgICAgICAgICAgIHNjb3BlLnByb3BlcnR5ID0gYXR0cnMucHJvcGVydHk7XG4gICAgICAgICAgICAgICAgfSxcblxuICAgICAgICAgICAgICAgIHBvc3Q6IGZ1bmN0aW9uIGZvcm1GaWVsZExpbmsoc2NvcGUsIGVsZW1lbnQsIGF0dHJzLCBmb3JtQ3RybCkge1xuICAgICAgICAgICAgICAgICAgICAvLyBMb2NhdGVzIGFuZCB3YXRjaGVzIHRoZSBtYXRjaGluZyBpbnB1dC9zZWxlY3QvZXRjIChiYXNlZCBvbiBpdHMgbmFtZSBhdHRyaWJ1dGUpIGluIHRoZSBwYXJlbnQgZm9ybVxuICAgICAgICAgICAgICAgICAgICB2YXIgcHJvcGVydHkgPSBhdHRycy5wcm9wZXJ0eSxcbiAgICAgICAgICAgICAgICAgICAgICAgIHByb3BlcnR5VmFsaWRGbiA9IGZ1bmN0aW9uIHByb3BlcnR5VmFsaWRGbigpIHsgcmV0dXJuIGZvcm1DdHJsW3Byb3BlcnR5XS4kdmFsaWQ7IH0sXG4gICAgICAgICAgICAgICAgICAgICAgICBmb3JtU3VibWl0dGVkRm4gPSBmdW5jdGlvbiBmb3JtU3VibWl0dGVkRm4oKSB7IHJldHVybiBmb3JtQ3RybC4kc3VibWl0dGVkOyB9O1xuXG4gICAgICAgICAgICAgICAgICAgIGVsZW1lbnQuYWRkQ2xhc3MoJ2Zvcm0tZmllbGQnKTtcblxuICAgICAgICAgICAgICAgICAgICAvLyBJZiBhIHByb3BlcnR5IHdhc24ndCBwcm92aWRlZCwgd2UgY2FuJ3QgZG8gbXVjaCBlbHNlXG4gICAgICAgICAgICAgICAgICAgIGlmICghcHJvcGVydHkpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAgICAgICAgIC8vIElmIGEgcHJvcGVydHkgd2FzIHByb3ZpZGVkLCBidXQgbm8gbmctbW9kZWwgd2FzIGRlZmluZWQgZm9yIHRoZSBmaWVsZCwgdmFsaWRhdGlvbiB3b24ndCB3b3JrXG4gICAgICAgICAgICAgICAgICAgIGlmICghZm9ybUN0cmxbcHJvcGVydHldKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gJGxvZy5pbmZvKCdGb3JtIGZpZWxkcyBjb250YWluaW5nIGlucHV0cyB3aXRob3V0IGFuIG5nLW1vZGVsIHByb3BlcnR5IHdpbGwgbm90IGJlIHZhbGlkYXRlZCcpO1xuICAgICAgICAgICAgICAgICAgICB9XG5cbiAgICAgICAgICAgICAgICAgICAgaW5pdCgpO1xuXG4gICAgICAgICAgICAgICAgICAgIGZ1bmN0aW9uIGluaXQoKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAvLyBVcGRhdGUgdGhlIGludGVyZmFjZSBpZiB0aGUgZm9ybSBpcyBzdWJtaXR0ZWQgb3IgdGhlIHByb3BlcnR5J3MgdmFsaWRpdHkgc3RhdGUgY2hhbmdlc1xuICAgICAgICAgICAgICAgICAgICAgICAgc2NvcGUuJHdhdGNoKGZvcm1TdWJtaXR0ZWRGbiwgY2hlY2tWYWxpZGl0eSk7XG4gICAgICAgICAgICAgICAgICAgICAgICBzY29wZS4kd2F0Y2gocHJvcGVydHlWYWxpZEZuLCBjaGVja1ZhbGlkaXR5KTtcbiAgICAgICAgICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAgICAgICAgIGZ1bmN0aW9uIGNoZWNrVmFsaWRpdHkoKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAvLyBPbmx5IHNob3cgYW4gZXJyb3IgaWYgdGhlIHVzZXIgaGFzIGFscmVhZHkgYXR0ZW1wdGVkIHRvIHN1Ym1pdCB0aGUgZm9ybVxuICAgICAgICAgICAgICAgICAgICAgICAgZWxlbWVudC50b2dnbGVDbGFzcygnZm9ybS1maWVsZC0tZXJyb3InLCBmb3JtQ3RybC4kc3VibWl0dGVkICYmIGZvcm1DdHJsW3Byb3BlcnR5XS4kaW52YWxpZCk7XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgIH07XG4gICAgfSk7XG4iLCJhbmd1bGFyLm1vZHVsZSgnYmNhcHAtcGF0dGVybi1sYWIuZm9ybS1maWVsZCcsIFtcbiAgICAnYmNhcHAtcGF0dGVybi1sYWIuZm9ybS1maWVsZC5kaXJlY3RpdmUnLFxuICAgICdiY2FwcC1wYXR0ZXJuLWxhYi5mb3JtLWZpZWxkLWVycm9yJyxcbiAgICAnYmNhcHAtcGF0dGVybi1sYWIuZm9ybS1maWVsZC1lcnJvcnMnXG5dKTtcbiIsImFuZ3VsYXIubW9kdWxlKCdiY2FwcC1wYXR0ZXJuLWxhYi5mb3JtLWZpZWxkLWVycm9yLmRpcmVjdGl2ZScsIFtdKVxuICAgIC5kaXJlY3RpdmUoJ2Zvcm1GaWVsZEVycm9yJywgZnVuY3Rpb24gZm9ybUZpZWxkRXJyb3JEaXJlY3RpdmUoJGNvbXBpbGUpIHtcbiAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICAgIHByaW9yaXR5OiAxMCxcbiAgICAgICAgICAgIHJlcGxhY2U6IHRydWUsXG4gICAgICAgICAgICByZXN0cmljdDogJ0VBJyxcbiAgICAgICAgICAgIHRlbXBsYXRlVXJsOiAnc3JjL2pzL2JpZ2NvbW1lcmNlL2Zvcm0tZmllbGQtZXJyb3IvZm9ybS1maWVsZC1lcnJvci50cGwuaHRtbCcsXG4gICAgICAgICAgICB0ZXJtaW5hbDogdHJ1ZSxcbiAgICAgICAgICAgIHRyYW5zY2x1ZGU6IHRydWUsXG4gICAgICAgICAgICBjb21waWxlOiBmdW5jdGlvbiBmb3JtRmllbGRFcnJvckNvbXBpbGUodEVsZW1lbnQsIHRBdHRycykge1xuICAgICAgICAgICAgICAgIC8vIFRoZSB0cmFuc2xhdGUgcHJvcGVydHkgd2lwZXMgb3V0IG91ciBuZy1tZXNzYWdlIGxvZ2ljIGluIHRoZSBwb3N0IGxpbmsgZnVuY3Rpb25cbiAgICAgICAgICAgICAgICAvLyBUaGUgcHJpb3JpdHkgYW5kIHRlcm1pbmFsIHByb3BlcnRpZXMgYWJvdmUgZW5zdXJlIHRoaXMgY2hlY2sgb2NjdXJzXG4gICAgICAgICAgICAgICAgaWYgKHRFbGVtZW50LmF0dHIoJ3RyYW5zbGF0ZScpICE9PSB1bmRlZmluZWQpIHtcbiAgICAgICAgICAgICAgICAgICAgdGhyb3cgbmV3IFN5bnRheEVycm9yKFxuICAgICAgICAgICAgICAgICAgICAgICAgJ1RoZSB0cmFuc2xhdGUgYXR0cmlidXRlIGNhbm5vdCBiZSB1c2VkIHdpdGggdGhlIGZvcm0tZmllbGQtZXJyb3IgZGlyZWN0aXZlLiAnICtcbiAgICAgICAgICAgICAgICAgICAgICAgICdVc2UgdGhlIHRyYW5zbGF0ZSBmaWx0ZXIgaW5zdGVhZCAoZXhhbXBsZToge3sgXCJteSBlcnJvciBtZXNzYWdlXCIgfCB0cmFuc2xhdGUgfX0pLiAnICtcbiAgICAgICAgICAgICAgICAgICAgICAgICdWYWxpZGF0b3I6ICcgKyB0QXR0cnMudmFsaWRhdGVcbiAgICAgICAgICAgICAgICAgICAgKTtcbiAgICAgICAgICAgICAgICB9XG5cbiAgICAgICAgICAgICAgICByZXR1cm4ge1xuICAgICAgICAgICAgICAgICAgICBwb3N0OiBmdW5jdGlvbiBmb3JtRmllbGRFcnJvclBvc3RMaW5rKHNjb3BlLCBlbGVtZW50LCBhdHRycywgY29udHJvbGxlcnMsIHRyYW5zY2x1ZGUpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHNjb3BlLnByb3BlcnR5ID0gc2NvcGUucHJvcGVydHkgfHwgYXR0cnMucHJvcGVydHk7XG5cbiAgICAgICAgICAgICAgICAgICAgICAgIHRyYW5zY2x1ZGUoZnVuY3Rpb24gZm9ybUZpZWxkRXJyb3JUcmFuc2NsdWRlKGVycm9yQ2xvbmUpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YXIgbGFiZWxFbGVtZW50ID0gYW5ndWxhci5lbGVtZW50KCc8bGFiZWw+Jyk7XG5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAvLyBuZ01lc3NhZ2UgZG9lc24ndCBwbGF5IHdlbGwgd2l0aCBkeW5hbWljIG1lc3NhZ2UgaW5zZXJ0aW9uLCB0cmFuc2xhdGlvbiwgb3JcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAvLyBtZXNzYWdlIGV4cHJlc3Npb25zLCBzbyB3ZSBidWlsZCBpdHMgZWxlbWVudCB1cCBoZXJlIGFuZCBpbmplY3QgaXQgaW50byB0aGUgRE9NXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgbGFiZWxFbGVtZW50LmF0dHIoJ2ZvcicsIHNjb3BlLnByb3BlcnR5KTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBsYWJlbEVsZW1lbnQuYXR0cignbmctbWVzc2FnZScsIGF0dHJzLnZhbGlkYXRlKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBsYWJlbEVsZW1lbnQuYXR0cigncm9sZScsICdhbGVydCcpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGxhYmVsRWxlbWVudC5hZGRDbGFzcygnZm9ybS1pbmxpbmVNZXNzYWdlJyk7XG5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAvLyBUaGUgZXJyb3Igc3BhbiBzaG91bGQgYWxyZWFkeSBoYXZlIGEgdHJhbnNsYXRpb24gd2F0Y2hlciBvbiBpdCBieSBub3csIHVzaW5nIGEgZmlsdGVyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgbGFiZWxFbGVtZW50LmFwcGVuZChlcnJvckNsb25lKTtcblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGVsZW1lbnQuYXBwZW5kKGxhYmVsRWxlbWVudCk7XG5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAkY29tcGlsZShlbGVtZW50KShzY29wZSk7XG4gICAgICAgICAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIH07XG4gICAgICAgICAgICB9XG4gICAgICAgIH07XG4gICAgfSk7XG4iLCJhbmd1bGFyLm1vZHVsZSgnYmNhcHAtcGF0dGVybi1sYWIuZm9ybS1maWVsZC1lcnJvcicsIFtcbiAgICAnYmNhcHAtcGF0dGVybi1sYWIuZm9ybS1maWVsZC1lcnJvci5kaXJlY3RpdmUnXG5dKTtcbiIsImFuZ3VsYXIubW9kdWxlKCdiY2FwcC1wYXR0ZXJuLWxhYi5mb3JtLWZpZWxkLWVycm9ycy5kaXJlY3RpdmUnLCBbXSlcbiAgICAuZGlyZWN0aXZlKCdmb3JtRmllbGRFcnJvcnMnLCBmdW5jdGlvbiBmb3JtRmllbGRFcnJvcnNEaXJlY3RpdmUoKSB7XG4gICAgICAgIHJldHVybiB7XG4gICAgICAgICAgICByZXBsYWNlOiB0cnVlLFxuICAgICAgICAgICAgcmVxdWlyZTogJ15mb3JtJyxcbiAgICAgICAgICAgIHJlc3RyaWN0OiAnRUEnLFxuICAgICAgICAgICAgdGVtcGxhdGVVcmw6ICdzcmMvanMvYmlnY29tbWVyY2UvZm9ybS1maWVsZC1lcnJvcnMvZm9ybS1maWVsZC1lcnJvcnMudHBsLmh0bWwnLFxuICAgICAgICAgICAgdHJhbnNjbHVkZTogdHJ1ZSxcbiAgICAgICAgICAgIGxpbms6IHtcbiAgICAgICAgICAgICAgICAvLyBQcmUtbGluayBpcyByZXF1aXJlZCwgYXMgd2UgaGF2ZSB0byBpbmplY3Qgb3VyIHNjb3BlIHByb3BlcnRpZXMgYmVmb3JlIHRoZSBjaGlsZFxuICAgICAgICAgICAgICAgIC8vIGZvcm0tZmllbGQtZXJyb3IgZGlyZWN0aXZlIChhbmQgaXRzIGludGVybmFsIG5nLW1lc3NhZ2UgZGlyZWN0aXZlJ3MpIHBvc3QtbGluayBmdW5jdGlvbnNcbiAgICAgICAgICAgICAgICBwcmU6IGZ1bmN0aW9uIGZvcm1GaWVsZEVycm9yc1ByZUxpbmsoc2NvcGUsIGVsZW1lbnQsIGF0dHJzLCBmb3JtQ3RybCkge1xuICAgICAgICAgICAgICAgICAgICAvLyBQcm9wZXJ0eSBuYW1lIGNhbiBiZSBpbmhlcml0ZWQgZnJvbSBwYXJlbnQgc2NvcGUsIHN1Y2ggYXMgZnJvbSB0aGUgZm9ybS1maWVsZCBkaXJlY3RpdmVcbiAgICAgICAgICAgICAgICAgICAgdmFyIHByb3BlcnR5ID0gc2NvcGUucHJvcGVydHkgfHwgYXR0cnMucHJvcGVydHksXG4gICAgICAgICAgICAgICAgICAgICAgICBwcm9wZXJ0eUZpZWxkID0gZm9ybUN0cmxbcHJvcGVydHldO1xuXG4gICAgICAgICAgICAgICAgICAgIC8vIEluaGVyaXRlZCBieSBmb3JtLWZpZWxkLWVycm9yIGRpcmVjdGl2ZS4gTGl2ZXMgZGlyZWN0bHkgb24gc2NvcGUgYmVjYXVzZSB0aGUgcmVxdWlyZVxuICAgICAgICAgICAgICAgICAgICAvLyBwcm9wZXJ0eSBkb2VzIG5vdCB3b3JrIHdlbGwgd2l0aCBkaXJlY3RpdmUgY29udHJvbGxlciBpbnN0YW5jZXNcbiAgICAgICAgICAgICAgICAgICAgc2NvcGUuZm9ybUN0cmwgPSBmb3JtQ3RybDtcbiAgICAgICAgICAgICAgICAgICAgc2NvcGUucHJvcGVydHkgPSBwcm9wZXJ0eTtcbiAgICAgICAgICAgICAgICAgICAgc2NvcGUucHJvcGVydHlGaWVsZCA9IHByb3BlcnR5RmllbGQ7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICB9O1xuICAgIH0pO1xuIiwiYW5ndWxhci5tb2R1bGUoJ2JjYXBwLXBhdHRlcm4tbGFiLmZvcm0tZmllbGQtZXJyb3JzJywgW1xuICAgICdiY2FwcC1wYXR0ZXJuLWxhYi5mb3JtLWZpZWxkLWVycm9ycy5kaXJlY3RpdmUnXG5dKTtcbiIsImFuZ3VsYXIubW9kdWxlKCdiY2FwcC1wYXR0ZXJuLWxhYi5pY29uLmNvbnRyb2xsZXInLCBbXG4gICAgJ2JjYXBwLXBhdHRlcm4tbGFiLmljb24uc3ZnUm9vdFBhdGgnXG5dKVxuICAgIC5jb250cm9sbGVyKCdJY29uQ3RybCcsIGZ1bmN0aW9uIGljb25EaXJlY3RpdmVDb250cm9sbGVyKCRodHRwLCAkdGVtcGxhdGVDYWNoZSwgc3ZnUm9vdFBhdGgpIHtcbiAgICAgICAgdmFyIGN0cmwgPSB0aGlzO1xuXG4gICAgICAgIGN0cmwudXBkYXRlR2x5cGggPSB1cGRhdGVHbHlwaDtcblxuICAgICAgICBmdW5jdGlvbiB1cGRhdGVHbHlwaChnbHlwaCkge1xuICAgICAgICAgICAgdmFyIGZ1bGxTdmdQYXRoID0gc3ZnUm9vdFBhdGggKyBnbHlwaCArICcuc3ZnJztcblxuICAgICAgICAgICAgcmV0dXJuICRodHRwLmdldChmdWxsU3ZnUGF0aCwgeyBjYWNoZTogJHRlbXBsYXRlQ2FjaGUgfSlcbiAgICAgICAgICAgICAgICAudGhlbihmdW5jdGlvbiBpY29uRGlyZWN0aXZlSHR0cFN1Y2Nlc3MocmVzcG9uc2UpIHtcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIHJlc3BvbnNlLmRhdGE7XG4gICAgICAgICAgICAgICAgfSk7XG4gICAgICAgIH1cbiAgICB9KTtcbiIsIi8qKlxuICogQGRlc2NyaXB0aW9uIEljb24gZGlyZWN0aXZlIHVzZWQgdG8gbG9hZCBhbiBpbmxpbmUgc3ZnIGljb24sIHNpbWxpYXIgdG8gaWNvblxuICogICAgICAgICAgICAgIGZvbnQgbWV0aG9kcyBvZiBwYXN0IDxpIGNsYXNzPVwiaWNvbi1mb28tYmFyXCI+PC9pPlxuICogQGV4YW1wbGVcbiAqIDxpY29uIGdseXBoPVwiaWMtYWRkLWNpcmNsZVwiPjwvaWNvbj5cbiAqL1xuYW5ndWxhci5tb2R1bGUoJ2JjYXBwLXBhdHRlcm4tbGFiLmljb24uZGlyZWN0aXZlJywgW1xuICAgICdiY2FwcC1wYXR0ZXJuLWxhYi5pY29uLmNvbnRyb2xsZXInXG5dKVxuICAgIC5kaXJlY3RpdmUoJ2ljb24nLCBmdW5jdGlvbiBpY29uRGlyZWN0aXZlKCkge1xuICAgICAgICByZXR1cm4ge1xuICAgICAgICAgICAgYmluZFRvQ29udHJvbGxlcjogdHJ1ZSxcbiAgICAgICAgICAgIGNvbnRyb2xsZXI6ICdJY29uQ3RybCBhcyBpY29uQ3RybCcsXG4gICAgICAgICAgICByZXN0cmljdDogJ0UnLFxuICAgICAgICAgICAgc2NvcGU6IHtcbiAgICAgICAgICAgICAgICBnbHlwaDogJ0AnXG4gICAgICAgICAgICB9LFxuICAgICAgICAgICAgY29tcGlsZTogZnVuY3Rpb24gaWNvbkRpcmVjdGl2ZUNvbXBpbGUodEVsZW1lbnQpIHtcbiAgICAgICAgICAgICAgICB0RWxlbWVudC5hZGRDbGFzcygnaWNvbicpO1xuICAgICAgICAgICAgICAgIHRFbGVtZW50LmF0dHIoJ2FyaWEtaGlkZGVuJywgdHJ1ZSk7XG5cbiAgICAgICAgICAgICAgICByZXR1cm4gZnVuY3Rpb24gaWNvbkRpcmVjdGl2ZUxpbmsoJHNjb3BlLCBlbGVtZW50LCBhdHRycywgY3RybCkge1xuICAgICAgICAgICAgICAgICAgICAkc2NvcGUuJHdhdGNoKCdpY29uQ3RybC5nbHlwaCcsIGZ1bmN0aW9uIGljb25EaXJlY3RpdmVMaW5rV2F0Y2gobmV3VmFsdWUpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGN0cmwudXBkYXRlR2x5cGgobmV3VmFsdWUpXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgLnRoZW4oZnVuY3Rpb24gaWNvblVwZGF0ZUdseXBoVGhlbihzdmcpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZWxlbWVudC5odG1sKHN2Zyk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICAgIH07XG4gICAgICAgICAgICB9XG4gICAgICAgIH07XG4gICAgfSk7XG4iLCJhbmd1bGFyLm1vZHVsZSgnYmNhcHAtcGF0dGVybi1sYWIuaWNvbicsIFtcbiAgICAnYmNhcHAtcGF0dGVybi1sYWIuaWNvbi5kaXJlY3RpdmUnXG5dKTtcbiIsImFuZ3VsYXIubW9kdWxlKCdiY2FwcC1wYXR0ZXJuLWxhYi5pY29uLnN2Z1Jvb3RQYXRoJywgW10pXG4gICAgLnByb3ZpZGVyKCdzdmdSb290UGF0aCcsIGZ1bmN0aW9uIHN2Z1Jvb3RQYXRoUHJvdmlkZXJDb25maWcoKSB7XG4gICAgICAgIHRoaXMuc2V0Um9vdFBhdGggPSBzZXRSb290UGF0aDtcbiAgICAgICAgdGhpcy4kZ2V0ID0gZnVuY3Rpb24gc3ZnUm9vdFBhdGhQcm92aWRlckdldCgkbG9nKSB7XG4gICAgICAgICAgICBpZiAodGhpcy5zdmdSb290UGF0aCA9PT0gdW5kZWZpbmVkKSB7XG4gICAgICAgICAgICAgICAgJGxvZy5lcnJvcignTm8gc3ZnUm9vdFBhdGggcHJvdmlkZWQuIFBsZWFzZSBjb25maWd1cmUgdGhpcyB1c2luZyB0aGUgc3ZnUm9vdFBhdGhQcm92aWRlcicpO1xuICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICByZXR1cm4gdGhpcy5zdmdSb290UGF0aDtcbiAgICAgICAgfTtcblxuICAgICAgICBmdW5jdGlvbiBzZXRSb290UGF0aChuZXdSb290UGF0aCkge1xuICAgICAgICAgICAgdGhpcy5zdmdSb290UGF0aCA9IG5ld1Jvb3RQYXRoO1xuICAgICAgICB9XG4gICAgfSk7XG4iLCJhbmd1bGFyLm1vZHVsZSgnYmNhcHAtcGF0dGVybi1sYWIubG9hZGluZy1ub3RpZmljYXRpb24uZGlyZWN0aXZlJywgW10pXG4gICAgLmRpcmVjdGl2ZSgnbG9hZGluZ05vdGlmaWNhdGlvbicsIGZ1bmN0aW9uIGxvYWRpbmdOb3RpZmljYXRpb25EaXJlY3RpdmUoJHJvb3RTY29wZSkge1xuICAgICAgICByZXR1cm4ge1xuICAgICAgICAgICAgcmVzdHJpY3Q6ICdFJyxcbiAgICAgICAgICAgIHRlbXBsYXRlVXJsOiAnc3JjL2pzL2JpZ2NvbW1lcmNlL2xvYWRpbmctbm90aWZpY2F0aW9uL2xvYWRpbmctbm90aWZpY2F0aW9uLnRwbC5odG1sJyxcblxuICAgICAgICAgICAgbGluazogZnVuY3Rpb24oc2NvcGUpIHtcbiAgICAgICAgICAgICAgICAkcm9vdFNjb3BlLiRvbignYWpheFJlcXVlc3RSdW5uaW5nJywgZnVuY3Rpb24oZXZlbnQsIHZhbCkge1xuICAgICAgICAgICAgICAgICAgICBzY29wZS5yZXF1ZXN0SW5Qcm9ncmVzcyA9IHZhbDtcbiAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfTtcbiAgICB9KTtcbiIsImFuZ3VsYXIubW9kdWxlKCdiY2FwcC1wYXR0ZXJuLWxhYi5sb2FkaW5nLW5vdGlmaWNhdGlvbicsIFtcbiAgICAnYmNhcHAtcGF0dGVybi1sYWIubG9hZGluZy1ub3RpZmljYXRpb24uZGlyZWN0aXZlJ1xuXSk7XG4iLCJhbmd1bGFyLm1vZHVsZSgnYmNhcHAtcGF0dGVybi1sYWIubG9hZGluZy1vdmVybGF5LmNvbnRyb2xsZXInLCBbXSlcbiAgICAuY29udHJvbGxlcignTG9hZGluZ092ZXJsYXlDdHJsJywgZnVuY3Rpb24gTG9hZGluZ092ZXJsYXlDdHJsKCRyb290U2NvcGUsICR0aW1lb3V0KSB7XG4gICAgICAgIHZhciBjdHJsID0gdGhpcyxcbiAgICAgICAgICAgIGRlZmF1bHREZWJvdW5jZSA9IDEwMCxcbiAgICAgICAgICAgIHRpbWVvdXQ7XG5cbiAgICAgICAgaWYgKGN0cmwuZGVib3VuY2UgPT09IHVuZGVmaW5lZCkge1xuICAgICAgICAgICAgY3RybC5kZWJvdW5jZSA9IGRlZmF1bHREZWJvdW5jZTtcbiAgICAgICAgfVxuXG4gICAgICAgIGlmIChjdHJsLnVzZVVpUm91dGVyKSB7XG4gICAgICAgICAgICAkcm9vdFNjb3BlLiRvbignJHN0YXRlQ2hhbmdlU3RhcnQnLCBzdGFydExvYWRpbmcpO1xuICAgICAgICAgICAgJHJvb3RTY29wZS4kb24oJyRzdGF0ZUNoYW5nZVN1Y2Nlc3MnLCBzdG9wTG9hZGluZyk7XG4gICAgICAgICAgICAkcm9vdFNjb3BlLiRvbignJHN0YXRlQ2hhbmdlRXJyb3InLCBzdG9wTG9hZGluZyk7XG4gICAgICAgIH1cblxuICAgICAgICBmdW5jdGlvbiBzdGFydExvYWRpbmcoZXZlbnQpIHtcbiAgICAgICAgICAgIGlmIChldmVudC5kZWZhdWx0UHJldmVudGVkKSB7XG4gICAgICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICB0aW1lb3V0ID0gJHRpbWVvdXQoZnVuY3Rpb24gc3RhcnRMb2FkaW5nVGltZXIoKSB7XG4gICAgICAgICAgICAgICAgY3RybC5sb2FkaW5nID0gdHJ1ZTtcbiAgICAgICAgICAgIH0sIGN0cmwuZGVib3VuY2UpO1xuICAgICAgICB9XG5cbiAgICAgICAgZnVuY3Rpb24gc3RvcExvYWRpbmcoZXZlbnQpIHtcbiAgICAgICAgICAgIGlmIChldmVudC5kZWZhdWx0UHJldmVudGVkKSB7XG4gICAgICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAkdGltZW91dC5jYW5jZWwodGltZW91dCk7XG4gICAgICAgICAgICBjdHJsLmxvYWRpbmcgPSBmYWxzZTtcbiAgICAgICAgfVxuICAgIH0pO1xuIiwiYW5ndWxhci5tb2R1bGUoJ2JjYXBwLXBhdHRlcm4tbGFiLmxvYWRpbmctb3ZlcmxheS5kaXJlY3RpdmUnLCBbXG4gICAgJ2JjYXBwLXBhdHRlcm4tbGFiLmxvYWRpbmctb3ZlcmxheS5jb250cm9sbGVyJ1xuXSlcbiAgICAuZGlyZWN0aXZlKCdsb2FkaW5nT3ZlcmxheScsIGZ1bmN0aW9uIGxvYWRpbmdPdmVybGF5KCRjb21waWxlKSB7XG4gICAgICAgIHJldHVybiB7XG4gICAgICAgICAgICBiaW5kVG9Db250cm9sbGVyOiB0cnVlLFxuICAgICAgICAgICAgY29udHJvbGxlcjogJ0xvYWRpbmdPdmVybGF5Q3RybCBhcyBsb2FkaW5nT3ZlcmxheUN0cmwnLFxuICAgICAgICAgICAgcmVzdHJpY3Q6ICdBJyxcbiAgICAgICAgICAgIHNjb3BlOiB7XG4gICAgICAgICAgICAgICAgZGVib3VuY2U6ICc9PycsXG4gICAgICAgICAgICAgICAgbG9hZGluZzogJz0/bG9hZGluZ092ZXJsYXknLFxuICAgICAgICAgICAgICAgIHVzZVVpUm91dGVyOiAnPT8nXG4gICAgICAgICAgICB9LFxuICAgICAgICAgICAgY29tcGlsZTogZnVuY3Rpb24gbG9hZGluZ092ZXJsYXlDb21waWxlKGVsZW1lbnQpIHtcbiAgICAgICAgICAgICAgICBlbGVtZW50LmFkZENsYXNzKCdsb2FkaW5nT3ZlcmxheS1jb250YWluZXInKTtcblxuICAgICAgICAgICAgICAgIHJldHVybiBmdW5jdGlvbiBsb2FkaW5nT3ZlcmxheUxpbmsoc2NvcGUsIGVsZW1lbnQpIHtcbiAgICAgICAgICAgICAgICAgICAgY29uc3Qgb3ZlcmxheSA9ICRjb21waWxlKCc8ZGl2IGNsYXNzPVwibG9hZGluZ092ZXJsYXlcIiBuZy1pZj1cImxvYWRpbmdPdmVybGF5Q3RybC5sb2FkaW5nXCI+PC9kaXY+Jykoc2NvcGUpO1xuICAgICAgICAgICAgICAgICAgICBlbGVtZW50LmFwcGVuZChvdmVybGF5KTtcbiAgICAgICAgICAgICAgICB9O1xuICAgICAgICAgICAgfVxuICAgICAgICB9O1xuICAgIH0pO1xuIiwiYW5ndWxhci5tb2R1bGUoJ2JjYXBwLXBhdHRlcm4tbGFiLmxvYWRpbmctb3ZlcmxheScsIFtcbiAgICAnYmNhcHAtcGF0dGVybi1sYWIubG9hZGluZy1vdmVybGF5LmRpcmVjdGl2ZSdcbl0pO1xuIiwiLypcbiAqIE92ZXJyaWRlIGFuZ3VsYXIgZm91bmRhdGlvbidzICRtb2RhbFN0YWNrIHNlcnZpY2UgdG8gcmVtb3ZlIHRoZSBgdG9wYCBjc3MgcHJvcGVydHkuXG4gKiBjYW5ub3QgdXNlIGEgZGVjb3JhdG9yIGJlY2F1c2UgdGhlIGBvcGVuYCByZWxpZXMgb24gY2xvc3VyZXMgYW5kIGRvZXMgbm90IHJldHVybiB0aGUgY29tcGlsZWQgZWxlbWVudC5cbiAqIENoYW5nZXMgYXJlIGJldHdlZW4gYC8vIENoYW5nZXNgIGNvbW1lbnRzXG4qL1xuYW5ndWxhci5tb2R1bGUoJ2JjYXBwLXBhdHRlcm4tbGFiLmJjLW1vZGFsLm1vZGFsU3RhY2suc2VydmljZScsIFtcblxuXSlcbiAgLmZhY3RvcnkoJyRtb2RhbFN0YWNrJywgWyckd2luZG93JywgJyR0cmFuc2l0aW9uJywgJyR0aW1lb3V0JywgJyRkb2N1bWVudCcsICckY29tcGlsZScsICckcm9vdFNjb3BlJywgJyQkc3RhY2tlZE1hcCcsXG4gICAgZnVuY3Rpb24gKCR3aW5kb3csICR0cmFuc2l0aW9uLCAkdGltZW91dCwgJGRvY3VtZW50LCAkY29tcGlsZSwgJHJvb3RTY29wZSwgJCRzdGFja2VkTWFwKSB7XG4gICAgICAvLyBDaGFuZ2VzOiBjaGFuZ2UgZnJvbSBgbW9kYWwtb3BlbmAgdG8gYGhhcy1hY3RpdmVNb2RhbGBcbiAgICAgIHZhciBPUEVORURfTU9EQUxfQ0xBU1MgPSAnaGFzLWFjdGl2ZU1vZGFsJztcbiAgICAgIC8vIENoYW5nZXNcblxuICAgICAgdmFyIGJhY2tkcm9wRG9tRWwsIGJhY2tkcm9wU2NvcGU7XG4gICAgICB2YXIgb3BlbmVkV2luZG93cyA9ICQkc3RhY2tlZE1hcC5jcmVhdGVOZXcoKTtcbiAgICAgIHZhciAkbW9kYWxTdGFjayA9IHt9O1xuXG4gICAgICBmdW5jdGlvbiBiYWNrZHJvcEluZGV4KCkge1xuICAgICAgICB2YXIgdG9wQmFja2Ryb3BJbmRleCA9IC0xO1xuICAgICAgICB2YXIgb3BlbmVkID0gb3BlbmVkV2luZG93cy5rZXlzKCk7XG4gICAgICAgIGZvciAodmFyIGkgPSAwOyBpIDwgb3BlbmVkLmxlbmd0aDsgaSsrKSB7XG4gICAgICAgICAgaWYgKG9wZW5lZFdpbmRvd3MuZ2V0KG9wZW5lZFtpXSkudmFsdWUuYmFja2Ryb3ApIHtcbiAgICAgICAgICAgIHRvcEJhY2tkcm9wSW5kZXggPSBpO1xuICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gdG9wQmFja2Ryb3BJbmRleDtcbiAgICAgIH1cblxuICAgICAgJHJvb3RTY29wZS4kd2F0Y2goYmFja2Ryb3BJbmRleCwgZnVuY3Rpb24obmV3QmFja2Ryb3BJbmRleCl7XG4gICAgICAgIGlmIChiYWNrZHJvcFNjb3BlKSB7XG4gICAgICAgICAgYmFja2Ryb3BTY29wZS5pbmRleCA9IG5ld0JhY2tkcm9wSW5kZXg7XG4gICAgICAgIH1cbiAgICAgIH0pO1xuXG4gICAgICBmdW5jdGlvbiByZW1vdmVNb2RhbFdpbmRvdyhtb2RhbEluc3RhbmNlKSB7XG4gICAgICAgIHZhciBib2R5ID0gJGRvY3VtZW50LmZpbmQoJ2JvZHknKS5lcSgwKTtcbiAgICAgICAgdmFyIG1vZGFsV2luZG93ID0gb3BlbmVkV2luZG93cy5nZXQobW9kYWxJbnN0YW5jZSkudmFsdWU7XG5cbiAgICAgICAgLy9jbGVhbiB1cCB0aGUgc3RhY2tcbiAgICAgICAgb3BlbmVkV2luZG93cy5yZW1vdmUobW9kYWxJbnN0YW5jZSk7XG5cbiAgICAgICAgLy9yZW1vdmUgd2luZG93IERPTSBlbGVtZW50XG4gICAgICAgIHJlbW92ZUFmdGVyQW5pbWF0ZShtb2RhbFdpbmRvdy5tb2RhbERvbUVsLCBtb2RhbFdpbmRvdy5tb2RhbFNjb3BlLCAzMDAsIGZ1bmN0aW9uKCkge1xuICAgICAgICAgIG1vZGFsV2luZG93Lm1vZGFsU2NvcGUuJGRlc3Ryb3koKTtcbiAgICAgICAgICBib2R5LnRvZ2dsZUNsYXNzKE9QRU5FRF9NT0RBTF9DTEFTUywgb3BlbmVkV2luZG93cy5sZW5ndGgoKSA+IDApO1xuICAgICAgICAgIGNoZWNrUmVtb3ZlQmFja2Ryb3AoKTtcbiAgICAgICAgfSk7XG4gICAgICB9XG5cbiAgICAgIGZ1bmN0aW9uIGNoZWNrUmVtb3ZlQmFja2Ryb3AoKSB7XG4gICAgICAgIC8vcmVtb3ZlIGJhY2tkcm9wIGlmIG5vIGxvbmdlciBuZWVkZWRcbiAgICAgICAgaWYgKGJhY2tkcm9wRG9tRWwgJiYgYmFja2Ryb3BJbmRleCgpID09IC0xKSB7XG4gICAgICAgICAgdmFyIGJhY2tkcm9wU2NvcGVSZWYgPSBiYWNrZHJvcFNjb3BlO1xuICAgICAgICAgIHJlbW92ZUFmdGVyQW5pbWF0ZShiYWNrZHJvcERvbUVsLCBiYWNrZHJvcFNjb3BlLCAxNTAsIGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICAgIGJhY2tkcm9wU2NvcGVSZWYuJGRlc3Ryb3koKTtcbiAgICAgICAgICAgIGJhY2tkcm9wU2NvcGVSZWYgPSBudWxsO1xuICAgICAgICAgIH0pO1xuICAgICAgICAgIGJhY2tkcm9wRG9tRWwgPSB1bmRlZmluZWQ7XG4gICAgICAgICAgYmFja2Ryb3BTY29wZSA9IHVuZGVmaW5lZDtcbiAgICAgICAgfVxuICAgICAgfVxuXG4gICAgICBmdW5jdGlvbiByZW1vdmVBZnRlckFuaW1hdGUoZG9tRWwsIHNjb3BlLCBlbXVsYXRlVGltZSwgZG9uZSkge1xuICAgICAgICAvLyBDbG9zaW5nIGFuaW1hdGlvblxuICAgICAgICBzY29wZS5hbmltYXRlID0gZmFsc2U7XG5cbiAgICAgICAgdmFyIHRyYW5zaXRpb25FbmRFdmVudE5hbWUgPSAkdHJhbnNpdGlvbi50cmFuc2l0aW9uRW5kRXZlbnROYW1lO1xuICAgICAgICBpZiAodHJhbnNpdGlvbkVuZEV2ZW50TmFtZSkge1xuICAgICAgICAgIC8vIHRyYW5zaXRpb24gb3V0XG4gICAgICAgICAgdmFyIHRpbWVvdXQgPSAkdGltZW91dChhZnRlckFuaW1hdGluZywgZW11bGF0ZVRpbWUpO1xuXG4gICAgICAgICAgZG9tRWwuYmluZCh0cmFuc2l0aW9uRW5kRXZlbnROYW1lLCBmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICAkdGltZW91dC5jYW5jZWwodGltZW91dCk7XG4gICAgICAgICAgICBhZnRlckFuaW1hdGluZygpO1xuICAgICAgICAgICAgc2NvcGUuJGFwcGx5KCk7XG4gICAgICAgICAgfSk7XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgLy8gRW5zdXJlIHRoaXMgY2FsbCBpcyBhc3luY1xuICAgICAgICAgICR0aW1lb3V0KGFmdGVyQW5pbWF0aW5nLCAwKTtcbiAgICAgICAgfVxuXG4gICAgICAgIGZ1bmN0aW9uIGFmdGVyQW5pbWF0aW5nKCkge1xuICAgICAgICAgIGlmIChhZnRlckFuaW1hdGluZy5kb25lKSB7XG4gICAgICAgICAgICByZXR1cm47XG4gICAgICAgICAgfVxuICAgICAgICAgIGFmdGVyQW5pbWF0aW5nLmRvbmUgPSB0cnVlO1xuXG4gICAgICAgICAgZG9tRWwucmVtb3ZlKCk7XG4gICAgICAgICAgaWYgKGRvbmUpIHtcbiAgICAgICAgICAgIGRvbmUoKTtcbiAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgIH1cblxuICAgICAgJGRvY3VtZW50LmJpbmQoJ2tleWRvd24nLCBmdW5jdGlvbiAoZXZ0KSB7XG4gICAgICAgIHZhciBtb2RhbDtcblxuICAgICAgICBpZiAoZXZ0LndoaWNoID09PSAyNykge1xuICAgICAgICAgIG1vZGFsID0gb3BlbmVkV2luZG93cy50b3AoKTtcbiAgICAgICAgICBpZiAobW9kYWwgJiYgbW9kYWwudmFsdWUua2V5Ym9hcmQpIHtcbiAgICAgICAgICAgICRyb290U2NvcGUuJGFwcGx5KGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICAgICAgJG1vZGFsU3RhY2suZGlzbWlzcyhtb2RhbC5rZXkpO1xuICAgICAgICAgICAgfSk7XG4gICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICB9KTtcblxuICAgICAgJG1vZGFsU3RhY2sub3BlbiA9IGZ1bmN0aW9uIChtb2RhbEluc3RhbmNlLCBtb2RhbCkge1xuXG4gICAgICAgIG9wZW5lZFdpbmRvd3MuYWRkKG1vZGFsSW5zdGFuY2UsIHtcbiAgICAgICAgICBkZWZlcnJlZDogbW9kYWwuZGVmZXJyZWQsXG4gICAgICAgICAgbW9kYWxTY29wZTogbW9kYWwuc2NvcGUsXG4gICAgICAgICAgYmFja2Ryb3A6IG1vZGFsLmJhY2tkcm9wLFxuICAgICAgICAgIGtleWJvYXJkOiBtb2RhbC5rZXlib2FyZFxuICAgICAgICB9KTtcblxuICAgICAgICB2YXIgYm9keSA9ICRkb2N1bWVudC5maW5kKCdib2R5JykuZXEoMCksXG4gICAgICAgICAgICBjdXJyQmFja2Ryb3BJbmRleCA9IGJhY2tkcm9wSW5kZXgoKTtcblxuICAgICAgICBpZiAoY3VyckJhY2tkcm9wSW5kZXggPj0gMCAmJiAhYmFja2Ryb3BEb21FbCkge1xuICAgICAgICAgIGJhY2tkcm9wU2NvcGUgPSAkcm9vdFNjb3BlLiRuZXcodHJ1ZSk7XG4gICAgICAgICAgYmFja2Ryb3BTY29wZS5pbmRleCA9IGN1cnJCYWNrZHJvcEluZGV4O1xuICAgICAgICAgIGJhY2tkcm9wRG9tRWwgPSAkY29tcGlsZSgnPGRpdiBtb2RhbC1iYWNrZHJvcD48L2Rpdj4nKShiYWNrZHJvcFNjb3BlKTtcbiAgICAgICAgICBib2R5LmFwcGVuZChiYWNrZHJvcERvbUVsKTtcbiAgICAgICAgfVxuXG4gICAgICAgIC8vIENoYW5nZXM6IGRlbGV0aW9uIG9mIGNzcyB0b3AgcHJvcGVydHkgY2FsY3VsYXRpb25cbiAgICAgICAgdmFyIGFuZ3VsYXJEb21FbCA9IGFuZ3VsYXIuZWxlbWVudCgnPGRpdiBtb2RhbC13aW5kb3cgc3R5bGU9XCJ2aXNpYmlsaXR5OiB2aXNpYmxlOyBkaXNwbGF5OiBibG9ja1wiPjwvZGl2PicpO1xuICAgICAgICBhbmd1bGFyRG9tRWwuYXR0cignd2luZG93LWNsYXNzJywgbW9kYWwud2luZG93Q2xhc3MpO1xuICAgICAgICBhbmd1bGFyRG9tRWwuYXR0cignaW5kZXgnLCBvcGVuZWRXaW5kb3dzLmxlbmd0aCgpIC0gMSk7XG4gICAgICAgIGFuZ3VsYXJEb21FbC5hdHRyKCdhbmltYXRlJywgJ2FuaW1hdGUnKTtcbiAgICAgICAgYW5ndWxhckRvbUVsLmh0bWwobW9kYWwuY29udGVudCk7XG5cbiAgICAgICAgdmFyIG1vZGFsRG9tRWwgPSAkY29tcGlsZShhbmd1bGFyRG9tRWwpKG1vZGFsLnNjb3BlKTtcbiAgICAgICAgb3BlbmVkV2luZG93cy50b3AoKS52YWx1ZS5tb2RhbERvbUVsID0gbW9kYWxEb21FbDtcbiAgICAgICAgYm9keS5hcHBlbmQobW9kYWxEb21FbCk7XG4gICAgICAgIGJvZHkuYWRkQ2xhc3MoT1BFTkVEX01PREFMX0NMQVNTKTtcbiAgICAgIH07XG5cbiAgICAgICRtb2RhbFN0YWNrLmNsb3NlID0gZnVuY3Rpb24gKG1vZGFsSW5zdGFuY2UsIHJlc3VsdCkge1xuICAgICAgICB2YXIgbW9kYWxXaW5kb3cgPSBvcGVuZWRXaW5kb3dzLmdldChtb2RhbEluc3RhbmNlKS52YWx1ZTtcbiAgICAgICAgaWYgKG1vZGFsV2luZG93KSB7XG4gICAgICAgICAgbW9kYWxXaW5kb3cuZGVmZXJyZWQucmVzb2x2ZShyZXN1bHQpO1xuICAgICAgICAgIHJlbW92ZU1vZGFsV2luZG93KG1vZGFsSW5zdGFuY2UpO1xuICAgICAgICB9XG4gICAgICB9O1xuXG4gICAgICAkbW9kYWxTdGFjay5kaXNtaXNzID0gZnVuY3Rpb24gKG1vZGFsSW5zdGFuY2UsIHJlYXNvbikge1xuICAgICAgICB2YXIgbW9kYWxXaW5kb3cgPSBvcGVuZWRXaW5kb3dzLmdldChtb2RhbEluc3RhbmNlKS52YWx1ZTtcbiAgICAgICAgaWYgKG1vZGFsV2luZG93KSB7XG4gICAgICAgICAgbW9kYWxXaW5kb3cuZGVmZXJyZWQucmVqZWN0KHJlYXNvbik7XG4gICAgICAgICAgcmVtb3ZlTW9kYWxXaW5kb3cobW9kYWxJbnN0YW5jZSk7XG4gICAgICAgIH1cbiAgICAgIH07XG5cbiAgICAgICRtb2RhbFN0YWNrLmRpc21pc3NBbGwgPSBmdW5jdGlvbiAocmVhc29uKSB7XG4gICAgICAgIHZhciB0b3BNb2RhbCA9IHRoaXMuZ2V0VG9wKCk7XG4gICAgICAgIHdoaWxlICh0b3BNb2RhbCkge1xuICAgICAgICAgIHRoaXMuZGlzbWlzcyh0b3BNb2RhbC5rZXksIHJlYXNvbik7XG4gICAgICAgICAgdG9wTW9kYWwgPSB0aGlzLmdldFRvcCgpO1xuICAgICAgICB9XG4gICAgICB9O1xuXG4gICAgICAkbW9kYWxTdGFjay5nZXRUb3AgPSBmdW5jdGlvbiAoKSB7XG4gICAgICAgIHJldHVybiBvcGVuZWRXaW5kb3dzLnRvcCgpO1xuICAgICAgfTtcblxuICAgICAgcmV0dXJuICRtb2RhbFN0YWNrO1xuICAgIH1dKTtcblxuIiwiLypcbiAqIFRoaXMgbW9kdWxlIG1vZGlmaWVzIGFuZ3VsYXIgZm91bmRhdGlvbidzIG1vZGFsIGltcGxlbWVudGF0aW9uLiBUaGlzIGRvZXMgbm90IGNyZWF0ZSBhIG5ldyBtb2RhbCBzZXJ2aWNlL2RpcmVjdGl2ZS5cbiAqIFxuKi9cbmFuZ3VsYXIubW9kdWxlKCdiY2FwcC1wYXR0ZXJuLWxhYi5iYy1tb2RhbCcsIFtcbiAgICAnYmNhcHAtcGF0dGVybi1sYWIuYmMtbW9kYWwubW9kYWxTdGFjay5zZXJ2aWNlJ1xuXSk7XG4iLCIvKipcbiAqIEBkZXNjcmlwdGlvbiBTcHJpdGUgZGlyZWN0aXZlIHVzZWQgdG8gbG9hZCBhbiBpY29uIGZyb20gYW4gaW1hZ2Ugc3ByaXRlLFxuICogICAgICAgICAgICAgIHNpbWxpYXIgdG8gdGhlIGljb24gZGlyZWN0aXZlIGJ1dCBsZXNzIFNWR1xuICogQGV4YW1wbGVcbiAqIDxzcHJpdGUgZ2x5cGg9XCJpYy1hbWV4XCI+PC9zcHJpdGU+XG4gKi9cblxuYW5ndWxhci5tb2R1bGUoJ2JjYXBwLXBhdHRlcm4tbGFiLnNwcml0ZS5kaXJlY3RpdmUnLCBbXSlcbiAgICAuZGlyZWN0aXZlKCdzcHJpdGUnLCBmdW5jdGlvbiBzcHJpdGVEaXJlY3RpdmUoKSB7XG4gICAgICAgIHJldHVybiB7XG4gICAgICAgICAgICByZXN0cmljdDogJ0UnLFxuICAgICAgICAgICAgc2NvcGU6IHtcbiAgICAgICAgICAgICAgICBnbHlwaDogJ0AnXG4gICAgICAgICAgICB9LFxuICAgICAgICAgICAgY29tcGlsZTogc3ByaXRlRGlyZWN0aXZlQ29tcGlsZVxuICAgICAgICB9O1xuXG4gICAgICAgIGZ1bmN0aW9uIHNwcml0ZURpcmVjdGl2ZUNvbXBpbGUodEVsZW1lbnQpIHtcbiAgICAgICAgICAgIHRFbGVtZW50LmFkZENsYXNzKCdzcHJpdGUnKTtcbiAgICAgICAgICAgIHRFbGVtZW50LmF0dHIoJ2FyaWEtaGlkZGVuJywgdHJ1ZSk7XG5cbiAgICAgICAgICAgIHJldHVybiBmdW5jdGlvbiBzcHJpdGVEaXJlY3RpdmVMaW5rKCRzY29wZSwgZWxlbWVudCwgYXR0cnMpIHtcbiAgICAgICAgICAgICAgICBhdHRycy4kb2JzZXJ2ZSgnZ2x5cGgnLCAobmV3VmFsdWUpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgZWxlbWVudC5hdHRyKCdjbGFzcycsICdzcHJpdGUgc3ByaXRlLS0nICsgbmV3VmFsdWUpO1xuICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgfTtcbiAgICAgICAgfVxuICAgIH0pO1xuIiwiYW5ndWxhci5tb2R1bGUoJ2JjYXBwLXBhdHRlcm4tbGFiLnNwcml0ZScsIFtcbiAgICAnYmNhcHAtcGF0dGVybi1sYWIuc3ByaXRlLmRpcmVjdGl2ZSdcbl0pO1xuIiwiLyoqXG4gKiBAZGVzY3JpcHRpb24gVXNlZCB0byBjcmVhdGUgYSB0b2dnbGUgc3dpdGNoIGZvciBmb3Jtc1xuICogQGV4YW1wbGVcbiAgICA8c3dpdGNoIG5nLW1vZGVsPVwiY3RybC5zd2l0Y2hNb2RlbDFcIj48L3N3aXRjaD5cblxuICAgIDxzd2l0Y2hcbiAgICAgICAgdG9nZ2xlLW9mZi10ZXh0PVwiT2ZmXCJcbiAgICAgICAgdG9nZ2xlLW9uLXRleHQ9XCJPblwiXG4gICAgICAgIG5nLW1vZGVsPVwiY3RybC5zd2l0Y2hNb2RlbDJcIj5cbiAgICA8L3N3aXRjaD5cblxuICAgIDxzd2l0Y2hcbiAgICAgICAgaGFzLWljb25cbiAgICAgICAgbmctbW9kZWw9XCJjdHJsLnN3aXRjaE1vZGVsM1wiPlxuICAgIDwvc3dpdGNoPlxuXG4gICAgPHN3aXRjaFxuICAgICAgICBpcy1pbXBvcnRhbnRcbiAgICAgICAgbGVmdC1sYWJlbD1cIkRvd24gZm9yIE1haW50ZW5hbmNlXCJcbiAgICAgICAgcmlnaHQtbGFiZWw9XCJPcGVuXCJcbiAgICAgICAgbmctbW9kZWw9XCJjdHJsLnN3aXRjaE1vZGVsNFwiPlxuICAgIDwvc3dpdGNoPlxuICovXG5hbmd1bGFyLm1vZHVsZSgnYmNhcHAtcGF0dGVybi1sYWIuc3dpdGNoLmRpcmVjdGl2ZScsIFtdKVxuICAgIC5kaXJlY3RpdmUoJ3N3aXRjaCcsIGZ1bmN0aW9uIHN3aXRjaERpcmVjdGl2ZSgpIHtcblxuICAgICAgICBmdW5jdGlvbiBnZXRVbmlxdWVJRChpZFByZWZpeCkge1xuICAgICAgICAgICAgcmV0dXJuIF8udW5pcXVlSWQoaWRQcmVmaXgpO1xuICAgICAgICB9XG5cbiAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICAgIHJlc3RyaWN0OiAnRScsXG4gICAgICAgICAgICB0ZW1wbGF0ZVVybDogJ3NyYy9qcy9iaWdjb21tZXJjZS9zd2l0Y2gvc3dpdGNoLnRwbC5odG1sJyxcbiAgICAgICAgICAgIHJlcXVpcmU6ICduZ01vZGVsJyxcbiAgICAgICAgICAgIHNjb3BlOiB7XG4gICAgICAgICAgICAgICAgYXJpYURlc2NyaXB0aW9uOiAnQCcsXG4gICAgICAgICAgICAgICAgbGFiZWxUZXh0OiAnQCcsXG4gICAgICAgICAgICAgICAgbGVmdERlc2NyaXB0aW9uOiAnQCcsXG4gICAgICAgICAgICAgICAgbmdGYWxzZVZhbHVlOiAnQCcsXG4gICAgICAgICAgICAgICAgbmdUcnVlVmFsdWU6ICdAJyxcbiAgICAgICAgICAgICAgICByaWdodERlc2NyaXB0aW9uOiAnQCcsXG4gICAgICAgICAgICAgICAgdG9nZ2xlT2ZmTGFiZWw6ICdAJyxcbiAgICAgICAgICAgICAgICB0b2dnbGVPbkxhYmVsOiAnQCcsXG4gICAgICAgICAgICAgICAgdW5pcXVlSWQ6ICdAJ1xuICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIGJpbmRUb0NvbnRyb2xsZXI6IHRydWUsXG4gICAgICAgICAgICBjb250cm9sbGVyQXM6ICdzd2l0Y2hDdHJsJyxcbiAgICAgICAgICAgIGNvbXBpbGU6IGZ1bmN0aW9uIHN3aXRjaERpcmVjdGl2ZUNvbXBpbGUodEVsZW0sIHRBdHRycykge1xuICAgICAgICAgICAgICAgIHZhciBjaGVja2JveEVsZW0gPSB0RWxlbS5maW5kKCdpbnB1dCcpO1xuXG4gICAgICAgICAgICAgICAgaWYgKHRBdHRycy5uZ0ZhbHNlVmFsdWUpIHtcbiAgICAgICAgICAgICAgICAgICAgY2hlY2tib3hFbGVtLmF0dHIoJ25nLWZhbHNlLXZhbHVlJywgdEF0dHJzLm5nRmFsc2VWYWx1ZSk7XG4gICAgICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAgICAgaWYgKHRBdHRycy5uZ1RydWVWYWx1ZSkge1xuICAgICAgICAgICAgICAgICAgICBjaGVja2JveEVsZW0uYXR0cignbmctdHJ1ZS12YWx1ZScsIHRBdHRycy5uZ1RydWVWYWx1ZSk7XG4gICAgICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAgICAgcmV0dXJuIGZ1bmN0aW9uIHN3aXRjaERpcmVjdGl2ZVBvc3RMaW5rKHNjb3BlLCBlbGVtZW50LCBhdHRycywgbmdNb2RlbEN0cmwpIHtcbiAgICAgICAgICAgICAgICAgICAgc2NvcGUuc3dpdGNoQ3RybC5pbml0KG5nTW9kZWxDdHJsKTtcbiAgICAgICAgICAgICAgICB9O1xuICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIGNvbnRyb2xsZXI6IGZ1bmN0aW9uIHN3aXRjaERpcmVjdGl2ZUN0cmwoJHNjb3BlLCAkZWxlbWVudCwgJGF0dHJzKSB7XG4gICAgICAgICAgICAgICAgdmFyIGN0cmwgPSB0aGlzO1xuXG4gICAgICAgICAgICAgICAgLy8gc3RhdGVcbiAgICAgICAgICAgICAgICBjdHJsLmlzSW1wb3J0YW50ID0gYW5ndWxhci5pc0RlZmluZWQoJGF0dHJzLmlzSW1wb3J0YW50KSAmJiAkYXR0cnMuaXNJbXBvcnRhbnQgIT09ICdmYWxzZSc7XG4gICAgICAgICAgICAgICAgY3RybC5oYXNJY29uID0gYW5ndWxhci5pc0RlZmluZWQoJGF0dHJzLmhhc0ljb24pICYmICRhdHRycy5oYXNJY29uICE9PSAnZmFsc2UnO1xuXG4gICAgICAgICAgICAgICAgLy8gbGFiZWxzXG4gICAgICAgICAgICAgICAgY3RybC5sYWJlbFRleHQgPSAkYXR0cnMudG9nZ2xlT2ZmTGFiZWw7XG5cbiAgICAgICAgICAgICAgICAvLyBpZHNcbiAgICAgICAgICAgICAgICBjdHJsLnVuaXF1ZUlkID0gZ2V0VW5pcXVlSUQoJ3N3aXRjaC0nKTtcbiAgICAgICAgICAgICAgICBjdHJsLmFyaWFEZXNjcmlwdGlvbklEID0gZ2V0VW5pcXVlSUQoJ3N3aXRjaC1hcmlhRGVzY3JpcHRpb24tJyk7XG5cbiAgICAgICAgICAgICAgICBjdHJsLmluaXQgPSBpbml0O1xuICAgICAgICAgICAgICAgIGN0cmwudXBkYXRlTW9kZWwgPSB1cGRhdGVNb2RlbDtcblxuICAgICAgICAgICAgICAgIGZ1bmN0aW9uIGluaXQobmdNb2RlbEN0cmwpIHtcbiAgICAgICAgICAgICAgICAgICAgY3RybC5uZ01vZGVsQ3RybCA9IG5nTW9kZWxDdHJsO1xuICAgICAgICAgICAgICAgICAgICBjdHJsLnZhbHVlID0gY3RybC5uZ01vZGVsQ3RybC4kbW9kZWxWYWx1ZTtcblxuICAgICAgICAgICAgICAgICAgICAkc2NvcGUuJHdhdGNoKCdzd2l0Y2hDdHJsLm5nTW9kZWxDdHJsLiRtb2RlbFZhbHVlJywgZnVuY3Rpb24gc3dpdGNoVmFsdWVDaGFuZ2VkKG5ld1ZhbHVlKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICBjdHJsLnZhbHVlID0gbmV3VmFsdWU7XG5cbiAgICAgICAgICAgICAgICAgICAgICAgIGN0cmwuaXNDaGVja2VkID0gXy5pc1N0cmluZyhuZXdWYWx1ZSkgPyBcIidcIiArIG5ld1ZhbHVlICsgXCInXCIgPT09IGN0cmwubmdUcnVlVmFsdWUgOiBuZXdWYWx1ZTtcbiAgICAgICAgICAgICAgICAgICAgICAgIGN0cmwubGFiZWxUZXh0ID0gISFjdHJsLmlzQ2hlY2tlZCA/IGN0cmwudG9nZ2xlT25MYWJlbDogY3RybC50b2dnbGVPZmZMYWJlbDtcbiAgICAgICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAgICAgZnVuY3Rpb24gdXBkYXRlTW9kZWwoKSB7XG4gICAgICAgICAgICAgICAgICAgIGN0cmwubmdNb2RlbEN0cmwuJHNldFZpZXdWYWx1ZShjdHJsLnZhbHVlKTtcbiAgICAgICAgICAgICAgICB9XG5cbiAgICAgICAgICAgIH1cbiAgICAgICAgfTtcbiAgICB9KTtcbiIsImFuZ3VsYXIubW9kdWxlKCdiY2FwcC1wYXR0ZXJuLWxhYi5zd2l0Y2gnLCBbXG4gICAgJ2JjYXBwLXBhdHRlcm4tbGFiLnN3aXRjaC5kaXJlY3RpdmUnXG5dKTtcbiIsImFuZ3VsYXIubW9kdWxlKCdiY2FwcC1wYXR0ZXJuLWxhYi51dGlsJywgW1xuICAgICdiY2FwcC1wYXR0ZXJuLWxhYi51dGlsLnRydXN0QXNIdG1sJ1xuXSk7XG4iLCJhbmd1bGFyLm1vZHVsZSgnYmNhcHAtcGF0dGVybi1sYWIuYmMtc2VydmVyLXRhYmxlLnNlcnZpY2UnLCBbXG4gICAgJ3VpLnJvdXRlcidcbl0pXG4gICAgLmZhY3RvcnkoJ0JjU2VydmVyVGFibGUnLCBmdW5jdGlvbiBiY1NlcnZlclRhYmxlKCRsb2csICRxLCAkc3RhdGUsICRzdGF0ZVBhcmFtcykge1xuICAgICAgICB2YXIgZGVmYXVsdFRhYmxlQ29uZmlnID0ge1xuICAgICAgICAgICAgZmlsdGVyczogW10sXG4gICAgICAgICAgICBxdWVyeUtleXM6IHtcbiAgICAgICAgICAgICAgICBwYWdlOiAncGFnZScsXG4gICAgICAgICAgICAgICAgbGltaXQ6ICdsaW1pdCcsXG4gICAgICAgICAgICAgICAgc29ydEJ5OiAnc29ydC1ieScsXG4gICAgICAgICAgICAgICAgc29ydERpcjogJ3NvcnQtb3JkZXInXG4gICAgICAgICAgICB9LFxuICAgICAgICAgICAgcm93SWRLZXk6ICdpZCcsXG4gICAgICAgICAgICBzb3J0RGlyVmFsdWVzOiB7XG4gICAgICAgICAgICAgICAgYXNjOiAnYXNjJyxcbiAgICAgICAgICAgICAgICBkZXNjOiAnZGVzYydcbiAgICAgICAgICAgIH1cbiAgICAgICAgfTtcblxuICAgICAgICBmdW5jdGlvbiBTZXJ2ZXJUYWJsZSh0YWJsZUlkLCB0YWJsZUNvbmZpZykge1xuICAgICAgICAgICAgdGhpcy5hbGxTZWxlY3RlZCA9IGZhbHNlO1xuICAgICAgICAgICAgdGhpcy5maWx0ZXJzID0ge307XG4gICAgICAgICAgICB0aGlzLmlkID0gdGFibGVJZDtcbiAgICAgICAgICAgIHRoaXMucGFnaW5hdGlvbiA9IHtcbiAgICAgICAgICAgICAgICBwYWdlOiBudWxsLFxuICAgICAgICAgICAgICAgIGxpbWl0OiBudWxsLFxuICAgICAgICAgICAgICAgIHRvdGFsOiBudWxsXG4gICAgICAgICAgICB9O1xuICAgICAgICAgICAgdGhpcy5wZW5kaW5nUmVxdWVzdCA9IGZhbHNlO1xuICAgICAgICAgICAgdGhpcy5yZXNvdXJjZUNhbGxiYWNrID0gYW5ndWxhci5ub29wO1xuICAgICAgICAgICAgdGhpcy5yb3dzID0gW107XG4gICAgICAgICAgICB0aGlzLnNlbGVjdGVkUm93cyA9IHt9O1xuICAgICAgICAgICAgdGhpcy5zb3J0QnkgPSAnJztcbiAgICAgICAgICAgIHRoaXMuc29ydERpciA9ICcnO1xuICAgICAgICAgICAgXG4gICAgICAgICAgICB0aGlzLnRhYmxlQ29uZmlnID0gXy5pc09iamVjdCh0YWJsZUNvbmZpZykgPyB0YWJsZUNvbmZpZyA6IHt9O1xuICAgICAgICAgICAgdGhpcy50YWJsZUNvbmZpZyA9IF8uZGVmYXVsdHModGhpcy50YWJsZUNvbmZpZywgZGVmYXVsdFRhYmxlQ29uZmlnKTtcbiAgICAgICAgfVxuXG4gICAgICAgIFNlcnZlclRhYmxlLnByb3RvdHlwZSA9IHtcbiAgICAgICAgICAgIGNyZWF0ZVBhcmFtc09iamVjdDogY3JlYXRlUGFyYW1zT2JqZWN0LFxuICAgICAgICAgICAgZmV0Y2hSZXNvdXJjZTogZmV0Y2hSZXNvdXJjZSxcbiAgICAgICAgICAgIGdldFNlbGVjdGVkUm93czogZ2V0U2VsZWN0ZWRSb3dzLFxuICAgICAgICAgICAgaW5pdDogaW5pdCxcbiAgICAgICAgICAgIGlzUm93U2VsZWN0ZWQ6IGlzUm93U2VsZWN0ZWQsXG4gICAgICAgICAgICBsb2FkU3RhdGVQYXJhbXM6IGxvYWRTdGF0ZVBhcmFtcyxcbiAgICAgICAgICAgIHNlbGVjdEFsbFJvd3M6IHNlbGVjdEFsbFJvd3MsXG4gICAgICAgICAgICBzZXRQYWdpbmF0aW9uVmFsdWVzOiBzZXRQYWdpbmF0aW9uVmFsdWVzLFxuICAgICAgICAgICAgc2V0Um93czogc2V0Um93cyxcbiAgICAgICAgICAgIHNldFNvcnRpbmdWYWx1ZXM6IHNldFNvcnRpbmdWYWx1ZXMsXG4gICAgICAgICAgICB1cGRhdGVQYWdlOiB1cGRhdGVQYWdlLFxuICAgICAgICAgICAgdXBkYXRlU29ydDogdXBkYXRlU29ydCxcbiAgICAgICAgICAgIHVwZGF0ZVRhYmxlOiB1cGRhdGVUYWJsZSxcbiAgICAgICAgICAgIHZhbGlkYXRlUmVzb3VyY2U6IHZhbGlkYXRlUmVzb3VyY2VcbiAgICAgICAgfTtcblxuICAgICAgICBmdW5jdGlvbiBjcmVhdGVQYXJhbXNPYmplY3QoKSB7XG4gICAgICAgICAgICB2YXIgcGFyYW1zID0ge30sXG4gICAgICAgICAgICAgICAgcXVlcnlLZXlzID0gdGhpcy50YWJsZUNvbmZpZy5xdWVyeUtleXMsXG4gICAgICAgICAgICAgICAgcXVlcnlQYXJhbU1hcCA9IFt7XG4gICAgICAgICAgICAgICAgICAgICAgICBxdWVyeUtleTogcXVlcnlLZXlzLnBhZ2UsXG4gICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZTogdGhpcy5wYWdpbmF0aW9uLnBhZ2VcbiAgICAgICAgICAgICAgICAgICAgfSwge1xuICAgICAgICAgICAgICAgICAgICAgICAgcXVlcnlLZXk6IHF1ZXJ5S2V5cy5saW1pdCxcbiAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlOiB0aGlzLnBhZ2luYXRpb24ubGltaXRcbiAgICAgICAgICAgICAgICAgICAgfSwge1xuICAgICAgICAgICAgICAgICAgICAgICAgcXVlcnlLZXk6IHF1ZXJ5S2V5cy5zb3J0QnksXG4gICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZTogdGhpcy5zb3J0QnlcbiAgICAgICAgICAgICAgICAgICAgfSwge1xuICAgICAgICAgICAgICAgICAgICAgICAgcXVlcnlLZXk6IHF1ZXJ5S2V5cy5zb3J0RGlyLFxuICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU6IHRoaXMuc29ydERpclxuICAgICAgICAgICAgICAgICAgICB9XTtcblxuICAgICAgICAgICAgXy5lYWNoKHF1ZXJ5UGFyYW1NYXAsIGZ1bmN0aW9uIHF1ZXJ5UGFyYW1NYXBFYWNoKHBhcmFtKSB7XG4gICAgICAgICAgICAgICAgaWYgKHBhcmFtLnF1ZXJ5S2V5ICE9PSB1bmRlZmluZWQpIHtcbiAgICAgICAgICAgICAgICAgICAgcGFyYW1zW3BhcmFtLnF1ZXJ5S2V5XSA9IHBhcmFtLnZhbHVlO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH0pO1xuXG4gICAgICAgICAgICBfLmV4dGVuZChwYXJhbXMsIHRoaXMuZmlsdGVycyk7XG5cbiAgICAgICAgICAgIHJldHVybiBwYXJhbXM7XG4gICAgICAgIH1cblxuICAgICAgICBmdW5jdGlvbiBmZXRjaFJlc291cmNlKCkge1xuICAgICAgICAgICAgdmFyIF90aGlzID0gdGhpcztcblxuICAgICAgICAgICAgdGhpcy5wZW5kaW5nUmVxdWVzdCA9IHRydWU7XG4gICAgICAgICAgICByZXR1cm4gdGhpcy5yZXNvdXJjZUNhbGxiYWNrKHRoaXMuY3JlYXRlUGFyYW1zT2JqZWN0KCkpXG4gICAgICAgICAgICAgICAgLnRoZW4oZnVuY3Rpb24gcmVzb3VyY2VDYWxsYmFja1RoZW4ocmVzb3VyY2UpIHtcbiAgICAgICAgICAgICAgICAgICAgaWYgKF90aGlzLnZhbGlkYXRlUmVzb3VyY2UocmVzb3VyY2UpKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICBfdGhpcy5zZXRSb3dzKHJlc291cmNlLnJvd3MpO1xuICAgICAgICAgICAgICAgICAgICAgICAgX3RoaXMuc2V0UGFnaW5hdGlvblZhbHVlcyhyZXNvdXJjZS5wYWdpbmF0aW9uKTtcbiAgICAgICAgICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBfdGhpcztcbiAgICAgICAgICAgICAgICB9KVxuICAgICAgICAgICAgICAgIC5jYXRjaChmdW5jdGlvbiByZXNvdXJjZUNhbGxiYWNrQ2F0Y2goZXJyb3IpIHtcbiAgICAgICAgICAgICAgICAgICAgJGxvZy5lcnJvcignYmMtc2VydmVyLXRhYmxlIGRpcmVjdGl2ZTogZmFpbGVkIHRvIGZldGNoIHJlc291cmNlJyk7XG5cbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuICRxLnJlamVjdChlcnJvcik7XG4gICAgICAgICAgICAgICAgfSlcbiAgICAgICAgICAgICAgICAuZmluYWxseShmdW5jdGlvbiByZXNvdXJjZUNhbGxiYWNrRmluYWxseSgpIHtcbiAgICAgICAgICAgICAgICAgICAgX3RoaXMucGVuZGluZ1JlcXVlc3QgPSBmYWxzZTtcbiAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgfVxuXG4gICAgICAgIGZ1bmN0aW9uIGdldFNlbGVjdGVkUm93cygpIHtcbiAgICAgICAgICAgIHZhciBfdGhpcyA9IHRoaXM7XG5cbiAgICAgICAgICAgIHJldHVybiBfLmZpbHRlcih0aGlzLnJvd3MsIGZ1bmN0aW9uIGdldFNlbGVjdGVkUm93c0ZpbHRlcihyb3cpIHtcbiAgICAgICAgICAgICAgICByZXR1cm4gX3RoaXMuaXNSb3dTZWxlY3RlZChyb3cpO1xuICAgICAgICAgICAgfSk7XG4gICAgICAgIH1cblxuICAgICAgICBmdW5jdGlvbiBpbml0KGNvbmZpZykge1xuICAgICAgICAgICAgaWYgKCFfLmlzT2JqZWN0KGNvbmZpZykpIHtcbiAgICAgICAgICAgICAgICBjb25maWcgPSB7fTtcbiAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgaWYgKF8uaXNGdW5jdGlvbihjb25maWcucmVzb3VyY2VDYWxsYmFjaykpIHtcbiAgICAgICAgICAgICAgICB0aGlzLnJlc291cmNlQ2FsbGJhY2sgPSBjb25maWcucmVzb3VyY2VDYWxsYmFjaztcbiAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgcmV0dXJuIHRoaXNcbiAgICAgICAgICAgICAgICAubG9hZFN0YXRlUGFyYW1zKGNvbmZpZy5zdGF0ZVBhcmFtcylcbiAgICAgICAgICAgICAgICAuZmV0Y2hSZXNvdXJjZSgpO1xuICAgICAgICB9XG5cbiAgICAgICAgZnVuY3Rpb24gaXNSb3dTZWxlY3RlZChyb3cpIHtcbiAgICAgICAgICAgIHJldHVybiB0aGlzLnNlbGVjdGVkUm93c1tyb3dbdGhpcy50YWJsZUNvbmZpZy5yb3dJZEtleV1dO1xuICAgICAgICB9XG5cbiAgICAgICAgZnVuY3Rpb24gbG9hZFN0YXRlUGFyYW1zKHN0YXRlUGFyYW1zKSB7XG4gICAgICAgICAgICB2YXIgcXVlcnlLZXlzID0gdGhpcy50YWJsZUNvbmZpZy5xdWVyeUtleXMsXG4gICAgICAgICAgICAgICAgX3RoaXMgPSB0aGlzO1xuXG4gICAgICAgICAgICBzdGF0ZVBhcmFtcyA9IHN0YXRlUGFyYW1zIHx8ICRzdGF0ZVBhcmFtcztcblxuICAgICAgICAgICAgdGhpcy5zZXRQYWdpbmF0aW9uVmFsdWVzKHtcbiAgICAgICAgICAgICAgICBwYWdlOiBzdGF0ZVBhcmFtc1txdWVyeUtleXMucGFnZV0sXG4gICAgICAgICAgICAgICAgbGltaXQ6IHN0YXRlUGFyYW1zW3F1ZXJ5S2V5cy5saW1pdF1cbiAgICAgICAgICAgIH0pO1xuXG4gICAgICAgICAgICB0aGlzLnNldFNvcnRpbmdWYWx1ZXMoc3RhdGVQYXJhbXNbcXVlcnlLZXlzLnNvcnRCeV0sIHN0YXRlUGFyYW1zW3F1ZXJ5S2V5cy5zb3J0RGlyXSk7XG5cbiAgICAgICAgICAgIC8vIHNldCBmaWx0ZXJzIGZyb20gcXVlcnkgcGFyYW1zXG4gICAgICAgICAgICBfLmVhY2godGhpcy50YWJsZUNvbmZpZy5maWx0ZXJzLCBmdW5jdGlvbiBzZXRGaWx0ZXJzRWFjaCh2YWx1ZSkge1xuICAgICAgICAgICAgICAgIF90aGlzLmZpbHRlcnNbdmFsdWVdID0gc3RhdGVQYXJhbXNbdmFsdWVdO1xuICAgICAgICAgICAgfSk7XG5cbiAgICAgICAgICAgIHJldHVybiB0aGlzO1xuICAgICAgICB9XG5cbiAgICAgICAgZnVuY3Rpb24gc2VsZWN0QWxsUm93cygpIHtcbiAgICAgICAgICAgIHZhciBfdGhpcyA9IHRoaXM7XG5cbiAgICAgICAgICAgIHRoaXMuYWxsU2VsZWN0ZWQgPSAhdGhpcy5hbGxTZWxlY3RlZDtcbiAgICAgICAgICAgIF8uZWFjaCh0aGlzLnNlbGVjdGVkUm93cywgZnVuY3Rpb24gc2VsZWN0QWxsUm93c0VhY2godmFsdWUsIGtleSkge1xuICAgICAgICAgICAgICAgIF90aGlzLnNlbGVjdGVkUm93c1trZXldID0gX3RoaXMuYWxsU2VsZWN0ZWQ7XG4gICAgICAgICAgICB9KTtcblxuICAgICAgICAgICAgcmV0dXJuIHRoaXM7XG4gICAgICAgIH1cblxuICAgICAgICBmdW5jdGlvbiBzZXRQYWdpbmF0aW9uVmFsdWVzKHBhZ2luYXRpb24pIHtcbiAgICAgICAgICAgIHRoaXMucGFnaW5hdGlvbiA9IHRoaXMucGFnaW5hdGlvbiB8fCB7fTtcbiAgICAgICAgICAgIF8uZXh0ZW5kKHRoaXMucGFnaW5hdGlvbiwgcGFnaW5hdGlvbik7XG5cbiAgICAgICAgICAgIHJldHVybiB0aGlzO1xuICAgICAgICB9XG5cbiAgICAgICAgZnVuY3Rpb24gc2V0Um93cyhyb3dzKSB7XG4gICAgICAgICAgICB2YXIgX3RoaXMgPSB0aGlzO1xuXG4gICAgICAgICAgICB0aGlzLnJvd3MgPSByb3dzO1xuICAgICAgICAgICAgdGhpcy5zZWxlY3RlZFJvd3MgPSBfLnJlZHVjZShyb3dzLCBmdW5jdGlvbiBpbml0aWFsaXplU2VsZWN0ZWRSb3dzT2JqZWN0KGFjY3VtLCByb3cpIHtcbiAgICAgICAgICAgICAgICBhY2N1bVtyb3dbX3RoaXMudGFibGVDb25maWcucm93SWRLZXldXSA9IGZhbHNlO1xuICAgICAgICAgICAgICAgIHJldHVybiBhY2N1bTtcbiAgICAgICAgICAgIH0sIHt9KTtcblxuICAgICAgICAgICAgcmV0dXJuIHRoaXM7XG4gICAgICAgIH1cblxuICAgICAgICBmdW5jdGlvbiBzZXRTb3J0aW5nVmFsdWVzKHNvcnRCeSwgc29ydERpcikge1xuICAgICAgICAgICAgdGhpcy5zb3J0QnkgPSBzb3J0QnkgfHwgdGhpcy5zb3J0Qnk7XG4gICAgICAgICAgICB0aGlzLnNvcnREaXIgPSBzb3J0RGlyIHx8IHRoaXMuc29ydERpcjtcblxuICAgICAgICAgICAgcmV0dXJuIHRoaXM7XG4gICAgICAgIH1cblxuICAgICAgICBmdW5jdGlvbiB1cGRhdGVQYWdlKHBhZ2UsIGxpbWl0LCB0b3RhbCkge1xuICAgICAgICAgICAgcmV0dXJuIHRoaXNcbiAgICAgICAgICAgICAgICAuc2V0UGFnaW5hdGlvblZhbHVlcyhwYWdlLCBsaW1pdCwgdG90YWwpXG4gICAgICAgICAgICAgICAgLnVwZGF0ZVRhYmxlKCk7XG4gICAgICAgIH1cblxuICAgICAgICBmdW5jdGlvbiB1cGRhdGVTb3J0KHNvcnRCeSwgc29ydERpcikge1xuICAgICAgICAgICAgcmV0dXJuIHRoaXNcbiAgICAgICAgICAgICAgICAuc2V0U29ydGluZ1ZhbHVlcyhzb3J0QnksIHNvcnREaXIpXG4gICAgICAgICAgICAgICAgLnNldFBhZ2luYXRpb25WYWx1ZXMoe1xuICAgICAgICAgICAgICAgICAgICBwYWdlOiAxXG4gICAgICAgICAgICAgICAgfSlcbiAgICAgICAgICAgICAgICAudXBkYXRlVGFibGUoKTtcbiAgICAgICAgfVxuXG4gICAgICAgIGZ1bmN0aW9uIHVwZGF0ZVRhYmxlKCkge1xuICAgICAgICAgICAgaWYgKCF0aGlzLnBlbmRpbmdSZXF1ZXN0KSB7XG4gICAgICAgICAgICAgICAgJHN0YXRlLmdvKCRzdGF0ZS5jdXJyZW50Lm5hbWUsIHRoaXMuY3JlYXRlUGFyYW1zT2JqZWN0KCkpO1xuICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICByZXR1cm4gdGhpcztcbiAgICAgICAgfVxuXG4gICAgICAgIGZ1bmN0aW9uIHZhbGlkYXRlUmVzb3VyY2UocmVzb3VyY2UpIHtcbiAgICAgICAgICAgIGlmICghXy5pc09iamVjdChyZXNvdXJjZSkpIHtcbiAgICAgICAgICAgICAgICAkbG9nLmVycm9yKCdiYy1zZXJ2ZXItdGFibGUgZGlyZWN0aXZlOiBSZXNvdXJjZSBjYWxsYmFjayBtdXN0IHJldHVybiBhbiBvYmplY3QnKTtcbiAgICAgICAgICAgICAgICByZXR1cm4gZmFsc2U7XG4gICAgICAgICAgICB9XG5cbiAgICAgICAgICAgIGlmICghXy5pc0FycmF5KHJlc291cmNlLnJvd3MpKSB7XG4gICAgICAgICAgICAgICAgJGxvZy5lcnJvcignYmMtc2VydmVyLXRhYmxlIGRpcmVjdGl2ZTogcmV0dXJuZWQgb2JqZWN0IG11c3QgY29udGFpbiBhIHJvd3MgcHJvcGVydHkgdGhhdCBpcyBhbiBhcnJheS4nKTtcbiAgICAgICAgICAgICAgICByZXR1cm4gZmFsc2U7XG4gICAgICAgICAgICB9XG5cbiAgICAgICAgICAgIGlmICghXy5pc09iamVjdChyZXNvdXJjZS5wYWdpbmF0aW9uKSkge1xuICAgICAgICAgICAgICAgICRsb2cuZXJyb3IoJ2JjLXNlcnZlci10YWJsZSBkaXJlY3RpdmU6IHJldHVybmVkIG9iamVjdCBtdXN0IGNvbnRhaW4gYSBwYWdpbmF0aW9uIHByb3BlcnR5IHRoYXQgaXMgYW4gb2JqZWN0LicpO1xuICAgICAgICAgICAgICAgIHJldHVybiBmYWxzZTtcbiAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgcmV0dXJuIHRydWU7XG4gICAgICAgIH1cblxuICAgICAgICByZXR1cm4gU2VydmVyVGFibGU7XG4gICAgfSk7XG4iLCJhbmd1bGFyLm1vZHVsZSgnYmNhcHAtcGF0dGVybi1sYWIuYmMtc2VydmVyLXRhYmxlLWZhY3Rvcnkuc2VydmljZScsIFtcbiAgICAnYmNhcHAtcGF0dGVybi1sYWIuYmMtc2VydmVyLXRhYmxlLnNlcnZpY2UnXG5dKVxuICAgIC5mYWN0b3J5KCdiY1NlcnZlclRhYmxlRmFjdG9yeScsIGZ1bmN0aW9uIGJjU2VydmVyVGFibGVGYWN0b3J5KCRsb2csIEJjU2VydmVyVGFibGUpIHtcbiAgICAgICAgdmFyIHRhYmxlcyA9IHt9LFxuICAgICAgICAgICAgc2VydmljZSA9IHtcbiAgICAgICAgICAgICAgICBjcmVhdGU6IGNyZWF0ZSxcbiAgICAgICAgICAgICAgICBnZXQ6IGdldCxcbiAgICAgICAgICAgICAgICByZW1vdmU6IHJlbW92ZVxuICAgICAgICAgICAgfTtcblxuICAgICAgICBmdW5jdGlvbiBjcmVhdGUodGFibGVJZCwgdGFibGVDb25maWcpIHtcbiAgICAgICAgICAgIGlmICh0YWJsZUlkIGluIHRhYmxlcykge1xuICAgICAgICAgICAgICAgIHJldHVybiBzZXJ2aWNlLmdldCh0YWJsZUlkKTtcbiAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgaWYgKCF0YWJsZUlkKSB7XG4gICAgICAgICAgICAgICAgdGFibGVJZCA9IF8udW5pcXVlSWQoJ2JjLXNlcnZlci10YWJsZS1pbnN0YW5jZS0nKTtcbiAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgdGFibGVzW3RhYmxlSWRdID0gbmV3IEJjU2VydmVyVGFibGUodGFibGVJZCwgdGFibGVDb25maWcpO1xuXG4gICAgICAgICAgICByZXR1cm4gdGFibGVzW3RhYmxlSWRdO1xuICAgICAgICB9XG5cbiAgICAgICAgZnVuY3Rpb24gZ2V0KHRhYmxlSWQpIHtcbiAgICAgICAgICAgIHJldHVybiB0YWJsZXNbdGFibGVJZF07XG4gICAgICAgIH1cblxuICAgICAgICBmdW5jdGlvbiByZW1vdmUodGFibGVJZCkge1xuICAgICAgICAgICAgZGVsZXRlIHRhYmxlc1t0YWJsZUlkXTtcbiAgICAgICAgfVxuXG4gICAgICAgIHJldHVybiBzZXJ2aWNlO1xuICAgIH0pO1xuIiwiLyoqXG4gKiBAbmFtZSBjYy1leHBpcnkgZGlyZWN0aXZlXG4gKiBAZGVzY3JpcHRpb24gQSBkaXJlY3RpdmUgZm9sbG93aW5nIGFuZ3VsYXItY3JlZGl0LWNhcmQncyBhcHByb2FjaCB0byB2YWxpZGF0aW5nL2Zvcm1hdHRpbmcgY3JlZGl0IGNhcmQgZXhwaXJhdGlvbiBkYXRlLlxuICogRXhwZWN0IHRoZSBjYy1leHBpcnkgbmdNb2RlbCB0byBiZSBpbiB0aGUgZm9ybWF0IG9mIGB7IG1vbnRoOiAnMDUnLCB5ZWFyOiAnMjAxNyd9YC5cbiAqL1xuYW5ndWxhci5tb2R1bGUoJ2JjYXBwLXBhdHRlcm4tbGFiLmNyZWRpdC1jYXJkLmNjLWV4cGlyeS5kaXJlY3RpdmUnLCBbXSlcbiAgICAuZGlyZWN0aXZlKCdjY0V4cGlyeScsIGZ1bmN0aW9uIGNjRXhwRGlyZWN0aXZlKCRmaWx0ZXIpIHtcbiAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICAgIGNvbXBpbGU6IGZ1bmN0aW9uICh0RWxlbSwgdEF0dHIpIHtcbiAgICAgICAgICAgICAgICBjb25zdCBFWFBJUkFUSU9OX01BWF9MRU5HVEggPSA3OyAvLyBsZW5ndGggb2YgYE1NIC8geXlgXG5cbiAgICAgICAgICAgICAgICB0QXR0ci4kc2V0KCdhdXRvY29tcGxldGUnLCAnY2MtZXhwJyk7XG4gICAgICAgICAgICAgICAgdEF0dHIuJHNldCgnbWF4bGVuZ3RoJywgRVhQSVJBVElPTl9NQVhfTEVOR1RIKTtcbiAgICAgICAgICAgICAgICB0QXR0ci4kc2V0KCdwYXR0ZXJuJywgJ1swLTldKicpOyAvLyBmb3IgbW9iaWxlIGtleWJvYXJkIGRpc3BsYXlcblxuICAgICAgICAgICAgICAgIHJldHVybiBmdW5jdGlvbiBjY0V4cGlyeUxpbmsoc2NvcGUsIHRFbGVtLCB0QXR0ciwgbmdNb2RlbEN0cmwpIHtcbiAgICAgICAgICAgICAgICAgICAgaW5pdCgpO1xuXG4gICAgICAgICAgICAgICAgICAgIGZ1bmN0aW9uIGluaXQoKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICBuZ01vZGVsQ3RybC4kcGFyc2Vycy51bnNoaWZ0KHBhcnNlcik7XG4gICAgICAgICAgICAgICAgICAgICAgICBuZ01vZGVsQ3RybC4kZm9ybWF0dGVycy5wdXNoKGZvcm1hdHRlcik7XG4gICAgICAgICAgICAgICAgICAgICAgICBuZ01vZGVsQ3RybC4kdmFsaWRhdG9ycy52YWxpZEZ1dHVyZURhdGUgPSB2YWxpZEZ1dHVyZURhdGU7XG5cbiAgICAgICAgICAgICAgICAgICAgICAgIHNjb3BlLiR3YXRjaChnZXRWaWV3VmFsdWUsIHJlbmRlckZvcm1hdHRlZFZpZXcpO1xuICAgICAgICAgICAgICAgICAgICB9XG5cbiAgICAgICAgICAgICAgICAgICAgLyoqXG4gICAgICAgICAgICAgICAgICAgICAqIGdldCB0aGUgaW5wdXQncyB2aWV3IHZhbHVlXG4gICAgICAgICAgICAgICAgICAgICAqL1xuICAgICAgICAgICAgICAgICAgICBmdW5jdGlvbiBnZXRWaWV3VmFsdWUoKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gbmdNb2RlbEN0cmwuJHZpZXdWYWx1ZTtcbiAgICAgICAgICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAgICAgICAgIC8qKlxuICAgICAgICAgICAgICAgICAgICAgKiBmb3JtYXRzIHRoZSBpbnB1dCB2aWV3IHZhbHVlIHRvIGJlIHRoZSBmb3JtYXQgYE1NIC8geXlgIGFuZCByZS1yZW5kZXJzIHZpZXdcbiAgICAgICAgICAgICAgICAgICAgICovXG4gICAgICAgICAgICAgICAgICAgIGZ1bmN0aW9uIHJlbmRlckZvcm1hdHRlZFZpZXcodmlld1ZhbHVlLCBwcmV2Vmlld1ZhbHVlKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICBpZiAoIXZpZXdWYWx1ZSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgICAgICAgICAgICAgLy8gYSBuZXcgdmFsdWUgaXMgYWRkZWQgKGFzIG9wcG9zZWQgdG8gcHJlc3NpbmcgYmFja3NwYWNlKVxuICAgICAgICAgICAgICAgICAgICAgICAgY29uc3QgaXNBZGRpdGlvbiA9IHZpZXdWYWx1ZS5sZW5ndGggPiBwcmV2Vmlld1ZhbHVlLmxlbmd0aDtcblxuICAgICAgICAgICAgICAgICAgICAgICAgbmdNb2RlbEN0cmwuJHNldFZpZXdWYWx1ZShmb3JtYXQodmlld1ZhbHVlLCBpc0FkZGl0aW9uKSk7XG4gICAgICAgICAgICAgICAgICAgICAgICBuZ01vZGVsQ3RybC4kcmVuZGVyKCk7XG4gICAgICAgICAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgICAgICAgICAvKipcbiAgICAgICAgICAgICAgICAgICAgICogVmFsaWRhdGVzIHdoZXRoZXIgdGhlIGVudGVyZWQgZXhwaXJhdGlvbiBkYXRlIGlzIHZhbGlkXG4gICAgICAgICAgICAgICAgICAgICAqL1xuICAgICAgICAgICAgICAgICAgICBmdW5jdGlvbiB2YWxpZEZ1dHVyZURhdGUobW9kZWxWYWx1ZSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgY29uc3Qge21vbnRoLCB5ZWFyfSA9IG1vZGVsVmFsdWU7XG5cbiAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiBpc1ZhbGlkRGF0ZShtb250aCwgeWVhcikgJiYgIWlzUGFzdChtb250aCwgeWVhcik7XG4gICAgICAgICAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgICAgICAgICAvKipcbiAgICAgICAgICAgICAgICAgICAgICogVmFsaWRhdGVzIHdoZXRoZXIgdGhlIGdpdmVuIG1vbnRoIGFuZCB5ZWFyIGFyZSBudW1iZXIgc3RyaW5ncyB3aXRoIGxlbmd0aCBvZiAyIGFuZCA0IHJlc3BlY3RpdmVseVxuICAgICAgICAgICAgICAgICAgICAgKi9cbiAgICAgICAgICAgICAgICAgICAgZnVuY3Rpb24gaXNWYWxpZERhdGUobW9udGgsIHllYXIpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IG1vbnRoUmVnZXggPSAvXlswLTldezJ9JC87XG4gICAgICAgICAgICAgICAgICAgICAgICBjb25zdCB5ZWFyUmVnZXggPSAvXlswLTldezR9JC87XG5cbiAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiBfLmlzU3RyaW5nKG1vbnRoKSAmJlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIF8uaXNTdHJpbmcoeWVhcikgJiZcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBtb250aFJlZ2V4LnRlc3QobW9udGgpICYmXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgeWVhclJlZ2V4LnRlc3QoeWVhcikgJiZcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpc1ZhbGlkTW9udGgobW9udGgpO1xuICAgICAgICAgICAgICAgICAgICB9XG5cbiAgICAgICAgICAgICAgICAgICAgLyoqXG4gICAgICAgICAgICAgICAgICAgICAqIENoZWNrcyB3aGV0aGVyIHRoZSBtb250aCBpcyB2YWxpZFxuICAgICAgICAgICAgICAgICAgICAgKi9cbiAgICAgICAgICAgICAgICAgICAgZnVuY3Rpb24gaXNWYWxpZE1vbnRoKG1vbnRoKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICBtb250aCA9IF8ucGFyc2VJbnQobW9udGgpO1xuXG4gICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gbW9udGggPiAwICYmIG1vbnRoIDwgMTM7XG4gICAgICAgICAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgICAgICAgICAvKipcbiAgICAgICAgICAgICAgICAgICAgICogQ2hlY2tzIHdoZXRoZXIgdGhlIGdpdmVuIG1vbnRoIGFuZCBkYXRlIGlzIGluIHRoZSBwYXN0XG4gICAgICAgICAgICAgICAgICAgICAqL1xuICAgICAgICAgICAgICAgICAgICBmdW5jdGlvbiBpc1Bhc3QobW9udGgsIHllYXIpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiBnZXRDdXJyTW9udGhEYXRlKCkgPiBuZXcgRGF0ZSh5ZWFyLCBtb250aCAtIDEpO1xuICAgICAgICAgICAgICAgICAgICB9XG5cbiAgICAgICAgICAgICAgICAgICAgLyoqXG4gICAgICAgICAgICAgICAgICAgICAqIEdldCB0aGUgZGF0ZSBvYmplY3QgYmFzZWQgb24gY3VycmVudCBtb250aCBhbmQgeWVhclxuICAgICAgICAgICAgICAgICAgICAgKi9cbiAgICAgICAgICAgICAgICAgICAgZnVuY3Rpb24gZ2V0Q3Vyck1vbnRoRGF0ZSgpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IGRhdGUgPSBuZXcgRGF0ZSgpO1xuXG4gICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gbmV3IERhdGUoZGF0ZS5nZXRGdWxsWWVhcigpLCBkYXRlLmdldE1vbnRoKCkpO1xuICAgICAgICAgICAgICAgICAgICB9XG5cbiAgICAgICAgICAgICAgICAgICAgLyoqXG4gICAgICAgICAgICAgICAgICAgICAqIFVzZXMgYW5ndWxhciBkYXRlIGZpbHRlciB0byBmb3JtYXQgZGF0ZSBtb2RlbCB0byBjb3JyZXNwb25kaW5nIHZpZXcgZm9ybWF0XG4gICAgICAgICAgICAgICAgICAgICAqL1xuICAgICAgICAgICAgICAgICAgICBmdW5jdGlvbiBmb3JtYXR0ZXIoZXhwID0ge30pIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IG1vbnRoID0gZXhwLm1vbnRoO1xuICAgICAgICAgICAgICAgICAgICAgICAgY29uc3QgeWVhciA9IGV4cC55ZWFyO1xuXG4gICAgICAgICAgICAgICAgICAgICAgICBpZiAoXy5pc0VtcHR5KG1vbnRoKSAmJiBfLmlzRW1wdHkoeWVhcikpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gJyc7XG4gICAgICAgICAgICAgICAgICAgICAgICB9XG5cbiAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiAkZmlsdGVyKCdkYXRlJykobmV3IERhdGUoeWVhciwgbW9udGggLSAxKSwgJ01NIC8geXknKTtcbiAgICAgICAgICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAgICAgICAgIC8qKlxuICAgICAgICAgICAgICAgICAgICAgKiBQYXJzZXMgdGhlIGZvcm1hdHRlZCB2aWV3IHZhbHVlcyB0byBtb2RlbC4gQ29udmVydHMgMiBkaWdpdCB5ZWFyIHRvIGZ1bGwgNCBkaWdpdCB5ZWFyXG4gICAgICAgICAgICAgICAgICAgICAqIEBwYXJhbSBleHBpcmF0aW9uIHtvYmplY3R9IFRoZSBleHBpcmF0aW9uIG9iamVjdCB7bW9udGgsIHllYXJ9XG4gICAgICAgICAgICAgICAgICAgICAqL1xuICAgICAgICAgICAgICAgICAgICBmdW5jdGlvbiBwYXJzZXIoZXhwaXJhdGlvbikge1xuICAgICAgICAgICAgICAgICAgICAgICAgY29uc3QgYmFzZVllYXIgPSBuZXcgRGF0ZSgpLmdldEZ1bGxZZWFyKCkudG9TdHJpbmcoKS5zbGljZSgwLCAyKTsgLy8gYCcyMCdgXG4gICAgICAgICAgICAgICAgICAgICAgICBjb25zdCB2YWx1ZXMgPSBleHBpcmF0aW9uLnNwbGl0KCcvJyk7XG4gICAgICAgICAgICAgICAgICAgICAgICBjb25zdCBtb250aCA9IHZhbHVlc1swXSA/IHZhbHVlc1swXS50cmltKCkgOiAnJztcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IHllYXIgPSB2YWx1ZXNbMV0gPyBiYXNlWWVhciArIHZhbHVlc1sxXS50cmltKCkgOiAnJztcblxuICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIHsgbW9udGgsIHllYXIgfTtcbiAgICAgICAgICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAgICAgICAgIC8qKlxuICAgICAgICAgICAgICAgICAgICAgKiBmb3JtYXRzIHRoZSB2aWV3IHZhbHVlIHRvIHRoZSBmb3JtICdNTSAvIHl5J1xuICAgICAgICAgICAgICAgICAgICAgKi9cbiAgICAgICAgICAgICAgICAgICAgZnVuY3Rpb24gZm9ybWF0KGV4cFN0ciwgaXNBZGRpdGlvbikge1xuICAgICAgICAgICAgICAgICAgICAgICAgY29uc3QgdmFsdWVzID0gZXhwU3RyLnNwbGl0KCcvJyk7XG4gICAgICAgICAgICAgICAgICAgICAgICBjb25zdCBtb250aCA9IHZhbHVlc1swXSA/IHZhbHVlc1swXS50cmltKCkgOiAnJztcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IHllYXIgPSB2YWx1ZXNbMV0gPyB2YWx1ZXNbMV0udHJpbSgpLnNsaWNlKC0yKSA6ICcnO1xuXG4gICAgICAgICAgICAgICAgICAgICAgICAvLyBkb24ndCBhZGQgc2xhc2hcbiAgICAgICAgICAgICAgICAgICAgICAgIGlmICgoIWlzQWRkaXRpb24gJiYgIXllYXIpIHx8IG1vbnRoLmxlbmd0aCA8IDIpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gbW9udGg7XG4gICAgICAgICAgICAgICAgICAgICAgICB9XG5cbiAgICAgICAgICAgICAgICAgICAgICAgIC8vIGFkZCBzbGFzaCBpbiB0aGUgcmlnaHQgc3BvdFxuICAgICAgICAgICAgICAgICAgICAgICAgaWYgKGlzQWRkaXRpb24gJiYgIXllYXIgJiYgbW9udGgubGVuZ3RoID4gMikge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiBgJHttb250aC5zbGljZSgwLCAyKX0gLyAke21vbnRoLnNsaWNlKDIpfWA7XG4gICAgICAgICAgICAgICAgICAgICAgICB9XG5cbiAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiBgJHttb250aH0gLyAke3llYXJ9YDtcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIH07XG4gICAgICAgICAgICB9LFxuICAgICAgICAgICAgcmVxdWlyZTogJ25nTW9kZWwnLFxuICAgICAgICAgICAgcmVzdHJpY3Q6ICdBJyxcbiAgICAgICAgfTtcbiAgICB9KTtcbiIsImFuZ3VsYXIubW9kdWxlKCdiY2FwcC1wYXR0ZXJuLWxhYi5jcmVkaXQtY2FyZC5jYy1leHBpcnknLCBbXG4gICAgJ2JjYXBwLXBhdHRlcm4tbGFiLmNyZWRpdC1jYXJkLmNjLWV4cGlyeS5kaXJlY3RpdmUnLFxuXSk7XG4iLCIvKipcbiAqIEBuYW1lIGJjLWN2YyBkaXJlY3RpdmVcbiAqIEBkZXNjcmlwdGlvbiBBIGN1c3RvbSBjb21wbGVtZW50YXJ5IGRpcmVjdGl2ZSB0byBhbmd1bGFyLWNyZWRpdC1jYXJkJ3MgYGNjQ3ZjYCBkaXJlY3RpdmUuXG4gKiBUbyBzdXBwb3J0IGFsbG93aW5nIGFuIG9wdGlvbmFsIGN2YyBmaWVsZCAoaS5lLiBTZWN1cmVuZXQpLCB0aGlzIGRpcmVjdGl2ZSBtdXN0IG92ZXJyaWRlXG4gKiB0aGUgdmFsaWRhdGlvbiBwcm92aWRlZCBieSBjY0N2YyBkaXJlY3RpdmUuXG4gKi9cbmFuZ3VsYXIubW9kdWxlKCdiY2FwcC1wYXR0ZXJuLWxhYi5jcmVkaXQtY2FyZC5iYy1jdmMnLCBbXG4gICAgJ2NyZWRpdC1jYXJkcycsXG5dKVxuICAgIC5kaXJlY3RpdmUoJ2JjQ3ZjJywgZnVuY3Rpb24gYmNDdmNEaXJlY3RpdmUoJHBhcnNlKSB7XG4gICAgICAgIHJldHVybiB7XG4gICAgICAgICAgICBsaW5rOiBmdW5jdGlvbiBiY0N2Y0xpbmsoc2NvcGUsIGVsZW1lbnQsIGF0dHJpYnV0ZXMsIG5nTW9kZWwpIHtcbiAgICAgICAgICAgICAgICAvLyBvdmVycmlkZSB0aGUgdmFsaWRhdGlvbiB0byBhbHdheXMgcmV0dXJuIHZhbGlkXG4gICAgICAgICAgICAgICAgLy8gaWYgY3ZjIGlzIG5vdCByZXF1aXJlZFxuICAgICAgICAgICAgICAgIGlmICghJHBhcnNlKGF0dHJpYnV0ZXMubmdSZXF1aXJlZCkoc2NvcGUpKSB7XG4gICAgICAgICAgICAgICAgICAgIG5nTW9kZWwuJHZhbGlkYXRvcnMuY2NDdmMgPSAoKSA9PiB0cnVlO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICBwcmlvcml0eTogNSwgLy8gaGlnaGVyIHByaW9yaXR5IHRvIGVuc3VyZSBjY0N2YydzIGxpbmsgaXMgcmFuIGZpcnN0XG4gICAgICAgICAgICByZXF1aXJlOiAnbmdNb2RlbCcsXG4gICAgICAgICAgICByZXN0cmljdDogJ0EnLFxuICAgICAgICB9O1xuICAgIH0pO1xuIiwiLyoqXG4gKiBAbmFtZSB0cnVzdEFzSHRtbFxuICogQGRlc2NyaXB0aW9uIFNpbXBsZSB1dGlsaXR5IGZpbHRlciB0byBydW4gdGhlIGdpdmVuIGh0bWwgc3RyaW5nIHRocm91Z2ggYW5ndWxhcidzICRzY2UudHJ1c3RBc0h0bWwgZnVuY3Rpb24uXG4gKlxuICogQHBhcmFtIHtTdHJpbmd9IHRleHQgVGhlIGh0bWwgc3RyaW5nIHRvIHRydXN0XG4gKiBAcmV0dXJuIHtTdHJpbmd9IEFuIGFuZ3VsYXItdHJ1c3RlZCBvYmplY3QgY29udGFpbmluZyB0aGUgaHRtbFxuICpcbiAqIEBleGFtcGxlIGA8cCBuZy1iaW5kLWh0bWw9XCJyYXdIdG1sIHwgdHJ1c3RBc0h0bWxcIj48L3A+YFxuICovXG5hbmd1bGFyLm1vZHVsZSgnYmNhcHAtcGF0dGVybi1sYWIudXRpbC50cnVzdEFzSHRtbCcsIFtdKVxuICAgIC5maWx0ZXIoJ3RydXN0QXNIdG1sJywgZnVuY3Rpb24gdHJ1c3RBc0h0bWwoJHNjZSl7XG4gICAgICAgIHJldHVybiBmdW5jdGlvbih0ZXh0KSB7XG4gICAgICAgICAgICByZXR1cm4gJHNjZS50cnVzdEFzSHRtbCh0ZXh0KTtcbiAgICAgICAgfTtcbiAgICB9KTtcbiJdLCJzb3VyY2VSb290IjoiL3NvdXJjZS8ifQ==