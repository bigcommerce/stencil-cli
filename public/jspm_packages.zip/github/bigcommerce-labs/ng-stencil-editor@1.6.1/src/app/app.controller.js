export default class AppCtrl {
    /*@ngInject*/
    constructor($window, BC_SEED_DATA, channelService, configService, gettextCatalog, sessionService) {
        this._$window = $window;
        this._channelService = channelService;
        this._confirmExit = _.bind(this.confirmExit, this);
        this._configService = configService;
        this._gettextCatalog = gettextCatalog;
        this._sessionService = sessionService;

        $window.addEventListener('mouseover', _.bind(_.throttle(this.emitSetCookie, 2000), this));
        $window.addEventListener('beforeunload', this._confirmExit);
        $window.addEventListener('unload', _.bind(this.resetConfig, this));

        // CLI sets disabledHeartbeat to true
        if (!BC_SEED_DATA.disableHeartbeat) {
            sessionService.registerIdleHandlers();
            sessionService.registerIdleTimeout(this._confirmExit);
        }
    }

    confirmExit(event) {
        if (this._configService.hasChanges()) {
            const confirmationMessage = this._gettextCatalog.getString('You will lose all unsaved changes.');

            // Cross-browser compatibility
            event.returnValue = confirmationMessage;

            // beforeunload expects any return to trigger the confirmation alert
            return confirmationMessage;
        }
    }

    emitSetCookie() {
        this._channelService.emit('set-cookie', {
            data: {
                configurationId: this._configService.getConfig().id
            }
        });
    }

    notIdle() {
        return this._sessionService.heartbeat()
            .then(resp => {
                if (!resp.ok) {
                    this.reloadPage();
                }
            })
            .catch(() => this.reloadPage());
    }

    reloadPage() {
        this._$window.location.reload();
    }

    resetConfig() {
        if (this._configService.hasChanges()) {
            this._configService.clear();
            this._configService.saveNative();
        }
    }
}
