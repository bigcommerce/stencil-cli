import BaseModalCtrl from 'src/app/modals/base-modal.controller.js';

export default class extends BaseModalCtrl {
    /*@ngInject*/
    constructor($modalInstance, SESSION) {
        super($modalInstance);

        this.countdown = SESSION.WARNING_DURATION;
    }
}
