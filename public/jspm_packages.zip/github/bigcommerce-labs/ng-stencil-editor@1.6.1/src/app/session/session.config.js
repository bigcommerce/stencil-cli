export default function config(IdleProvider, KeepaliveProvider, SESSION) {
    'ngInject';

    IdleProvider.idle(SESSION.IDLE_DURATION);
    IdleProvider.timeout(SESSION.WARNING_DURATION);
    KeepaliveProvider.interval(SESSION.KEEPALIVE_INTERVAL);
    KeepaliveProvider.http(SESSION.KEEPALIVE_HTTP);
}
