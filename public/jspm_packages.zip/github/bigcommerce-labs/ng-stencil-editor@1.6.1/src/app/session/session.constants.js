export default {
    // Time in seconds
    IDLE_DURATION: 60 * 15,
    KEEPALIVE_HTTP: '/admin/remote.php?w=heartbeat',
    KEEPALIVE_INTERVAL: 60 * 5,
    PHP_LOGOUT_URL: '/admin/index.php?ToDo=logOut&ajaxLogout=1&type=idle',
    WARNING_DURATION: 60 * 5,
};
