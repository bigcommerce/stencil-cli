export default class {
    /*@ngInject*/
    constructor ($timeout, channelService, loadingService) {
        this._$timeout = $timeout;
        this._loadingService = loadingService;
        this.createChannel = channelService.createChannel.bind(channelService);

        // set loading to true for initial iframe load
        this.isLoading(true);
    }

    isLoading(value) {
        this._$timeout(() => this._loadingService.isLoading(value));

        return value;
    }
}
