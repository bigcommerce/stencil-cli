import CliNotAvailableModalCtrl from 'src/app/modals/cli-not-available-modal/cli-not-available-modal.controller.js';
import ConfirmClearModalCtrl from 'src/app/modals/confirm-clear-modal/confirm-clear-modal.controller.js';
import ConfirmPublishModalCtrl from 'src/app/modals/confirm-publish-modal/confirm-publish-modal.controller.js';
import ConfirmResetModalCtrl from 'src/app/modals/confirm-reset-modal/confirm-reset-modal.controller.js';
import UnhandledErrorModalCtrl from 'src/app/modals/unhandled-error-modal/unhandled-error-modal.controller.js';

export default class StencilEditorCtrl {
    /*@ngInject*/
    constructor($modal, $q, $timeout, BC_APP_CONFIG, channelService, configService, flashMessages, fontsService, gettextCatalog, loadingService, variationService, versionService) {
        this._$modal = $modal;
        this._$q = $q;
        this._$timeout = $timeout;
        this._BC_APP_CONFIG = BC_APP_CONFIG;
        this._channelService = channelService;
        this._configService = configService;
        this._flashMessages = flashMessages;
        this._fontsService = fontsService;
        this._gettextCatalog = gettextCatalog;
        this._loadingService = loadingService;
        this._variationService = variationService;
        this._versionService = versionService;

        this.init();
    }

    init() {
        // Expose the current model data to the template
        this.config = this._configService.getConfig();
        this.fieldsets = this._versionService.getFieldsets();
        this.version = this._versionService.getVersion();

        // inject the initial fonts for the current configuration settings
        this._fontsService.setInitialFonts(this.config.settings);

        this.hydrateFields(this.fieldsets);
        this.reloadStylesheets(this.config.id);
    }

    apply() {
        return this._$modal
            .open({
                controller: ConfirmPublishModalCtrl,
                controllerAs: 'confirmPublishModalCtrl',
                templateUrl: 'app/modals/confirm-publish-modal/confirm-publish-modal.tpl.html',
                windowClass: 'modal'
            })
            .result.then(() => {
                const successMessage = this._gettextCatalog.getString('Variation was successfully applied to your store.');

                return this._configService.publish(this.config)
                    .then(config => this._variationService.updateCurrentVariation(config))
                    .then(() => this._flashMessages.success(successMessage))
                    .then(() => this.resetForm())
                    .catch(error => this.openErrorModal(error));
            });
    }

    clear() {
        return this._$modal
            .open({
                controller: ConfirmClearModalCtrl,
                controllerAs: 'confirmClearModalCtrl',
                templateUrl: 'app/modals/confirm-clear-modal/confirm-clear-modal.tpl.html',
                windowClass: 'modal'
            })
            .result.then(() => {
                return this._configService.clear()
                    .then(() => this._configService.refreshIframe())
                    .then(() => this.resetForm());
            });
    }

    hydrateFields(fieldsets = []) {
        _.each(fieldsets, (fieldset) => {
            _.each(fieldset.settings, (field) => {
                const key = field.key;
                const settings = this.config.settings;

                if (key && _.isUndefined(settings[key])) {
                    field.defaultValue = '';
                }

                field.templateOptions.onChange = newValue => {
                    const config = this._configService.getConfig();
                    const requiresRefresh = field.data.forceReload;

                    field.templateOptions.updated = true;

                    this._configService.hasChanges(true);
                    this._configService
                        .preview(config, { requiresRefresh })
                        .then(resp => resp.configurationId)
                        .then(configId => {
                            if (!requiresRefresh) {
                                return this.reloadStylesheets(configId);
                            }
                        });

                    if (field.type === 'font') {
                        this._fontsService.addFont(newValue);
                    }
                };
            });
        });
    }

    /**
     * Returns whether *any* unsaved changes requires reload.
     * @return {Boolean}
     */
    needsForceReload() {
        const changes = this._configService.findChanges();

        return _.any(changes, (value, key) => this._versionService.needsForceReload(key));
    }

    openErrorModal(error = {}) {
        let options;

        if (error.status === 405) {
            options = {
                controller: CliNotAvailableModalCtrl,
                controllerAs: 'cliNotAvailableModalCtrl',
                templateUrl: 'app/modals/cli-not-available-modal/cli-not-available-modal.tpl.html',
                windowClass: 'modal'
            };
        } else {
            options = {
                controller: UnhandledErrorModalCtrl,
                controllerAs: 'unhandledErrorModalCtrl',
                templateUrl: 'app/modals/unhandled-error-modal/unhandled-error-modal.tpl.html',
                windowClass: 'modal'
            };
        }

        return this._$modal.open(options);
    }

    reloadStylesheets(configurationId) {
        this._loadingService.isLoading(true);

        return this._channelService.emit('reload-stylesheets', {
            data: { configurationId },
            error: _.bind(this.reloadStylesheetsComplete, this),
            success: _.bind(this.reloadStylesheetsComplete, this)
        });
    }

    reloadStylesheetsComplete() {
        this._$timeout.cancel(this._loadingTimeout);

        return this._$timeout(() => {
            this._loadingService.isLoading(false);
        });
    }

    resetForm() {
        // ensure our form is in its pristine state
        if (this.editorForm) {
            this.editorForm.$setPristine();
            this.editorForm.$setUntouched();

            _.each(this.fieldsets, (fieldset) => {
                _.each(fieldset.settings, (field) => {
                    if (field.templateOptions) {
                        field.templateOptions.updated = false;
                    }
                });
            });
        }
    }

    resetVariant() {
        return this._$modal
            .open({
                controller: ConfirmResetModalCtrl,
                controllerAs: 'confirmResetModalCtrl',
                templateUrl: 'app/modals/confirm-reset-modal/confirm-reset-modal.tpl.html',
                windowClass: 'modal'
            })
            .result.then(() => {
                const activeVariation = this._variationService.activeVariation();

                this._configService
                    .reset(activeVariation)
                    .then(() => this.resetForm())
                    .catch(error => this.openErrorModal(error));
            });
    }

    submit() {
        const successMessage = this._gettextCatalog.getString('Your changes were saved successfully.');

        this._configService.save(this.config)
            .then(() => this._flashMessages.success(successMessage))
            .then(() => this.resetForm())
            .catch(error => this.openErrorModal(error));
    }

    variationChange() {
        this.resetForm();
        this.init();
        this._configService.refreshIframe();
    }

    variationChanging() {
        this._loadingService.isLoading(true);
    }
}
