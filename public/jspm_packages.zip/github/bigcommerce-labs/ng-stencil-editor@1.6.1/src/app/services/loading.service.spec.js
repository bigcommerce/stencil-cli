import 'angular';
import 'angular-mocks';

import LoadingService from './loading.service.js';

describe('Loading Service: ', () =>  {
    function createService() {
        return new LoadingService();
    }

    describe('isLoading method', () => {
        it('should get the internal _isLoading value (false) when no argument supplied', () => {
            const loadingService = createService();

            expect(loadingService.isLoading()).toBe(false);
        });

        it('should set the internal _isLoading value if an argument is supplied', () => {
            const loadingService = createService();

            loadingService.isLoading(true);

            expect(loadingService.isLoading()).toBe(true);
        });
    });
});
