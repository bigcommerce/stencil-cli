import 'angular';
import 'angular-mocks';

import AppCtrl from './app.controller.js';

describe('App Ctrl: ', () => {
    let channelService = jasmine.createSpyObj('channelService', [
        'emit',
    ]);
    let configService = jasmine.createSpyObj('configService', [
        'clear',
        'getConfig',
        'hasChanges',
        'reset',
        'saveNative',
    ]);
    let sessionService = jasmine.createSpyObj('sessionService', [
        'heartbeat',
        'registerIdleHandlers',
        'registerIdleTimeout',
    ]);
    let $cookies = jasmine.createSpyObj('$cookies', ['remove']);
    let $window = jasmine.createSpyObj('$window', ['addEventListener']);
    let $controller;
    let $rootScope;
    let $scope;
    let $q;
    let controller;

    function createController($scope) {
        return $controller(AppCtrl, {
            $cookies,
            $scope,
            $window,
            channelService,
            configService,
            sessionService
        });
    }

    beforeEach(inject(($injector) => {
        $rootScope = $injector.get('$rootScope');
        $scope = $rootScope.$new();
        $controller = $injector.get('$controller');
        $q = $injector.get('$q');
    }));

    describe('constructor', () => {
        it('should setup the eventListeners', () => {
            controller = createController($scope);

            expect($window.addEventListener).toHaveBeenCalledWith('beforeunload', jasmine.any(Function));
            expect($window.addEventListener).toHaveBeenCalledWith('unload', jasmine.any(Function));
            expect($window.addEventListener).toHaveBeenCalledWith('mouseover', jasmine.any(Function));
        });
    });

    describe('confirmExit() method', () => {
        const event = {};

        it('should return a confirmation message', () => {
            controller = createController($scope);
            configService.hasChanges.and.returnValue(true);

            expect(controller.confirmExit(event)).toEqual(jasmine.any(String));
        });

        it('should set the event.returnValue for cross-browser support', () => {
            controller = createController($scope);

            const confirmationMessage = controller.confirmExit(event);

            expect(event.returnValue).toEqual(confirmationMessage);
        });
    });

    describe('notIdle() method', () => {
        it('should call sessionSerivce.heartbeat()', () => {
            sessionService.heartbeat.and.returnValue($q.when());
            controller = createController($scope);

            controller.notIdle();

            expect(sessionService.heartbeat).toHaveBeenCalled();
        });

        it('should call reloadPage() if the request fails', () => {
            sessionService.heartbeat.and.returnValue($q.reject());
            controller = createController($scope);
            spyOn(controller, 'reloadPage');

            controller.notIdle();
            $rootScope.$apply();

            expect(controller.reloadPage).toHaveBeenCalled();
        });

        it('should call reloadPage() if the request data is not ok', () => {
            sessionService.heartbeat.and.returnValue($q.when({
                data: {
                    ok: false
                }
            }));
            controller = createController($scope);
            spyOn(controller, 'reloadPage');

            controller.notIdle();
            $rootScope.$apply();

            expect(controller.reloadPage).toHaveBeenCalled();
        });
    });

    describe('reloadPage() method', () => {
        it('should call $window.location.reload()', () => {
            controller = createController($scope);
            controller._$window = {
                location: {
                    reload: jasmine.createSpy()
                }
            };

            controller.reloadPage();

            expect(controller._$window.location.reload).toHaveBeenCalled();
        });
    });

    describe('resetConfig() method', () => {
        configService.hasChanges.and.returnValue(true);

        it('should call configService reset method', () => {
            controller = createController($scope);

            controller.resetConfig();

            expect(configService.clear).toHaveBeenCalled();
        });

        it('should call configService saveNative method', () => {
            controller = createController($scope);

            controller.resetConfig();

            expect(configService.saveNative).toHaveBeenCalled();
        });
    });
});
