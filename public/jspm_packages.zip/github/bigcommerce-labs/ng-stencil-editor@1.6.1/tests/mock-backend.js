import 'angular';
import 'angular-mocks';
import 'src/app/app.module.js';
import mockConfig from './mocks/config.mock.js';
import mockVersion from './mocks/version.mock.js';
import mockVariation from './mocks/variation.mock.js';

function mockBackend(_, $httpBackend, API) {
    // GET /configuration
    $httpBackend.whenGET(new RegExp(API.CONFIG_PATH + '/.*')).respond({ data: mockConfig });

    // POST /configuration
    $httpBackend.whenPOST(new RegExp(API.CONFIG_PATH + '/.*')).respond({ data: {
        configurationId: 'newConfigurationId'
    }});

    // GET /version
    $httpBackend.whenGET(new RegExp(API.VERSION_PATH + '/.*')).respond({ data: mockVersion });

    // GET /variation
    $httpBackend.whenGET(new RegExp(API.VARIATION_PATH + '/.*')).respond({ data: mockVariation });

    // Pass through
    $httpBackend.whenDELETE(/.*/).passThrough();
    $httpBackend.whenGET(/.*/).passThrough();
    $httpBackend.whenPATCH(/.*/).passThrough();
    $httpBackend.whenPOST(/.*/).passThrough();
    $httpBackend.whenPUT(/.*/).passThrough();
}

// Bootstrap with mock data
angular.module('ng-stencil-editor.mock-backend', ['ngMockE2E']).run(mockBackend);
angular.module('ng-stencil-editor').requires.push('ng-stencil-editor.mock-backend');

export default mockBackend;
