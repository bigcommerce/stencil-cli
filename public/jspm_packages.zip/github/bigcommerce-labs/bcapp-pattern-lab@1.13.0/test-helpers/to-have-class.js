/**
 * Custom "toHaveClass" matcher.
 *
 * From https://gist.github.com/fpirsch/1790c604a6d54d372a40
 *
 * Usage :
 *   expect($('html')).toHaveClass('wf-active');
 *   expect($('#button')).not.toHaveClass('disabled');
 **/

beforeEach(function() {
    this.addMatchers({
        toHaveClass: function (expected) {
            var deferred = protractor.promise.defer();
            this.actual.getAttribute('class').then(function(classes) {
                var hasClass = classes.split(' ').indexOf(expected) >= 0;
                deferred.fulfill(hasClass);
            });
            return deferred.promise;
        }
    });
});
