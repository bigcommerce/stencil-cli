/* */ 
angular.module('bcapp-pattern-lab.form-field.directive', [])
    .directive('formField', function formFieldDirective($log) {
        return {
            require: '^form',
            restrict: 'EA',
            scope: true,
            link: {
                pre: function formFieldLink(scope, element, attrs) {
                    // Inherited by the form-field-errors directive to avoid redeclaration
                    scope.property = attrs.property;
                },

                post: function formFieldLink(scope, element, attrs, formCtrl) {
                    // Locates and watches the matching input/select/etc (based on its name attribute) in the parent form
                    var property = attrs.property,
                        propertyValidFn = function propertyValidFn() { return formCtrl[property].$valid; },
                        formSubmittedFn = function formSubmittedFn() { return formCtrl.$submitted; };

                    element.addClass('form-field');

                    // If a property wasn't provided, we can't do much else
                    if (!property) {
                        return;
                    }

                    // If a property was provided, but no ng-model was defined for the field, validation won't work
                    if (!formCtrl[property]) {
                        return $log.info('Form fields containing inputs without an ng-model property will not be validated');
                    }

                    init();

                    function init() {
                        // Update the interface if the form is submitted or the property's validity state changes
                        scope.$watch(formSubmittedFn, checkValidity);
                        scope.$watch(propertyValidFn, checkValidity);
                    }

                    function checkValidity() {
                        // Only show an error if the user has already attempted to submit the form
                        element.toggleClass('form-field--error', formCtrl.$submitted && formCtrl[property].$invalid);
                    }
                }
            }
        };
    });
