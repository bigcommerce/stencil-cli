/* */ 
angular.module('bcapp-pattern-lab.sprite', [
    'bcapp-pattern-lab.sprite.directive'
]);
