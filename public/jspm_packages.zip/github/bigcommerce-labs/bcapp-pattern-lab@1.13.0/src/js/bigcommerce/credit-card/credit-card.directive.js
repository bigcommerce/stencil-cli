/**
 * @name credit-card directive
 * @description Component containing cc number, cvc, name, and expiry. Has an isolated scope with no controller.
 * @require form
 *
 * @param ccData {object} Contains ccNumber, ccType, ccExpiry, and ccName
 * @param ccConfig {object} The configuration object. Currently supporting `cardCode` and `fullName`, both boolean to indicate
 * whether the respective fields should be shown
 */
angular.module('bcapp-pattern-lab.credit-card.directive', [])
    .directive('creditCard', function creditCardDirective() {
        return {
            link: function creditCardLink(scope, elem, attr, formCtrl) {
                const defaultConfig = {
                    cardCode: true,
                    fullName: true,
                };

                scope.ccConfig = _.defaults(scope.ccConfig, defaultConfig);

                /**
                 * The credit card type is deduced by the `ccNumber` directive. This is in turn exposed
                 * as `$ccEagerType` on the input control element. Watch for changes and bind the type to the corresponding
                 * value on ccData.
                 */
                scope.$watch(getCcType, setCcType);

                scope.formCtrl = formCtrl;

                function getCcType() {
                    return formCtrl.ccNumber.$ccEagerType;
                }

                function setCcType(type) {
                    scope.ccData.ccType = type;
                }
            },
            require: '^form',
            restrict: 'EA',
            scope: {
                ccData: '=',
                ccConfig: '=',
            },
            templateUrl: 'src/js/bigcommerce/credit-card/credit-card.tpl.html'
        };
    });
