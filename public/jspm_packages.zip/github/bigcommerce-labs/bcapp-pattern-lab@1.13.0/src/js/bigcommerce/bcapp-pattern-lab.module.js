/* */ 
angular.module('bcapp-pattern-lab', [
    'gettext',
    'ngAnimate',
    'ngMessages',
    'mm.foundation',
    'bcapp-pattern-lab-templates',
    'bcapp-pattern-lab.bc-datepicker',
    'bcapp-pattern-lab.bc-dropdown',
    'bcapp-pattern-lab.bc-modal',
    'bcapp-pattern-lab.bc-pagination',
    'bcapp-pattern-lab.bc-server-table',
    'bcapp-pattern-lab.checkbox-list',
    'bcapp-pattern-lab.credit-card',
    'bcapp-pattern-lab.form',
    'bcapp-pattern-lab.form-field',
    'bcapp-pattern-lab.icon',
    'bcapp-pattern-lab.loading-notification',
    'bcapp-pattern-lab.loading-overlay',
    'bcapp-pattern-lab.sprite',
    'bcapp-pattern-lab.switch'
]);
