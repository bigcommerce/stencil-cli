/* */ 
angular.module('bcapp-pattern-lab.loading-overlay.directive', [
    'bcapp-pattern-lab.loading-overlay.controller'
])
    .directive('loadingOverlay', function loadingOverlay() {
        return {
            bindToController: true,
            controller: 'LoadingOverlayCtrl as loadingOverlayCtrl',
            restrict: 'A',
            scope: {
                debounce: '=?',
                loading: '=?loadingOverlay',
                useUiRouter: '=?'
            },
            templateUrl: 'src/js/bigcommerce/loading-overlay/loading-overlay.tpl.html',
            transclude: true,
            compile: function loadingOverlayCompile(element) {
                element.addClass('loadingOverlay-container');
            }
        };
    });
