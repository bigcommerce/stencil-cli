/* */ 
angular.module('website.bc-server-table.constants', [])
    .constant('DEMO_TABLE_CONFIG', {
        queryKeys: {
            page: 'page',
            limit: 'limit',
            sortBy: 'sort-by',
            sortDir: 'sort-order'
        },
        sortDirValues: {
            asc: 'asc',
            desc: 'dsc'
        },
        filters: ['time'],
        rowIdKey: 'name'
    })
    .constant('DEMO_TABLE_ID', 'demo-table');
