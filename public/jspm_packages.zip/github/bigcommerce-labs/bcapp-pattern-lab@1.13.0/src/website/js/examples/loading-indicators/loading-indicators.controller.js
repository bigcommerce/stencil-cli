/* */ 
angular.module('website.loading-indicators.controller', [])
    .controller('LoadingIndicatorsCtrl', function($rootScope, $timeout) {

        var ctrl = this;

        ctrl.fakeHttpRequest = fakeHttpRequest;
        ctrl.fakeStateTransition = fakeStateTransition;
        ctrl.toggleManualLoading = toggleManualLoading;

        function fakeHttpRequest() {
            // Here we are emitting the event manually, in a real scenario
            // you should inject the ajaxRequestStatus httpInterceptor from ng-common
            // which will emit these events automatically on normal $http requests
            $rootScope.$emit('ajaxRequestRunning', true);

            $timeout(function() {
                $rootScope.$emit('ajaxRequestRunning', false);
            }, 3000);
        }

        function fakeStateTransition() {
            // Here we are emitting the event manually, in a real scenario
            // you wouldnt do this.
            $rootScope.$emit('$stateChangeStart', true);

            $timeout(function() {
                $rootScope.$emit('$stateChangeSuccess', false);
            }, 3000);
        }

        function toggleManualLoading() {
            ctrl.manualLoading = !ctrl.manualLoading;
        }
    });
