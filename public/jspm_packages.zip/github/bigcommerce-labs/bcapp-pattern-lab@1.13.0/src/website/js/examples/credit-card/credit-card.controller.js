/* */ 
angular.module('website.credit-card.controller', [])

    .controller('CreditCardCtrl', function CreditCardCtrl() {
        var ctrl = this;

        ctrl.ccData = {
            ccNumber: '',
            ccCvv: '',
            ccName: '',
            ccExpiry: {
                month: '',
                year: ''
            },
            ccType: '',
        };

        ctrl.ccConfig = {
            cardCode: true,
            fullName: true,
        };
    });
