/* */ 
"format global";
var gulp = require('gulp'),
    config = require('../config'),
    htmlreplace = require('gulp-html-replace');

function replaceHTML() {
    var stream = gulp.src(config.templates.public + '/*.html')
        .pipe(htmlreplace({
            patternLabJS: 'js/bcapp/bcapp-pattern-lab.min.js',
            websiteJS: 'js/website/website.min.js'
        }))
        .pipe(gulp.dest(config.templates.public));
    return stream;
}

gulp.task('htmlReplace:deploy', replaceHTML);
