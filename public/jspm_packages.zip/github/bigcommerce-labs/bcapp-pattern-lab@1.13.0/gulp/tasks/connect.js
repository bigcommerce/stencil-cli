/* */ 
"format global";
var gulp = require('gulp'),
    config = require('../config'),
    connect = require('gulp-connect');

gulp.task('connect', function() {
    connect.server({
        port: 8000,
        root: ['.', config.dest.build]
    });
});
