/* */ 
"format global";
var gulp = require('gulp'),
    config = require('../config'),
    handleErrors = require('../util/handleErrors'),
    imagemin = require('gulp-imagemin');

function svgs() {

    var stream = gulp.src([
            config.svg.src + '/**/*',
            '!' + config.icons.src + '/**' // Don't include icons in this, this is in the icons task
        ])
        .pipe(imagemin())
        .on('error', handleErrors)
        .pipe(gulp.dest(config.svg.build));

    return stream;

}

gulp.task('svg', svgs);
