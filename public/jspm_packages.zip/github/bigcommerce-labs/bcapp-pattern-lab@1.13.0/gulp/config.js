/* */ 
"format global";
module.exports = {
    dest: {
        build: './build',
        dist: './dist',
        public: './public',
        src: './src'
    },
    css: {
        build: './build/css',
        dist: './dist/css',
        public: './public/css',
        src: './src/scss'
    },
    icons: {
        build: './build/svg/icons',
        src: './src/svg/icons'
    },
    images: {
        build: './build/images',
        dist: './dist/images',
        public: './public/images',
        src: './src/images'
    },
    spriteImages: {
        src: './src/sprite-images'
    },
    svg: {
        build: './build/svg',
        dist: './dist/svg',
        public: './public/svg',
        src: './src/svg'
    },
    fonts: {
        build: './build/fonts',
        dist: './dist/fonts',
        public: './public/fonts',
        src: './src/fonts'
    },
    js: {
        build: './build/js',
        dist: './dist/js',
        public: './public/js',
        src: './src/js'
    },
    templates: {
        build: './build',
        public: './public',
        src: './src/website'
    },
    materialDesignIcons: {
        bower: './src/vendor/bower_components/material-design-icons',
        src: './src/svg/icons/material-design-icons'
    },
    bower_components: [
        // Components also included in ng-common or microapps_common
        './src/vendor/bower_components/angular/angular.js',
        './src/vendor/bower_components/angular-animate/angular-animate.min.js',
        './src/vendor/bower_components/angular-gettext/dist/angular-gettext.min.js',
        './src/vendor/bower_components/angular-ui-router/release/angular-ui-router.js',
        './src/vendor/bower_components/angular-mocks/angular-mocks.js',
        './src/vendor/bower_components/angular-sanitize/angular-sanitize.js',
        './src/vendor/bower_components/lodash/dist/lodash.js',
        './src/vendor/bower_components/moment/moment.js',

        // Specifically just for showing code examples in the pattern lab website
        './src/vendor/bower_components/codemirror/lib/codemirror.js',
        './src/vendor/bower_components/codemirror/mode/xml/xml.js',
        './src/vendor/bower_components/codemirror/mode/htmlmixed/htmlmixed.js',
        './src/vendor/bower_components/codemirror/mode/css/css.js',
        './src/vendor/bower_components/codemirror/mode/sass/sass.js',
        './src/vendor/bower_components/codemirror/mode/javascript/javascript.js',
        './src/vendor/bower_components/angular-ui-codemirror/ui-codemirror.js',
    ],
    bower_components_required: [
        // Components required by bcapp-pattern-lab component, but not included in other common libraries
        './src/vendor/bower_components/angular-credit-cards/release/angular-credit-cards.js',
        './src/vendor/bower_components/angular-foundation/mm-foundation.js',
        './src/vendor/bower_components/angular-messages/angular-messages.js',
        './src/vendor/bower_components/moment/moment.js',
        './src/vendor/bower_components/rome/dist/rome.standalone.js'
    ],
    bcAppDirectory: process.env.BC_APP_DIR || '../bigcommerce',
    seleniumServerJar: process.env.SELENIUM_SERVER_JAR || '/usr/local/lib/node_modules/protractor/selenium/selenium-server-standalone-2.42.2.jar',
    chromeDriver: process.env.CHROME_DRIVER || '/usr/local/lib/node_modules/protractor/selenium/chromedriver',
    serverPort: 8000
};
