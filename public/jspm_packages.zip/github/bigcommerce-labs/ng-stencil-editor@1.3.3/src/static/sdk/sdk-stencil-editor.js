'use strict';

(function stencilEditorSDK(window, Channel) {
    var _cookieName = 'preview_config_id',
        // Adding a dot because cookie set by bcapp also adds a dot
        _cookieDomain = (window.location.hostname === 'localhost' ? '' : '.') + window.location.hostname,
        _noop = function() {};

    init();

    function init() {
        if (runningInIframe()) {
            registerJsChannelEvents();
        } else {
            insertBanner();
        }
    }

    /**
     * Adds a link element with the passed font url
     * @param {string} fontUrl
     * @param {object} options
     */
    function addFont(fontUrl, options) {
        var link = document.createElement('link'),
            linkLoadHandler;

        options = options || {};
        options.error = options.error || _noop;
        options.success = options.success || _noop;

        link.setAttribute('rel', 'stylesheet');
        link.setAttribute('href', fontUrl);

        linkLoadHandler = link.addEventListener('load', function newFontLoaded() {
            options.success(fontUrl);

            link.removeEventListener('load', linkLoadHandler);

            focusBody();
        });

        document.head.appendChild(link);

        return true;
    }

    /**
     * Removes the cookie and reloads the page
     */
    function closePreview(event) {
        event.preventDefault();

        window.Cookies.remove(_cookieName, {
            domain: _cookieDomain
        });

        reloadPage();
    }

    /**
     * Force the browser to repaint the page after a stylesheet update
     */
    function focusBody() {
        document.body.focus();
    }

    /**
     * Generate a stylesheet url replacing the configId
     * and adding a query parameter with a timestamp
     * @param  {string} url
     * @param  {string} configurationId
     * @return {string}
     */
    function generateStylesheetUrl(url, configurationId) {
        var queryIndex = url.indexOf('?'),
            stylesheetUrlRegex = /(\/stencil\/.*?\/)(.+?)(\/.*)/i,
            match,
            baseUrl,
            cssPath;

        if (queryIndex !== -1) {
            url = url.substring(0, queryIndex);
        }

        match = url.match(stylesheetUrlRegex);

        if (!match) {
            throw new Error('Supplied url is not a valid stylesheet url');
        }

        baseUrl = match[1];
        cssPath = match[3];

        return baseUrl + configurationId + cssPath + '?preview=' + Date.now();
    }

    /**
     * Return an array of stylesheet link elements
     * @return {array}
     */
    function getStylesheets() {
        var stylesheets = document.head.querySelectorAll('link[data-stencil-stylesheet]');

        return Array.prototype.slice.call(stylesheets);
    }

    /**
     * Creates and prepends the Preview banner to the document body.
     */
    function insertBanner() {
        var banner = document.createElement('div'),
            bannerHeight,
            bodyMarginTop;

        banner.className = 'stencilEditorPreview-banner';
        banner.innerHTML =
            '<style>' +
                '.stencilEditorPreview-banner { ' +
                    'background-color: #556273;' +
                    'display: table;' +
                    'height: 62px;' +
                    'padding: 0 20px;' +
                    'position: absolute;' +
                    'top: -63px;' +
                    'width: 100%;' +
                '}' +
                '.stencilEditorPreview-close {' +
                    'color: #FFFFFF;' +
                    'display: table-cell;' +
                    'text-align: right;' +
                    'text-decoration: none;' +
                    'vertical-align: middle;' +
                '}' +
                '.stencilEditorPreview-logo {' +
                    'display: table-cell;' +
                    'height: 55px;' +
                    'vertical-align: middle;' +
                    'width: 55px;' +
                '}' +
                '.stencilEditorPreview-text {' +
                    'color: #FFFFFF;' +
                    'display: table-cell;' +
                    'vertical-align: middle' +
                '}' +
            '</style>' +

            '<div class="stencilEditorPreview-logo">' +
                '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 -8 65 65">' +
                    '<g opacity=".6" fill="#00A9C7">' +
                        '<path d="M16 21.1c5 0 9.5 1.4 13 3.6 1.5-1.9 2.4-4.2 2.4-6.6 0-7.1-7.7-12.9-17.1-12.9C4.8 5.2 3.5 11 3.5 18.1c0 3.3.3 6.2 1.5 8.5 1.6-3.3 4.8-5.5 11-5.5z"/>' +
                        '<path d="M29 24.7c-3 3.8-8.4 6.3-14.7 6.3-5.1 0-7.8-1.7-9.3-4.4-1.2 2.6-1.5 5.9-1.5 9.4C3.5 44.3 5 51 16 51s19.9-6.7 19.9-15c0-4.5-2.7-8.5-6.9-11.3z"/>' +
                    '</g>' +
                    '<path fill="#00A9C7" d="M5 26.7c1.4 2.7 4.1 4.4 9.3 4.4 6.3 0 11.7-2.5 14.7-6.3-3.5-2.3-8-3.6-13-3.6-6.2-.1-9.4 2.1-11 5.5z"/>' +
                '</svg>' +
            '</div>' +
            '<h1 class="stencilEditorPreview-text">Theme Preview</h1>' +
            '<a id="editor-close-preview" class="stencilEditorPreview-close" href="#">Close</a>';

        document.body.appendChild(banner);

        bannerHeight = banner.offsetHeight;
        bodyMarginTop = window.parseInt(document.body.style.marginTop, 10);

        if (window.isNaN(bodyMarginTop)) {
            bodyMarginTop = 0;
        }

        document.body.style.marginTop = (bannerHeight + bodyMarginTop) + 'px';
        document.getElementById('editor-close-preview').onclick = closePreview;
    }

    /*
     * Registers JsChannel subscriptions
     */
    function registerJsChannelEvents() {
        var chan = Channel.build({
            window: window.parent,
            origin: '*',
            scope: 'stencilEditor'
        });

        chan.bind('add-font', addFontHandler);
        chan.bind('reload-stylesheets', reloadStylesheetsHandler);
        chan.bind('reload-page', reloadPageHandler);
        chan.bind('set-cookie', setCookieHandler);

        function addFontHandler(trans, data) {
            var fontUrl = JSON.parse(data).fontUrl,
                options = {
                    error: function(message) { trans.error(message); },
                    success: function(message) { trans.complete(message); }
                };

            trans.delayReturn(true);

            return addFont(fontUrl, options);
        }

        function reloadStylesheetsHandler(trans, data) {
            var configurationId = JSON.parse(data).configurationId,
                loadedStylesheetsCount = getLoadedStylesheets().length,
                options = {
                    error: callOnce(onError),
                    // call trans.complete once after all stylesheets have been reloaded
                    success: callAfterNTimes(loadedStylesheetsCount, onSuccess)
                };

            function onError(message) { return trans.error(message); }
            function onSuccess(message) { return trans.complete(message); }

            trans.delayReturn(true);

            setCookie(configurationId);

            return reloadStylesheets(configurationId, options);

        }

        /**
         * Get the stylesheets on the page and filter for ones that are loaded.
         * @return {Array} Array of stylesheet nodes
         */
        function getLoadedStylesheets() {
            return getStylesheets().filter(function(link) {
                return !link.hasAttribute('data-is-loading');
            });
        }

        /**
         * Invoke the callback after the nth time this function has been called. See _.after in underscore or lodash.
         * @param  {Number} n The number of calls before func is invoked.
         * @param  {Function} func The callback function to invoke.
         * @return {Function} The new restricted function.
         */
        function callAfterNTimes(n, func) {
            return function callAfterFunc() {
                if (--n < 1) {
                  return func.apply(this, arguments);
                }
            };
        }

        /**
         * Creates a function that is restricted to invoking func once. Repeat calls to the function returns the value of the first invocation.
         * @param  {Function} func The callback function to invoke.
         * @return {Function} The new restricted function.
         */
        function callOnce(func) {
            var called = false,
                result;

            return function onceFunc() {
                if (!called) {
                    called = true;
                    result = func.apply(this, arguments);
                }

                return result;
            }
        }

        function reloadPageHandler() {
            return reloadPage();
        }

        function setCookieHandler(trans, data) {
            var configurationId = JSON.parse(data).configurationId;

            return setCookie(configurationId);
        }
    }

    /**
     * Reloads the current page
     * @returns {boolean}
     */
    function reloadPage() {
        document.location.reload(true);

        return true;
    }

    /**
     * Reloads stylesheets by appending Date.now() to their href
     * @returns {boolean}
     */
    function reloadStylesheets(configurationId, options) {
        options = options || {};
        options.error = options.error || _noop;
        options.success = options.success || _noop;

        getStylesheets().forEach(updateStylesheet.bind(null, configurationId, options));

        return true;
    }

    function updateStylesheet(configurationId, options, currentLink) {
        var url = currentLink.getAttribute('href'),
            newLink;

        if (!url) {
            return;
        }

        if (currentLink.hasAttribute('data-is-loading')) {
            document.head.removeChild(currentLink);
        } else {
            newLink = currentLink.cloneNode(false);

            newLink.setAttribute('href', generateStylesheetUrl(url, configurationId));
            newLink.setAttribute('data-is-loading', true);

            newLink.addEventListener('load', stylesheetLoad);
            newLink.addEventListener('error', stylesheetError);

            // Insert the new stylesheet before the old one to avoid any flash of un-styled content. The load
            // and error events only work for the initial load, which is why we replace the link on each update.
            document.head.insertBefore(newLink, currentLink);
        }

        function stylesheetLoad() {
            newLink.removeAttribute('data-is-loading');

            // Destroy any existing handlers to save memory on subsequent stylesheet changes
            newLink.removeEventListener('error', stylesheetError);
            newLink.removeEventListener('load', stylesheetLoad);


            // Remove the old stylesheet to allow the new one to take over
            document.head.removeChild(currentLink);

            options.success(url);

            focusBody();
        }

        function stylesheetError() {
            options.error(url);

            // Something went wrong with our new stylesheet, so destroy it and keep the old one
            newLink.removeEventListener('error', stylesheetError);
            newLink.removeEventListener('load', stylesheetLoad);

            document.head.removeChild(newLink);
        }
    }

    /**
     * Checks if the current window is being run inside an iframe
     * @returns {boolean}
     */
    function runningInIframe() {
        try {
            return window.self !== window.top;
        } catch(e) {
            return true;
        }
    }

    /**
     * Sets the cookie
     * @param {string} configurationId
     */
    function setCookie(configurationId) {
        // Adding a dot because cookie set by bcapp also adds a dot
        window.Cookies.set(_cookieName, configurationId, {
            domain: _cookieDomain
        });
    }

})(window, window.Channel);
