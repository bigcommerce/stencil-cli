export default function run($log, $rootScope, $state, $urlRouter, configService) {
    'ngInject';
    $rootScope
        .$on('$stateChangeError', (event, toState, toParams, fromState, fromParams, error) => {
            $log.error('Error in state transition: ', error);
        });

    $rootScope.$on('$locationChangeSuccess', function(event) {
        event.preventDefault();

        // If it's a manual navigation don't notify the router to avoid
        // calling the resolves again
        if (configService._isManuallyNavigating) {
            configService._isManuallyNavigating = false;
        } else {
            $urlRouter.sync();
        }
    });

    $urlRouter.listen();
}
