import CliNotAvailableModalCtrl from 'src/app/modals/cli-not-available-modal/cli-not-available-modal.controller.js';
import ConfirmClearModalCtrl from 'src/app/modals/confirm-clear-modal/confirm-clear-modal.controller.js';
import ConfirmResetModalCtrl from 'src/app/modals/confirm-reset-modal/confirm-reset-modal.controller.js';
import UnhandledErrorModalCtrl from 'src/app/modals/unhandled-error-modal/unhandled-error-modal.controller.js';

export default class StencilEditorCtrl {
    /*@ngInject*/
    constructor($modal, BC_APP_CONFIG, channelService, configService, fontsService, gettextCatalog, variationService, versionService) {
        this._$modal = $modal;
        this._BC_APP_CONFIG = BC_APP_CONFIG;
        this._channelService = channelService;
        this._configService = configService;
        this._fontsService = fontsService;
        this._gettextCatalog = gettextCatalog;
        this._variationService = variationService;
        this._versionService = versionService;
        this._fields = [];

        this.init();
    }

    init() {
        // Clear the existing fields, if any
        this._fields.length = 0;

        // Expose the current model data to the template
        this.config = this._configService.getConfig();
        this.version = this._versionService.getVersion();
        this.fieldsets = this._versionService.getFieldsets();

        this.reloadStylesheets(this.config.id);

        // Hydrate the fields with the config data
        _.each(this.fieldsets, (fieldset) => {
            _.each(fieldset.settings, (field) => {
                const key = field.key;

                if (_.isUndefined(key)) {
                    return;
                }

                if (_.isUndefined(this.config.settings[key])) {
                    return;
                }

                field.defaultValue = this.config.settings[key].toString();

                field.templateOptions.options = _.map(field.templateOptions.options, option => {
                    option.value = option.value.toString();

                    return option;
                });

                field.templateOptions.onChange = newValue => {
                    this._configService.hasChanges(true);

                    this._configService
                        .preview(this._configService.getConfig(), { requiresRefresh: field.data.forceReload })
                        .then((resp) => this.reloadStylesheets(resp.configurationId));

                    field.templateOptions.updated = true;

                    if (field.type === 'font') {
                        this._fontsService.addFont(newValue);
                    }
                };

                this._fields.push(field);
            });
        });
    }

    apply() {
        // @TODO: Implement apply endpoint in production (v2)
        this._$modal
            .open({
                controller: CliNotAvailableModalCtrl,
                controllerAs: 'cliNotAvailableModalCtrl',
                templateUrl: 'app/modals/cli-not-available-modal/cli-not-available-modal.tpl.html',
                windowClass: 'modal'
            });
    }

    clear() {
        this._$modal
            .open({
                controller: ConfirmClearModalCtrl,
                controllerAs: 'confirmClearModalCtrl',
                templateUrl: 'app/modals/confirm-clear-modal/confirm-clear-modal.tpl.html',
                windowClass: 'modal'
            })
            .result.then(() => {
                return this._configService
                    .clear(this.needsForceReload())
                    .then(() => this.reloadStylesheets())
                    .then(() => this.resetForm());
            });
    }

    openErrorModal(error = {}) {
        let options;

        if (error.status === 405) {
            options = {
                controller: CliNotAvailableModalCtrl,
                controllerAs: 'cliNotAvailableModalCtrl',
                templateUrl: 'app/modals/cli-not-available-modal/cli-not-available-modal.tpl.html',
                windowClass: 'modal'
            };
        } else {
            options = {
                controller: UnhandledErrorModalCtrl,
                controllerAs: 'unhandledErrorModalCtrl',
                templateUrl: 'app/modals/unhandled-error-modal/unhandled-error-modal.tpl.html',
                windowClass: 'modal'
            };
        }

        return this._$modal.open(options);
    }

    needsForceReload() {
        const changes = this._configService.findChanges();

        return _.any(changes, (value, key) => this._versionService.needsForceReload(key));
    }

    reloadStylesheets(configurationId) {
        return this._channelService.emit('reload-stylesheets', {
            configurationId: configurationId
        });
    }

    resetForm() {
        // ensure our form is in its pristine state
        if (this.editorForm) {
            this.editorForm.$setPristine();
            this.editorForm.$setUntouched();

            _.each(this._fields, (field) => {
                if (field.templateOptions) {
                    field.templateOptions.updated = false;
                }
            });
        }
    }

    resetVariant() {
        this._$modal
            .open({
                controller: ConfirmResetModalCtrl,
                controllerAs: 'confirmResetModalCtrl',
                templateUrl: 'app/modals/confirm-reset-modal/confirm-reset-modal.tpl.html',
                windowClass: 'modal'
            })
            .result.then(() => {
                const activeVariation = this._variationService.activeVariation();

                this._configService
                    .reset(activeVariation)
                    .then(() => this.resetForm())
                    .catch(error => this.openErrorModal(error));
            });
    }

    submit() {
        this._configService.save(this.config)
            .then(() => this.resetForm());
    }
}
