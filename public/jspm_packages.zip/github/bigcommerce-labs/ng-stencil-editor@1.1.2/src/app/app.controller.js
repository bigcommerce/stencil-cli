export default class AppCtrl {
    /*@ngInject*/
    constructor($cookies, $scope, $window, appService, channelService, configService, gettextCatalog) {
        this._$cookies = $cookies;
        this._$scope = $scope;
        this._channelService = channelService;
        this._configService = configService;
        this._gettextCatalog = gettextCatalog;

        $window.addEventListener('mouseover', _.bind(_.throttle(this.emitActive, 2000), this));
        $window.addEventListener('beforeunload', _.bind(this.confirmExit, this));
        $window.addEventListener('unload', _.bind(this.removeCookie, this));
        $window.addEventListener('unload', _.bind(this.resetConfig, this));

        // Set initial cookie
        $cookies.stencil_editor_enabled = appService.getEditorToken();
    }

    confirmExit(event) {
        if (this._configService.hasChanges()) {
            const confirmationMessage = this._gettextCatalog.getString('You will lose all unsaved changes.');

            // Cross-browser compatibility
            event.returnValue = confirmationMessage;

            // beforeunload expects any return to trigger the confirmation alert
            return confirmationMessage;
        }
    }

    emitActive() {
        this._channelService.emit('window-active', {
            configurationId: this._configService.getConfig().id
        });
    }

    removeCookie() {
        this._$scope.$apply(() => {
            delete this._$cookies['stencil_editor_enabled'];
        });
    }

    resetConfig() {
        if (this._configService.hasChanges()) {
            this._configService.clear();
            this._configService.saveNative();
        }
    }
}
