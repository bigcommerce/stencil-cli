import AppCtrl from 'src/app/app.controller.js';
import StencilEditorCtrl from 'src/app/stencil-editor/stencil-editor.controller.js';
import StencilPreviewCtrl from 'src/app/stencil-preview/stencil-preview.controller.js';

function config($httpProvider, $locationProvider, $stateProvider, BC_APP_CONFIG, svgRootPathProvider) {
    $httpProvider.interceptors.push('ajaxRequestStatus');

    $locationProvider.html5Mode(true);

    $stateProvider.state('ng-stencil-editor', {
        url: '/ng-stencil-editor/{versionId}/{variationId}/{configurationId}',
        params: {
            configurationId: { value: '1' },
            variationId: { value: '1' },
            versionId: { value: 'theme' },
        },
        resolve: {
            /*@ngInject*/
            configResolve: ($stateParams, configService) => {
                return configService.fetchConfig($stateParams.configurationId);
            },

            /*@ngInject*/
            variationResolve: ($stateParams, variationService) => {
                return variationService.fetchVariation($stateParams.variationId);
            },

            /*@ngInject*/
            versionResolve: ($stateParams, versionService) => {
                return versionService.fetchVersion($stateParams.versionId);
            }
        },
        views: {
            '@': {
                controller: AppCtrl,
                controllerAs: 'appCtrl',
                templateUrl: 'app/app.tpl.html'
            },

            'editor@ng-stencil-editor': {
                controller: StencilEditorCtrl,
                controllerAs: 'stencilEditorCtrl',
                templateUrl: 'app/stencil-editor/stencil-editor.tpl.html'
            },

            'preview@ng-stencil-editor': {
                controller: StencilPreviewCtrl,
                controllerAs: 'stencilPreviewCtrl',
                templateUrl: 'app/stencil-preview/stencil-preview.tpl.html'
            }
        }

    });

    // @TODO: This should be injected by the consuming platform: BCApp vs Stencil-CLI
    svgRootPathProvider.setRootPath(BC_APP_CONFIG.cdnPath + '/public/jspm_packages/github/bigcommerce-labs/bcapp-pattern-lab@1.13.0/dist/svg/icons/');
}

config.$inject = ['$httpProvider', '$locationProvider', '$stateProvider', 'BC_APP_CONFIG', 'svgRootPathProvider'];

export default config;
