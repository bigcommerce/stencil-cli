import BaseModalCtrl from 'src/app/modals/base-modal.controller.js';

export default class extends BaseModalCtrl {
    /*@ngInject*/
    constructor($modalInstance, $state, variation) {
        super($modalInstance);

        this._$state = $state;
        this._variation = variation;
    }

    ok($event) {
        super.ok($event);

        return this._$state.go('.', {
            configurationId: this._variation.configurationId,
            variationId: this._variation.id
        });
    }
}
