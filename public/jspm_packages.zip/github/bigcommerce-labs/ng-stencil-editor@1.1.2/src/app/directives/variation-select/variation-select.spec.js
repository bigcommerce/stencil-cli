import 'angular';
import 'angular-mocks';

import VariationSelectCtrl from 'src/app/directives/variation-select/variation-select.controller.js';

describe('Variation select directive: ', () => {
    const mockEvent = jasmine.createSpyObj('$event', [
        'preventDefault',
    ]);
    let mockModal = {
        result: {
            then(confirmCallback, cancelCallback) {
                this.confirmCallBack = confirmCallback;
                this.cancelCallback = cancelCallback;

                return {
                    then: angular.noop
                };
            }
        },
        close(item) {
            this.result.confirmCallBack(item);
        },
        dismiss(type) {
            this.result.cancelCallback(type);
        }
    };
    const mockVariation = { id: 1 };
    const variationService = jasmine.createSpyObj('variationService', [
        'activeVariation',
        'currentVariation',
        'getVariations'
    ]);

    let $modal = {
        open: () => {
            return mockModal;
        }
    };
    let $controller;
    let $rootScope;
    let $scope;
    let controller;

    function createController($scope) {
        return $controller(VariationSelectCtrl, {
            $scope: $scope,
            $modal: $modal,
            variationService: variationService
        });
    }

    beforeEach(() => {
        angular.mock.module(function($provide) {
            $provide.value('variationService', variationService);
        });

        variationService.activeVariation.and.returnValue(mockVariation);
    });

    beforeEach(inject(($injector) => {
        $rootScope = $injector.get('$rootScope');
        $scope = $rootScope.$new();
        $controller = $injector.get('$controller');
    }));

    describe('isActiveVariation() method', () => {
        beforeEach(() => {
            controller = createController($scope);
        });

        it('should return true when variation id matches the current variation id', () => {
            expect(controller.isActiveVariation(mockVariation)).toEqual(true);
        });

        it('should return false when variation id does not match the current variation id', () => {
            variationService.activeVariation.and.returnValue({ id: 2 });

            expect(controller.isActiveVariation(mockVariation)).toEqual(false);
        });
    });

    describe('confirm() method', () => {
        beforeEach(() => {
            controller = createController($scope);
            controller.variationChange = _.noop;
        });

        it('should set a new variation name with a clean form', () => {
            controller.editorForm = {
                $dirty: false
            };
            controller.confirm(mockEvent, mockVariation);

            $scope.$digest();

            expect(variationService.activeVariation).toHaveBeenCalledWith(mockVariation);
        });

        it('should warn the user before switching the variation with a dirty form', () => {
            spyOn(controller, 'warn').and.returnValue(mockModal.result);

            controller.editorForm = {
                $dirty: true
            };
            controller.confirm(mockEvent, mockVariation);

            expect(controller.warn).toHaveBeenCalledWith(mockEvent, mockVariation);
        });
    });

    describe('warn() method', () => {
        beforeEach(() => {
            spyOn($modal, 'open').and.returnValue(mockModal);

            controller = createController($scope);
            controller.variationChange = _.noop;
            controller.editorForm = {
                $dirty: true
            };
            controller.confirm(mockEvent, mockVariation);
        });

        it('should open a modal to warn the user of unsaved changes', () => {
            expect(mockEvent.preventDefault).toHaveBeenCalled();
            expect(controller._$modal.open).toHaveBeenCalled();
        });

        it('should set a new variation name when the modal is closed', () => {
            controller._$modal.open().close(mockVariation);

            expect(variationService.activeVariation).toHaveBeenCalledWith(mockVariation);
        });

    });

});
