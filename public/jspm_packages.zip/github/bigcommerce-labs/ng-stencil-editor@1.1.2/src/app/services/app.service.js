export default class AppService {
    /*@ngInject*/
    constructor($sce, BC_APP_CONFIG, urlParser) {
        this._$sce = $sce;
        this._BC_APP_CONFIG = BC_APP_CONFIG;
        this._urlParser = urlParser;
    }

    getEditorToken() {
        return this._urlParser.getParam(this.getStoreUrl(), 'stencilEditor');
    }

    getStoreUrl() {
        return this._$sce.trustAsResourceUrl(this._BC_APP_CONFIG.storeUrl);
    }
}
