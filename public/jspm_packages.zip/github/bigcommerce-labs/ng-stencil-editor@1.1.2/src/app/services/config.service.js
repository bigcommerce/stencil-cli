export default class ConfigService {
    /*@ngInject*/
    constructor($http, $q, $state, API, BC_APP_CONFIG) {
        this._config = {};
        this._configBackup = {};
        this._hasChanges = false;
        this._refresh = false;
        this._$http = $http;
        this._$q = $q;
        this._$state = $state;
        this._API = API;
        this._BC_APP_CONFIG = BC_APP_CONFIG;
    }

    backup(config) {
        this._configBackup = _.cloneDeep(config);

        return config;
    }

    clear(requiresRefresh = false) {
        this.setConfig(this._configBackup);
        this.hasChanges(false);

        return this.preview(this._config, { requiresRefresh: requiresRefresh });
    }

    fetchConfig(configurationId) {
        return this._$http.get(this._API.CONFIG_PATH + '/' + configurationId)
            .then(resp => resp.data.data)
            .then(resp => this.setConfig(resp));
    }

    findChanges() {
        return _.transform(this._config.settings, (result, value, key) => {
            if (!_.isEqual(value, this._configBackup.settings[key])) {
                result[key] = value;
            }
        });
    }

    getConfig() {
        return this._config;
    }

    getSettings() {
        return this._.config.settings;
    }

    hasChanges(value) {
        if (!_.isUndefined(value)) {
            this._hasChanges = value;
        }

        return this._hasChanges;
    }

    navigate(params) {
        const deferred = this._$q.defer();

        this._$state.go(this._$state.current, params, { notify: false })
            .then(() => deferred.resolve(params))
            .catch(error => deferred.reject(error));

        return deferred.promise;
    }

    preview(config, options = {}) {
        options.preview = true;

        return this.save(config, options);
    }

    publish(config, options = {}) {
        options.publish = true;

        return this.save(config, options);
    }

    requiresRefresh(refreshValue) {
        if (!_.isUndefined(refreshValue)) {
            this._refresh = refreshValue;
        }

        return this._refresh;
    }

    reset(variation) {
        const defaultConfigId = variation.defaultConfigurationId;

        return this.fetchConfig(defaultConfigId)
            .then(config => {
                return this.save(config, {
                    requiresRefresh: true,
                    reset: true
                });
            });
    }

    save(config, options = {}) {
        const data = {
            preview: options.preview || false,
            publish: options.publish || false,
            reset: options.reset || false,
            settings: config.settings,
            variationId: config.variationId,
        };

        return this._$http.post(this._API.CONFIG_PATH, data)
            .then(resp => resp.data.data)
            .then(resp => {
                config.id = resp.configurationId;

                if (options.publish || !options.preview) {
                    this.backup(config);
                    this.hasChanges(false);
                }

                // We don't set requiresRefresh every time to avoid the
                // case where the user changes a field that doesn't require a refresh
                // after changing one that does (removing the fresh button from the UI)
                if (options.requiresRefresh) {
                    this.requiresRefresh(true);
                }

                return resp;
            })
            .then(resp => this.navigate(resp));
    }

    /**
     * Makes a native AJAX request because $http was unreliable when called
     * from onunload event
     */
    saveNative() {
        const request = new XMLHttpRequest();

        request.open('POST', this._API.CONFIG_PATH, true);
        request.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded; charset=UTF-8');
        request.send(this.getConfig());
    }

    setConfig(configToSet) {
        this.backup(configToSet);

        _.extend(this._config, configToSet);

        return this._config;
    }
}
