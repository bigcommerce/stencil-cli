import _ from 'lodash';

export default class VersionService {
    /*@ngInject*/
    constructor($http, API) {
        this._$http = $http;
        this._API = API;
        this._fieldsets = [];
        this._version = {};
    }

    fetchVersion(versionId) {
        return this._$http.get(this._API.VERSION_PATH + '/' + versionId)
            .then(resp => resp.data.data)
            .then(resp => this.setVersion(resp))
            .then(resp => this.mapFieldsets(resp.editorSchema))
            .then(resp => this.setFieldsets(resp));
    }

    getFieldsets() {
        return this._fieldsets;
    }

    getVersion() {
        return this._version;
    }

    mapFieldsets(schema) {
        return _.map(schema, (fieldset) => {
            return {
                name: fieldset.name,
                settings: _.map(fieldset.settings, this.mapField)
            };
        });
    }

    mapField(field) {
        let type = field.type;

        if (type === 'text') {
            type = 'input';
        }

        if (type === 'image') {
            type = 'upload';
        }

        return {
            key: field.id,
            type: type,
            data: {
                content: field.content,
                forceReload: field.force_reload
            },
            templateOptions: {
                label: field.label,
                max: field.max,
                min: field.min,
                options: field.options || [],
                placeholder: field.placeholder,
                step: field.step,
                type: field.type
            }
        };
    }

    setFieldsets(fieldsets) {
        this._fieldsets = fieldsets;

        return fieldsets;
    }

    setVersion(version) {
        this._version = version;

        return version;
    }

    needsForceReload(key) {
        return _.chain(this._fieldsets)
            .pluck('settings')
            .flatten()
            .any({key: key, data: { forceReload: true }})
            .value();
    }
}
