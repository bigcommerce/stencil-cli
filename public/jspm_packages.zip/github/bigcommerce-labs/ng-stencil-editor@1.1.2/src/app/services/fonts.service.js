export default class FontsService {
    /*@ngInject*/
    constructor(channelService, configService) {
        this._channelService = channelService;
        this._configService = configService;
        this._loadedFonts = {};

        this.setInitialFonts();
    }

    addFont(font) {
        if (!this._loadedFonts[font])  {
            this._loadedFonts[font] = true;

            this.emitInjectFont(this.parseFont(font));
        }
    }

    emitInjectFont(fontUrl) {
        if (fontUrl) {
            this._channelService.emit('add-font', {
                fontUrl: fontUrl
            });
        }
    }

    parseFont(font) {
        const provider = font.split('_')[0];

        switch (provider) {
            case 'Google':
                return this.parseGoogleFont(font);
            default:
                return;
        }
    }

    parseGoogleFont(font) {
        const split = font.split('_');

        let formattedFont = '';
        let family = split[1];
        let weight = split[2];

        if (split.length === 2) {
            formattedFont += family + '|';
        } else if (split.length > 2) {
            weight = weight.split(',')[0];
            formattedFont += family + ':' + weight + '|';
        }

        return '//fonts.googleapis.com/css?family=' + formattedFont;
    }

    // TODO: Move to the config resolve and remove dependency on configService
    setInitialFonts() {
        const fontKeyFormat = new RegExp(/\w+-font$/);
        const settings = this._configService.getConfig().settings;

        _.each(settings, (value, key) => {
            if (fontKeyFormat.test(key)) {
                this._loadedFonts[value] = true;
            }
        });
    }
}
