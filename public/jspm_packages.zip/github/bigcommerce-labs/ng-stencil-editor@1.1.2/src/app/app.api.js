export default angular.module('ng-stencil-editor.api', [])
    .provider('API', function APIProvider(BC_APP_CONFIG) {
        this.$get = function getAPI(_) {
            const BASE_URL = BC_APP_CONFIG.basePath;
            const API = {
                CONFIG_PATH: '/configurations',
                VARIATION_PATH: '/variations',
                VERSION_PATH: '/versions',
            };

            return _.mapValues(API, api => BASE_URL + api);
        };
    });
