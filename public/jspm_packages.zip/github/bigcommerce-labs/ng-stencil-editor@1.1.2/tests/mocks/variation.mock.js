export default {
    "id": "1",
    "themeName": "Theme Name",
    "themeId": "string",
    "versionId": "string",
    "variationName": "Variation 1",
    "price": 0,
    "partner": {
        "id": "string",
        "name": "string",
        "contactUrl": "string",
        "contactEmail": "string"
    },
    "description": "string",
    "industries": [
        "string"
    ],
    "features": [
        "string"
    ],
    "optimizedFor": [
        "string"
    ],
    "screenshot": {
        "largePreview": "string",
        "largeThumb": "string",
        "smallThumb": "string"
    },
    "mobileScreenshot": "string",
    "demoUrl": "string",
    "documentationUrl": "string",
    "displayVersion": "string",
    "releaseNotes": "string",
    "status": "string",
    "relatedVariations": [
        {
            "id": "1",
            "variationName": "Variation 1",
            "screenshot": {
                "largePreview": "string",
                "largeThumb": "string",
                "smallThumb": "string"
            },
            "configurationId": "1",
            "isCurrent": true
        },
        {
            "id": "2",
            "variationName": "Variation 2",
            "screenshot": {
                "largePreview": "string",
                "largeThumb": "string",
                "smallThumb": "string"
            },
            "configurationId": "2",
            "isCurrent": false
        },
        {
            "id": "3",
            "variationName": "Variation 3",
            "screenshot": {
                "largePreview": "string",
                "largeThumb": "string",
                "smallThumb": "string"
            },
            "configurationId": "2",
            "isCurrent": false
        }
    ],
    "configurationId": "1",
    "defaultConfigurationId": "1",
    "isCurrent": true
};
