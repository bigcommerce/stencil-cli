/* */ 
"format global";
var gemini = require('gemini'),
    viewport = require('../viewport');

gemini.suite('grids', function(suite) {
    suite.setUrl('/grid.html');

    gemini.suite('grid xsmall', function(suite) {
        suite
            .before(viewport.xsmallViewport)
            .setCaptureElements('#labExampleGrid')
            .capture('normal');
    });

    gemini.suite('grid', function(suite) {
        suite
            .setCaptureElements('#labExampleGrid')
            .capture('normal');
    });
});
