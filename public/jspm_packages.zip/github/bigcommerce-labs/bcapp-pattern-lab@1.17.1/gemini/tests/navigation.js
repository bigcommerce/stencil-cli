/* */ 
"format global";
var gemini = require('gemini');

gemini.suite('navigation', function(suite) {
    suite.setUrl('/navigation.html');

    gemini.suite('nav bar', function(suite) {
        suite
            .setCaptureElements('#labExampleNavBar')
            .capture('normal');
    });

    gemini.suite('nav bar steps', function(suite) {
        suite
            .setCaptureElements('#labExampleNavBarSteps')
            .capture('normal');
    });

    gemini.suite('nav list', function(suite) {
        suite
            .setCaptureElements('#labExampleNavList')
            .capture('normal');
    });

    gemini.suite('breadcrumbs', function(suite) {
        suite
            .setCaptureElements('#labExampleBreadcrumbs')
            .capture('normal');
    });
});
