/* */ 
'use strict';

angular.module('bcapp-pattern-lab', ['gettext', 'ngAnimate', 'ngMessages', 'mm.foundation', 'bcapp-pattern-lab-templates', 'bcapp-pattern-lab.bc-datepicker', 'bcapp-pattern-lab.bc-dropdown', 'bcapp-pattern-lab.bc-modal', 'bcapp-pattern-lab.bc-pagination', 'bcapp-pattern-lab.bc-server-table', 'bcapp-pattern-lab.checkbox-list', 'bcapp-pattern-lab.color-picker', 'bcapp-pattern-lab.credit-card', 'bcapp-pattern-lab.credit-card-types', 'bcapp-pattern-lab.form', 'bcapp-pattern-lab.form-field', 'bcapp-pattern-lab.form-input-color', 'bcapp-pattern-lab.html5Mode', 'bcapp-pattern-lab.icon', 'bcapp-pattern-lab.loading-notification', 'bcapp-pattern-lab.loading-overlay', 'bcapp-pattern-lab.sprite', 'bcapp-pattern-lab.switch', 'bcapp-pattern-lab.util']);
/* globals moment */
'use strict';

angular.module('bcapp-pattern-lab.bc-datepicker.constants', []).constant('BC_DATEPICKER_DEFAULTS', {
    dayFormat: 'D',
    inputFormat: moment.localeData().longDateFormat('L'),
    styles: {
        back: 'datepicker-back',
        container: 'datepicker',
        date: 'datepicker-date',
        dayBody: 'datepicker-days-body',
        dayBodyElem: 'datepicker-day',
        dayConcealed: 'datepicker-day-concealed',
        dayDisabled: 'is-disabled',
        dayHead: 'datepicker-days-head',
        dayHeadElem: 'datepicker-day-name',
        dayPrevMonth: 'datepicker-day-prev-month',
        dayNextMonth: 'datepicker-day-next-month',
        dayRow: 'datepicker-days-row',
        dayTable: 'datepicker-days',
        month: 'datepicker-month',
        monthLabel: 'datepicker-month',
        next: 'datepicker-next',
        positioned: 'datepicker-attachment',
        selectedDay: 'is-selected',
        selectedTime: 'datepicker-time-selected',
        time: 'datepicker-time',
        timeList: 'datepicker-time-list',
        timeOption: 'datepicker-time-option'
    },
    time: false,
    weekdayFormat: 'short'
});
/* globals rome */
'use strict';

angular.module('bcapp-pattern-lab.bc-datepicker.directive', ['bcapp-pattern-lab.bc-datepicker.constants']).directive('bcDatepicker', function bcDatepickerDirective(BC_DATEPICKER_DEFAULTS) {
    return {
        restrict: 'A',
        require: 'ngModel',
        scope: {
            options: '=?'
        },

        link: function datepickerLinkFunction(scope, element, attrs, ngModel) {
            if (scope.options === undefined) {
                scope.options = {};
            }

            // Add defaults to the options object
            _.defaults(scope.options, BC_DATEPICKER_DEFAULTS);

            // Create a new rome (calendar) instance
            scope.calendar = rome(element[0], scope.options);

            // On 'data' event set ngModel to the passed value
            scope.calendar.on('data', function onData(value) {
                ngModel.$setViewValue(value);
                scope.$apply();
            });

            scope.calendar.on('ready', function onReady(options) {
                if (attrs.placeholder === undefined) {
                    attrs.$set('placeholder', options.inputFormat);
                }
            });

            // Removing calendar event listeners
            element.on('$destroy', function onDestroy() {
                scope.calendar.destroy();
            });
        }
    };
});
'use strict';

angular.module('bcapp-pattern-lab.bc-datepicker', ['bcapp-pattern-lab.bc-datepicker.directive']);
'use strict';

angular.module('bcapp-pattern-lab.bc-dropdown-menu.directive', []).directive('bcDropdownMenu', function () {
    return {
        restrict: 'A',
        require: '^bcDropdown',
        compile: function compile(tElement) {
            tElement.addClass('dropdown-menu');
            tElement.attr('role', 'listbox');

            return function (scope, element, attrs, bcDropdownCtrl) {
                element.attr('id', bcDropdownCtrl.getUniqueId());
                element.attr('aria-expanded', bcDropdownCtrl.getIsOpen());
                // listen for dropdowns being opened and toggle aria-expanded to reflect current state
                scope.$on('toggleThisDropdown', function () {
                    element.attr('aria-expanded', bcDropdownCtrl.getIsOpen());
                });
            };
        }
    };
});
'use strict';

angular.module('bcapp-pattern-lab.bc-dropdown-toggle.directive', []).directive('bcDropdownToggle', function ($compile) {
    return {
        restrict: 'A',
        terminal: true,
        priority: 1001, // set higher than ng-repeat to prevent double compilation
        require: '^bcDropdown',
        compile: function compile(tElement) {
            tElement.removeAttr('bc-dropdown-toggle');

            return function (scope, element, attrs, bcDropdownCtrl) {
                element.attr('dropdown-toggle', '#' + bcDropdownCtrl.getUniqueId());
                element.attr('aria-controls', bcDropdownCtrl.getUniqueId());
                element.on('click', bcDropdownCtrl.toggleIsOpen);
                $compile(element)(scope);
            };
        }
    };
});
'use strict';

angular.module('bcapp-pattern-lab.bc-dropdown.controller', []).controller('BcDropdownController', function bcDropdownController($scope, $rootScope) {
    var ctrl = this;
    var isOpen = false;
    var uniqueId = undefined;

    ctrl.closeDropdown = closeDropdown;
    ctrl.getIsOpen = getIsOpen;
    ctrl.getUniqueId = getUniqueId;
    ctrl.setIsOpen = setIsOpen;
    ctrl.toggleIsOpen = toggleIsOpen;

    // listen for other dropdowns being opened in the app.
    $scope.$on('bcDropdownToggle', function (event, triggeringID) {
        // if I'm open and not the dropdown being triggered, then I should close
        if (isOpen && triggeringID !== uniqueId) {
            ctrl.closeDropdown();
        }
    });

    function closeDropdown() {
        ctrl.setIsOpen(false);
        $scope.$broadcast('toggleThisDropdown');
    }

    function getIsOpen() {
        return isOpen;
    }

    function getUniqueId() {
        if (!uniqueId) {
            uniqueId = _.uniqueId('bc-dropdown-');
        }
        return uniqueId;
    }

    function setIsOpen(val) {
        isOpen = val;
    }

    function toggleIsOpen() {
        isOpen = !isOpen;
        // tell child directives a toggle in open status has occurred
        $scope.$broadcast('toggleThisDropdown');
        // tell application that a dropdown has been opened so others can close
        $rootScope.$broadcast('bcDropdownToggle', uniqueId);
    }
});
'use strict';

angular.module('bcapp-pattern-lab.bc-dropdown.directive', ['bcapp-pattern-lab.bc-dropdown.controller']).directive('bcDropdown', function ($document) {
    return {
        bindToController: true,
        controller: 'BcDropdownController',
        controllerAs: 'bcDropdownController',
        restrict: 'EA',
        compile: function compile(tElement) {
            tElement.attr('role', 'combobox');

            return function ($scope, $element, attrs, ctrl) {
                // This directive is a composite of 2 separate Foundation directives
                // which don't provide hooks to know when it's clicked or opened
                // they do however deal with propagation of events so this, somewhat blind
                // document event is safe. All it does is swap aria states at the moment
                // in a cheap way to keep this directive in sync with it's child directive
                $document.on('click', ctrl.closeDropdown);

                $element.on('$destroy', function () {
                    $document.off('click', ctrl.closeDropdown);
                });
            };
        }
    };
});
'use strict';

angular.module('bcapp-pattern-lab.bc-dropdown', ['bcapp-pattern-lab.bc-dropdown.directive', 'bcapp-pattern-lab.bc-dropdown-toggle.directive', 'bcapp-pattern-lab.bc-dropdown-menu.directive']);
'use strict';

angular.module('bcapp-pattern-lab.bc-pagination.directive', []).directive('bcPagination', function bcPaginationDirective($parse) {
    return {
        restrict: 'E',
        scope: true,
        templateUrl: 'src/js/bigcommerce/bc-pagination/bc-pagination.tpl.html',

        compile: function bcPaginationCompile(tElement, tAttrs) {
            var attrObj = {};

            // Since this is a wrapper of angular-foundation's pagination directive we need to copy all
            // of the attributes passed to our directive and store them in the attrObj.
            _.each(tAttrs.$attr, function (key) {
                if (key !== 'class') {
                    attrObj[key] = tElement.attr(key);
                }
            });

            // Adding our custom callback to the attrObj, angular-foundation will call this function
            // when a page number is clicked in the pagination.
            attrObj['on-select-page'] = 'paginationCallback(page)';

            // Add all the attributes to angular-foundation's pagination directive
            tElement.find('pagination').attr(attrObj);

            return function bcPaginationLink($scope, element, attrs) {
                var onChangeParseGetter = $parse(attrs.onChange),
                    defaultLimits = [10, 20, 30, 50, 100];

                $scope.setLimit = function (limit, event) {
                    event.preventDefault();
                    limit = _.parseInt(limit);
                    $parse(attrs.itemsPerPage).assign($scope.$parent, limit);
                    $scope.paginationCallback(1, limit);
                };

                $scope.getCurrentPage = function () {
                    return $parse(attrs.page)($scope.$parent);
                };

                $scope.getCurrentLimit = function () {
                    return $parse(attrs.itemsPerPage)($scope.$parent);
                };

                $scope.getItemsPerPage = function () {
                    return $parse(attrs.itemsPerPage)($scope.$parent) || 0;
                };

                $scope.getTotalItems = function () {
                    return $parse(attrs.totalItems)($scope.$parent) || 0;
                };

                $scope.show = function () {
                    return $scope.getTotalItems() > $scope.getItemsPerPage();
                };

                $scope.showLimits = function () {
                    return $scope.show() && $parse(attrs.showLimits)($scope.$parent) !== false;
                };

                $scope.getLimits = function () {
                    var limits = $parse(attrs.limits)($scope.$parent);

                    if (!Array.isArray(limits)) {
                        return defaultLimits;
                    }

                    return limits;
                };

                $scope.paginationCallback = function (page, limit) {
                    var additionalScopeProperties = {
                        limit: limit || $scope.getCurrentLimit(),
                        page: page
                    },
                        onChangeParseResult;

                    $parse(attrs.page).assign($scope.$parent, page);

                    onChangeParseResult = onChangeParseGetter($scope, additionalScopeProperties);

                    // if the onChange string is a function and not an expression: call it with the additionalScopeProperties obj (for backwards compatability)
                    // else the expression has already been ran: do nothing
                    if (typeof onChangeParseResult === 'function') {
                        onChangeParseResult(additionalScopeProperties);
                    }
                };
            };
        }
    };
});
'use strict';

angular.module('bcapp-pattern-lab.bc-pagination', ['bcapp-pattern-lab.bc-pagination.directive']);
'use strict';

angular.module('bcapp-pattern-lab.bc-server-table.controller', ['bcapp-pattern-lab.bc-server-table.service']).controller('BcServerTableCtrl', function BcServerTableCtrl($attrs, $log, $parse, $scope, BcServerTable) {
    var ctrl = this,
        bcServerTablePrototype = BcServerTable.prototype;

    // Call the BcServerTable constructor on the controller
    // in order to set all the controller properties directly.
    // This is here for backwards compatability purposes.
    BcServerTable.call(ctrl, null, $parse($attrs.tableConfig)($scope));

    // controller functions
    ctrl.createParamsObject = bcServerTablePrototype.createParamsObject;
    ctrl.fetchResource = bcServerTablePrototype.fetchResource;
    ctrl.getSelectedRows = bcServerTablePrototype.getSelectedRows;
    ctrl.init = bcServerTablePrototype.init;
    ctrl.isRowSelected = bcServerTablePrototype.isRowSelected;
    ctrl.loadStateParams = bcServerTablePrototype.loadStateParams;
    ctrl.selectAllRows = bcServerTablePrototype.selectAllRows;
    ctrl.setPaginationValues = bcServerTablePrototype.setPaginationValues;
    ctrl.setRows = bcServerTablePrototype.setRows;
    ctrl.setSortingValues = bcServerTablePrototype.setSortingValues;
    ctrl.updatePage = _.bind(bcServerTablePrototype.updatePage, ctrl);
    ctrl.updateSort = bcServerTablePrototype.updateSort;
    ctrl.updateTable = bcServerTablePrototype.updateTable;
    ctrl.validateResource = bcServerTablePrototype.validateResource;

    init();

    function init() {
        var resourceCallback;

        resourceCallback = $parse($attrs.resourceCallback)($scope);
        if (!_.isFunction(resourceCallback)) {
            $log.error('bc-server-table directive: resource-callback must be a function.');
            return;
        }
        ctrl.resourceCallback = resourceCallback;

        ctrl.init();
    }
});
'use strict';

angular.module('bcapp-pattern-lab.bc-server-table.directive', ['bcapp-pattern-lab.bc-server-table.controller', 'bcapp-pattern-lab.bc-server-table.sort-by.directive', 'ui.router'])
/**
 * The bc-server-table directive creates a data table that handles
 * server side pagination, sorting, and filtering. It exposes a few scope variables,
 * that can be used to display the table content with custom markup (see example
 * in the pattern lab for an actual implementation of the bc-server-table).
 *
 * The following attributes can be passed in order to configure the bc-server-table:
 * - resource-callback (required)
 * - tableConfig (optional)
 *
 * - resource-callback - a function that returns a promise which is resovled
 * with an object of the following format:
 *      {
 *          rows: Array,
 *          pagination: {
 *              page: Number,
 *              limit: Number,
 *              total: Number
 *          }
 *      }
 *
 * This directive exposes a scope variable called bcServerTable that
 * can be used to display content, and implement additional functionality
 * to the table (such as pagination, sorting, and selection logic).
 *
 * - bcServerTable.rows
 *      - Can be used with ng-repeat to display the data
 * - bcServerTable.filters
 *      - Can be used to change/update filters. These filters must appear
 *        in the state definition in order to work correctly.
 * - bcServerTable.updateTable()
 *      - Perform a state transistion with the current table info
 * - bcServerTable.pagination
 *      - exposes page, limit, and total
 * - bcServerTable.setPaginationValues(pagination)
 *      - convenience method for setting pagination values at once.
 *
 * - bcServerTable.selectedRows
 *      - an map object with unique id's as keys and boolean values as the selected state
 * - bcServerTable.allSelected
 *      - a boolean value used to determine if all rows were selected or cleared
 * - bcServerTable.selectAllRows()
 *      - toggle all rows selection state
 * - bcServerTable.isRowSelected(row)
 *      - helper function to determine if a row is selected
 * - bcServerTable.getSelectedRows()
 *      - function that returns an array of row objects that are currently selected
 *
 */
.directive('bcServerTable', function bcServerTableDirective($parse) {
    var directive = {
        restrict: 'EA',
        controller: 'BcServerTableCtrl as bcServerTable',
        link: function bcServerTableLink($scope, element, attrs, bcServerTableCtrl) {
            if (attrs.tableController) {
                // expose bcServerTableCtrl to tableController if it exists
                $parse(attrs.tableController).assign($scope, bcServerTableCtrl);
            }
        }
    };

    return directive;
});
'use strict';

angular.module('bcapp-pattern-lab.bc-server-table', ['bcapp-pattern-lab.bc-server-table.directive', 'bcapp-pattern-lab.bc-server-table.sort-by.directive', 'bcapp-pattern-lab.bc-server-table-factory.service']);
'use strict';

angular.module('bcapp-pattern-lab.bc-server-table.sort-by.directive', ['bcapp-pattern-lab.bc-server-table-factory.service']).directive('bcSortBy', function bcSortByDirective($log, bcServerTableFactory) {
    var directive = {
        templateUrl: 'src/js/bigcommerce/bc-server-table/bc-sort-by.tpl.html',
        restrict: 'E',
        transclude: true,
        scope: {
            sortValue: '@',
            columnName: '@',
            tableId: '@'
        },
        require: '?^^bcServerTable',
        link: bcSortByDirectiveLink
    };

    function bcSortByDirectiveLink(scope, element, attrs, bcServerTableCtrl) {
        var bcServerTable, sortDirValues;

        if (scope.tableId) {
            bcServerTable = bcServerTableFactory.get(scope.tableId);
        } else if (bcServerTableCtrl) {
            bcServerTable = bcServerTableCtrl;
        } else {
            $log.error('bc-sort-by directive requires a table-id, or a parent bcServerTableCtrl directive.');
        }

        sortDirValues = bcServerTable.tableConfig.sortDirValues;

        scope.asc = sortDirValues.asc;
        scope.desc = sortDirValues.desc;
        scope.sortBy = bcServerTable.sortBy;
        scope.sortDir = bcServerTable.sortDir;
        scope.sort = sort;

        function sort($event) {
            var sortBy, sortDir;

            if ($event) {
                $event.preventDefault();
            }

            if (bcServerTable.sortBy === scope.sortValue) {
                sortBy = bcServerTable.sortBy;
                sortDir = bcServerTable.sortDir === scope.asc ? scope.desc : scope.asc;
            } else {
                sortBy = scope.sortValue;
                sortDir = scope.asc;
            }

            bcServerTable.updateSort(sortBy, sortDir);
        }
    }

    return directive;
});
'use strict';

angular.module('bcapp-pattern-lab.checkbox-list.controller', []).controller('CheckboxListCtrl', function CheckboxListCtrl($attrs, $element, $log, $parse, $scope) {
    var ctrl = this,
        falseValue = $parse($attrs.ngFalseValue)(ctrl) || false,
        trueValue = $parse($attrs.ngTrueValue)(ctrl) || true,
        ngModel = $element.controller('ngModel');

    init();

    // Getters
    function getModelValue() {
        return ngModel.$modelValue;
    }

    function getValue() {
        return ctrl.value || ctrl.ngValue;
    }

    function getSelectedValues() {
        return ctrl.selectedValues;
    }

    // Setters
    function updateModelValue(modelValue) {
        ngModel.$setViewValue(modelValue);
        ngModel.$commitViewValue();
        ngModel.$render();
    }

    function updateSelectedValues(modelValue) {
        if (modelValue === trueValue) {
            addToSelectedValues();
        } else if (modelValue === falseValue) {
            removeFromSelectedValues();
        }
    }

    function addToSelectedValues() {
        var isIncluded = _.include(ctrl.selectedValues, getValue());

        if (!isIncluded) {
            ctrl.selectedValues.push(getValue());
        }
    }

    function removeFromSelectedValues() {
        var index = _.indexOf(ctrl.selectedValues, getValue());

        if (index !== -1) {
            ctrl.selectedValues.splice(index, 1);
        }
    }

    // Watchers
    function modelValueWatch(modelValue, oldModelValue) {
        var oldSelectedValues, selectedValuesChanged;

        // When ngModel value changes
        if (_.isUndefined(modelValue) || modelValue === oldModelValue) {
            return;
        }

        // Retain a shallow copy of selectedValues before update
        oldSelectedValues = ctrl.selectedValues.slice();

        // Update selectedValues
        updateSelectedValues(modelValue);

        // Determine if selectedValues array has changed
        selectedValuesChanged = !!_.xor(ctrl.selectedValues, oldSelectedValues).length;

        // If changed, evoke delegate method (if defined)
        if (ctrl.onChange && selectedValuesChanged) {
            ctrl.onChange({
                selectedValues: ctrl.selectedValues,
                oldSelectedValues: oldSelectedValues
            });
        }
    }

    function selectedValuesWatch(selectedValues) {
        // When selectedValues collection changes
        var isIncluded = _.include(selectedValues, getValue()),
            modelValue = getModelValue();

        if (isIncluded && modelValue !== trueValue) {
            updateModelValue(trueValue);
        } else if (!isIncluded && modelValue !== falseValue) {
            updateModelValue(falseValue);
        }
    }

    // Initializer
    function init() {
        if ($attrs.type !== 'checkbox') {
            $log.error('checkbox-list directive: element must be <input type="checkbox">');

            return;
        }

        $scope.$watch(getModelValue, modelValueWatch);
        $scope.$watchCollection(getSelectedValues, selectedValuesWatch);
    }
});
'use strict';

angular.module('bcapp-pattern-lab.checkbox-list.directive', ['bcapp-pattern-lab.checkbox-list.controller'])

/**
 * A directive for collating values from an array of checkboxes.
 *
 * @require ngModel
 * @param {Array.<string|number|Object>} checkboxList - Array to hold selected values
 * @param {*} value - Value to add to checkboxList
 * @param {function(selectedValues, oldSelectedValues} [checkboxListChange] - Optional onChange callback
 *
 * @example:
 * ```html
 * <div ng-repeat="option in options">
 *     <input type="checkbox" 
 *         name="option{{ option.id }}"
 *         value="option.id" 
 *         checkbox-list="selectedValues" 
 *         checkbox-list-change="onChange(selectedValues)" 
 *         ng-model="option.checked"
 *     />
 * </div>
 * ```
 * 
 * ```js
 * scope.selectedValues = [];
 * scope.options = [
 *     {
 *         id: 1,
 *         label: 'Option 1'
 *     },
 *     {
 *         id: 2,
 *         label: 'Option 2'
 *     },
 *     {
 *         id: 3,
 *         label: 'Option 3'
 *     }
 * ];
 * 
 * scope.onChange = function onChange(selectedValues) {
 *     console.log(selectedValues);
 * };
 * ```
 * 
 * When options[0] and options[1] are checked, selectedValues should be [1, 2]
 * and onChange will be evoked. This directive also works with an array of primitive values.
 * i.e.: scope.options = ["a", "b", "c"].
 */

.directive('checkboxList', function checkboxListDirective() {
    return {
        restrict: 'A',
        require: 'ngModel',
        controller: 'CheckboxListCtrl',
        controllerAs: 'checkboxListCtrl',
        bindToController: true,
        scope: {
            onChange: '&checkboxListChange',
            selectedValues: '=checkboxList',
            value: '=',
            ngValue: '='
        }
    };
});
'use strict';

angular.module('bcapp-pattern-lab.checkbox-list', ['bcapp-pattern-lab.checkbox-list.directive']);
'use strict';

angular.module('bcapp-pattern-lab.color-picker-palette.controller', []).controller('ColorPickerPaletteCtrl', function () {
    var ctrl = this;

    ctrl.createNewColor = createNewColor;

    function createNewColor($event) {
        $event.preventDefault();

        ctrl.createNewPaletteColor();
    }
});
'use strict';

angular.module('bcapp-pattern-lab.color-picker-palette.directive', ['bcapp-pattern-lab.color-picker-palette.controller']).directive('colorPickerPalette', function colorPickerPaletteDirective() {
    return {
        bindToController: true,
        controller: 'ColorPickerPaletteCtrl',
        controllerAs: 'colorPickerPaletteCtrl',
        restrict: 'E',
        scope: {
            colors: '=',
            createNewPaletteColor: '=',
            setNewColor: '='
        },
        templateUrl: 'src/js/bigcommerce/color-picker/color-picker-palette.tpl.html',
        compile: function colorPickerPaletteDirectiveCompile(tElement) {
            tElement.addClass('colorPicker-palette');
        }
    };
});
/* globals ColorPicker */
'use strict';

angular.module('bcapp-pattern-lab.color-picker.controller', []).controller('ColorPickerCtrl', function ColorPickerCtrl($element) {
    var ctrl = this;

    var colorSelection = undefined;
    var colorSelectionIndicator = undefined;
    var colorSlider = undefined;
    var colorSliderIndicator = undefined;

    ctrl.createColorPicker = createColorPicker;
    ctrl.createNewPaletteColor = createNewPaletteColor;
    ctrl.setModelCtrl = setModelCtrl;
    ctrl.setNewColor = setNewColor;

    function createColorPicker() {
        colorSelection = $element[0].querySelector('[data-bc-picker]');
        colorSelectionIndicator = $element[0].querySelector('[data-bc-picker-indicator]');
        colorSlider = $element[0].querySelector('[data-bc-slider]');
        colorSliderIndicator = $element[0].querySelector('[data-bc-slider-indicator]');

        ColorPicker.fixIndicators(colorSliderIndicator, colorSelectionIndicator);

        ctrl.cp = new ColorPicker(colorSlider, colorSelection, pickNewColor);
    }

    function createNewPaletteColor() {
        if (ctrl.palette.indexOf(getSelectedColor()) < 0) {
            ctrl.palette.push(getSelectedColor());
        }
    }

    function getSelectedColor() {
        return ctrl.color;
    }

    function pickNewColor(hex, hsv, rgb, pickerCoordinate, sliderCoordinate) {
        ColorPicker.positionIndicators(colorSliderIndicator, colorSelectionIndicator, sliderCoordinate, pickerCoordinate);

        ctrl.ngModelCtrl.$setViewValue(hex);
        ctrl.ngModelCtrl.$render();
    }

    function render() {
        ctrl.color = ctrl.ngModelCtrl.$viewValue;
    }

    function setModelCtrl(ngModelCtrl) {
        ctrl.ngModelCtrl = ngModelCtrl;
        ctrl.ngModelCtrl.$render = render;
    }

    function setNewColor($event, newColor) {
        $event.preventDefault();

        ctrl.cp.setHex(newColor);
    }
});
'use strict';

angular.module('bcapp-pattern-lab.color-picker.directive', ['bcapp-pattern-lab.color-picker.controller', 'bcapp-pattern-lab.html5Mode']).directive('colorPicker', function colorPickerDirective($location, html5Mode) {
    return {
        bindToController: true,
        controller: 'ColorPickerCtrl',
        controllerAs: 'colorPickerCtrl',
        require: ['colorPicker', '^ngModel'],
        restrict: 'E',
        scope: {
            palette: '='
        },
        templateUrl: 'src/js/bigcommerce/color-picker/color-picker.tpl.html',

        compile: function colorPickerDirectiveCompile(tElement) {
            tElement.addClass('colorPicker');

            return function colorPickerDirectiveLink($scope, element, attrs, ctrls) {
                var ctrl = ctrls[0];
                var ngModelCtrl = ctrls[1];

                ctrl.setModelCtrl(ngModelCtrl);
                ctrl.createColorPicker();

                // Apps that have a <base> tag require to have absolute paths
                // when using svg url references
                if (html5Mode.enabled) {
                    _.each(element[0].querySelectorAll('[fill]'), function (el) {
                        var betweenParenthesis = /\(([^)]+)\)/;
                        var elem = angular.element(el);
                        var currentFill = elem.attr('fill');

                        if (_.contains(currentFill, 'url(#')) {
                            var newFill = betweenParenthesis.exec(currentFill)[1];

                            elem.attr('fill', 'url(' + $location.path() + newFill + ')');
                        }
                    });
                }

                $scope.$watch(getModelValue, function modelWatch(newVal) {
                    if (newVal) {
                        ctrl.cp.setHex(newVal);
                    }
                });

                function getModelValue() {
                    return ctrl.ngModelCtrl.$modelValue;
                }
            };
        }
    };
});
'use strict';

angular.module('bcapp-pattern-lab.color-picker', ['bcapp-pattern-lab.color-picker.directive', 'bcapp-pattern-lab.color-picker-palette.directive']);
/**
 * @name credit-card directive
 * @description Component containing cc number, cvc, name, and expiry. Has an isolated scope with no controller.
 * @require form
 *
 * @param ccData {object} Contains ccNumber, ccType, ccExpiry, and ccName
 * @param ccConfig {object} The configuration object. Currently supporting:
 *  - cardCode {boolean} Indicates whether the cvv field should be shown. Default true.
 *  - cardCodeRequired {boolean} Indicates whether the cvv field is required. This only matters when cardCode is set to true. Default true.
 *  - fullName {boolean} Indicates whether the name field should be shown. Default true.
 * @param eagerType {boolean} If this attribute is set to false, then disable eager type detection. Defaults true.
 */
'use strict';

angular.module('bcapp-pattern-lab.credit-card.directive', ['bcapp-pattern-lab.icon']).directive('creditCard', function creditCardDirective($compile, $parse, $templateCache) {
    var cvvTooltipTemplate = $templateCache.get('src/js/bigcommerce/credit-card/credit-card-cvv/tooltip.tpl.html');

    return {
        compile: function creditCardCompile(tElem, tAttrs) {
            var isEagerType = true;

            if (tAttrs.eagerType && $parse(tAttrs.eagerType)() === false) {
                var ccNumber = tElem[0].querySelector('#ccNumber');

                ccNumber.removeAttribute('ccEagerType');
                isEagerType = false;
            }

            return function creditCardLink(scope, elem, attr, formCtrl) {
                var cvvTooltipElement = $compile(cvvTooltipTemplate)(scope);
                var defaultConfig = {
                    cardCode: true,
                    cardCodeRequired: true,
                    fullName: true
                };

                scope.getCvvTooltipHtml = getCvvTooltipHtml;

                init();

                function init() {
                    scope.formCtrl = formCtrl;
                    scope.ccConfig = _.defaults(scope.ccConfig, defaultConfig);

                    /**
                     * The credit card type is deduced by the `ccNumber` directive. This is in turn exposed
                     * as either `$ccEagerType` or `$ccType` on the input control element. Watch for changes and bind the type to the corresponding
                     * value on ccData.
                     */
                    scope.$watch(getDetectedCcType, setCcType);
                }

                /**
                 * Return the html for the tooltip. Using outerHTML to also include the root element
                 * @return {String} Html string for the cvv tooltip template
                 */
                function getCvvTooltipHtml() {
                    return cvvTooltipElement[0].outerHTML;
                }

                /**
                 * Get the detected credit card type exposed on the form control by the ccNumber child directive.
                 * This value will be exposed as $ccEagerType or $ccType depending on whether this feature is enabled.
                 * @return {string|null}
                 */
                function getDetectedCcType() {
                    return isEagerType ? formCtrl.ccNumber.$ccEagerType : formCtrl.ccNumber.$ccType;
                }

                /**
                 * Set ccData.ccType
                 * @param {string|null} type The credit card type, i.e. 'visa'
                 * @return {string|null} type
                 */
                function setCcType(type) {
                    scope.ccData.ccType = type;

                    return type;
                }
            };
        },
        require: '^form',
        restrict: 'EA',
        scope: {
            ccData: '=',
            ccConfig: '='
        },
        templateUrl: 'src/js/bigcommerce/credit-card/credit-card.tpl.html'
    };
});
'use strict';

angular.module('bcapp-pattern-lab.credit-card', ['credit-cards', 'bcapp-pattern-lab.credit-card.bc-cvc', 'bcapp-pattern-lab.credit-card.cc-expiry', 'bcapp-pattern-lab.credit-card.directive', 'gettext']);
'use strict';

angular.module('bcapp-pattern-lab.credit-card-types.constant', []).constant('CC_TYPES', {
    'American Express': 'amex',
    'Diners Club': 'dinersclub',
    'Discover': 'discover',
    'MasterCard': 'mastercard',
    'Visa': 'visa'
});
'use strict';

angular.module('bcapp-pattern-lab.credit-card-types.controller', ['bcapp-pattern-lab.credit-card-types.constant']).controller('CreditCardTypesCtrl', function CreditCardTypesCtrl($element, CC_TYPES) {
    var ctrl = this;

    ctrl.hasSelectedType = hasSelectedType;
    ctrl.isSelectedType = isSelectedType;
    ctrl.mapToSvg = mapToSvg;

    init();

    function init() {
        $element.addClass('creditCardTypes');
    }

    /**
     * Checks whether a type has been selected (or detected by the credit-card component)
     * @return {Boolean}
     */
    function hasSelectedType() {
        return !_.isEmpty(ctrl.getSelectedType());
    }

    /**
     * Checks if the passed in ccType is the same as the selected ccType
     * @param ccType {String}
     * @return {Boolean}
     */
    function isSelectedType(ccType) {
        return ccType === ctrl.getSelectedType();
    }

    /**
     * Map the ccType to a corresponding svg name
     * @param ccType {String}
     * @return {String}
     */
    function mapToSvg(ccType) {
        return CC_TYPES[ccType];
    }
});
/**
 * @name credit-card-types directive
 * @description Component displaying and greying out credit card type icons based on the selected credit card type.
 * `.is-active` is added to the corresponding selected credit card type. `.not-active` is added for the other
 * types. If no credit card types has been selected, then neither `.is-active` and `.not-active` will be added at all.
 *
 * @param selectedType {String} Credit card type. Valid types are 'Visa', 'MasterCard', 'Diners Club', 'Discover', and 'American Express'
 * @param supportedTypes {Array} Array of credit card types to display. The card types use the same strings: 'American Express', 'Discover', 'MasterCard', 'Visa'
 */
'use strict';

angular.module('bcapp-pattern-lab.credit-card-types.directive', ['bcapp-pattern-lab.credit-card-types.controller']).directive('creditCardTypes', function creditCardTypesDirective() {
    return {
        bindToController: true,
        controller: 'CreditCardTypesCtrl as creditCardTypesCtrl',
        restrict: 'E',
        scope: {
            getSelectedType: '&selectedType',
            getSupportedTypes: '&supportedTypes'
        },
        templateUrl: 'src/js/bigcommerce/credit-card-types/credit-card-types.tpl.html'
    };
});
'use strict';

angular.module('bcapp-pattern-lab.credit-card-types', ['bcapp-pattern-lab.credit-card-types.constant', 'bcapp-pattern-lab.credit-card-types.controller', 'bcapp-pattern-lab.credit-card-types.directive']);
'use strict';

angular.module('bcapp-pattern-lab.form.directive', []).directive('form', function formDirective() {
    return {
        restrict: 'E',
        link: function formLink(scope, element, attrs) {
            element.addClass('form');
            element.attr('novalidate', '');

            // Use disable-auto-focus="true" to turn off automatic error focusing
            if (!attrs.disableAutoFocus) {
                element.on('submit', function formAutoFocusSubmitHandler() {
                    var invalidField = element[0].querySelector('.ng-invalid');

                    if (invalidField) {
                        invalidField.focus();

                        // Auto-select existing text for fields that support it (text, email, password, etc.)
                        if (invalidField.select) {
                            invalidField.select();
                        }
                    }
                });
            }
        }
    };
});
'use strict';

angular.module('bcapp-pattern-lab.form', ['bcapp-pattern-lab.form.directive']);
'use strict';

angular.module('bcapp-pattern-lab.form-field.directive', []).directive('formField', function formFieldDirective($log) {
    return {
        require: '^form',
        restrict: 'EA',
        scope: true,
        link: {
            pre: function formFieldLink(scope, element, attrs) {
                // Inherited by the form-field-errors directive to avoid redeclaration
                scope.property = attrs.property;
            },

            post: function formFieldLink(scope, element, attrs, formCtrl) {
                // Locates and watches the matching input/select/etc (based on its name attribute) in the parent form
                var property = attrs.property,
                    propertyValidFn = function propertyValidFn() {
                    return formCtrl[property].$valid;
                },
                    formSubmittedFn = function formSubmittedFn() {
                    return formCtrl.$submitted;
                };

                element.addClass('form-field');

                // If a property wasn't provided, we can't do much else
                if (!property) {
                    return;
                }

                // If a property was provided, but no ng-model was defined for the field, validation won't work
                if (!formCtrl[property]) {
                    return $log.info('Form fields containing inputs without an ng-model property will not be validated');
                }

                init();

                function init() {
                    // Update the interface if the form is submitted or the property's validity state changes
                    scope.$watch(formSubmittedFn, checkValidity);
                    scope.$watch(propertyValidFn, checkValidity);
                }

                function checkValidity() {
                    // Only show an error if the user has already attempted to submit the form
                    element.toggleClass('form-field--error', formCtrl.$submitted && formCtrl[property].$invalid);
                }
            }
        }
    };
});
'use strict';

angular.module('bcapp-pattern-lab.form-field', ['bcapp-pattern-lab.form-field.directive', 'bcapp-pattern-lab.form-field-error', 'bcapp-pattern-lab.form-field-errors']);
'use strict';

angular.module('bcapp-pattern-lab.form-field-error.directive', []).directive('formFieldError', function formFieldErrorDirective($compile) {
    return {
        priority: 10,
        replace: true,
        restrict: 'EA',
        templateUrl: 'src/js/bigcommerce/form-field-error/form-field-error.tpl.html',
        terminal: true,
        transclude: true,
        compile: function formFieldErrorCompile(tElement, tAttrs) {
            // The translate property wipes out our ng-message logic in the post link function
            // The priority and terminal properties above ensure this check occurs
            if (tElement.attr('translate') !== undefined) {
                throw new SyntaxError('The translate attribute cannot be used with the form-field-error directive. ' + 'Use the translate filter instead (example: {{ "my error message" | translate }}). ' + 'Validator: ' + tAttrs.validate);
            }

            return {
                post: function formFieldErrorPostLink(scope, element, attrs, controllers, transclude) {
                    scope.property = scope.property || attrs.property;

                    transclude(function formFieldErrorTransclude(errorClone) {
                        var labelElement = angular.element('<label>');

                        // ngMessage doesn't play well with dynamic message insertion, translation, or
                        // message expressions, so we build its element up here and inject it into the DOM
                        labelElement.attr('for', scope.property);
                        labelElement.attr('ng-message', attrs.validate);
                        labelElement.attr('role', 'alert');
                        labelElement.addClass('form-inlineMessage');

                        // The error span should already have a translation watcher on it by now, using a filter
                        labelElement.append(errorClone);

                        element.append(labelElement);

                        $compile(element)(scope);
                    });
                }
            };
        }
    };
});
'use strict';

angular.module('bcapp-pattern-lab.form-field-error', ['bcapp-pattern-lab.form-field-error.directive']);
'use strict';

angular.module('bcapp-pattern-lab.form-field-errors.directive', []).directive('formFieldErrors', function formFieldErrorsDirective() {
    return {
        replace: true,
        require: '^form',
        restrict: 'EA',
        templateUrl: 'src/js/bigcommerce/form-field-errors/form-field-errors.tpl.html',
        transclude: true,
        link: {
            // Pre-link is required, as we have to inject our scope properties before the child
            // form-field-error directive (and its internal ng-message directive's) post-link functions
            pre: function formFieldErrorsPreLink(scope, element, attrs, formCtrl) {
                // Property name can be inherited from parent scope, such as from the form-field directive
                var property = scope.property || attrs.property,
                    propertyField = formCtrl[property];

                // Inherited by form-field-error directive. Lives directly on scope because the require
                // property does not work well with directive controller instances
                scope.formCtrl = formCtrl;
                scope.property = property;
                scope.propertyField = propertyField;
            }
        }
    };
});
'use strict';

angular.module('bcapp-pattern-lab.form-field-errors', ['bcapp-pattern-lab.form-field-errors.directive']);
'use strict';

angular.module('bcapp-pattern-lab.form-input-color.controller', []).controller('FormInputColorCtrl', function ($element) {
    var ctrl = this;
    var hexColorRegex = /^#(([0-9a-fA-F]{2}){3}|([0-9a-fA-F]){3})$/;

    var isVisible = false;

    ctrl.onChange = onChange;
    ctrl.hidePicker = hidePicker;
    ctrl.isPickerVisible = isPickerVisible;
    ctrl.setModelCtrl = setModelCtrl;
    ctrl.showPicker = showPicker;
    ctrl.uniqueId = getUniqueID('formInputColor-');

    function onChange() {
        if (hexColorRegex.test(ctrl.color)) {
            ctrl.lastValidColor = ctrl.color;
            ctrl.ngModelCtrl.$setViewValue(ctrl.color);
        }
    }

    function getUniqueID(idPrefix) {
        return _.uniqueId(idPrefix);
    }

    function isPickerVisible(isVisibleToSet) {
        if (isVisibleToSet !== undefined) {
            isVisible = isVisibleToSet;
        }

        return isVisible;
    }

    function hidePicker($event) {
        if ($element[0].contains($event.target)) {
            return;
        }

        ctrl.isPickerVisible(false);
    }

    function render() {
        ctrl.color = ctrl.ngModelCtrl.$viewValue;
        ctrl.lastValidColor = ctrl.color;
    }

    function setModelCtrl(ngModelCtrl) {
        ctrl.ngModelCtrl = ngModelCtrl;
        ctrl.ngModelCtrl.$render = render;
    }

    function showPicker($event) {
        $event.preventDefault();

        ctrl.isPickerVisible(true);
    }
});
'use strict';

angular.module('bcapp-pattern-lab.form-input-color.directive', ['bcapp-pattern-lab.form-input-color.controller']).directive('formInputColor', function formInputColorDirective($document) {
    return {
        bindToController: true,
        controller: 'FormInputColorCtrl',
        controllerAs: 'formInputColorCtrl',
        require: ['formInputColor', '^ngModel'],
        restrict: 'E',
        scope: {
            labelText: '=',
            palette: '=',
            placeholderText: '='
        },
        templateUrl: 'src/js/bigcommerce/form-input-color/form-input-color.tpl.html',

        compile: function formInputColorDirectiveCompile(tElement) {
            tElement.addClass('form-inputColor');

            return function formInputColorDirectiveLink($scope, element, attrs, ctrls) {
                var ctrl = ctrls[0];
                var ngModelCtrl = ctrls[1];

                ctrl.setModelCtrl(ngModelCtrl);

                $document.on('mousedown', function hidePicker(event) {
                    $scope.$apply(function () {
                        ctrl.hidePicker(event);
                    });
                });
            };
        }
    };
});
'use strict';

angular.module('bcapp-pattern-lab.form-input-color', ['bcapp-pattern-lab.form-input-color.directive']);
'use strict';

angular.module('bcapp-pattern-lab.html5Mode', ['bcapp-pattern-lab.html5Mode.service']);
'use strict';

angular.module('bcapp-pattern-lab.html5Mode.service', []).provider('html5Mode', function html5ModeProvider($locationProvider) {
    this.$get = function html5ModeService() {
        return $locationProvider.html5Mode();
    };
});
'use strict';

angular.module('bcapp-pattern-lab.icon.controller', ['bcapp-pattern-lab.icon.svgRootPath']).controller('IconCtrl', function iconDirectiveController($http, $templateCache, svgRootPath) {
    var ctrl = this;

    ctrl.updateGlyph = updateGlyph;

    function updateGlyph(glyph) {
        var fullSvgPath = svgRootPath + glyph + '.svg';

        return $http.get(fullSvgPath, { cache: $templateCache }).then(function iconDirectiveHttpSuccess(response) {
            return response.data;
        });
    }
});
/**
 * @description Icon directive used to load an inline svg icon, simliar to icon
 *              font methods of past <i class="icon-foo-bar"></i>
 * @example
 * <icon glyph="ic-add-circle"></icon>
 */
'use strict';

angular.module('bcapp-pattern-lab.icon.directive', ['bcapp-pattern-lab.icon.controller']).directive('icon', function iconDirective() {
    return {
        bindToController: true,
        controller: 'IconCtrl as iconCtrl',
        restrict: 'E',
        scope: {
            glyph: '@'
        },
        compile: function iconDirectiveCompile(tElement) {
            tElement.addClass('icon');
            tElement.attr('aria-hidden', true);

            return function iconDirectiveLink($scope, element, attrs, ctrl) {
                $scope.$watch('iconCtrl.glyph', function iconDirectiveLinkWatch(newValue) {
                    ctrl.updateGlyph(newValue).then(function iconUpdateGlyphThen(svg) {
                        element.html(svg);
                    });
                });
            };
        }
    };
});
'use strict';

angular.module('bcapp-pattern-lab.icon', ['bcapp-pattern-lab.icon.directive']);
'use strict';

angular.module('bcapp-pattern-lab.icon.svgRootPath', []).provider('svgRootPath', function svgRootPathProviderConfig() {
    this.setRootPath = setRootPath;
    this.$get = function svgRootPathProviderGet($log) {
        if (this.svgRootPath === undefined) {
            $log.error('No svgRootPath provided. Please configure this using the svgRootPathProvider');
        }

        return this.svgRootPath;
    };

    function setRootPath(newRootPath) {
        this.svgRootPath = newRootPath;
    }
});
'use strict';

angular.module('bcapp-pattern-lab.loading-notification.directive', []).directive('loadingNotification', function loadingNotificationDirective($rootScope) {
    return {
        restrict: 'E',
        templateUrl: 'src/js/bigcommerce/loading-notification/loading-notification.tpl.html',

        link: function link(scope) {
            $rootScope.$on('ajaxRequestRunning', function (event, val) {
                scope.requestInProgress = val;
            });
        }
    };
});
'use strict';

angular.module('bcapp-pattern-lab.loading-notification', ['bcapp-pattern-lab.loading-notification.directive']);
'use strict';

angular.module('bcapp-pattern-lab.loading-overlay.controller', []).controller('LoadingOverlayCtrl', function LoadingOverlayCtrl($rootScope, $timeout) {
    var ctrl = this,
        defaultDebounce = 100,
        timeout;

    if (ctrl.debounce === undefined) {
        ctrl.debounce = defaultDebounce;
    }

    if (ctrl.useUiRouter) {
        $rootScope.$on('$stateChangeStart', startLoading);
        $rootScope.$on('$stateChangeSuccess', stopLoading);
        $rootScope.$on('$stateChangeError', stopLoading);
    }

    function startLoading(event) {
        if (event.defaultPrevented) {
            return;
        }

        timeout = $timeout(function startLoadingTimer() {
            ctrl.loading = true;
        }, ctrl.debounce);
    }

    function stopLoading(event) {
        if (event.defaultPrevented) {
            return;
        }

        $timeout.cancel(timeout);
        ctrl.loading = false;
    }
});
'use strict';

angular.module('bcapp-pattern-lab.loading-overlay.directive', ['bcapp-pattern-lab.loading-overlay.controller']).directive('loadingOverlay', function loadingOverlay($compile) {
    return {
        bindToController: true,
        controller: 'LoadingOverlayCtrl as loadingOverlayCtrl',
        restrict: 'A',
        scope: {
            debounce: '=?',
            loading: '=?loadingOverlay',
            useUiRouter: '=?'
        },
        compile: function loadingOverlayCompile(element) {
            element.addClass('loadingOverlay-container');

            return function loadingOverlayLink(scope, element) {
                var overlay = $compile('<div class="loadingOverlay" ng-if="loadingOverlayCtrl.loading"></div>')(scope);
                element.append(overlay);
            };
        }
    };
});
'use strict';

angular.module('bcapp-pattern-lab.loading-overlay', ['bcapp-pattern-lab.loading-overlay.directive']);
/*
 * Override angular foundation's $modalStack service to remove the `top` css property.
 * cannot use a decorator because the `open` relies on closures and does not return the compiled element.
 * Changes are between `// Changes` comments
*/
'use strict';

angular.module('bcapp-pattern-lab.bc-modal.modalStack.service', []).factory('$modalStack', ['$window', '$transition', '$timeout', '$document', '$compile', '$rootScope', '$$stackedMap', function ($window, $transition, $timeout, $document, $compile, $rootScope, $$stackedMap) {
  // Changes: change from `modal-open` to `has-activeModal`
  var OPENED_MODAL_CLASS = 'has-activeModal';
  // Changes

  var backdropDomEl, backdropScope;
  var openedWindows = $$stackedMap.createNew();
  var $modalStack = {};

  function backdropIndex() {
    var topBackdropIndex = -1;
    var opened = openedWindows.keys();
    for (var i = 0; i < opened.length; i++) {
      if (openedWindows.get(opened[i]).value.backdrop) {
        topBackdropIndex = i;
      }
    }
    return topBackdropIndex;
  }

  $rootScope.$watch(backdropIndex, function (newBackdropIndex) {
    if (backdropScope) {
      backdropScope.index = newBackdropIndex;
    }
  });

  function removeModalWindow(modalInstance) {
    var body = $document.find('body').eq(0);
    var modalWindow = openedWindows.get(modalInstance).value;

    //clean up the stack
    openedWindows.remove(modalInstance);

    //remove window DOM element
    removeAfterAnimate(modalWindow.modalDomEl, modalWindow.modalScope, 300, function () {
      modalWindow.modalScope.$destroy();
      body.toggleClass(OPENED_MODAL_CLASS, openedWindows.length() > 0);
      checkRemoveBackdrop();
    });
  }

  function checkRemoveBackdrop() {
    //remove backdrop if no longer needed
    if (backdropDomEl && backdropIndex() == -1) {
      var backdropScopeRef = backdropScope;
      removeAfterAnimate(backdropDomEl, backdropScope, 150, function () {
        backdropScopeRef.$destroy();
        backdropScopeRef = null;
      });
      backdropDomEl = undefined;
      backdropScope = undefined;
    }
  }

  function removeAfterAnimate(domEl, scope, emulateTime, done) {
    // Closing animation
    scope.animate = false;

    var transitionEndEventName = $transition.transitionEndEventName;
    if (transitionEndEventName) {
      // transition out
      var timeout = $timeout(afterAnimating, emulateTime);

      domEl.bind(transitionEndEventName, function () {
        $timeout.cancel(timeout);
        afterAnimating();
        scope.$apply();
      });
    } else {
      // Ensure this call is async
      $timeout(afterAnimating, 0);
    }

    function afterAnimating() {
      if (afterAnimating.done) {
        return;
      }
      afterAnimating.done = true;

      domEl.remove();
      if (done) {
        done();
      }
    }
  }

  $document.bind('keydown', function (evt) {
    var modal;

    if (evt.which === 27) {
      modal = openedWindows.top();
      if (modal && modal.value.keyboard) {
        $rootScope.$apply(function () {
          $modalStack.dismiss(modal.key);
        });
      }
    }
  });

  $modalStack.open = function (modalInstance, modal) {

    openedWindows.add(modalInstance, {
      deferred: modal.deferred,
      modalScope: modal.scope,
      backdrop: modal.backdrop,
      keyboard: modal.keyboard
    });

    var body = $document.find('body').eq(0),
        currBackdropIndex = backdropIndex();

    if (currBackdropIndex >= 0 && !backdropDomEl) {
      backdropScope = $rootScope.$new(true);
      backdropScope.index = currBackdropIndex;
      backdropDomEl = $compile('<div modal-backdrop></div>')(backdropScope);
      body.append(backdropDomEl);
    }

    // Changes: deletion of css top property calculation
    var angularDomEl = angular.element('<div modal-window style="visibility: visible; display: block"></div>');
    angularDomEl.attr('window-class', modal.windowClass);
    angularDomEl.attr('index', openedWindows.length() - 1);
    angularDomEl.attr('animate', 'animate');
    angularDomEl.html(modal.content);

    var modalDomEl = $compile(angularDomEl)(modal.scope);
    openedWindows.top().value.modalDomEl = modalDomEl;
    body.append(modalDomEl);
    body.addClass(OPENED_MODAL_CLASS);
  };

  $modalStack.close = function (modalInstance, result) {
    var modalWindow = openedWindows.get(modalInstance).value;
    if (modalWindow) {
      modalWindow.deferred.resolve(result);
      removeModalWindow(modalInstance);
    }
  };

  $modalStack.dismiss = function (modalInstance, reason) {
    var modalWindow = openedWindows.get(modalInstance).value;
    if (modalWindow) {
      modalWindow.deferred.reject(reason);
      removeModalWindow(modalInstance);
    }
  };

  $modalStack.dismissAll = function (reason) {
    var topModal = this.getTop();
    while (topModal) {
      this.dismiss(topModal.key, reason);
      topModal = this.getTop();
    }
  };

  $modalStack.getTop = function () {
    return openedWindows.top();
  };

  return $modalStack;
}]);
/*
 * This module modifies angular foundation's modal implementation. This does not create a new modal service/directive.
 * 
*/
'use strict';

angular.module('bcapp-pattern-lab.bc-modal', ['bcapp-pattern-lab.bc-modal.modalStack.service']);
/**
 * @description Used to create a toggle switch for forms
 * @example
    <switch ng-model="ctrl.switchModel1"></switch>

    <switch
        toggle-off-text="Off"
        toggle-on-text="On"
        ng-model="ctrl.switchModel2">
    </switch>

    <switch
        has-icon
        ng-model="ctrl.switchModel3">
    </switch>

    <switch
        is-important
        left-label="Down for Maintenance"
        right-label="Open"
        ng-model="ctrl.switchModel4">
    </switch>
 */
'use strict';

angular.module('bcapp-pattern-lab.switch.directive', []).directive('switch', function switchDirective() {

    function getUniqueID(idPrefix) {
        return _.uniqueId(idPrefix);
    }

    return {
        restrict: 'E',
        templateUrl: 'src/js/bigcommerce/switch/switch.tpl.html',
        require: 'ngModel',
        scope: {
            ariaDescription: '@',
            labelText: '@',
            leftDescription: '@',
            ngFalseValue: '@',
            ngTrueValue: '@',
            rightDescription: '@',
            toggleOffLabel: '@',
            toggleOnLabel: '@',
            uniqueId: '@'
        },
        bindToController: true,
        controllerAs: 'switchCtrl',
        compile: function switchDirectiveCompile(tElem, tAttrs) {
            var checkboxElem = tElem.find('input');

            if (tAttrs.ngFalseValue) {
                checkboxElem.attr('ng-false-value', tAttrs.ngFalseValue);
            }

            if (tAttrs.ngTrueValue) {
                checkboxElem.attr('ng-true-value', tAttrs.ngTrueValue);
            }

            return function switchDirectivePostLink(scope, element, attrs, ngModelCtrl) {
                scope.switchCtrl.init(ngModelCtrl);
            };
        },
        controller: function switchDirectiveCtrl($scope, $element, $attrs) {
            var ctrl = this;

            // state
            ctrl.isImportant = angular.isDefined($attrs.isImportant) && $attrs.isImportant !== 'false';
            ctrl.hasIcon = angular.isDefined($attrs.hasIcon) && $attrs.hasIcon !== 'false';

            // labels
            ctrl.labelText = $attrs.toggleOffLabel;

            // ids
            ctrl.uniqueId = getUniqueID('switch-');
            ctrl.ariaDescriptionID = getUniqueID('switch-ariaDescription-');

            ctrl.init = init;
            ctrl.updateModel = updateModel;

            function init(ngModelCtrl) {
                ctrl.ngModelCtrl = ngModelCtrl;
                ctrl.value = ctrl.ngModelCtrl.$modelValue;

                $scope.$watch('switchCtrl.ngModelCtrl.$modelValue', function switchValueChanged(newValue) {
                    ctrl.value = newValue;

                    ctrl.isChecked = _.isString(newValue) ? "'" + newValue + "'" === ctrl.ngTrueValue : newValue;
                    ctrl.labelText = !!ctrl.isChecked ? ctrl.toggleOnLabel : ctrl.toggleOffLabel;
                });
            }

            function updateModel() {
                ctrl.ngModelCtrl.$setViewValue(ctrl.value);
            }
        }
    };
});
'use strict';

angular.module('bcapp-pattern-lab.switch', ['bcapp-pattern-lab.switch.directive']);
/**
 * @description Sprite directive used to load an icon from an image sprite,
 *              simliar to the icon directive but less SVG
 * @example
 * <sprite glyph="ic-amex"></sprite>
 */

'use strict';

angular.module('bcapp-pattern-lab.sprite.directive', []).directive('sprite', function spriteDirective() {
    return {
        restrict: 'E',
        scope: {
            glyph: '@'
        },
        compile: spriteDirectiveCompile
    };

    function spriteDirectiveCompile(tElement) {
        tElement.addClass('sprite');
        tElement.attr('aria-hidden', true);

        return function spriteDirectiveLink($scope, element, attrs) {
            attrs.$observe('glyph', function (newValue) {
                element.attr('class', 'sprite sprite--' + newValue);
            });
        };
    }
});
'use strict';

angular.module('bcapp-pattern-lab.sprite', ['bcapp-pattern-lab.sprite.directive']);
'use strict';

angular.module('bcapp-pattern-lab.util', ['bcapp-pattern-lab.util.trustAsHtml']);
'use strict';

angular.module('bcapp-pattern-lab.bc-server-table.service', ['ui.router']).factory('BcServerTable', function bcServerTable($log, $q, $state, $stateParams) {
    var defaultTableConfig = {
        filters: [],
        queryKeys: {
            page: 'page',
            limit: 'limit',
            sortBy: 'sort-by',
            sortDir: 'sort-order'
        },
        rowIdKey: 'id',
        sortDirValues: {
            asc: 'asc',
            desc: 'desc'
        }
    };

    function ServerTable(tableId, tableConfig) {
        this.allSelected = false;
        this.filters = {};
        this.id = tableId;
        this.pagination = {
            page: null,
            limit: null,
            total: null
        };
        this.pendingRequest = false;
        this.resourceCallback = angular.noop;
        this.rows = [];
        this.selectedRows = {};
        this.sortBy = '';
        this.sortDir = '';

        this.tableConfig = _.isObject(tableConfig) ? tableConfig : {};
        this.tableConfig = _.defaults(this.tableConfig, defaultTableConfig);
    }

    ServerTable.prototype = {
        createParamsObject: createParamsObject,
        fetchResource: fetchResource,
        getSelectedRows: getSelectedRows,
        init: init,
        isRowSelected: isRowSelected,
        loadStateParams: loadStateParams,
        selectAllRows: selectAllRows,
        setPaginationValues: setPaginationValues,
        setRows: setRows,
        setSortingValues: setSortingValues,
        updatePage: updatePage,
        updateSort: updateSort,
        updateTable: updateTable,
        validateResource: validateResource
    };

    function createParamsObject() {
        var params = {},
            queryKeys = this.tableConfig.queryKeys,
            queryParamMap = [{
            queryKey: queryKeys.page,
            value: this.pagination.page
        }, {
            queryKey: queryKeys.limit,
            value: this.pagination.limit
        }, {
            queryKey: queryKeys.sortBy,
            value: this.sortBy
        }, {
            queryKey: queryKeys.sortDir,
            value: this.sortDir
        }];

        _.each(queryParamMap, function queryParamMapEach(param) {
            if (param.queryKey !== undefined) {
                params[param.queryKey] = param.value;
            }
        });

        _.extend(params, this.filters);

        return params;
    }

    function fetchResource() {
        var _this = this;

        this.pendingRequest = true;
        return this.resourceCallback(this.createParamsObject()).then(function resourceCallbackThen(resource) {
            if (_this.validateResource(resource)) {
                _this.setRows(resource.rows);
                _this.setPaginationValues(resource.pagination);
            }

            return _this;
        })['catch'](function resourceCallbackCatch(error) {
            $log.error('bc-server-table directive: failed to fetch resource');

            return $q.reject(error);
        })['finally'](function resourceCallbackFinally() {
            _this.pendingRequest = false;
        });
    }

    function getSelectedRows() {
        var _this = this;

        return _.filter(this.rows, function getSelectedRowsFilter(row) {
            return _this.isRowSelected(row);
        });
    }

    function init(config) {
        if (!_.isObject(config)) {
            config = {};
        }

        if (_.isFunction(config.resourceCallback)) {
            this.resourceCallback = config.resourceCallback;
        }

        return this.loadStateParams(config.stateParams).fetchResource();
    }

    function isRowSelected(row) {
        return this.selectedRows[row[this.tableConfig.rowIdKey]];
    }

    function loadStateParams(stateParams) {
        var queryKeys = this.tableConfig.queryKeys,
            _this = this;

        stateParams = stateParams || $stateParams;

        this.setPaginationValues({
            page: stateParams[queryKeys.page],
            limit: stateParams[queryKeys.limit]
        });

        this.setSortingValues(stateParams[queryKeys.sortBy], stateParams[queryKeys.sortDir]);

        // set filters from query params
        _.each(this.tableConfig.filters, function setFiltersEach(value) {
            _this.filters[value] = stateParams[value];
        });

        return this;
    }

    function selectAllRows() {
        var _this = this;

        this.allSelected = !this.allSelected;
        _.each(this.selectedRows, function selectAllRowsEach(value, key) {
            _this.selectedRows[key] = _this.allSelected;
        });

        return this;
    }

    function setPaginationValues(pagination) {
        this.pagination = this.pagination || {};
        _.extend(this.pagination, pagination);

        return this;
    }

    function setRows(rows) {
        var _this = this;

        this.rows = rows;
        this.selectedRows = _.reduce(rows, function initializeSelectedRowsObject(accum, row) {
            accum[row[_this.tableConfig.rowIdKey]] = false;
            return accum;
        }, {});

        return this;
    }

    function setSortingValues(sortBy, sortDir) {
        this.sortBy = sortBy || this.sortBy;
        this.sortDir = sortDir || this.sortDir;

        return this;
    }

    function updatePage(page, limit, total) {
        return this.setPaginationValues(page, limit, total).updateTable();
    }

    function updateSort(sortBy, sortDir) {
        return this.setSortingValues(sortBy, sortDir).setPaginationValues({
            page: 1
        }).updateTable();
    }

    function updateTable() {
        if (!this.pendingRequest) {
            $state.go($state.current.name, this.createParamsObject());
        }

        return this;
    }

    function validateResource(resource) {
        if (!_.isObject(resource)) {
            $log.error('bc-server-table directive: Resource callback must return an object');
            return false;
        }

        if (!_.isArray(resource.rows)) {
            $log.error('bc-server-table directive: returned object must contain a rows property that is an array.');
            return false;
        }

        if (!_.isObject(resource.pagination)) {
            $log.error('bc-server-table directive: returned object must contain a pagination property that is an object.');
            return false;
        }

        return true;
    }

    return ServerTable;
});
'use strict';

angular.module('bcapp-pattern-lab.bc-server-table-factory.service', ['bcapp-pattern-lab.bc-server-table.service']).factory('bcServerTableFactory', function bcServerTableFactory($log, BcServerTable) {
    var tables = {},
        service = {
        create: create,
        get: get,
        remove: remove
    };

    function create(tableId, tableConfig) {
        if (tableId in tables) {
            return service.get(tableId);
        }

        if (!tableId) {
            tableId = _.uniqueId('bc-server-table-instance-');
        }

        tables[tableId] = new BcServerTable(tableId, tableConfig);

        return tables[tableId];
    }

    function get(tableId) {
        return tables[tableId];
    }

    function remove(tableId) {
        delete tables[tableId];
    }

    return service;
});
/**
 * @name cc-expiry directive
 * @description A directive following angular-credit-card's approach to validating/formatting credit card expiration date.
 * Expect the cc-expiry ngModel to be in the format of `{ month: '05', year: '2017'}`.
 */
'use strict';

angular.module('bcapp-pattern-lab.credit-card.cc-expiry.directive', []).directive('ccExpiry', function ccExpDirective($filter) {
    return {
        compile: function compile(tElem, tAttr) {
            var EXPIRATION_MAX_LENGTH = 7; // length of `MM / yy`

            tAttr.$set('autocomplete', 'cc-exp');
            tAttr.$set('maxlength', EXPIRATION_MAX_LENGTH);
            tAttr.$set('pattern', '[0-9]*'); // for mobile keyboard display

            return function ccExpiryLink(scope, tElem, tAttr, ngModelCtrl) {
                init();

                function init() {
                    ngModelCtrl.$parsers.unshift(parser);
                    ngModelCtrl.$formatters.push(formatter);
                    ngModelCtrl.$validators.validFutureDate = validFutureDate;

                    scope.$watch(getViewValue, renderFormattedView);
                }

                /**
                 * get the input's view value
                 */
                function getViewValue() {
                    return ngModelCtrl.$viewValue;
                }

                /**
                 * formats the input view value to be the format `MM / yy` and re-renders view
                 */
                function renderFormattedView(viewValue, prevViewValue) {
                    if (!viewValue) {
                        return;
                    }

                    // a new value is added (as opposed to pressing backspace)
                    var isAddition = viewValue.length > prevViewValue.length;

                    ngModelCtrl.$setViewValue(format(viewValue, isAddition));
                    ngModelCtrl.$render();
                }

                /**
                 * Validates whether the entered expiration date is valid
                 */
                function validFutureDate(modelValue) {
                    var month = modelValue.month;
                    var year = modelValue.year;

                    return isValidDate(month, year) && !isPast(month, year);
                }

                /**
                 * Validates whether the given month and year are number strings with length of 2 and 4 respectively
                 */
                function isValidDate(month, year) {
                    var monthRegex = /^[0-9]{2}$/;
                    var yearRegex = /^[0-9]{4}$/;

                    return _.isString(month) && _.isString(year) && monthRegex.test(month) && yearRegex.test(year) && isValidMonth(month);
                }

                /**
                 * Checks whether the month is valid
                 */
                function isValidMonth(month) {
                    month = _.parseInt(month);

                    return month > 0 && month < 13;
                }

                /**
                 * Checks whether the given month and date is in the past
                 */
                function isPast(month, year) {
                    return getCurrMonthDate() > new Date(year, month - 1);
                }

                /**
                 * Get the date object based on current month and year
                 */
                function getCurrMonthDate() {
                    var date = new Date();

                    return new Date(date.getFullYear(), date.getMonth());
                }

                /**
                 * Uses angular date filter to format date model to corresponding view format
                 */
                function formatter() {
                    var exp = arguments.length <= 0 || arguments[0] === undefined ? {} : arguments[0];

                    var month = exp.month;
                    var year = exp.year;

                    if (_.isEmpty(month) && _.isEmpty(year)) {
                        return '';
                    }

                    return $filter('date')(new Date(year, month - 1), 'MM / yy');
                }

                /**
                 * Parses the formatted view values to model. Converts 2 digit year to full 4 digit year
                 * @param expiration {object} The expiration object {month, year}
                 */
                function parser(expiration) {
                    var baseYear = new Date().getFullYear().toString().slice(0, 2); // `'20'`
                    var values = expiration.split('/');
                    var month = values[0] ? values[0].trim() : '';
                    var year = values[1] ? baseYear + values[1].trim() : '';

                    return { month: month, year: year };
                }

                /**
                 * formats the view value to the form 'MM / yy'
                 */
                function format(expStr, isAddition) {
                    var values = expStr.split('/');
                    var month = values[0] ? values[0].trim() : '';
                    var year = values[1] ? values[1].trim().slice(-2) : '';

                    // don't add slash
                    if (!isAddition && !year || month.length < 2) {
                        return month;
                    }

                    // add slash in the right spot
                    if (isAddition && !year && month.length > 2) {
                        return month.slice(0, 2) + ' / ' + month.slice(2);
                    }

                    return month + ' / ' + year;
                }
            };
        },
        require: 'ngModel',
        restrict: 'A'
    };
});
'use strict';

angular.module('bcapp-pattern-lab.credit-card.cc-expiry', ['bcapp-pattern-lab.credit-card.cc-expiry.directive']);
/**
 * @name bc-cvc directive
 * @description A custom complementary directive to angular-credit-card's `ccCvc` directive.
 * To support allowing an optional cvc field (i.e. Securenet), this directive must override
 * the validation provided by ccCvc directive.
 */
'use strict';

angular.module('bcapp-pattern-lab.credit-card.bc-cvc', ['credit-cards']).directive('bcCvc', function bcCvcDirective($parse) {
    return {
        link: function bcCvcLink(scope, element, attributes, ngModel) {
            // override the validation to always return valid
            // if cvc is not required
            if (!$parse(attributes.ngRequired)(scope)) {
                ngModel.$validators.ccCvc = function () {
                    return true;
                };
            }
        },
        priority: 5, // higher priority to ensure ccCvc's link is ran first
        require: 'ngModel',
        restrict: 'A'
    };
});
/**
 * @name trustAsHtml
 * @description Simple utility filter to run the given html string through angular's $sce.trustAsHtml function.
 *
 * @param {String} text The html string to trust
 * @return {String} An angular-trusted object containing the html
 *
 * @example `<p ng-bind-html="rawHtml | trustAsHtml"></p>`
 */
'use strict';

angular.module('bcapp-pattern-lab.util.trustAsHtml', []).filter('trustAsHtml', function trustAsHtml($sce) {
    return function (text) {
        return $sce.trustAsHtml(text);
    };
});
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImJpZ2NvbW1lcmNlL2JjYXBwLXBhdHRlcm4tbGFiLm1vZHVsZS5qcyIsImJpZ2NvbW1lcmNlL2JjLWRhdGVwaWNrZXIvYmMtZGF0ZXBpY2tlci5jb25zdGFudHMuanMiLCJiaWdjb21tZXJjZS9iYy1kYXRlcGlja2VyL2JjLWRhdGVwaWNrZXIuZGlyZWN0aXZlLmpzIiwiYmlnY29tbWVyY2UvYmMtZGF0ZXBpY2tlci9iYy1kYXRlcGlja2VyLmpzIiwiYmlnY29tbWVyY2UvYmMtZHJvcGRvd24vYmMtZHJvcGRvd24tbWVudS5kaXJlY3RpdmUuanMiLCJiaWdjb21tZXJjZS9iYy1kcm9wZG93bi9iYy1kcm9wZG93bi10b2dnbGUuZGlyZWN0aXZlLmpzIiwiYmlnY29tbWVyY2UvYmMtZHJvcGRvd24vYmMtZHJvcGRvd24uY29udHJvbGxlci5qcyIsImJpZ2NvbW1lcmNlL2JjLWRyb3Bkb3duL2JjLWRyb3Bkb3duLmRpcmVjdGl2ZS5qcyIsImJpZ2NvbW1lcmNlL2JjLWRyb3Bkb3duL2JjLWRyb3Bkb3duLm1vZHVsZS5qcyIsImJpZ2NvbW1lcmNlL2JjLXBhZ2luYXRpb24vYmMtcGFnaW5hdGlvbi5kaXJlY3RpdmUuanMiLCJiaWdjb21tZXJjZS9iYy1wYWdpbmF0aW9uL2JjLXBhZ2luYXRpb24ubW9kdWxlLmpzIiwiYmlnY29tbWVyY2UvYmMtc2VydmVyLXRhYmxlL2JjLXNlcnZlci10YWJsZS5jb250cm9sbGVyLmpzIiwiYmlnY29tbWVyY2UvYmMtc2VydmVyLXRhYmxlL2JjLXNlcnZlci10YWJsZS5kaXJlY3RpdmUuanMiLCJiaWdjb21tZXJjZS9iYy1zZXJ2ZXItdGFibGUvYmMtc2VydmVyLXRhYmxlLm1vZHVsZS5qcyIsImJpZ2NvbW1lcmNlL2JjLXNlcnZlci10YWJsZS9iYy1zb3J0LWJ5LmRpcmVjdGl2ZS5qcyIsImJpZ2NvbW1lcmNlL2NoZWNrYm94LWxpc3QvY2hlY2tib3gtbGlzdC5jb250cm9sbGVyLmpzIiwiYmlnY29tbWVyY2UvY2hlY2tib3gtbGlzdC9jaGVja2JveC1saXN0LmRpcmVjdGl2ZS5qcyIsImJpZ2NvbW1lcmNlL2NoZWNrYm94LWxpc3QvY2hlY2tib3gtbGlzdC5tb2R1bGUuanMiLCJiaWdjb21tZXJjZS9jb2xvci1waWNrZXIvY29sb3ItcGlja2VyLXBhbGV0dGUuY29udHJvbGxlci5qcyIsImJpZ2NvbW1lcmNlL2NvbG9yLXBpY2tlci9jb2xvci1waWNrZXItcGFsZXR0ZS5kaXJlY3RpdmUuanMiLCJiaWdjb21tZXJjZS9jb2xvci1waWNrZXIvY29sb3ItcGlja2VyLmNvbnRyb2xsZXIuanMiLCJiaWdjb21tZXJjZS9jb2xvci1waWNrZXIvY29sb3ItcGlja2VyLmRpcmVjdGl2ZS5qcyIsImJpZ2NvbW1lcmNlL2NvbG9yLXBpY2tlci9jb2xvci1waWNrZXIubW9kdWxlLmpzIiwiYmlnY29tbWVyY2UvY3JlZGl0LWNhcmQvY3JlZGl0LWNhcmQuZGlyZWN0aXZlLmpzIiwiYmlnY29tbWVyY2UvY3JlZGl0LWNhcmQvY3JlZGl0LWNhcmQubW9kdWxlLmpzIiwiYmlnY29tbWVyY2UvY3JlZGl0LWNhcmQtdHlwZXMvY3JlZGl0LWNhcmQtdHlwZXMuY29uc3RhbnQuanMiLCJiaWdjb21tZXJjZS9jcmVkaXQtY2FyZC10eXBlcy9jcmVkaXQtY2FyZC10eXBlcy5jb250cm9sbGVyLmpzIiwiYmlnY29tbWVyY2UvY3JlZGl0LWNhcmQtdHlwZXMvY3JlZGl0LWNhcmQtdHlwZXMuZGlyZWN0aXZlLmpzIiwiYmlnY29tbWVyY2UvY3JlZGl0LWNhcmQtdHlwZXMvY3JlZGl0LWNhcmQtdHlwZXMubW9kdWxlLmpzIiwiYmlnY29tbWVyY2UvZm9ybS9mb3JtLmRpcmVjdGl2ZS5qcyIsImJpZ2NvbW1lcmNlL2Zvcm0vZm9ybS5tb2R1bGUuanMiLCJiaWdjb21tZXJjZS9mb3JtLWZpZWxkL2Zvcm0tZmllbGQuZGlyZWN0aXZlLmpzIiwiYmlnY29tbWVyY2UvZm9ybS1maWVsZC9mb3JtLWZpZWxkLm1vZHVsZS5qcyIsImJpZ2NvbW1lcmNlL2Zvcm0tZmllbGQtZXJyb3IvZm9ybS1maWVsZC1lcnJvci5kaXJlY3RpdmUuanMiLCJiaWdjb21tZXJjZS9mb3JtLWZpZWxkLWVycm9yL2Zvcm0tZmllbGQtZXJyb3IubW9kdWxlLmpzIiwiYmlnY29tbWVyY2UvZm9ybS1maWVsZC1lcnJvcnMvZm9ybS1maWVsZC1lcnJvcnMuZGlyZWN0aXZlLmpzIiwiYmlnY29tbWVyY2UvZm9ybS1maWVsZC1lcnJvcnMvZm9ybS1maWVsZC1lcnJvcnMubW9kdWxlLmpzIiwiYmlnY29tbWVyY2UvZm9ybS1pbnB1dC1jb2xvci9mb3JtLWlucHV0LWNvbG9yLmNvbnRyb2xsZXIuanMiLCJiaWdjb21tZXJjZS9mb3JtLWlucHV0LWNvbG9yL2Zvcm0taW5wdXQtY29sb3IuZGlyZWN0aXZlLmpzIiwiYmlnY29tbWVyY2UvZm9ybS1pbnB1dC1jb2xvci9mb3JtLWlucHV0LWNvbG9yLm1vZHVsZS5qcyIsImJpZ2NvbW1lcmNlL2h0bWw1TW9kZS9odG1sNU1vZGUubW9kdWxlLmpzIiwiYmlnY29tbWVyY2UvaHRtbDVNb2RlL2h0bWw1TW9kZS5zZXJ2aWNlLmpzIiwiYmlnY29tbWVyY2UvaWNvbi9pY29uLmNvbnRyb2xsZXIuanMiLCJiaWdjb21tZXJjZS9pY29uL2ljb24uZGlyZWN0aXZlLmpzIiwiYmlnY29tbWVyY2UvaWNvbi9pY29uLmpzIiwiYmlnY29tbWVyY2UvaWNvbi9pY29uLnN2Z1Jvb3RQYXRoLmpzIiwiYmlnY29tbWVyY2UvbG9hZGluZy1ub3RpZmljYXRpb24vbG9hZGluZy1ub3RpZmljYXRpb24uZGlyZWN0aXZlLmpzIiwiYmlnY29tbWVyY2UvbG9hZGluZy1ub3RpZmljYXRpb24vbG9hZGluZy1ub3RpZmljYXRpb24uanMiLCJiaWdjb21tZXJjZS9sb2FkaW5nLW92ZXJsYXkvbG9hZGluZy1vdmVybGF5LmNvbnRyb2xsZXIuanMiLCJiaWdjb21tZXJjZS9sb2FkaW5nLW92ZXJsYXkvbG9hZGluZy1vdmVybGF5LmRpcmVjdGl2ZS5qcyIsImJpZ2NvbW1lcmNlL2xvYWRpbmctb3ZlcmxheS9sb2FkaW5nLW92ZXJsYXkuanMiLCJiaWdjb21tZXJjZS9tb2RhbC9iYy1tb2RhbC5tb2RhbFN0YWNrLnNlcnZpY2UuanMiLCJiaWdjb21tZXJjZS9tb2RhbC9iYy1tb2RhbC5tb2R1bGUuanMiLCJiaWdjb21tZXJjZS9zd2l0Y2gvc3dpdGNoLmRpcmVjdGl2ZS5qcyIsImJpZ2NvbW1lcmNlL3N3aXRjaC9zd2l0Y2gubW9kdWxlLmpzIiwiYmlnY29tbWVyY2Uvc3ByaXRlL3Nwcml0ZS5kaXJlY3RpdmUuanMiLCJiaWdjb21tZXJjZS9zcHJpdGUvc3ByaXRlLmpzIiwiYmlnY29tbWVyY2UvdXRpbC91dGlsLm1vZHVsZS5qcyIsImJpZ2NvbW1lcmNlL2JjLXNlcnZlci10YWJsZS9iYy1zZXJ2ZXItdGFibGUvYmMtc2VydmVyLXRhYmxlLnNlcnZpY2UuanMiLCJiaWdjb21tZXJjZS9iYy1zZXJ2ZXItdGFibGUvYmMtc2VydmVyLXRhYmxlLWZhY3RvcnkvYmMtc2VydmVyLXRhYmxlLWZhY3Rvcnkuc2VydmljZS5qcyIsImJpZ2NvbW1lcmNlL2NyZWRpdC1jYXJkL2NjLWV4cGlyeS9jYy1leHBpcnkuZGlyZWN0aXZlLmpzIiwiYmlnY29tbWVyY2UvY3JlZGl0LWNhcmQvY2MtZXhwaXJ5L2NjLWV4cGlyeS5tb2R1bGUuanMiLCJiaWdjb21tZXJjZS9jcmVkaXQtY2FyZC9jcmVkaXQtY2FyZC1jdnYvYmMtY3ZjLmRpcmVjdGl2ZS5qcyIsImJpZ2NvbW1lcmNlL3V0aWwvdHJ1c3RBc0h0bWwvdHJ1c3RBc0h0bWwuZmlsdGVyLmpzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7O0FBQUEsT0FBTyxDQUFDLE1BQU0sQ0FBQyxtQkFBbUIsRUFBRSxDQUNoQyxTQUFTLEVBQ1QsV0FBVyxFQUNYLFlBQVksRUFDWixlQUFlLEVBQ2YsNkJBQTZCLEVBQzdCLGlDQUFpQyxFQUNqQywrQkFBK0IsRUFDL0IsNEJBQTRCLEVBQzVCLGlDQUFpQyxFQUNqQyxtQ0FBbUMsRUFDbkMsaUNBQWlDLEVBQ2pDLGdDQUFnQyxFQUNoQywrQkFBK0IsRUFDL0IscUNBQXFDLEVBQ3JDLHdCQUF3QixFQUN4Qiw4QkFBOEIsRUFDOUIsb0NBQW9DLEVBQ3BDLDZCQUE2QixFQUM3Qix3QkFBd0IsRUFDeEIsd0NBQXdDLEVBQ3hDLG1DQUFtQyxFQUNuQywwQkFBMEIsRUFDMUIsMEJBQTBCLEVBQzFCLHdCQUF3QixDQUMzQixDQUFDLENBQUM7Ozs7QUN4QkgsT0FBTyxDQUFDLE1BQU0sQ0FBQywyQ0FBMkMsRUFBRSxFQUFFLENBQUMsQ0FDMUQsUUFBUSxDQUFDLHdCQUF3QixFQUFFO0FBQ2hDLGFBQVMsRUFBRSxHQUFHO0FBQ2QsZUFBVyxFQUFFLE1BQU0sQ0FBQyxVQUFVLEVBQUUsQ0FBQyxjQUFjLENBQUMsR0FBRyxDQUFDO0FBQ3BELFVBQU0sRUFBRTtBQUNKLFlBQUksRUFBRSxpQkFBaUI7QUFDdkIsaUJBQVMsRUFBRSxZQUFZO0FBQ3ZCLFlBQUksRUFBRSxpQkFBaUI7QUFDdkIsZUFBTyxFQUFFLHNCQUFzQjtBQUMvQixtQkFBVyxFQUFFLGdCQUFnQjtBQUM3QixvQkFBWSxFQUFFLDBCQUEwQjtBQUN4QyxtQkFBVyxFQUFFLGFBQWE7QUFDMUIsZUFBTyxFQUFFLHNCQUFzQjtBQUMvQixtQkFBVyxFQUFFLHFCQUFxQjtBQUNsQyxvQkFBWSxFQUFFLDJCQUEyQjtBQUN6QyxvQkFBWSxFQUFFLDJCQUEyQjtBQUN6QyxjQUFNLEVBQUUscUJBQXFCO0FBQzdCLGdCQUFRLEVBQUUsaUJBQWlCO0FBQzNCLGFBQUssRUFBRSxrQkFBa0I7QUFDekIsa0JBQVUsRUFBRSxrQkFBa0I7QUFDOUIsWUFBSSxFQUFFLGlCQUFpQjtBQUN2QixrQkFBVSxFQUFFLHVCQUF1QjtBQUNuQyxtQkFBVyxFQUFFLGFBQWE7QUFDMUIsb0JBQVksRUFBRSwwQkFBMEI7QUFDeEMsWUFBSSxFQUFFLGlCQUFpQjtBQUN2QixnQkFBUSxFQUFFLHNCQUFzQjtBQUNoQyxrQkFBVSxFQUFFLHdCQUF3QjtLQUN2QztBQUNELFFBQUksRUFBRSxLQUFLO0FBQ1gsaUJBQWEsRUFBRSxPQUFPO0NBQ3pCLENBQUMsQ0FBQzs7OztBQzlCUCxPQUFPLENBQUMsTUFBTSxDQUFDLDJDQUEyQyxFQUFFLENBQ3hELDJDQUEyQyxDQUM5QyxDQUFDLENBQ0csU0FBUyxDQUFDLGNBQWMsRUFBRSxTQUFTLHFCQUFxQixDQUFDLHNCQUFzQixFQUFFO0FBQzlFLFdBQU87QUFDSCxnQkFBUSxFQUFFLEdBQUc7QUFDYixlQUFPLEVBQUUsU0FBUztBQUNsQixhQUFLLEVBQUU7QUFDSCxtQkFBTyxFQUFFLElBQUk7U0FDaEI7O0FBRUQsWUFBSSxFQUFFLFNBQVMsc0JBQXNCLENBQUMsS0FBSyxFQUFFLE9BQU8sRUFBRSxLQUFLLEVBQUUsT0FBTyxFQUFFO0FBQ2xFLGdCQUFJLEtBQUssQ0FBQyxPQUFPLEtBQUssU0FBUyxFQUFFO0FBQzdCLHFCQUFLLENBQUMsT0FBTyxHQUFHLEVBQUUsQ0FBQzthQUN0Qjs7O0FBR0QsYUFBQyxDQUFDLFFBQVEsQ0FBQyxLQUFLLENBQUMsT0FBTyxFQUFFLHNCQUFzQixDQUFDLENBQUM7OztBQUdsRCxpQkFBSyxDQUFDLFFBQVEsR0FBRyxJQUFJLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxFQUFFLEtBQUssQ0FBQyxPQUFPLENBQUMsQ0FBQzs7O0FBR2pELGlCQUFLLENBQUMsUUFBUSxDQUFDLEVBQUUsQ0FBQyxNQUFNLEVBQUUsU0FBUyxNQUFNLENBQUMsS0FBSyxFQUFFO0FBQzdDLHVCQUFPLENBQUMsYUFBYSxDQUFDLEtBQUssQ0FBQyxDQUFDO0FBQzdCLHFCQUFLLENBQUMsTUFBTSxFQUFFLENBQUM7YUFDbEIsQ0FBQyxDQUFDOztBQUVILGlCQUFLLENBQUMsUUFBUSxDQUFDLEVBQUUsQ0FBQyxPQUFPLEVBQUUsU0FBUyxPQUFPLENBQUMsT0FBTyxFQUFFO0FBQ2pELG9CQUFJLEtBQUssQ0FBQyxXQUFXLEtBQUssU0FBUyxFQUFFO0FBQ2pDLHlCQUFLLENBQUMsSUFBSSxDQUFDLGFBQWEsRUFBRSxPQUFPLENBQUMsV0FBVyxDQUFDLENBQUM7aUJBQ2xEO2FBQ0osQ0FBQyxDQUFDOzs7QUFHSCxtQkFBTyxDQUFDLEVBQUUsQ0FBQyxVQUFVLEVBQUUsU0FBUyxTQUFTLEdBQUc7QUFDeEMscUJBQUssQ0FBQyxRQUFRLENBQUMsT0FBTyxFQUFFLENBQUM7YUFDNUIsQ0FBQyxDQUFDO1NBQ047S0FDSixDQUFDO0NBQ0wsQ0FBQyxDQUFDOzs7QUN6Q1AsT0FBTyxDQUFDLE1BQU0sQ0FBQyxpQ0FBaUMsRUFBRSxDQUM5QywyQ0FBMkMsQ0FDOUMsQ0FBQyxDQUFDOzs7QUNGSCxPQUFPLENBQUMsTUFBTSxDQUFDLDhDQUE4QyxFQUFFLEVBQUUsQ0FBQyxDQUM3RCxTQUFTLENBQUMsZ0JBQWdCLEVBQUUsWUFBTTtBQUMvQixXQUFPO0FBQ0gsZ0JBQVEsRUFBRSxHQUFHO0FBQ2IsZUFBTyxFQUFFLGFBQWE7QUFDdEIsZUFBTyxFQUFFLGlCQUFDLFFBQVEsRUFBSztBQUNuQixvQkFBUSxDQUFDLFFBQVEsQ0FBQyxlQUFlLENBQUMsQ0FBQztBQUNuQyxvQkFBUSxDQUFDLElBQUksQ0FBQyxNQUFNLEVBQUUsU0FBUyxDQUFDLENBQUM7O0FBRWpDLG1CQUFPLFVBQUMsS0FBSyxFQUFFLE9BQU8sRUFBRSxLQUFLLEVBQUUsY0FBYyxFQUFLO0FBQzlDLHVCQUFPLENBQUMsSUFBSSxDQUFDLElBQUksRUFBRSxjQUFjLENBQUMsV0FBVyxFQUFFLENBQUMsQ0FBQztBQUNqRCx1QkFBTyxDQUFDLElBQUksQ0FBQyxlQUFlLEVBQUUsY0FBYyxDQUFDLFNBQVMsRUFBRSxDQUFDLENBQUM7O0FBRTFELHFCQUFLLENBQUMsR0FBRyxDQUFDLG9CQUFvQixFQUFFLFlBQU07QUFDbEMsMkJBQU8sQ0FBQyxJQUFJLENBQUMsZUFBZSxFQUFFLGNBQWMsQ0FBQyxTQUFTLEVBQUUsQ0FBQyxDQUFDO2lCQUM3RCxDQUFDLENBQUM7YUFDTixDQUFDO1NBQ0w7S0FDSixDQUFDO0NBQ0wsQ0FBQyxDQUFDOzs7QUNuQlAsT0FBTyxDQUFDLE1BQU0sQ0FBQyxnREFBZ0QsRUFBRSxFQUFFLENBQUMsQ0FDL0QsU0FBUyxDQUFDLGtCQUFrQixFQUFFLFVBQUMsUUFBUSxFQUFLO0FBQ3pDLFdBQU87QUFDSCxnQkFBUSxFQUFFLEdBQUc7QUFDYixnQkFBUSxFQUFFLElBQUk7QUFDZCxnQkFBUSxFQUFFLElBQUk7QUFDZCxlQUFPLEVBQUUsYUFBYTtBQUN0QixlQUFPLEVBQUUsaUJBQUMsUUFBUSxFQUFLO0FBQ25CLG9CQUFRLENBQUMsVUFBVSxDQUFDLG9CQUFvQixDQUFDLENBQUM7O0FBRTFDLG1CQUFPLFVBQUMsS0FBSyxFQUFFLE9BQU8sRUFBRSxLQUFLLEVBQUUsY0FBYyxFQUFLO0FBQzlDLHVCQUFPLENBQUMsSUFBSSxDQUFDLGlCQUFpQixFQUFFLEdBQUcsR0FBRyxjQUFjLENBQUMsV0FBVyxFQUFFLENBQUMsQ0FBQztBQUNwRSx1QkFBTyxDQUFDLElBQUksQ0FBQyxlQUFlLEVBQUUsY0FBYyxDQUFDLFdBQVcsRUFBRSxDQUFDLENBQUM7QUFDNUQsdUJBQU8sQ0FBQyxFQUFFLENBQUMsT0FBTyxFQUFFLGNBQWMsQ0FBQyxZQUFZLENBQUMsQ0FBQztBQUNqRCx3QkFBUSxDQUFDLE9BQU8sQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDO2FBQzVCLENBQUM7U0FDTDtLQUNKLENBQUM7Q0FDTCxDQUFDLENBQUM7OztBQ2xCUCxPQUFPLENBQUMsTUFBTSxDQUFDLDBDQUEwQyxFQUFFLEVBQUUsQ0FBQyxDQUN6RCxVQUFVLENBQUMsc0JBQXNCLEVBQUUsU0FBUyxvQkFBb0IsQ0FBQyxNQUFNLEVBQUUsVUFBVSxFQUFFO0FBQ2xGLFFBQU0sSUFBSSxHQUFHLElBQUksQ0FBQztBQUNsQixRQUFJLE1BQU0sR0FBRyxLQUFLLENBQUM7QUFDbkIsUUFBSSxRQUFRLFlBQUEsQ0FBQzs7QUFFYixRQUFJLENBQUMsYUFBYSxHQUFHLGFBQWEsQ0FBQztBQUNuQyxRQUFJLENBQUMsU0FBUyxHQUFHLFNBQVMsQ0FBQztBQUMzQixRQUFJLENBQUMsV0FBVyxHQUFHLFdBQVcsQ0FBQztBQUMvQixRQUFJLENBQUMsU0FBUyxHQUFHLFNBQVMsQ0FBQztBQUMzQixRQUFJLENBQUMsWUFBWSxHQUFHLFlBQVksQ0FBQzs7O0FBR2pDLFVBQU0sQ0FBQyxHQUFHLENBQUMsa0JBQWtCLEVBQUUsVUFBQyxLQUFLLEVBQUUsWUFBWSxFQUFLOztBQUVwRCxZQUFJLE1BQU0sSUFBSSxZQUFZLEtBQUssUUFBUSxFQUFFO0FBQ3JDLGdCQUFJLENBQUMsYUFBYSxFQUFFLENBQUM7U0FDeEI7S0FDSixDQUFDLENBQUM7O0FBRUgsYUFBUyxhQUFhLEdBQUc7QUFDckIsWUFBSSxDQUFDLFNBQVMsQ0FBQyxLQUFLLENBQUMsQ0FBQztBQUN0QixjQUFNLENBQUMsVUFBVSxDQUFDLG9CQUFvQixDQUFDLENBQUM7S0FDM0M7O0FBRUQsYUFBUyxTQUFTLEdBQUc7QUFDakIsZUFBTyxNQUFNLENBQUM7S0FDakI7O0FBRUQsYUFBUyxXQUFXLEdBQUc7QUFDbkIsWUFBSSxDQUFDLFFBQVEsRUFBRTtBQUNYLG9CQUFRLEdBQUcsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxjQUFjLENBQUMsQ0FBQztTQUN6QztBQUNELGVBQU8sUUFBUSxDQUFDO0tBQ25COztBQUVELGFBQVMsU0FBUyxDQUFDLEdBQUcsRUFBRTtBQUNwQixjQUFNLEdBQUcsR0FBRyxDQUFDO0tBQ2hCOztBQUVELGFBQVMsWUFBWSxHQUFHO0FBQ3BCLGNBQU0sR0FBRyxDQUFDLE1BQU0sQ0FBQzs7QUFFakIsY0FBTSxDQUFDLFVBQVUsQ0FBQyxvQkFBb0IsQ0FBQyxDQUFDOztBQUV4QyxrQkFBVSxDQUFDLFVBQVUsQ0FBQyxrQkFBa0IsRUFBRSxRQUFRLENBQUMsQ0FBQztLQUN2RDtDQUNKLENBQUMsQ0FBQzs7O0FDL0NQLE9BQU8sQ0FBQyxNQUFNLENBQUMseUNBQXlDLEVBQUUsQ0FDdEQsMENBQTBDLENBQzdDLENBQUMsQ0FDRyxTQUFTLENBQUMsWUFBWSxFQUFFLFVBQUMsU0FBUyxFQUFLO0FBQ3BDLFdBQU87QUFDSCx3QkFBZ0IsRUFBRSxJQUFJO0FBQ3RCLGtCQUFVLEVBQUUsc0JBQXNCO0FBQ2xDLG9CQUFZLEVBQUUsc0JBQXNCO0FBQ3BDLGdCQUFRLEVBQUUsSUFBSTtBQUNkLGVBQU8sRUFBRSxpQkFBQyxRQUFRLEVBQUs7QUFDbkIsb0JBQVEsQ0FBQyxJQUFJLENBQUMsTUFBTSxFQUFFLFVBQVUsQ0FBQyxDQUFDOztBQUVsQyxtQkFBTyxVQUFDLE1BQU0sRUFBRSxRQUFRLEVBQUUsS0FBSyxFQUFFLElBQUksRUFBSzs7Ozs7O0FBTXRDLHlCQUFTLENBQUMsRUFBRSxDQUFDLE9BQU8sRUFBRSxJQUFJLENBQUMsYUFBYSxDQUFDLENBQUM7O0FBRTFDLHdCQUFRLENBQUMsRUFBRSxDQUFDLFVBQVUsRUFBRSxZQUFNO0FBQzFCLDZCQUFTLENBQUMsR0FBRyxDQUFDLE9BQU8sRUFBRSxJQUFJLENBQUMsYUFBYSxDQUFDLENBQUM7aUJBQzlDLENBQUMsQ0FBQzthQUNOLENBQUM7U0FDTDtLQUNKLENBQUM7Q0FDTCxDQUFDLENBQUM7OztBQzFCUCxPQUFPLENBQUMsTUFBTSxDQUFDLCtCQUErQixFQUFFLENBQzVDLHlDQUF5QyxFQUN6QyxnREFBZ0QsRUFDaEQsOENBQThDLENBQ2pELENBQUMsQ0FBQzs7O0FDSkgsT0FBTyxDQUFDLE1BQU0sQ0FBQywyQ0FBMkMsRUFBRSxFQUFFLENBQUMsQ0FDMUQsU0FBUyxDQUFDLGNBQWMsRUFBRSxTQUFTLHFCQUFxQixDQUFDLE1BQU0sRUFBRTtBQUM5RCxXQUFPO0FBQ0gsZ0JBQVEsRUFBRSxHQUFHO0FBQ2IsYUFBSyxFQUFFLElBQUk7QUFDWCxtQkFBVyxFQUFFLHlEQUF5RDs7QUFFdEUsZUFBTyxFQUFFLFNBQVMsbUJBQW1CLENBQUMsUUFBUSxFQUFFLE1BQU0sRUFBRTtBQUNwRCxnQkFBSSxPQUFPLEdBQUcsRUFBRSxDQUFDOzs7O0FBSWpCLGFBQUMsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLEtBQUssRUFBRSxVQUFTLEdBQUcsRUFBRTtBQUMvQixvQkFBSSxHQUFHLEtBQUssT0FBTyxFQUFFO0FBQ2pCLDJCQUFPLENBQUMsR0FBRyxDQUFDLEdBQUcsUUFBUSxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsQ0FBQztpQkFDckM7YUFDSixDQUFDLENBQUM7Ozs7QUFJSCxtQkFBTyxDQUFDLGdCQUFnQixDQUFDLEdBQUcsMEJBQTBCLENBQUM7OztBQUd2RCxvQkFBUSxDQUFDLElBQUksQ0FBQyxZQUFZLENBQUMsQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLENBQUM7O0FBRTFDLG1CQUFPLFNBQVMsZ0JBQWdCLENBQUMsTUFBTSxFQUFFLE9BQU8sRUFBRSxLQUFLLEVBQUU7QUFDckQsb0JBQUksbUJBQW1CLEdBQUcsTUFBTSxDQUFDLEtBQUssQ0FBQyxRQUFRLENBQUM7b0JBQzVDLGFBQWEsR0FBRyxDQUFDLEVBQUUsRUFBRSxFQUFFLEVBQUUsRUFBRSxFQUFFLEVBQUUsRUFBRSxHQUFHLENBQUMsQ0FBQzs7QUFFMUMsc0JBQU0sQ0FBQyxRQUFRLEdBQUcsVUFBUyxLQUFLLEVBQUUsS0FBSyxFQUFFO0FBQ3JDLHlCQUFLLENBQUMsY0FBYyxFQUFFLENBQUM7QUFDdkIseUJBQUssR0FBRyxDQUFDLENBQUMsUUFBUSxDQUFDLEtBQUssQ0FBQyxDQUFDO0FBQzFCLDBCQUFNLENBQUMsS0FBSyxDQUFDLFlBQVksQ0FBQyxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsT0FBTyxFQUFFLEtBQUssQ0FBQyxDQUFDO0FBQ3pELDBCQUFNLENBQUMsa0JBQWtCLENBQUMsQ0FBQyxFQUFFLEtBQUssQ0FBQyxDQUFDO2lCQUN2QyxDQUFDOztBQUVGLHNCQUFNLENBQUMsY0FBYyxHQUFHLFlBQVc7QUFDL0IsMkJBQU8sTUFBTSxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsQ0FBQyxNQUFNLENBQUMsT0FBTyxDQUFDLENBQUM7aUJBQzdDLENBQUM7O0FBRUYsc0JBQU0sQ0FBQyxlQUFlLEdBQUcsWUFBVztBQUNoQywyQkFBTyxNQUFNLENBQUMsS0FBSyxDQUFDLFlBQVksQ0FBQyxDQUFDLE1BQU0sQ0FBQyxPQUFPLENBQUMsQ0FBQztpQkFDckQsQ0FBQzs7QUFFRixzQkFBTSxDQUFDLGVBQWUsR0FBRyxZQUFXO0FBQ2hDLDJCQUFPLE1BQU0sQ0FBQyxLQUFLLENBQUMsWUFBWSxDQUFDLENBQUMsTUFBTSxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsQ0FBQztpQkFDMUQsQ0FBQzs7QUFFRixzQkFBTSxDQUFDLGFBQWEsR0FBRyxZQUFXO0FBQzlCLDJCQUFPLE1BQU0sQ0FBQyxLQUFLLENBQUMsVUFBVSxDQUFDLENBQUMsTUFBTSxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsQ0FBQztpQkFDeEQsQ0FBQzs7QUFFRixzQkFBTSxDQUFDLElBQUksR0FBRyxZQUFXO0FBQ3JCLDJCQUFPLE1BQU0sQ0FBQyxhQUFhLEVBQUUsR0FBRyxNQUFNLENBQUMsZUFBZSxFQUFFLENBQUM7aUJBQzVELENBQUM7O0FBRUYsc0JBQU0sQ0FBQyxVQUFVLEdBQUcsWUFBVztBQUMzQiwyQkFBTyxNQUFNLENBQUMsSUFBSSxFQUFFLElBQUksTUFBTSxDQUFDLEtBQUssQ0FBQyxVQUFVLENBQUMsQ0FBQyxNQUFNLENBQUMsT0FBTyxDQUFDLEtBQUssS0FBSyxDQUFDO2lCQUM5RSxDQUFDOztBQUVGLHNCQUFNLENBQUMsU0FBUyxHQUFHLFlBQVc7QUFDMUIsd0JBQUksTUFBTSxHQUFHLE1BQU0sQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDLENBQUMsTUFBTSxDQUFDLE9BQU8sQ0FBQyxDQUFDOztBQUVsRCx3QkFBSSxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsTUFBTSxDQUFDLEVBQUU7QUFDeEIsK0JBQU8sYUFBYSxDQUFDO3FCQUN4Qjs7QUFFRCwyQkFBTyxNQUFNLENBQUM7aUJBQ2pCLENBQUM7O0FBRUYsc0JBQU0sQ0FBQyxrQkFBa0IsR0FBRyxVQUFTLElBQUksRUFBRSxLQUFLLEVBQUU7QUFDOUMsd0JBQUkseUJBQXlCLEdBQUc7QUFDeEIsNkJBQUssRUFBRSxLQUFLLElBQUksTUFBTSxDQUFDLGVBQWUsRUFBRTtBQUN4Qyw0QkFBSSxFQUFFLElBQUk7cUJBQ2I7d0JBQ0QsbUJBQW1CLENBQUM7O0FBRXhCLDBCQUFNLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsT0FBTyxFQUFFLElBQUksQ0FBQyxDQUFDOztBQUVoRCx1Q0FBbUIsR0FBRyxtQkFBbUIsQ0FBQyxNQUFNLEVBQUUseUJBQXlCLENBQUMsQ0FBQzs7OztBQUk3RSx3QkFBSSxPQUFPLG1CQUFtQixLQUFLLFVBQVUsRUFBRTtBQUMzQywyQ0FBbUIsQ0FBQyx5QkFBeUIsQ0FBQyxDQUFDO3FCQUNsRDtpQkFDSixDQUFDO2FBQ0wsQ0FBQztTQUNMO0tBQ0osQ0FBQztDQUNMLENBQUMsQ0FBQzs7O0FDMUZQLE9BQU8sQ0FBQyxNQUFNLENBQUMsaUNBQWlDLEVBQUUsQ0FDOUMsMkNBQTJDLENBQzlDLENBQUMsQ0FBQzs7O0FDRkgsT0FBTyxDQUFDLE1BQU0sQ0FBQyw4Q0FBOEMsRUFBRSxDQUMzRCwyQ0FBMkMsQ0FDOUMsQ0FBQyxDQUVHLFVBQVUsQ0FBQyxtQkFBbUIsRUFBRSxTQUFTLGlCQUFpQixDQUFDLE1BQU0sRUFBRSxJQUFJLEVBQUUsTUFBTSxFQUFFLE1BQU0sRUFBRSxhQUFhLEVBQUU7QUFDckcsUUFBSSxJQUFJLEdBQUcsSUFBSTtRQUNYLHNCQUFzQixHQUFHLGFBQWEsQ0FBQyxTQUFTLENBQUM7Ozs7O0FBS3JELGlCQUFhLENBQUMsSUFBSSxDQUFDLElBQUksRUFBRSxJQUFJLEVBQUcsTUFBTSxDQUFDLE1BQU0sQ0FBQyxXQUFXLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBRSxDQUFDOzs7QUFHckUsUUFBSSxDQUFDLGtCQUFrQixHQUFHLHNCQUFzQixDQUFDLGtCQUFrQixDQUFDO0FBQ3BFLFFBQUksQ0FBQyxhQUFhLEdBQUcsc0JBQXNCLENBQUMsYUFBYSxDQUFDO0FBQzFELFFBQUksQ0FBQyxlQUFlLEdBQUcsc0JBQXNCLENBQUMsZUFBZSxDQUFDO0FBQzlELFFBQUksQ0FBQyxJQUFJLEdBQUcsc0JBQXNCLENBQUMsSUFBSSxDQUFDO0FBQ3hDLFFBQUksQ0FBQyxhQUFhLEdBQUcsc0JBQXNCLENBQUMsYUFBYSxDQUFDO0FBQzFELFFBQUksQ0FBQyxlQUFlLEdBQUcsc0JBQXNCLENBQUMsZUFBZSxDQUFDO0FBQzlELFFBQUksQ0FBQyxhQUFhLEdBQUcsc0JBQXNCLENBQUMsYUFBYSxDQUFDO0FBQzFELFFBQUksQ0FBQyxtQkFBbUIsR0FBRyxzQkFBc0IsQ0FBQyxtQkFBbUIsQ0FBQztBQUN0RSxRQUFJLENBQUMsT0FBTyxHQUFHLHNCQUFzQixDQUFDLE9BQU8sQ0FBQztBQUM5QyxRQUFJLENBQUMsZ0JBQWdCLEdBQUcsc0JBQXNCLENBQUMsZ0JBQWdCLENBQUM7QUFDaEUsUUFBSSxDQUFDLFVBQVUsR0FBRyxDQUFDLENBQUMsSUFBSSxDQUFDLHNCQUFzQixDQUFDLFVBQVUsRUFBRSxJQUFJLENBQUMsQ0FBQztBQUNsRSxRQUFJLENBQUMsVUFBVSxHQUFHLHNCQUFzQixDQUFDLFVBQVUsQ0FBQztBQUNwRCxRQUFJLENBQUMsV0FBVyxHQUFHLHNCQUFzQixDQUFDLFdBQVcsQ0FBQztBQUN0RCxRQUFJLENBQUMsZ0JBQWdCLEdBQUcsc0JBQXNCLENBQUMsZ0JBQWdCLENBQUM7O0FBRWhFLFFBQUksRUFBRSxDQUFDOztBQUVQLGFBQVMsSUFBSSxHQUFHO0FBQ1osWUFBSSxnQkFBZ0IsQ0FBQzs7QUFFckIsd0JBQWdCLEdBQUcsTUFBTSxDQUFDLE1BQU0sQ0FBQyxnQkFBZ0IsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDO0FBQzNELFlBQUksQ0FBQyxDQUFDLENBQUMsVUFBVSxDQUFDLGdCQUFnQixDQUFDLEVBQUU7QUFDakMsZ0JBQUksQ0FBQyxLQUFLLENBQUMsa0VBQWtFLENBQUMsQ0FBQztBQUMvRSxtQkFBTztTQUNWO0FBQ0QsWUFBSSxDQUFDLGdCQUFnQixHQUFHLGdCQUFnQixDQUFDOztBQUV6QyxZQUFJLENBQUMsSUFBSSxFQUFFLENBQUM7S0FDZjtDQUNKLENBQUMsQ0FBQzs7O0FDM0NQLE9BQU8sQ0FBQyxNQUFNLENBQUMsNkNBQTZDLEVBQUUsQ0FDMUQsOENBQThDLEVBQzlDLHFEQUFxRCxFQUNyRCxXQUFXLENBQ2QsQ0FBQzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Q0FrREcsU0FBUyxDQUFDLGVBQWUsRUFBRSxTQUFTLHNCQUFzQixDQUFDLE1BQU0sRUFBRTtBQUNoRSxRQUFJLFNBQVMsR0FBRztBQUNaLGdCQUFRLEVBQUUsSUFBSTtBQUNkLGtCQUFVLEVBQUUsb0NBQW9DO0FBQ2hELFlBQUksRUFBRSxTQUFTLGlCQUFpQixDQUFDLE1BQU0sRUFBRSxPQUFPLEVBQUUsS0FBSyxFQUFFLGlCQUFpQixFQUFFO0FBQ3hFLGdCQUFJLEtBQUssQ0FBQyxlQUFlLEVBQUU7O0FBRXZCLHNCQUFNLENBQUMsS0FBSyxDQUFDLGVBQWUsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxNQUFNLEVBQUUsaUJBQWlCLENBQUMsQ0FBQzthQUNuRTtTQUNKO0tBQ0osQ0FBQzs7QUFFRixXQUFPLFNBQVMsQ0FBQztDQUNwQixDQUFDLENBQUM7OztBQ25FUCxPQUFPLENBQUMsTUFBTSxDQUFDLG1DQUFtQyxFQUFFLENBQ2hELDZDQUE2QyxFQUM3QyxxREFBcUQsRUFDckQsbURBQW1ELENBQ3RELENBQUMsQ0FBQzs7O0FDSkgsT0FBTyxDQUFDLE1BQU0sQ0FBQyxxREFBcUQsRUFBRSxDQUNsRSxtREFBbUQsQ0FDdEQsQ0FBQyxDQUNHLFNBQVMsQ0FBQyxVQUFVLEVBQUUsU0FBUyxpQkFBaUIsQ0FBQyxJQUFJLEVBQUUsb0JBQW9CLEVBQUU7QUFDMUUsUUFBSSxTQUFTLEdBQUc7QUFDWixtQkFBVyxFQUFFLHdEQUF3RDtBQUNyRSxnQkFBUSxFQUFFLEdBQUc7QUFDYixrQkFBVSxFQUFFLElBQUk7QUFDaEIsYUFBSyxFQUFFO0FBQ0gscUJBQVMsRUFBRSxHQUFHO0FBQ2Qsc0JBQVUsRUFBRSxHQUFHO0FBQ2YsbUJBQU8sRUFBRSxHQUFHO1NBQ2Y7QUFDRCxlQUFPLEVBQUUsa0JBQWtCO0FBQzNCLFlBQUksRUFBRSxxQkFBcUI7S0FDOUIsQ0FBQzs7QUFFRixhQUFTLHFCQUFxQixDQUFDLEtBQUssRUFBRSxPQUFPLEVBQUUsS0FBSyxFQUFFLGlCQUFpQixFQUFFO0FBQ3JFLFlBQUksYUFBYSxFQUNiLGFBQWEsQ0FBQzs7QUFFbEIsWUFBSSxLQUFLLENBQUMsT0FBTyxFQUFFO0FBQ2YseUJBQWEsR0FBRyxvQkFBb0IsQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyxDQUFDO1NBQzNELE1BQU0sSUFBSSxpQkFBaUIsRUFBRTtBQUMxQix5QkFBYSxHQUFHLGlCQUFpQixDQUFDO1NBQ3JDLE1BQU07QUFDSCxnQkFBSSxDQUFDLEtBQUssQ0FBQyxvRkFBb0YsQ0FBQyxDQUFDO1NBQ3BHOztBQUVELHFCQUFhLEdBQUcsYUFBYSxDQUFDLFdBQVcsQ0FBQyxhQUFhLENBQUM7O0FBRXhELGFBQUssQ0FBQyxHQUFHLEdBQUcsYUFBYSxDQUFDLEdBQUcsQ0FBQztBQUM5QixhQUFLLENBQUMsSUFBSSxHQUFHLGFBQWEsQ0FBQyxJQUFJLENBQUM7QUFDaEMsYUFBSyxDQUFDLE1BQU0sR0FBRyxhQUFhLENBQUMsTUFBTSxDQUFDO0FBQ3BDLGFBQUssQ0FBQyxPQUFPLEdBQUcsYUFBYSxDQUFDLE9BQU8sQ0FBQztBQUN0QyxhQUFLLENBQUMsSUFBSSxHQUFHLElBQUksQ0FBQzs7QUFFbEIsaUJBQVMsSUFBSSxDQUFDLE1BQU0sRUFBRTtBQUNsQixnQkFBSSxNQUFNLEVBQ04sT0FBTyxDQUFDOztBQUVaLGdCQUFJLE1BQU0sRUFBRTtBQUNSLHNCQUFNLENBQUMsY0FBYyxFQUFFLENBQUM7YUFDM0I7O0FBRUQsZ0JBQUksYUFBYSxDQUFDLE1BQU0sS0FBSyxLQUFLLENBQUMsU0FBUyxFQUFFO0FBQzFDLHNCQUFNLEdBQUcsYUFBYSxDQUFDLE1BQU0sQ0FBQztBQUM5Qix1QkFBTyxHQUFHLGFBQWEsQ0FBQyxPQUFPLEtBQUssS0FBSyxDQUFDLEdBQUcsR0FBRyxLQUFLLENBQUMsSUFBSSxHQUFHLEtBQUssQ0FBQyxHQUFHLENBQUM7YUFDMUUsTUFBTTtBQUNILHNCQUFNLEdBQUcsS0FBSyxDQUFDLFNBQVMsQ0FBQztBQUN6Qix1QkFBTyxHQUFHLEtBQUssQ0FBQyxHQUFHLENBQUM7YUFDdkI7O0FBRUQseUJBQWEsQ0FBQyxVQUFVLENBQUMsTUFBTSxFQUFFLE9BQU8sQ0FBQyxDQUFDO1NBQzdDO0tBQ0o7O0FBRUQsV0FBTyxTQUFTLENBQUM7Q0FDcEIsQ0FBQyxDQUFDOzs7QUMxRFAsT0FBTyxDQUFDLE1BQU0sQ0FBQyw0Q0FBNEMsRUFBRSxFQUFFLENBQUMsQ0FDM0QsVUFBVSxDQUFDLGtCQUFrQixFQUFFLFNBQVMsZ0JBQWdCLENBQUMsTUFBTSxFQUFFLFFBQVEsRUFBRSxJQUFJLEVBQUUsTUFBTSxFQUFFLE1BQU0sRUFBRTtBQUM5RixRQUFJLElBQUksR0FBRyxJQUFJO1FBQ1gsVUFBVSxHQUFHLE1BQU0sQ0FBQyxNQUFNLENBQUMsWUFBWSxDQUFDLENBQUMsSUFBSSxDQUFDLElBQUksS0FBSztRQUN2RCxTQUFTLEdBQUcsTUFBTSxDQUFDLE1BQU0sQ0FBQyxXQUFXLENBQUMsQ0FBQyxJQUFJLENBQUMsSUFBSSxJQUFJO1FBQ3BELE9BQU8sR0FBRyxRQUFRLENBQUMsVUFBVSxDQUFDLFNBQVMsQ0FBQyxDQUFDOztBQUU3QyxRQUFJLEVBQUUsQ0FBQzs7O0FBR1AsYUFBUyxhQUFhLEdBQUc7QUFDckIsZUFBTyxPQUFPLENBQUMsV0FBVyxDQUFDO0tBQzlCOztBQUVELGFBQVMsUUFBUSxHQUFHO0FBQ2hCLGVBQU8sSUFBSSxDQUFDLEtBQUssSUFBSSxJQUFJLENBQUMsT0FBTyxDQUFDO0tBQ3JDOztBQUVELGFBQVMsaUJBQWlCLEdBQUc7QUFDekIsZUFBTyxJQUFJLENBQUMsY0FBYyxDQUFDO0tBQzlCOzs7QUFHRCxhQUFTLGdCQUFnQixDQUFDLFVBQVUsRUFBRTtBQUNsQyxlQUFPLENBQUMsYUFBYSxDQUFDLFVBQVUsQ0FBQyxDQUFDO0FBQ2xDLGVBQU8sQ0FBQyxnQkFBZ0IsRUFBRSxDQUFDO0FBQzNCLGVBQU8sQ0FBQyxPQUFPLEVBQUUsQ0FBQztLQUNyQjs7QUFFRCxhQUFTLG9CQUFvQixDQUFDLFVBQVUsRUFBRTtBQUN0QyxZQUFJLFVBQVUsS0FBSyxTQUFTLEVBQUU7QUFDMUIsK0JBQW1CLEVBQUUsQ0FBQztTQUN6QixNQUFNLElBQUksVUFBVSxLQUFLLFVBQVUsRUFBRTtBQUNsQyxvQ0FBd0IsRUFBRSxDQUFDO1NBQzlCO0tBQ0o7O0FBRUQsYUFBUyxtQkFBbUIsR0FBRztBQUMzQixZQUFJLFVBQVUsR0FBRyxDQUFDLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxjQUFjLEVBQUUsUUFBUSxFQUFFLENBQUMsQ0FBQzs7QUFFNUQsWUFBSSxDQUFDLFVBQVUsRUFBRTtBQUNiLGdCQUFJLENBQUMsY0FBYyxDQUFDLElBQUksQ0FBQyxRQUFRLEVBQUUsQ0FBQyxDQUFDO1NBQ3hDO0tBQ0o7O0FBRUQsYUFBUyx3QkFBd0IsR0FBRztBQUNoQyxZQUFJLEtBQUssR0FBRyxDQUFDLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxjQUFjLEVBQUUsUUFBUSxFQUFFLENBQUMsQ0FBQzs7QUFFdkQsWUFBSSxLQUFLLEtBQUssQ0FBQyxDQUFDLEVBQUU7QUFDZCxnQkFBSSxDQUFDLGNBQWMsQ0FBQyxNQUFNLENBQUMsS0FBSyxFQUFFLENBQUMsQ0FBQyxDQUFDO1NBQ3hDO0tBQ0o7OztBQUdELGFBQVMsZUFBZSxDQUFDLFVBQVUsRUFBRSxhQUFhLEVBQUU7QUFDaEQsWUFBSSxpQkFBaUIsRUFDakIscUJBQXFCLENBQUM7OztBQUcxQixZQUFJLENBQUMsQ0FBQyxXQUFXLENBQUMsVUFBVSxDQUFDLElBQUksVUFBVSxLQUFLLGFBQWEsRUFBRTtBQUMzRCxtQkFBTztTQUNWOzs7QUFHRCx5QkFBaUIsR0FBRyxJQUFJLENBQUMsY0FBYyxDQUFDLEtBQUssRUFBRSxDQUFDOzs7QUFHaEQsNEJBQW9CLENBQUMsVUFBVSxDQUFDLENBQUM7OztBQUdqQyw2QkFBcUIsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsY0FBYyxFQUFFLGlCQUFpQixDQUFDLENBQUMsTUFBTSxDQUFDOzs7QUFHL0UsWUFBSSxJQUFJLENBQUMsUUFBUSxJQUFJLHFCQUFxQixFQUFFO0FBQ3hDLGdCQUFJLENBQUMsUUFBUSxDQUFDO0FBQ1YsOEJBQWMsRUFBRSxJQUFJLENBQUMsY0FBYztBQUNuQyxpQ0FBaUIsRUFBRSxpQkFBaUI7YUFDdkMsQ0FBQyxDQUFDO1NBQ047S0FDSjs7QUFFRCxhQUFTLG1CQUFtQixDQUFDLGNBQWMsRUFBRTs7QUFFekMsWUFBSSxVQUFVLEdBQUcsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxjQUFjLEVBQUUsUUFBUSxFQUFFLENBQUM7WUFDbEQsVUFBVSxHQUFHLGFBQWEsRUFBRSxDQUFDOztBQUVqQyxZQUFJLFVBQVUsSUFBSSxVQUFVLEtBQUssU0FBUyxFQUFFO0FBQ3hDLDRCQUFnQixDQUFDLFNBQVMsQ0FBQyxDQUFDO1NBQy9CLE1BQU0sSUFBSSxDQUFDLFVBQVUsSUFBSSxVQUFVLEtBQUssVUFBVSxFQUFFO0FBQ2pELDRCQUFnQixDQUFDLFVBQVUsQ0FBQyxDQUFDO1NBQ2hDO0tBQ0o7OztBQUdELGFBQVMsSUFBSSxHQUFHO0FBQ1osWUFBSSxNQUFNLENBQUMsSUFBSSxLQUFLLFVBQVUsRUFBRTtBQUM1QixnQkFBSSxDQUFDLEtBQUssQ0FBQyxrRUFBa0UsQ0FBQyxDQUFDOztBQUUvRSxtQkFBTztTQUNWOztBQUVELGNBQU0sQ0FBQyxNQUFNLENBQUMsYUFBYSxFQUFFLGVBQWUsQ0FBQyxDQUFDO0FBQzlDLGNBQU0sQ0FBQyxnQkFBZ0IsQ0FBQyxpQkFBaUIsRUFBRSxtQkFBbUIsQ0FBQyxDQUFDO0tBQ25FO0NBQ0osQ0FBQyxDQUFDOzs7QUN4R1AsT0FBTyxDQUFDLE1BQU0sQ0FBQywyQ0FBMkMsRUFBRSxDQUN4RCw0Q0FBNEMsQ0FDL0MsQ0FBQzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Q0FrREcsU0FBUyxDQUFDLGNBQWMsRUFBRSxTQUFTLHFCQUFxQixHQUFHO0FBQ3hELFdBQU87QUFDSCxnQkFBUSxFQUFFLEdBQUc7QUFDYixlQUFPLEVBQUUsU0FBUztBQUNsQixrQkFBVSxFQUFFLGtCQUFrQjtBQUM5QixvQkFBWSxFQUFFLGtCQUFrQjtBQUNoQyx3QkFBZ0IsRUFBRSxJQUFJO0FBQ3RCLGFBQUssRUFBRTtBQUNILG9CQUFRLEVBQUUscUJBQXFCO0FBQy9CLDBCQUFjLEVBQUUsZUFBZTtBQUMvQixpQkFBSyxFQUFFLEdBQUc7QUFDVixtQkFBTyxFQUFFLEdBQUc7U0FDZjtLQUNKLENBQUM7Q0FDTCxDQUFDLENBQUM7OztBQ2xFUCxPQUFPLENBQUMsTUFBTSxDQUFDLGlDQUFpQyxFQUFFLENBQzlDLDJDQUEyQyxDQUM5QyxDQUFDLENBQUM7OztBQ0ZILE9BQU8sQ0FBQyxNQUFNLENBQUMsbURBQW1ELEVBQUUsRUFBRSxDQUFDLENBRWxFLFVBQVUsQ0FBQyx3QkFBd0IsRUFBRSxZQUFXO0FBQzdDLFFBQUksSUFBSSxHQUFHLElBQUksQ0FBQzs7QUFFaEIsUUFBSSxDQUFDLGNBQWMsR0FBRyxjQUFjLENBQUM7O0FBRXJDLGFBQVMsY0FBYyxDQUFDLE1BQU0sRUFBRTtBQUM1QixjQUFNLENBQUMsY0FBYyxFQUFFLENBQUM7O0FBRXhCLFlBQUksQ0FBQyxxQkFBcUIsRUFBRSxDQUFDO0tBQ2hDO0NBQ0osQ0FBQyxDQUFDOzs7QUNaUCxPQUFPLENBQUMsTUFBTSxDQUFDLGtEQUFrRCxFQUFFLENBQy9ELG1EQUFtRCxDQUN0RCxDQUFDLENBRUcsU0FBUyxDQUFDLG9CQUFvQixFQUFFLFNBQVMsMkJBQTJCLEdBQUc7QUFDcEUsV0FBTztBQUNILHdCQUFnQixFQUFFLElBQUk7QUFDdEIsa0JBQVUsRUFBRSx3QkFBd0I7QUFDcEMsb0JBQVksRUFBRSx3QkFBd0I7QUFDdEMsZ0JBQVEsRUFBRSxHQUFHO0FBQ2IsYUFBSyxFQUFFO0FBQ0gsa0JBQU0sRUFBRSxHQUFHO0FBQ1gsaUNBQXFCLEVBQUUsR0FBRztBQUMxQix1QkFBVyxFQUFFLEdBQUc7U0FDbkI7QUFDRCxtQkFBVyxFQUFFLCtEQUErRDtBQUM1RSxlQUFPLEVBQUUsU0FBUyxrQ0FBa0MsQ0FBQyxRQUFRLEVBQUU7QUFDM0Qsb0JBQVEsQ0FBQyxRQUFRLENBQUMscUJBQXFCLENBQUMsQ0FBQztTQUM1QztLQUNKLENBQUM7Q0FDTCxDQUFDLENBQUM7Ozs7QUNuQlAsT0FBTyxDQUFDLE1BQU0sQ0FBQywyQ0FBMkMsRUFBRSxFQUFFLENBQUMsQ0FDMUQsVUFBVSxDQUFDLGlCQUFpQixFQUFFLFNBQVMsZUFBZSxDQUFDLFFBQVEsRUFBRTtBQUM5RCxRQUFNLElBQUksR0FBRyxJQUFJLENBQUM7O0FBRWxCLFFBQUksY0FBYyxZQUFBLENBQUM7QUFDbkIsUUFBSSx1QkFBdUIsWUFBQSxDQUFDO0FBQzVCLFFBQUksV0FBVyxZQUFBLENBQUM7QUFDaEIsUUFBSSxvQkFBb0IsWUFBQSxDQUFDOztBQUV6QixRQUFJLENBQUMsaUJBQWlCLEdBQUcsaUJBQWlCLENBQUM7QUFDM0MsUUFBSSxDQUFDLHFCQUFxQixHQUFHLHFCQUFxQixDQUFDO0FBQ25ELFFBQUksQ0FBQyxZQUFZLEdBQUcsWUFBWSxDQUFDO0FBQ2pDLFFBQUksQ0FBQyxXQUFXLEdBQUcsV0FBVyxDQUFDOztBQUUvQixhQUFTLGlCQUFpQixHQUFHO0FBQ3pCLHNCQUFjLEdBQUcsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLGFBQWEsQ0FBQyxrQkFBa0IsQ0FBQyxDQUFDO0FBQy9ELCtCQUF1QixHQUFHLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxhQUFhLENBQUMsNEJBQTRCLENBQUMsQ0FBQztBQUNsRixtQkFBVyxHQUFHLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxhQUFhLENBQUMsa0JBQWtCLENBQUMsQ0FBQztBQUM1RCw0QkFBb0IsR0FBRyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsYUFBYSxDQUFDLDRCQUE0QixDQUFDLENBQUM7O0FBRS9FLG1CQUFXLENBQUMsYUFBYSxDQUNyQixvQkFBb0IsRUFDcEIsdUJBQXVCLENBQUMsQ0FBQzs7QUFFN0IsWUFBSSxDQUFDLEVBQUUsR0FBRyxJQUFJLFdBQVcsQ0FDckIsV0FBVyxFQUNYLGNBQWMsRUFDZCxZQUFZLENBQ2YsQ0FBQztLQUNMOztBQUVELGFBQVMscUJBQXFCLEdBQUc7QUFDN0IsWUFBSSxJQUFJLENBQUMsT0FBTyxDQUFDLE9BQU8sQ0FBQyxnQkFBZ0IsRUFBRSxDQUFDLEdBQUcsQ0FBQyxFQUFFO0FBQzlDLGdCQUFJLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxnQkFBZ0IsRUFBRSxDQUFDLENBQUM7U0FDekM7S0FDSjs7QUFFRCxhQUFTLGdCQUFnQixHQUFHO0FBQ3hCLGVBQU8sSUFBSSxDQUFDLEtBQUssQ0FBQztLQUNyQjs7QUFFRCxhQUFTLFlBQVksQ0FBQyxHQUFHLEVBQUUsR0FBRyxFQUFFLEdBQUcsRUFBRSxnQkFBZ0IsRUFBRSxnQkFBZ0IsRUFBRTtBQUNyRSxtQkFBVyxDQUFDLGtCQUFrQixDQUMxQixvQkFBb0IsRUFDcEIsdUJBQXVCLEVBQ3ZCLGdCQUFnQixFQUFFLGdCQUFnQixDQUNyQyxDQUFDOztBQUVGLFlBQUksQ0FBQyxXQUFXLENBQUMsYUFBYSxDQUFDLEdBQUcsQ0FBQyxDQUFDO0FBQ3BDLFlBQUksQ0FBQyxXQUFXLENBQUMsT0FBTyxFQUFFLENBQUM7S0FDOUI7O0FBRUQsYUFBUyxNQUFNLEdBQUc7QUFDZCxZQUFJLENBQUMsS0FBSyxHQUFHLElBQUksQ0FBQyxXQUFXLENBQUMsVUFBVSxDQUFDO0tBQzVDOztBQUVELGFBQVMsWUFBWSxDQUFDLFdBQVcsRUFBRTtBQUMvQixZQUFJLENBQUMsV0FBVyxHQUFHLFdBQVcsQ0FBQztBQUMvQixZQUFJLENBQUMsV0FBVyxDQUFDLE9BQU8sR0FBRyxNQUFNLENBQUM7S0FDckM7O0FBRUQsYUFBUyxXQUFXLENBQUMsTUFBTSxFQUFFLFFBQVEsRUFBRTtBQUNuQyxjQUFNLENBQUMsY0FBYyxFQUFFLENBQUM7O0FBRXhCLFlBQUksQ0FBQyxFQUFFLENBQUMsTUFBTSxDQUFDLFFBQVEsQ0FBQyxDQUFDO0tBQzVCO0NBQ0osQ0FBQyxDQUFDOzs7QUNuRVAsT0FBTyxDQUFDLE1BQU0sQ0FBQywwQ0FBMEMsRUFBRSxDQUN2RCwyQ0FBMkMsRUFDM0MsNkJBQTZCLENBQ2hDLENBQUMsQ0FFRyxTQUFTLENBQUMsYUFBYSxFQUFFLFNBQVMsb0JBQW9CLENBQUMsU0FBUyxFQUFFLFNBQVMsRUFBRTtBQUMxRSxXQUFPO0FBQ0gsd0JBQWdCLEVBQUUsSUFBSTtBQUN0QixrQkFBVSxFQUFFLGlCQUFpQjtBQUM3QixvQkFBWSxFQUFFLGlCQUFpQjtBQUMvQixlQUFPLEVBQUUsQ0FBQyxhQUFhLEVBQUUsVUFBVSxDQUFDO0FBQ3BDLGdCQUFRLEVBQUUsR0FBRztBQUNiLGFBQUssRUFBRTtBQUNILG1CQUFPLEVBQUUsR0FBRztTQUNmO0FBQ0QsbUJBQVcsRUFBRSx1REFBdUQ7O0FBRXBFLGVBQU8sRUFBRSxTQUFTLDJCQUEyQixDQUFDLFFBQVEsRUFBRTtBQUNwRCxvQkFBUSxDQUFDLFFBQVEsQ0FBQyxhQUFhLENBQUMsQ0FBQzs7QUFFakMsbUJBQU8sU0FBUyx3QkFBd0IsQ0FBQyxNQUFNLEVBQUUsT0FBTyxFQUFFLEtBQUssRUFBRSxLQUFLLEVBQUU7QUFDcEUsb0JBQU0sSUFBSSxHQUFHLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUN0QixvQkFBTSxXQUFXLEdBQUcsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDOztBQUU3QixvQkFBSSxDQUFDLFlBQVksQ0FBQyxXQUFXLENBQUMsQ0FBQztBQUMvQixvQkFBSSxDQUFDLGlCQUFpQixFQUFFLENBQUM7Ozs7QUFJekIsb0JBQUksU0FBUyxDQUFDLE9BQU8sRUFBRTtBQUNuQixxQkFBQyxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsZ0JBQWdCLENBQUMsUUFBUSxDQUFDLEVBQUUsVUFBUyxFQUFFLEVBQUU7QUFDdkQsNEJBQU0sa0JBQWtCLEdBQUcsYUFBYSxDQUFDO0FBQ3pDLDRCQUFNLElBQUksR0FBRyxPQUFPLENBQUMsT0FBTyxDQUFDLEVBQUUsQ0FBQyxDQUFDO0FBQ2pDLDRCQUFNLFdBQVcsR0FBRyxJQUFJLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDOztBQUV0Qyw0QkFBSSxDQUFDLENBQUMsUUFBUSxDQUFDLFdBQVcsRUFBRSxPQUFPLENBQUMsRUFBRTtBQUNsQyxnQ0FBTSxPQUFPLEdBQUcsa0JBQWtCLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDOztBQUV4RCxnQ0FBSSxDQUFDLElBQUksQ0FBQyxNQUFNLEVBQUUsTUFBTSxHQUFHLFNBQVMsQ0FBQyxJQUFJLEVBQUUsR0FBRyxPQUFPLEdBQUcsR0FBRyxDQUFDLENBQUM7eUJBQ2hFO3FCQUNKLENBQUMsQ0FBQztpQkFDTjs7QUFFRCxzQkFBTSxDQUFDLE1BQU0sQ0FBQyxhQUFhLEVBQUUsU0FBUyxVQUFVLENBQUMsTUFBTSxFQUFFO0FBQ3JELHdCQUFJLE1BQU0sRUFBRTtBQUNSLDRCQUFJLENBQUMsRUFBRSxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsQ0FBQztxQkFDMUI7aUJBQ0osQ0FBQyxDQUFDOztBQUVILHlCQUFTLGFBQWEsR0FBRztBQUNyQiwyQkFBTyxJQUFJLENBQUMsV0FBVyxDQUFDLFdBQVcsQ0FBQztpQkFDdkM7YUFDSixDQUFDO1NBQ0w7S0FDSixDQUFDO0NBQ0wsQ0FBQyxDQUFDOzs7QUN2RFAsT0FBTyxDQUFDLE1BQU0sQ0FBQyxnQ0FBZ0MsRUFBRSxDQUM3QywwQ0FBMEMsRUFDMUMsa0RBQWtELENBQ3JELENBQUMsQ0FBQzs7Ozs7Ozs7Ozs7Ozs7O0FDU0gsT0FBTyxDQUFDLE1BQU0sQ0FBQyx5Q0FBeUMsRUFBRSxDQUN0RCx3QkFBd0IsQ0FDM0IsQ0FBQyxDQUNHLFNBQVMsQ0FBQyxZQUFZLEVBQUUsU0FBUyxtQkFBbUIsQ0FBQyxRQUFRLEVBQUUsTUFBTSxFQUFFLGNBQWMsRUFBRTtBQUNwRixRQUFNLGtCQUFrQixHQUFHLGNBQWMsQ0FBQyxHQUFHLENBQUMsaUVBQWlFLENBQUMsQ0FBQzs7QUFFakgsV0FBTztBQUNILGVBQU8sRUFBRSxTQUFTLGlCQUFpQixDQUFDLEtBQUssRUFBRSxNQUFNLEVBQUM7QUFDOUMsZ0JBQUksV0FBVyxHQUFHLElBQUksQ0FBQzs7QUFFdkIsZ0JBQUksTUFBTSxDQUFDLFNBQVMsSUFBSSxNQUFNLENBQUMsTUFBTSxDQUFDLFNBQVMsQ0FBQyxFQUFFLEtBQUssS0FBSyxFQUFFO0FBQzFELG9CQUFNLFFBQVEsR0FBRyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsYUFBYSxDQUFDLFdBQVcsQ0FBQyxDQUFDOztBQUVyRCx3QkFBUSxDQUFDLGVBQWUsQ0FBQyxhQUFhLENBQUMsQ0FBQztBQUN4QywyQkFBVyxHQUFHLEtBQUssQ0FBQzthQUN2Qjs7QUFFRCxtQkFBTyxTQUFTLGNBQWMsQ0FBQyxLQUFLLEVBQUUsSUFBSSxFQUFFLElBQUksRUFBRSxRQUFRLEVBQUU7QUFDeEQsb0JBQU0saUJBQWlCLEdBQUcsUUFBUSxDQUFDLGtCQUFrQixDQUFDLENBQUMsS0FBSyxDQUFDLENBQUM7QUFDOUQsb0JBQU0sYUFBYSxHQUFHO0FBQ2xCLDRCQUFRLEVBQUUsSUFBSTtBQUNkLG9DQUFnQixFQUFFLElBQUk7QUFDdEIsNEJBQVEsRUFBRSxJQUFJO2lCQUNqQixDQUFDOztBQUVGLHFCQUFLLENBQUMsaUJBQWlCLEdBQUcsaUJBQWlCLENBQUM7O0FBRTVDLG9CQUFJLEVBQUUsQ0FBQzs7QUFFUCx5QkFBUyxJQUFJLEdBQUc7QUFDWix5QkFBSyxDQUFDLFFBQVEsR0FBRyxRQUFRLENBQUM7QUFDMUIseUJBQUssQ0FBQyxRQUFRLEdBQUcsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxLQUFLLENBQUMsUUFBUSxFQUFFLGFBQWEsQ0FBQyxDQUFDOzs7Ozs7O0FBTzNELHlCQUFLLENBQUMsTUFBTSxDQUFDLGlCQUFpQixFQUFFLFNBQVMsQ0FBQyxDQUFDO2lCQUM5Qzs7Ozs7O0FBTUQseUJBQVMsaUJBQWlCLEdBQUc7QUFDekIsMkJBQU8saUJBQWlCLENBQUMsQ0FBQyxDQUFDLENBQUMsU0FBUyxDQUFDO2lCQUN6Qzs7Ozs7OztBQU9ELHlCQUFTLGlCQUFpQixHQUFHO0FBQ3pCLDJCQUFPLFdBQVcsR0FBRyxRQUFRLENBQUMsUUFBUSxDQUFDLFlBQVksR0FBRyxRQUFRLENBQUMsUUFBUSxDQUFDLE9BQU8sQ0FBQztpQkFDbkY7Ozs7Ozs7QUFPRCx5QkFBUyxTQUFTLENBQUMsSUFBSSxFQUFFO0FBQ3JCLHlCQUFLLENBQUMsTUFBTSxDQUFDLE1BQU0sR0FBRyxJQUFJLENBQUM7O0FBRTNCLDJCQUFPLElBQUksQ0FBQztpQkFDZjthQUNKLENBQUM7U0FDTDtBQUNELGVBQU8sRUFBRSxPQUFPO0FBQ2hCLGdCQUFRLEVBQUUsSUFBSTtBQUNkLGFBQUssRUFBRTtBQUNILGtCQUFNLEVBQUUsR0FBRztBQUNYLG9CQUFRLEVBQUUsR0FBRztTQUNoQjtBQUNELG1CQUFXLEVBQUUscURBQXFEO0tBQ3JFLENBQUM7Q0FDTCxDQUFDLENBQUM7OztBQzFGUCxPQUFPLENBQUMsTUFBTSxDQUFDLCtCQUErQixFQUFFLENBQzVDLGNBQWMsRUFDZCxzQ0FBc0MsRUFDdEMseUNBQXlDLEVBQ3pDLHlDQUF5QyxFQUN6QyxTQUFTLENBQ1osQ0FBQyxDQUFDOzs7QUNOSCxPQUFPLENBQUMsTUFBTSxDQUFDLDhDQUE4QyxFQUFFLEVBQUUsQ0FBQyxDQUM3RCxRQUFRLENBQUMsVUFBVSxFQUFFO0FBQ2xCLHNCQUFrQixFQUFFLE1BQU07QUFDMUIsaUJBQWEsRUFBRSxZQUFZO0FBQzNCLGNBQVUsRUFBRSxVQUFVO0FBQ3RCLGdCQUFZLEVBQUUsWUFBWTtBQUMxQixVQUFNLEVBQUUsTUFBTTtDQUNqQixDQUFDLENBQUM7OztBQ1BQLE9BQU8sQ0FBQyxNQUFNLENBQUMsZ0RBQWdELEVBQUUsQ0FDN0QsOENBQThDLENBQ2pELENBQUMsQ0FDRyxVQUFVLENBQUMscUJBQXFCLEVBQUUsU0FBUyxtQkFBbUIsQ0FBQyxRQUFRLEVBQUUsUUFBUSxFQUFFO0FBQ2hGLFFBQU0sSUFBSSxHQUFHLElBQUksQ0FBQzs7QUFFbEIsUUFBSSxDQUFDLGVBQWUsR0FBRyxlQUFlLENBQUM7QUFDdkMsUUFBSSxDQUFDLGNBQWMsR0FBRyxjQUFjLENBQUM7QUFDckMsUUFBSSxDQUFDLFFBQVEsR0FBRyxRQUFRLENBQUM7O0FBRXpCLFFBQUksRUFBRSxDQUFDOztBQUVQLGFBQVMsSUFBSSxHQUFHO0FBQ1osZ0JBQVEsQ0FBQyxRQUFRLENBQUMsaUJBQWlCLENBQUMsQ0FBQztLQUN4Qzs7Ozs7O0FBTUQsYUFBUyxlQUFlLEdBQUc7QUFDdkIsZUFBTyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLGVBQWUsRUFBRSxDQUFDLENBQUM7S0FDN0M7Ozs7Ozs7QUFPRCxhQUFTLGNBQWMsQ0FBQyxNQUFNLEVBQUU7QUFDNUIsZUFBTyxNQUFNLEtBQUssSUFBSSxDQUFDLGVBQWUsRUFBRSxDQUFDO0tBQzVDOzs7Ozs7O0FBT0QsYUFBUyxRQUFRLENBQUMsTUFBTSxFQUFFO0FBQ3RCLGVBQU8sUUFBUSxDQUFDLE1BQU0sQ0FBQyxDQUFDO0tBQzNCO0NBQ0osQ0FBQyxDQUFDOzs7Ozs7Ozs7Ozs7QUNoQ1AsT0FBTyxDQUFDLE1BQU0sQ0FBQywrQ0FBK0MsRUFBRSxDQUM1RCxnREFBZ0QsQ0FDbkQsQ0FBQyxDQUNHLFNBQVMsQ0FBQyxpQkFBaUIsRUFBRSxTQUFTLHdCQUF3QixHQUFHO0FBQzlELFdBQU87QUFDSCx3QkFBZ0IsRUFBRSxJQUFJO0FBQ3RCLGtCQUFVLEVBQUUsNENBQTRDO0FBQ3hELGdCQUFRLEVBQUUsR0FBRztBQUNiLGFBQUssRUFBRTtBQUNILDJCQUFlLEVBQUUsZUFBZTtBQUNoQyw2QkFBaUIsRUFBRSxpQkFBaUI7U0FDdkM7QUFDRCxtQkFBVyxFQUFFLGlFQUFpRTtLQUNqRixDQUFDO0NBQ0wsQ0FBQyxDQUFDOzs7QUN2QlAsT0FBTyxDQUFDLE1BQU0sQ0FBQyxxQ0FBcUMsRUFBRSxDQUNsRCw4Q0FBOEMsRUFDOUMsZ0RBQWdELEVBQ2hELCtDQUErQyxDQUNsRCxDQUFDLENBQUM7OztBQ0pILE9BQU8sQ0FBQyxNQUFNLENBQUMsa0NBQWtDLEVBQUUsRUFBRSxDQUFDLENBQ2pELFNBQVMsQ0FBQyxNQUFNLEVBQUUsU0FBUyxhQUFhLEdBQUc7QUFDeEMsV0FBTztBQUNILGdCQUFRLEVBQUUsR0FBRztBQUNiLFlBQUksRUFBRSxTQUFTLFFBQVEsQ0FBQyxLQUFLLEVBQUUsT0FBTyxFQUFFLEtBQUssRUFBRTtBQUMzQyxtQkFBTyxDQUFDLFFBQVEsQ0FBQyxNQUFNLENBQUMsQ0FBQztBQUN6QixtQkFBTyxDQUFDLElBQUksQ0FBQyxZQUFZLEVBQUUsRUFBRSxDQUFDLENBQUM7OztBQUcvQixnQkFBSSxDQUFDLEtBQUssQ0FBQyxnQkFBZ0IsRUFBRTtBQUN6Qix1QkFBTyxDQUFDLEVBQUUsQ0FBQyxRQUFRLEVBQUUsU0FBUywwQkFBMEIsR0FBRztBQUN2RCx3QkFBSSxZQUFZLEdBQUcsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDLGFBQWEsQ0FBQyxhQUFhLENBQUMsQ0FBQzs7QUFFM0Qsd0JBQUksWUFBWSxFQUFFO0FBQ2Qsb0NBQVksQ0FBQyxLQUFLLEVBQUUsQ0FBQzs7O0FBR3JCLDRCQUFJLFlBQVksQ0FBQyxNQUFNLEVBQUU7QUFDckIsd0NBQVksQ0FBQyxNQUFNLEVBQUUsQ0FBQzt5QkFDekI7cUJBQ0o7aUJBQ0osQ0FBQyxDQUFDO2FBQ047U0FDSjtLQUNKLENBQUM7Q0FDTCxDQUFDLENBQUM7OztBQ3pCUCxPQUFPLENBQUMsTUFBTSxDQUFDLHdCQUF3QixFQUFFLENBQ3JDLGtDQUFrQyxDQUNyQyxDQUFDLENBQUM7OztBQ0ZILE9BQU8sQ0FBQyxNQUFNLENBQUMsd0NBQXdDLEVBQUUsRUFBRSxDQUFDLENBQ3ZELFNBQVMsQ0FBQyxXQUFXLEVBQUUsU0FBUyxrQkFBa0IsQ0FBQyxJQUFJLEVBQUU7QUFDdEQsV0FBTztBQUNILGVBQU8sRUFBRSxPQUFPO0FBQ2hCLGdCQUFRLEVBQUUsSUFBSTtBQUNkLGFBQUssRUFBRSxJQUFJO0FBQ1gsWUFBSSxFQUFFO0FBQ0YsZUFBRyxFQUFFLFNBQVMsYUFBYSxDQUFDLEtBQUssRUFBRSxPQUFPLEVBQUUsS0FBSyxFQUFFOztBQUUvQyxxQkFBSyxDQUFDLFFBQVEsR0FBRyxLQUFLLENBQUMsUUFBUSxDQUFDO2FBQ25DOztBQUVELGdCQUFJLEVBQUUsU0FBUyxhQUFhLENBQUMsS0FBSyxFQUFFLE9BQU8sRUFBRSxLQUFLLEVBQUUsUUFBUSxFQUFFOztBQUUxRCxvQkFBSSxRQUFRLEdBQUcsS0FBSyxDQUFDLFFBQVE7b0JBQ3pCLGVBQWUsR0FBRyxTQUFTLGVBQWUsR0FBRztBQUFFLDJCQUFPLFFBQVEsQ0FBQyxRQUFRLENBQUMsQ0FBQyxNQUFNLENBQUM7aUJBQUU7b0JBQ2xGLGVBQWUsR0FBRyxTQUFTLGVBQWUsR0FBRztBQUFFLDJCQUFPLFFBQVEsQ0FBQyxVQUFVLENBQUM7aUJBQUUsQ0FBQzs7QUFFakYsdUJBQU8sQ0FBQyxRQUFRLENBQUMsWUFBWSxDQUFDLENBQUM7OztBQUcvQixvQkFBSSxDQUFDLFFBQVEsRUFBRTtBQUNYLDJCQUFPO2lCQUNWOzs7QUFHRCxvQkFBSSxDQUFDLFFBQVEsQ0FBQyxRQUFRLENBQUMsRUFBRTtBQUNyQiwyQkFBTyxJQUFJLENBQUMsSUFBSSxDQUFDLGtGQUFrRixDQUFDLENBQUM7aUJBQ3hHOztBQUVELG9CQUFJLEVBQUUsQ0FBQzs7QUFFUCx5QkFBUyxJQUFJLEdBQUc7O0FBRVoseUJBQUssQ0FBQyxNQUFNLENBQUMsZUFBZSxFQUFFLGFBQWEsQ0FBQyxDQUFDO0FBQzdDLHlCQUFLLENBQUMsTUFBTSxDQUFDLGVBQWUsRUFBRSxhQUFhLENBQUMsQ0FBQztpQkFDaEQ7O0FBRUQseUJBQVMsYUFBYSxHQUFHOztBQUVyQiwyQkFBTyxDQUFDLFdBQVcsQ0FBQyxtQkFBbUIsRUFBRSxRQUFRLENBQUMsVUFBVSxJQUFJLFFBQVEsQ0FBQyxRQUFRLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQztpQkFDaEc7YUFDSjtTQUNKO0tBQ0osQ0FBQztDQUNMLENBQUMsQ0FBQzs7O0FDN0NQLE9BQU8sQ0FBQyxNQUFNLENBQUMsOEJBQThCLEVBQUUsQ0FDM0Msd0NBQXdDLEVBQ3hDLG9DQUFvQyxFQUNwQyxxQ0FBcUMsQ0FDeEMsQ0FBQyxDQUFDOzs7QUNKSCxPQUFPLENBQUMsTUFBTSxDQUFDLDhDQUE4QyxFQUFFLEVBQUUsQ0FBQyxDQUM3RCxTQUFTLENBQUMsZ0JBQWdCLEVBQUUsU0FBUyx1QkFBdUIsQ0FBQyxRQUFRLEVBQUU7QUFDcEUsV0FBTztBQUNILGdCQUFRLEVBQUUsRUFBRTtBQUNaLGVBQU8sRUFBRSxJQUFJO0FBQ2IsZ0JBQVEsRUFBRSxJQUFJO0FBQ2QsbUJBQVcsRUFBRSwrREFBK0Q7QUFDNUUsZ0JBQVEsRUFBRSxJQUFJO0FBQ2Qsa0JBQVUsRUFBRSxJQUFJO0FBQ2hCLGVBQU8sRUFBRSxTQUFTLHFCQUFxQixDQUFDLFFBQVEsRUFBRSxNQUFNLEVBQUU7OztBQUd0RCxnQkFBSSxRQUFRLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxLQUFLLFNBQVMsRUFBRTtBQUMxQyxzQkFBTSxJQUFJLFdBQVcsQ0FDakIsOEVBQThFLEdBQzlFLG9GQUFvRixHQUNwRixhQUFhLEdBQUcsTUFBTSxDQUFDLFFBQVEsQ0FDbEMsQ0FBQzthQUNMOztBQUVELG1CQUFPO0FBQ0gsb0JBQUksRUFBRSxTQUFTLHNCQUFzQixDQUFDLEtBQUssRUFBRSxPQUFPLEVBQUUsS0FBSyxFQUFFLFdBQVcsRUFBRSxVQUFVLEVBQUU7QUFDbEYseUJBQUssQ0FBQyxRQUFRLEdBQUcsS0FBSyxDQUFDLFFBQVEsSUFBSSxLQUFLLENBQUMsUUFBUSxDQUFDOztBQUVsRCw4QkFBVSxDQUFDLFNBQVMsd0JBQXdCLENBQUMsVUFBVSxFQUFFO0FBQ3JELDRCQUFJLFlBQVksR0FBRyxPQUFPLENBQUMsT0FBTyxDQUFDLFNBQVMsQ0FBQyxDQUFDOzs7O0FBSTlDLG9DQUFZLENBQUMsSUFBSSxDQUFDLEtBQUssRUFBRSxLQUFLLENBQUMsUUFBUSxDQUFDLENBQUM7QUFDekMsb0NBQVksQ0FBQyxJQUFJLENBQUMsWUFBWSxFQUFFLEtBQUssQ0FBQyxRQUFRLENBQUMsQ0FBQztBQUNoRCxvQ0FBWSxDQUFDLElBQUksQ0FBQyxNQUFNLEVBQUUsT0FBTyxDQUFDLENBQUM7QUFDbkMsb0NBQVksQ0FBQyxRQUFRLENBQUMsb0JBQW9CLENBQUMsQ0FBQzs7O0FBRzVDLG9DQUFZLENBQUMsTUFBTSxDQUFDLFVBQVUsQ0FBQyxDQUFDOztBQUVoQywrQkFBTyxDQUFDLE1BQU0sQ0FBQyxZQUFZLENBQUMsQ0FBQzs7QUFFN0IsZ0NBQVEsQ0FBQyxPQUFPLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQztxQkFDNUIsQ0FBQyxDQUFDO2lCQUNOO2FBQ0osQ0FBQztTQUNMO0tBQ0osQ0FBQztDQUNMLENBQUMsQ0FBQzs7O0FDN0NQLE9BQU8sQ0FBQyxNQUFNLENBQUMsb0NBQW9DLEVBQUUsQ0FDakQsOENBQThDLENBQ2pELENBQUMsQ0FBQzs7O0FDRkgsT0FBTyxDQUFDLE1BQU0sQ0FBQywrQ0FBK0MsRUFBRSxFQUFFLENBQUMsQ0FDOUQsU0FBUyxDQUFDLGlCQUFpQixFQUFFLFNBQVMsd0JBQXdCLEdBQUc7QUFDOUQsV0FBTztBQUNILGVBQU8sRUFBRSxJQUFJO0FBQ2IsZUFBTyxFQUFFLE9BQU87QUFDaEIsZ0JBQVEsRUFBRSxJQUFJO0FBQ2QsbUJBQVcsRUFBRSxpRUFBaUU7QUFDOUUsa0JBQVUsRUFBRSxJQUFJO0FBQ2hCLFlBQUksRUFBRTs7O0FBR0YsZUFBRyxFQUFFLFNBQVMsc0JBQXNCLENBQUMsS0FBSyxFQUFFLE9BQU8sRUFBRSxLQUFLLEVBQUUsUUFBUSxFQUFFOztBQUVsRSxvQkFBSSxRQUFRLEdBQUcsS0FBSyxDQUFDLFFBQVEsSUFBSSxLQUFLLENBQUMsUUFBUTtvQkFDM0MsYUFBYSxHQUFHLFFBQVEsQ0FBQyxRQUFRLENBQUMsQ0FBQzs7OztBQUl2QyxxQkFBSyxDQUFDLFFBQVEsR0FBRyxRQUFRLENBQUM7QUFDMUIscUJBQUssQ0FBQyxRQUFRLEdBQUcsUUFBUSxDQUFDO0FBQzFCLHFCQUFLLENBQUMsYUFBYSxHQUFHLGFBQWEsQ0FBQzthQUN2QztTQUNKO0tBQ0osQ0FBQztDQUNMLENBQUMsQ0FBQzs7O0FDeEJQLE9BQU8sQ0FBQyxNQUFNLENBQUMscUNBQXFDLEVBQUUsQ0FDbEQsK0NBQStDLENBQ2xELENBQUMsQ0FBQzs7O0FDRkgsT0FBTyxDQUFDLE1BQU0sQ0FBQywrQ0FBK0MsRUFBRSxFQUFFLENBQUMsQ0FFOUQsVUFBVSxDQUFDLG9CQUFvQixFQUFFLFVBQVMsUUFBUSxFQUFFO0FBQ2pELFFBQU0sSUFBSSxHQUFHLElBQUksQ0FBQztBQUNsQixRQUFNLGFBQWEsR0FBRywyQ0FBMkMsQ0FBQzs7QUFFbEUsUUFBSSxTQUFTLEdBQUcsS0FBSyxDQUFDOztBQUV0QixRQUFJLENBQUMsUUFBUSxHQUFHLFFBQVEsQ0FBQztBQUN6QixRQUFJLENBQUMsVUFBVSxHQUFHLFVBQVUsQ0FBQztBQUM3QixRQUFJLENBQUMsZUFBZSxHQUFHLGVBQWUsQ0FBQztBQUN2QyxRQUFJLENBQUMsWUFBWSxHQUFHLFlBQVksQ0FBQztBQUNqQyxRQUFJLENBQUMsVUFBVSxHQUFHLFVBQVUsQ0FBQztBQUM3QixRQUFJLENBQUMsUUFBUSxHQUFHLFdBQVcsQ0FBQyxpQkFBaUIsQ0FBQyxDQUFDOztBQUUvQyxhQUFTLFFBQVEsR0FBRztBQUNoQixZQUFJLGFBQWEsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxFQUFFO0FBQ2hDLGdCQUFJLENBQUMsY0FBYyxHQUFHLElBQUksQ0FBQyxLQUFLLENBQUM7QUFDakMsZ0JBQUksQ0FBQyxXQUFXLENBQUMsYUFBYSxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsQ0FBQztTQUM5QztLQUNKOztBQUVELGFBQVMsV0FBVyxDQUFDLFFBQVEsRUFBRTtBQUMzQixlQUFPLENBQUMsQ0FBQyxRQUFRLENBQUMsUUFBUSxDQUFDLENBQUM7S0FDL0I7O0FBRUQsYUFBUyxlQUFlLENBQUMsY0FBYyxFQUFFO0FBQ3JDLFlBQUksY0FBYyxLQUFLLFNBQVMsRUFBRTtBQUM5QixxQkFBUyxHQUFHLGNBQWMsQ0FBQztTQUM5Qjs7QUFFRCxlQUFPLFNBQVMsQ0FBQztLQUNwQjs7QUFFRCxhQUFTLFVBQVUsQ0FBQyxNQUFNLEVBQUU7QUFDeEIsWUFBSSxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsRUFBRTtBQUNyQyxtQkFBTztTQUNWOztBQUVELFlBQUksQ0FBQyxlQUFlLENBQUMsS0FBSyxDQUFDLENBQUM7S0FDL0I7O0FBRUQsYUFBUyxNQUFNLEdBQUc7QUFDZCxZQUFJLENBQUMsS0FBSyxHQUFHLElBQUksQ0FBQyxXQUFXLENBQUMsVUFBVSxDQUFDO0FBQ3pDLFlBQUksQ0FBQyxjQUFjLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBQztLQUNwQzs7QUFFRCxhQUFTLFlBQVksQ0FBQyxXQUFXLEVBQUU7QUFDL0IsWUFBSSxDQUFDLFdBQVcsR0FBRyxXQUFXLENBQUM7QUFDL0IsWUFBSSxDQUFDLFdBQVcsQ0FBQyxPQUFPLEdBQUcsTUFBTSxDQUFDO0tBQ3JDOztBQUVELGFBQVMsVUFBVSxDQUFDLE1BQU0sRUFBRTtBQUN4QixjQUFNLENBQUMsY0FBYyxFQUFFLENBQUM7O0FBRXhCLFlBQUksQ0FBQyxlQUFlLENBQUMsSUFBSSxDQUFDLENBQUM7S0FDOUI7Q0FDSixDQUFDLENBQUM7OztBQ3pEUCxPQUFPLENBQUMsTUFBTSxDQUFDLDhDQUE4QyxFQUFFLENBQzNELCtDQUErQyxDQUNsRCxDQUFDLENBRUcsU0FBUyxDQUFDLGdCQUFnQixFQUFFLFNBQVMsdUJBQXVCLENBQUMsU0FBUyxFQUFFO0FBQ3JFLFdBQU87QUFDSCx3QkFBZ0IsRUFBRSxJQUFJO0FBQ3RCLGtCQUFVLEVBQUUsb0JBQW9CO0FBQ2hDLG9CQUFZLEVBQUUsb0JBQW9CO0FBQ2xDLGVBQU8sRUFBRSxDQUFDLGdCQUFnQixFQUFFLFVBQVUsQ0FBQztBQUN2QyxnQkFBUSxFQUFFLEdBQUc7QUFDYixhQUFLLEVBQUU7QUFDSCxxQkFBUyxFQUFFLEdBQUc7QUFDZCxtQkFBTyxFQUFFLEdBQUc7QUFDWiwyQkFBZSxFQUFFLEdBQUc7U0FDdkI7QUFDRCxtQkFBVyxFQUFFLCtEQUErRDs7QUFFNUUsZUFBTyxFQUFFLFNBQVMsOEJBQThCLENBQUMsUUFBUSxFQUFFO0FBQ3ZELG9CQUFRLENBQUMsUUFBUSxDQUFDLGlCQUFpQixDQUFDLENBQUM7O0FBRXJDLG1CQUFPLFNBQVMsMkJBQTJCLENBQUMsTUFBTSxFQUFFLE9BQU8sRUFBRSxLQUFLLEVBQUUsS0FBSyxFQUFFO0FBQ3ZFLG9CQUFNLElBQUksR0FBRyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDdEIsb0JBQU0sV0FBVyxHQUFHLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQzs7QUFFN0Isb0JBQUksQ0FBQyxZQUFZLENBQUMsV0FBVyxDQUFDLENBQUM7O0FBRS9CLHlCQUFTLENBQUMsRUFBRSxDQUFDLFdBQVcsRUFBRSxTQUFTLFVBQVUsQ0FBQyxLQUFLLEVBQUU7QUFDakQsMEJBQU0sQ0FBQyxNQUFNLENBQUMsWUFBVztBQUNyQiw0QkFBSSxDQUFDLFVBQVUsQ0FBQyxLQUFLLENBQUMsQ0FBQztxQkFDMUIsQ0FBQyxDQUFDO2lCQUNOLENBQUMsQ0FBQzthQUNOLENBQUM7U0FDTDtLQUNKLENBQUM7Q0FDTCxDQUFDLENBQUM7OztBQ25DUCxPQUFPLENBQUMsTUFBTSxDQUFDLG9DQUFvQyxFQUFFLENBQ2pELDhDQUE4QyxDQUNqRCxDQUFDLENBQUM7OztBQ0ZILE9BQU8sQ0FBQyxNQUFNLENBQUMsNkJBQTZCLEVBQUUsQ0FDMUMscUNBQXFDLENBQ3hDLENBQUMsQ0FBQzs7O0FDRkgsT0FBTyxDQUFDLE1BQU0sQ0FBQyxxQ0FBcUMsRUFBRSxFQUFFLENBQUMsQ0FDcEQsUUFBUSxDQUFDLFdBQVcsRUFBRSxTQUFTLGlCQUFpQixDQUFDLGlCQUFpQixFQUFFO0FBQ2pFLFFBQUksQ0FBQyxJQUFJLEdBQUcsU0FBUyxnQkFBZ0IsR0FBRztBQUNwQyxlQUFPLGlCQUFpQixDQUFDLFNBQVMsRUFBRSxDQUFDO0tBQ3hDLENBQUM7Q0FDTCxDQUFDLENBQUM7OztBQ0xQLE9BQU8sQ0FBQyxNQUFNLENBQUMsbUNBQW1DLEVBQUUsQ0FDaEQsb0NBQW9DLENBQ3ZDLENBQUMsQ0FDRyxVQUFVLENBQUMsVUFBVSxFQUFFLFNBQVMsdUJBQXVCLENBQUMsS0FBSyxFQUFFLGNBQWMsRUFBRSxXQUFXLEVBQUU7QUFDekYsUUFBSSxJQUFJLEdBQUcsSUFBSSxDQUFDOztBQUVoQixRQUFJLENBQUMsV0FBVyxHQUFHLFdBQVcsQ0FBQzs7QUFFL0IsYUFBUyxXQUFXLENBQUMsS0FBSyxFQUFFO0FBQ3hCLFlBQUksV0FBVyxHQUFHLFdBQVcsR0FBRyxLQUFLLEdBQUcsTUFBTSxDQUFDOztBQUUvQyxlQUFPLEtBQUssQ0FBQyxHQUFHLENBQUMsV0FBVyxFQUFFLEVBQUUsS0FBSyxFQUFFLGNBQWMsRUFBRSxDQUFDLENBQ25ELElBQUksQ0FBQyxTQUFTLHdCQUF3QixDQUFDLFFBQVEsRUFBRTtBQUM5QyxtQkFBTyxRQUFRLENBQUMsSUFBSSxDQUFDO1NBQ3hCLENBQUMsQ0FBQztLQUNWO0NBQ0osQ0FBQyxDQUFDOzs7Ozs7Ozs7QUNWUCxPQUFPLENBQUMsTUFBTSxDQUFDLGtDQUFrQyxFQUFFLENBQy9DLG1DQUFtQyxDQUN0QyxDQUFDLENBQ0csU0FBUyxDQUFDLE1BQU0sRUFBRSxTQUFTLGFBQWEsR0FBRztBQUN4QyxXQUFPO0FBQ0gsd0JBQWdCLEVBQUUsSUFBSTtBQUN0QixrQkFBVSxFQUFFLHNCQUFzQjtBQUNsQyxnQkFBUSxFQUFFLEdBQUc7QUFDYixhQUFLLEVBQUU7QUFDSCxpQkFBSyxFQUFFLEdBQUc7U0FDYjtBQUNELGVBQU8sRUFBRSxTQUFTLG9CQUFvQixDQUFDLFFBQVEsRUFBRTtBQUM3QyxvQkFBUSxDQUFDLFFBQVEsQ0FBQyxNQUFNLENBQUMsQ0FBQztBQUMxQixvQkFBUSxDQUFDLElBQUksQ0FBQyxhQUFhLEVBQUUsSUFBSSxDQUFDLENBQUM7O0FBRW5DLG1CQUFPLFNBQVMsaUJBQWlCLENBQUMsTUFBTSxFQUFFLE9BQU8sRUFBRSxLQUFLLEVBQUUsSUFBSSxFQUFFO0FBQzVELHNCQUFNLENBQUMsTUFBTSxDQUFDLGdCQUFnQixFQUFFLFNBQVMsc0JBQXNCLENBQUMsUUFBUSxFQUFFO0FBQ3RFLHdCQUFJLENBQUMsV0FBVyxDQUFDLFFBQVEsQ0FBQyxDQUNyQixJQUFJLENBQUMsU0FBUyxtQkFBbUIsQ0FBQyxHQUFHLEVBQUU7QUFDcEMsK0JBQU8sQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLENBQUM7cUJBQ3JCLENBQUMsQ0FBQztpQkFDVixDQUFDLENBQUM7YUFDTixDQUFDO1NBQ0w7S0FDSixDQUFDO0NBQ0wsQ0FBQyxDQUFDOzs7QUMvQlAsT0FBTyxDQUFDLE1BQU0sQ0FBQyx3QkFBd0IsRUFBRSxDQUNyQyxrQ0FBa0MsQ0FDckMsQ0FBQyxDQUFDOzs7QUNGSCxPQUFPLENBQUMsTUFBTSxDQUFDLG9DQUFvQyxFQUFFLEVBQUUsQ0FBQyxDQUNuRCxRQUFRLENBQUMsYUFBYSxFQUFFLFNBQVMseUJBQXlCLEdBQUc7QUFDMUQsUUFBSSxDQUFDLFdBQVcsR0FBRyxXQUFXLENBQUM7QUFDL0IsUUFBSSxDQUFDLElBQUksR0FBRyxTQUFTLHNCQUFzQixDQUFDLElBQUksRUFBRTtBQUM5QyxZQUFJLElBQUksQ0FBQyxXQUFXLEtBQUssU0FBUyxFQUFFO0FBQ2hDLGdCQUFJLENBQUMsS0FBSyxDQUFDLDhFQUE4RSxDQUFDLENBQUM7U0FDOUY7O0FBRUQsZUFBTyxJQUFJLENBQUMsV0FBVyxDQUFDO0tBQzNCLENBQUM7O0FBRUYsYUFBUyxXQUFXLENBQUMsV0FBVyxFQUFFO0FBQzlCLFlBQUksQ0FBQyxXQUFXLEdBQUcsV0FBVyxDQUFDO0tBQ2xDO0NBQ0osQ0FBQyxDQUFDOzs7QUNkUCxPQUFPLENBQUMsTUFBTSxDQUFDLGtEQUFrRCxFQUFFLEVBQUUsQ0FBQyxDQUNqRSxTQUFTLENBQUMscUJBQXFCLEVBQUUsU0FBUyw0QkFBNEIsQ0FBQyxVQUFVLEVBQUU7QUFDaEYsV0FBTztBQUNILGdCQUFRLEVBQUUsR0FBRztBQUNiLG1CQUFXLEVBQUUsdUVBQXVFOztBQUVwRixZQUFJLEVBQUUsY0FBUyxLQUFLLEVBQUU7QUFDbEIsc0JBQVUsQ0FBQyxHQUFHLENBQUMsb0JBQW9CLEVBQUUsVUFBUyxLQUFLLEVBQUUsR0FBRyxFQUFFO0FBQ3RELHFCQUFLLENBQUMsaUJBQWlCLEdBQUcsR0FBRyxDQUFDO2FBQ2pDLENBQUMsQ0FBQztTQUNOO0tBQ0osQ0FBQztDQUNMLENBQUMsQ0FBQzs7O0FDWlAsT0FBTyxDQUFDLE1BQU0sQ0FBQyx3Q0FBd0MsRUFBRSxDQUNyRCxrREFBa0QsQ0FDckQsQ0FBQyxDQUFDOzs7QUNGSCxPQUFPLENBQUMsTUFBTSxDQUFDLDhDQUE4QyxFQUFFLEVBQUUsQ0FBQyxDQUM3RCxVQUFVLENBQUMsb0JBQW9CLEVBQUUsU0FBUyxrQkFBa0IsQ0FBQyxVQUFVLEVBQUUsUUFBUSxFQUFFO0FBQ2hGLFFBQUksSUFBSSxHQUFHLElBQUk7UUFDWCxlQUFlLEdBQUcsR0FBRztRQUNyQixPQUFPLENBQUM7O0FBRVosUUFBSSxJQUFJLENBQUMsUUFBUSxLQUFLLFNBQVMsRUFBRTtBQUM3QixZQUFJLENBQUMsUUFBUSxHQUFHLGVBQWUsQ0FBQztLQUNuQzs7QUFFRCxRQUFJLElBQUksQ0FBQyxXQUFXLEVBQUU7QUFDbEIsa0JBQVUsQ0FBQyxHQUFHLENBQUMsbUJBQW1CLEVBQUUsWUFBWSxDQUFDLENBQUM7QUFDbEQsa0JBQVUsQ0FBQyxHQUFHLENBQUMscUJBQXFCLEVBQUUsV0FBVyxDQUFDLENBQUM7QUFDbkQsa0JBQVUsQ0FBQyxHQUFHLENBQUMsbUJBQW1CLEVBQUUsV0FBVyxDQUFDLENBQUM7S0FDcEQ7O0FBRUQsYUFBUyxZQUFZLENBQUMsS0FBSyxFQUFFO0FBQ3pCLFlBQUksS0FBSyxDQUFDLGdCQUFnQixFQUFFO0FBQ3hCLG1CQUFPO1NBQ1Y7O0FBRUQsZUFBTyxHQUFHLFFBQVEsQ0FBQyxTQUFTLGlCQUFpQixHQUFHO0FBQzVDLGdCQUFJLENBQUMsT0FBTyxHQUFHLElBQUksQ0FBQztTQUN2QixFQUFFLElBQUksQ0FBQyxRQUFRLENBQUMsQ0FBQztLQUNyQjs7QUFFRCxhQUFTLFdBQVcsQ0FBQyxLQUFLLEVBQUU7QUFDeEIsWUFBSSxLQUFLLENBQUMsZ0JBQWdCLEVBQUU7QUFDeEIsbUJBQU87U0FDVjs7QUFFRCxnQkFBUSxDQUFDLE1BQU0sQ0FBQyxPQUFPLENBQUMsQ0FBQztBQUN6QixZQUFJLENBQUMsT0FBTyxHQUFHLEtBQUssQ0FBQztLQUN4QjtDQUNKLENBQUMsQ0FBQzs7O0FDbENQLE9BQU8sQ0FBQyxNQUFNLENBQUMsNkNBQTZDLEVBQUUsQ0FDMUQsOENBQThDLENBQ2pELENBQUMsQ0FDRyxTQUFTLENBQUMsZ0JBQWdCLEVBQUUsU0FBUyxjQUFjLENBQUMsUUFBUSxFQUFFO0FBQzNELFdBQU87QUFDSCx3QkFBZ0IsRUFBRSxJQUFJO0FBQ3RCLGtCQUFVLEVBQUUsMENBQTBDO0FBQ3RELGdCQUFRLEVBQUUsR0FBRztBQUNiLGFBQUssRUFBRTtBQUNILG9CQUFRLEVBQUUsSUFBSTtBQUNkLG1CQUFPLEVBQUUsa0JBQWtCO0FBQzNCLHVCQUFXLEVBQUUsSUFBSTtTQUNwQjtBQUNELGVBQU8sRUFBRSxTQUFTLHFCQUFxQixDQUFDLE9BQU8sRUFBRTtBQUM3QyxtQkFBTyxDQUFDLFFBQVEsQ0FBQywwQkFBMEIsQ0FBQyxDQUFDOztBQUU3QyxtQkFBTyxTQUFTLGtCQUFrQixDQUFDLEtBQUssRUFBRSxPQUFPLEVBQUU7QUFDL0Msb0JBQU0sT0FBTyxHQUFHLFFBQVEsQ0FBQyx1RUFBdUUsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDO0FBQ3pHLHVCQUFPLENBQUMsTUFBTSxDQUFDLE9BQU8sQ0FBQyxDQUFDO2FBQzNCLENBQUM7U0FDTDtLQUNKLENBQUM7Q0FDTCxDQUFDLENBQUM7OztBQ3RCUCxPQUFPLENBQUMsTUFBTSxDQUFDLG1DQUFtQyxFQUFFLENBQ2hELDZDQUE2QyxDQUNoRCxDQUFDLENBQUM7Ozs7Ozs7O0FDR0gsT0FBTyxDQUFDLE1BQU0sQ0FBQywrQ0FBK0MsRUFBRSxFQUUvRCxDQUFDLENBQ0MsT0FBTyxDQUFDLGFBQWEsRUFBRSxDQUFDLFNBQVMsRUFBRSxhQUFhLEVBQUUsVUFBVSxFQUFFLFdBQVcsRUFBRSxVQUFVLEVBQUUsWUFBWSxFQUFFLGNBQWMsRUFDbEgsVUFBVSxPQUFPLEVBQUUsV0FBVyxFQUFFLFFBQVEsRUFBRSxTQUFTLEVBQUUsUUFBUSxFQUFFLFVBQVUsRUFBRSxZQUFZLEVBQUU7O0FBRXZGLE1BQUksa0JBQWtCLEdBQUcsaUJBQWlCLENBQUM7OztBQUczQyxNQUFJLGFBQWEsRUFBRSxhQUFhLENBQUM7QUFDakMsTUFBSSxhQUFhLEdBQUcsWUFBWSxDQUFDLFNBQVMsRUFBRSxDQUFDO0FBQzdDLE1BQUksV0FBVyxHQUFHLEVBQUUsQ0FBQzs7QUFFckIsV0FBUyxhQUFhLEdBQUc7QUFDdkIsUUFBSSxnQkFBZ0IsR0FBRyxDQUFDLENBQUMsQ0FBQztBQUMxQixRQUFJLE1BQU0sR0FBRyxhQUFhLENBQUMsSUFBSSxFQUFFLENBQUM7QUFDbEMsU0FBSyxJQUFJLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxHQUFHLE1BQU0sQ0FBQyxNQUFNLEVBQUUsQ0FBQyxFQUFFLEVBQUU7QUFDdEMsVUFBSSxhQUFhLENBQUMsR0FBRyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxRQUFRLEVBQUU7QUFDL0Msd0JBQWdCLEdBQUcsQ0FBQyxDQUFDO09BQ3RCO0tBQ0Y7QUFDRCxXQUFPLGdCQUFnQixDQUFDO0dBQ3pCOztBQUVELFlBQVUsQ0FBQyxNQUFNLENBQUMsYUFBYSxFQUFFLFVBQVMsZ0JBQWdCLEVBQUM7QUFDekQsUUFBSSxhQUFhLEVBQUU7QUFDakIsbUJBQWEsQ0FBQyxLQUFLLEdBQUcsZ0JBQWdCLENBQUM7S0FDeEM7R0FDRixDQUFDLENBQUM7O0FBRUgsV0FBUyxpQkFBaUIsQ0FBQyxhQUFhLEVBQUU7QUFDeEMsUUFBSSxJQUFJLEdBQUcsU0FBUyxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDeEMsUUFBSSxXQUFXLEdBQUcsYUFBYSxDQUFDLEdBQUcsQ0FBQyxhQUFhLENBQUMsQ0FBQyxLQUFLLENBQUM7OztBQUd6RCxpQkFBYSxDQUFDLE1BQU0sQ0FBQyxhQUFhLENBQUMsQ0FBQzs7O0FBR3BDLHNCQUFrQixDQUFDLFdBQVcsQ0FBQyxVQUFVLEVBQUUsV0FBVyxDQUFDLFVBQVUsRUFBRSxHQUFHLEVBQUUsWUFBVztBQUNqRixpQkFBVyxDQUFDLFVBQVUsQ0FBQyxRQUFRLEVBQUUsQ0FBQztBQUNsQyxVQUFJLENBQUMsV0FBVyxDQUFDLGtCQUFrQixFQUFFLGFBQWEsQ0FBQyxNQUFNLEVBQUUsR0FBRyxDQUFDLENBQUMsQ0FBQztBQUNqRSx5QkFBbUIsRUFBRSxDQUFDO0tBQ3ZCLENBQUMsQ0FBQztHQUNKOztBQUVELFdBQVMsbUJBQW1CLEdBQUc7O0FBRTdCLFFBQUksYUFBYSxJQUFJLGFBQWEsRUFBRSxJQUFJLENBQUMsQ0FBQyxFQUFFO0FBQzFDLFVBQUksZ0JBQWdCLEdBQUcsYUFBYSxDQUFDO0FBQ3JDLHdCQUFrQixDQUFDLGFBQWEsRUFBRSxhQUFhLEVBQUUsR0FBRyxFQUFFLFlBQVk7QUFDaEUsd0JBQWdCLENBQUMsUUFBUSxFQUFFLENBQUM7QUFDNUIsd0JBQWdCLEdBQUcsSUFBSSxDQUFDO09BQ3pCLENBQUMsQ0FBQztBQUNILG1CQUFhLEdBQUcsU0FBUyxDQUFDO0FBQzFCLG1CQUFhLEdBQUcsU0FBUyxDQUFDO0tBQzNCO0dBQ0Y7O0FBRUQsV0FBUyxrQkFBa0IsQ0FBQyxLQUFLLEVBQUUsS0FBSyxFQUFFLFdBQVcsRUFBRSxJQUFJLEVBQUU7O0FBRTNELFNBQUssQ0FBQyxPQUFPLEdBQUcsS0FBSyxDQUFDOztBQUV0QixRQUFJLHNCQUFzQixHQUFHLFdBQVcsQ0FBQyxzQkFBc0IsQ0FBQztBQUNoRSxRQUFJLHNCQUFzQixFQUFFOztBQUUxQixVQUFJLE9BQU8sR0FBRyxRQUFRLENBQUMsY0FBYyxFQUFFLFdBQVcsQ0FBQyxDQUFDOztBQUVwRCxXQUFLLENBQUMsSUFBSSxDQUFDLHNCQUFzQixFQUFFLFlBQVk7QUFDN0MsZ0JBQVEsQ0FBQyxNQUFNLENBQUMsT0FBTyxDQUFDLENBQUM7QUFDekIsc0JBQWMsRUFBRSxDQUFDO0FBQ2pCLGFBQUssQ0FBQyxNQUFNLEVBQUUsQ0FBQztPQUNoQixDQUFDLENBQUM7S0FDSixNQUFNOztBQUVMLGNBQVEsQ0FBQyxjQUFjLEVBQUUsQ0FBQyxDQUFDLENBQUM7S0FDN0I7O0FBRUQsYUFBUyxjQUFjLEdBQUc7QUFDeEIsVUFBSSxjQUFjLENBQUMsSUFBSSxFQUFFO0FBQ3ZCLGVBQU87T0FDUjtBQUNELG9CQUFjLENBQUMsSUFBSSxHQUFHLElBQUksQ0FBQzs7QUFFM0IsV0FBSyxDQUFDLE1BQU0sRUFBRSxDQUFDO0FBQ2YsVUFBSSxJQUFJLEVBQUU7QUFDUixZQUFJLEVBQUUsQ0FBQztPQUNSO0tBQ0Y7R0FDRjs7QUFFRCxXQUFTLENBQUMsSUFBSSxDQUFDLFNBQVMsRUFBRSxVQUFVLEdBQUcsRUFBRTtBQUN2QyxRQUFJLEtBQUssQ0FBQzs7QUFFVixRQUFJLEdBQUcsQ0FBQyxLQUFLLEtBQUssRUFBRSxFQUFFO0FBQ3BCLFdBQUssR0FBRyxhQUFhLENBQUMsR0FBRyxFQUFFLENBQUM7QUFDNUIsVUFBSSxLQUFLLElBQUksS0FBSyxDQUFDLEtBQUssQ0FBQyxRQUFRLEVBQUU7QUFDakMsa0JBQVUsQ0FBQyxNQUFNLENBQUMsWUFBWTtBQUM1QixxQkFBVyxDQUFDLE9BQU8sQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLENBQUM7U0FDaEMsQ0FBQyxDQUFDO09BQ0o7S0FDRjtHQUNGLENBQUMsQ0FBQzs7QUFFSCxhQUFXLENBQUMsSUFBSSxHQUFHLFVBQVUsYUFBYSxFQUFFLEtBQUssRUFBRTs7QUFFakQsaUJBQWEsQ0FBQyxHQUFHLENBQUMsYUFBYSxFQUFFO0FBQy9CLGNBQVEsRUFBRSxLQUFLLENBQUMsUUFBUTtBQUN4QixnQkFBVSxFQUFFLEtBQUssQ0FBQyxLQUFLO0FBQ3ZCLGNBQVEsRUFBRSxLQUFLLENBQUMsUUFBUTtBQUN4QixjQUFRLEVBQUUsS0FBSyxDQUFDLFFBQVE7S0FDekIsQ0FBQyxDQUFDOztBQUVILFFBQUksSUFBSSxHQUFHLFNBQVMsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQztRQUNuQyxpQkFBaUIsR0FBRyxhQUFhLEVBQUUsQ0FBQzs7QUFFeEMsUUFBSSxpQkFBaUIsSUFBSSxDQUFDLElBQUksQ0FBQyxhQUFhLEVBQUU7QUFDNUMsbUJBQWEsR0FBRyxVQUFVLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDO0FBQ3RDLG1CQUFhLENBQUMsS0FBSyxHQUFHLGlCQUFpQixDQUFDO0FBQ3hDLG1CQUFhLEdBQUcsUUFBUSxDQUFDLDRCQUE0QixDQUFDLENBQUMsYUFBYSxDQUFDLENBQUM7QUFDdEUsVUFBSSxDQUFDLE1BQU0sQ0FBQyxhQUFhLENBQUMsQ0FBQztLQUM1Qjs7O0FBR0QsUUFBSSxZQUFZLEdBQUcsT0FBTyxDQUFDLE9BQU8sQ0FBQyxzRUFBc0UsQ0FBQyxDQUFDO0FBQzNHLGdCQUFZLENBQUMsSUFBSSxDQUFDLGNBQWMsRUFBRSxLQUFLLENBQUMsV0FBVyxDQUFDLENBQUM7QUFDckQsZ0JBQVksQ0FBQyxJQUFJLENBQUMsT0FBTyxFQUFFLGFBQWEsQ0FBQyxNQUFNLEVBQUUsR0FBRyxDQUFDLENBQUMsQ0FBQztBQUN2RCxnQkFBWSxDQUFDLElBQUksQ0FBQyxTQUFTLEVBQUUsU0FBUyxDQUFDLENBQUM7QUFDeEMsZ0JBQVksQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyxDQUFDOztBQUVqQyxRQUFJLFVBQVUsR0FBRyxRQUFRLENBQUMsWUFBWSxDQUFDLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxDQUFDO0FBQ3JELGlCQUFhLENBQUMsR0FBRyxFQUFFLENBQUMsS0FBSyxDQUFDLFVBQVUsR0FBRyxVQUFVLENBQUM7QUFDbEQsUUFBSSxDQUFDLE1BQU0sQ0FBQyxVQUFVLENBQUMsQ0FBQztBQUN4QixRQUFJLENBQUMsUUFBUSxDQUFDLGtCQUFrQixDQUFDLENBQUM7R0FDbkMsQ0FBQzs7QUFFRixhQUFXLENBQUMsS0FBSyxHQUFHLFVBQVUsYUFBYSxFQUFFLE1BQU0sRUFBRTtBQUNuRCxRQUFJLFdBQVcsR0FBRyxhQUFhLENBQUMsR0FBRyxDQUFDLGFBQWEsQ0FBQyxDQUFDLEtBQUssQ0FBQztBQUN6RCxRQUFJLFdBQVcsRUFBRTtBQUNmLGlCQUFXLENBQUMsUUFBUSxDQUFDLE9BQU8sQ0FBQyxNQUFNLENBQUMsQ0FBQztBQUNyQyx1QkFBaUIsQ0FBQyxhQUFhLENBQUMsQ0FBQztLQUNsQztHQUNGLENBQUM7O0FBRUYsYUFBVyxDQUFDLE9BQU8sR0FBRyxVQUFVLGFBQWEsRUFBRSxNQUFNLEVBQUU7QUFDckQsUUFBSSxXQUFXLEdBQUcsYUFBYSxDQUFDLEdBQUcsQ0FBQyxhQUFhLENBQUMsQ0FBQyxLQUFLLENBQUM7QUFDekQsUUFBSSxXQUFXLEVBQUU7QUFDZixpQkFBVyxDQUFDLFFBQVEsQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDLENBQUM7QUFDcEMsdUJBQWlCLENBQUMsYUFBYSxDQUFDLENBQUM7S0FDbEM7R0FDRixDQUFDOztBQUVGLGFBQVcsQ0FBQyxVQUFVLEdBQUcsVUFBVSxNQUFNLEVBQUU7QUFDekMsUUFBSSxRQUFRLEdBQUcsSUFBSSxDQUFDLE1BQU0sRUFBRSxDQUFDO0FBQzdCLFdBQU8sUUFBUSxFQUFFO0FBQ2YsVUFBSSxDQUFDLE9BQU8sQ0FBQyxRQUFRLENBQUMsR0FBRyxFQUFFLE1BQU0sQ0FBQyxDQUFDO0FBQ25DLGNBQVEsR0FBRyxJQUFJLENBQUMsTUFBTSxFQUFFLENBQUM7S0FDMUI7R0FDRixDQUFDOztBQUVGLGFBQVcsQ0FBQyxNQUFNLEdBQUcsWUFBWTtBQUMvQixXQUFPLGFBQWEsQ0FBQyxHQUFHLEVBQUUsQ0FBQztHQUM1QixDQUFDOztBQUVGLFNBQU8sV0FBVyxDQUFDO0NBQ3BCLENBQUMsQ0FBQyxDQUFDOzs7Ozs7O0FDcktSLE9BQU8sQ0FBQyxNQUFNLENBQUMsNEJBQTRCLEVBQUUsQ0FDekMsK0NBQStDLENBQ2xELENBQUMsQ0FBQzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUNpQkgsT0FBTyxDQUFDLE1BQU0sQ0FBQyxvQ0FBb0MsRUFBRSxFQUFFLENBQUMsQ0FDbkQsU0FBUyxDQUFDLFFBQVEsRUFBRSxTQUFTLGVBQWUsR0FBRzs7QUFFNUMsYUFBUyxXQUFXLENBQUMsUUFBUSxFQUFFO0FBQzNCLGVBQU8sQ0FBQyxDQUFDLFFBQVEsQ0FBQyxRQUFRLENBQUMsQ0FBQztLQUMvQjs7QUFFRCxXQUFPO0FBQ0gsZ0JBQVEsRUFBRSxHQUFHO0FBQ2IsbUJBQVcsRUFBRSwyQ0FBMkM7QUFDeEQsZUFBTyxFQUFFLFNBQVM7QUFDbEIsYUFBSyxFQUFFO0FBQ0gsMkJBQWUsRUFBRSxHQUFHO0FBQ3BCLHFCQUFTLEVBQUUsR0FBRztBQUNkLDJCQUFlLEVBQUUsR0FBRztBQUNwQix3QkFBWSxFQUFFLEdBQUc7QUFDakIsdUJBQVcsRUFBRSxHQUFHO0FBQ2hCLDRCQUFnQixFQUFFLEdBQUc7QUFDckIsMEJBQWMsRUFBRSxHQUFHO0FBQ25CLHlCQUFhLEVBQUUsR0FBRztBQUNsQixvQkFBUSxFQUFFLEdBQUc7U0FDaEI7QUFDRCx3QkFBZ0IsRUFBRSxJQUFJO0FBQ3RCLG9CQUFZLEVBQUUsWUFBWTtBQUMxQixlQUFPLEVBQUUsU0FBUyxzQkFBc0IsQ0FBQyxLQUFLLEVBQUUsTUFBTSxFQUFFO0FBQ3BELGdCQUFJLFlBQVksR0FBRyxLQUFLLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxDQUFDOztBQUV2QyxnQkFBSSxNQUFNLENBQUMsWUFBWSxFQUFFO0FBQ3JCLDRCQUFZLENBQUMsSUFBSSxDQUFDLGdCQUFnQixFQUFFLE1BQU0sQ0FBQyxZQUFZLENBQUMsQ0FBQzthQUM1RDs7QUFFRCxnQkFBSSxNQUFNLENBQUMsV0FBVyxFQUFFO0FBQ3BCLDRCQUFZLENBQUMsSUFBSSxDQUFDLGVBQWUsRUFBRSxNQUFNLENBQUMsV0FBVyxDQUFDLENBQUM7YUFDMUQ7O0FBRUQsbUJBQU8sU0FBUyx1QkFBdUIsQ0FBQyxLQUFLLEVBQUUsT0FBTyxFQUFFLEtBQUssRUFBRSxXQUFXLEVBQUU7QUFDeEUscUJBQUssQ0FBQyxVQUFVLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxDQUFDO2FBQ3RDLENBQUM7U0FDTDtBQUNELGtCQUFVLEVBQUUsU0FBUyxtQkFBbUIsQ0FBQyxNQUFNLEVBQUUsUUFBUSxFQUFFLE1BQU0sRUFBRTtBQUMvRCxnQkFBSSxJQUFJLEdBQUcsSUFBSSxDQUFDOzs7QUFHaEIsZ0JBQUksQ0FBQyxXQUFXLEdBQUcsT0FBTyxDQUFDLFNBQVMsQ0FBQyxNQUFNLENBQUMsV0FBVyxDQUFDLElBQUksTUFBTSxDQUFDLFdBQVcsS0FBSyxPQUFPLENBQUM7QUFDM0YsZ0JBQUksQ0FBQyxPQUFPLEdBQUcsT0FBTyxDQUFDLFNBQVMsQ0FBQyxNQUFNLENBQUMsT0FBTyxDQUFDLElBQUksTUFBTSxDQUFDLE9BQU8sS0FBSyxPQUFPLENBQUM7OztBQUcvRSxnQkFBSSxDQUFDLFNBQVMsR0FBRyxNQUFNLENBQUMsY0FBYyxDQUFDOzs7QUFHdkMsZ0JBQUksQ0FBQyxRQUFRLEdBQUcsV0FBVyxDQUFDLFNBQVMsQ0FBQyxDQUFDO0FBQ3ZDLGdCQUFJLENBQUMsaUJBQWlCLEdBQUcsV0FBVyxDQUFDLHlCQUF5QixDQUFDLENBQUM7O0FBRWhFLGdCQUFJLENBQUMsSUFBSSxHQUFHLElBQUksQ0FBQztBQUNqQixnQkFBSSxDQUFDLFdBQVcsR0FBRyxXQUFXLENBQUM7O0FBRS9CLHFCQUFTLElBQUksQ0FBQyxXQUFXLEVBQUU7QUFDdkIsb0JBQUksQ0FBQyxXQUFXLEdBQUcsV0FBVyxDQUFDO0FBQy9CLG9CQUFJLENBQUMsS0FBSyxHQUFHLElBQUksQ0FBQyxXQUFXLENBQUMsV0FBVyxDQUFDOztBQUUxQyxzQkFBTSxDQUFDLE1BQU0sQ0FBQyxvQ0FBb0MsRUFBRSxTQUFTLGtCQUFrQixDQUFDLFFBQVEsRUFBRTtBQUN0Rix3QkFBSSxDQUFDLEtBQUssR0FBRyxRQUFRLENBQUM7O0FBRXRCLHdCQUFJLENBQUMsU0FBUyxHQUFHLENBQUMsQ0FBQyxRQUFRLENBQUMsUUFBUSxDQUFDLEdBQUcsR0FBRyxHQUFHLFFBQVEsR0FBRyxHQUFHLEtBQUssSUFBSSxDQUFDLFdBQVcsR0FBRyxRQUFRLENBQUM7QUFDN0Ysd0JBQUksQ0FBQyxTQUFTLEdBQUcsQ0FBQyxDQUFDLElBQUksQ0FBQyxTQUFTLEdBQUcsSUFBSSxDQUFDLGFBQWEsR0FBRSxJQUFJLENBQUMsY0FBYyxDQUFDO2lCQUMvRSxDQUFDLENBQUM7YUFDTjs7QUFFRCxxQkFBUyxXQUFXLEdBQUc7QUFDbkIsb0JBQUksQ0FBQyxXQUFXLENBQUMsYUFBYSxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsQ0FBQzthQUM5QztTQUVKO0tBQ0osQ0FBQztDQUNMLENBQUMsQ0FBQzs7O0FDakdQLE9BQU8sQ0FBQyxNQUFNLENBQUMsMEJBQTBCLEVBQUUsQ0FDdkMsb0NBQW9DLENBQ3ZDLENBQUMsQ0FBQzs7Ozs7Ozs7OztBQ0tILE9BQU8sQ0FBQyxNQUFNLENBQUMsb0NBQW9DLEVBQUUsRUFBRSxDQUFDLENBQ25ELFNBQVMsQ0FBQyxRQUFRLEVBQUUsU0FBUyxlQUFlLEdBQUc7QUFDNUMsV0FBTztBQUNILGdCQUFRLEVBQUUsR0FBRztBQUNiLGFBQUssRUFBRTtBQUNILGlCQUFLLEVBQUUsR0FBRztTQUNiO0FBQ0QsZUFBTyxFQUFFLHNCQUFzQjtLQUNsQyxDQUFDOztBQUVGLGFBQVMsc0JBQXNCLENBQUMsUUFBUSxFQUFFO0FBQ3RDLGdCQUFRLENBQUMsUUFBUSxDQUFDLFFBQVEsQ0FBQyxDQUFDO0FBQzVCLGdCQUFRLENBQUMsSUFBSSxDQUFDLGFBQWEsRUFBRSxJQUFJLENBQUMsQ0FBQzs7QUFFbkMsZUFBTyxTQUFTLG1CQUFtQixDQUFDLE1BQU0sRUFBRSxPQUFPLEVBQUUsS0FBSyxFQUFFO0FBQ3hELGlCQUFLLENBQUMsUUFBUSxDQUFDLE9BQU8sRUFBRSxVQUFDLFFBQVEsRUFBSztBQUNsQyx1QkFBTyxDQUFDLElBQUksQ0FBQyxPQUFPLEVBQUUsaUJBQWlCLEdBQUcsUUFBUSxDQUFDLENBQUM7YUFDdkQsQ0FBQyxDQUFDO1NBQ04sQ0FBQztLQUNMO0NBQ0osQ0FBQyxDQUFDOzs7QUMzQlAsT0FBTyxDQUFDLE1BQU0sQ0FBQywwQkFBMEIsRUFBRSxDQUN2QyxvQ0FBb0MsQ0FDdkMsQ0FBQyxDQUFDOzs7QUNGSCxPQUFPLENBQUMsTUFBTSxDQUFDLHdCQUF3QixFQUFFLENBQ3JDLG9DQUFvQyxDQUN2QyxDQUFDLENBQUM7OztBQ0ZILE9BQU8sQ0FBQyxNQUFNLENBQUMsMkNBQTJDLEVBQUUsQ0FDeEQsV0FBVyxDQUNkLENBQUMsQ0FDRyxPQUFPLENBQUMsZUFBZSxFQUFFLFNBQVMsYUFBYSxDQUFDLElBQUksRUFBRSxFQUFFLEVBQUUsTUFBTSxFQUFFLFlBQVksRUFBRTtBQUM3RSxRQUFJLGtCQUFrQixHQUFHO0FBQ3JCLGVBQU8sRUFBRSxFQUFFO0FBQ1gsaUJBQVMsRUFBRTtBQUNQLGdCQUFJLEVBQUUsTUFBTTtBQUNaLGlCQUFLLEVBQUUsT0FBTztBQUNkLGtCQUFNLEVBQUUsU0FBUztBQUNqQixtQkFBTyxFQUFFLFlBQVk7U0FDeEI7QUFDRCxnQkFBUSxFQUFFLElBQUk7QUFDZCxxQkFBYSxFQUFFO0FBQ1gsZUFBRyxFQUFFLEtBQUs7QUFDVixnQkFBSSxFQUFFLE1BQU07U0FDZjtLQUNKLENBQUM7O0FBRUYsYUFBUyxXQUFXLENBQUMsT0FBTyxFQUFFLFdBQVcsRUFBRTtBQUN2QyxZQUFJLENBQUMsV0FBVyxHQUFHLEtBQUssQ0FBQztBQUN6QixZQUFJLENBQUMsT0FBTyxHQUFHLEVBQUUsQ0FBQztBQUNsQixZQUFJLENBQUMsRUFBRSxHQUFHLE9BQU8sQ0FBQztBQUNsQixZQUFJLENBQUMsVUFBVSxHQUFHO0FBQ2QsZ0JBQUksRUFBRSxJQUFJO0FBQ1YsaUJBQUssRUFBRSxJQUFJO0FBQ1gsaUJBQUssRUFBRSxJQUFJO1NBQ2QsQ0FBQztBQUNGLFlBQUksQ0FBQyxjQUFjLEdBQUcsS0FBSyxDQUFDO0FBQzVCLFlBQUksQ0FBQyxnQkFBZ0IsR0FBRyxPQUFPLENBQUMsSUFBSSxDQUFDO0FBQ3JDLFlBQUksQ0FBQyxJQUFJLEdBQUcsRUFBRSxDQUFDO0FBQ2YsWUFBSSxDQUFDLFlBQVksR0FBRyxFQUFFLENBQUM7QUFDdkIsWUFBSSxDQUFDLE1BQU0sR0FBRyxFQUFFLENBQUM7QUFDakIsWUFBSSxDQUFDLE9BQU8sR0FBRyxFQUFFLENBQUM7O0FBRWxCLFlBQUksQ0FBQyxXQUFXLEdBQUcsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxXQUFXLENBQUMsR0FBRyxXQUFXLEdBQUcsRUFBRSxDQUFDO0FBQzlELFlBQUksQ0FBQyxXQUFXLEdBQUcsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsV0FBVyxFQUFFLGtCQUFrQixDQUFDLENBQUM7S0FDdkU7O0FBRUQsZUFBVyxDQUFDLFNBQVMsR0FBRztBQUNwQiwwQkFBa0IsRUFBRSxrQkFBa0I7QUFDdEMscUJBQWEsRUFBRSxhQUFhO0FBQzVCLHVCQUFlLEVBQUUsZUFBZTtBQUNoQyxZQUFJLEVBQUUsSUFBSTtBQUNWLHFCQUFhLEVBQUUsYUFBYTtBQUM1Qix1QkFBZSxFQUFFLGVBQWU7QUFDaEMscUJBQWEsRUFBRSxhQUFhO0FBQzVCLDJCQUFtQixFQUFFLG1CQUFtQjtBQUN4QyxlQUFPLEVBQUUsT0FBTztBQUNoQix3QkFBZ0IsRUFBRSxnQkFBZ0I7QUFDbEMsa0JBQVUsRUFBRSxVQUFVO0FBQ3RCLGtCQUFVLEVBQUUsVUFBVTtBQUN0QixtQkFBVyxFQUFFLFdBQVc7QUFDeEIsd0JBQWdCLEVBQUUsZ0JBQWdCO0tBQ3JDLENBQUM7O0FBRUYsYUFBUyxrQkFBa0IsR0FBRztBQUMxQixZQUFJLE1BQU0sR0FBRyxFQUFFO1lBQ1gsU0FBUyxHQUFHLElBQUksQ0FBQyxXQUFXLENBQUMsU0FBUztZQUN0QyxhQUFhLEdBQUcsQ0FBQztBQUNULG9CQUFRLEVBQUUsU0FBUyxDQUFDLElBQUk7QUFDeEIsaUJBQUssRUFBRSxJQUFJLENBQUMsVUFBVSxDQUFDLElBQUk7U0FDOUIsRUFBRTtBQUNDLG9CQUFRLEVBQUUsU0FBUyxDQUFDLEtBQUs7QUFDekIsaUJBQUssRUFBRSxJQUFJLENBQUMsVUFBVSxDQUFDLEtBQUs7U0FDL0IsRUFBRTtBQUNDLG9CQUFRLEVBQUUsU0FBUyxDQUFDLE1BQU07QUFDMUIsaUJBQUssRUFBRSxJQUFJLENBQUMsTUFBTTtTQUNyQixFQUFFO0FBQ0Msb0JBQVEsRUFBRSxTQUFTLENBQUMsT0FBTztBQUMzQixpQkFBSyxFQUFFLElBQUksQ0FBQyxPQUFPO1NBQ3RCLENBQUMsQ0FBQzs7QUFFWCxTQUFDLENBQUMsSUFBSSxDQUFDLGFBQWEsRUFBRSxTQUFTLGlCQUFpQixDQUFDLEtBQUssRUFBRTtBQUNwRCxnQkFBSSxLQUFLLENBQUMsUUFBUSxLQUFLLFNBQVMsRUFBRTtBQUM5QixzQkFBTSxDQUFDLEtBQUssQ0FBQyxRQUFRLENBQUMsR0FBRyxLQUFLLENBQUMsS0FBSyxDQUFDO2FBQ3hDO1NBQ0osQ0FBQyxDQUFDOztBQUVILFNBQUMsQ0FBQyxNQUFNLENBQUMsTUFBTSxFQUFFLElBQUksQ0FBQyxPQUFPLENBQUMsQ0FBQzs7QUFFL0IsZUFBTyxNQUFNLENBQUM7S0FDakI7O0FBRUQsYUFBUyxhQUFhLEdBQUc7QUFDckIsWUFBSSxLQUFLLEdBQUcsSUFBSSxDQUFDOztBQUVqQixZQUFJLENBQUMsY0FBYyxHQUFHLElBQUksQ0FBQztBQUMzQixlQUFPLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxJQUFJLENBQUMsa0JBQWtCLEVBQUUsQ0FBQyxDQUNsRCxJQUFJLENBQUMsU0FBUyxvQkFBb0IsQ0FBQyxRQUFRLEVBQUU7QUFDMUMsZ0JBQUksS0FBSyxDQUFDLGdCQUFnQixDQUFDLFFBQVEsQ0FBQyxFQUFFO0FBQ2xDLHFCQUFLLENBQUMsT0FBTyxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsQ0FBQztBQUM3QixxQkFBSyxDQUFDLG1CQUFtQixDQUFDLFFBQVEsQ0FBQyxVQUFVLENBQUMsQ0FBQzthQUNsRDs7QUFFRCxtQkFBTyxLQUFLLENBQUM7U0FDaEIsQ0FBQyxTQUNJLENBQUMsU0FBUyxxQkFBcUIsQ0FBQyxLQUFLLEVBQUU7QUFDekMsZ0JBQUksQ0FBQyxLQUFLLENBQUMscURBQXFELENBQUMsQ0FBQzs7QUFFbEUsbUJBQU8sRUFBRSxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsQ0FBQztTQUMzQixDQUFDLFdBQ00sQ0FBQyxTQUFTLHVCQUF1QixHQUFHO0FBQ3hDLGlCQUFLLENBQUMsY0FBYyxHQUFHLEtBQUssQ0FBQztTQUNoQyxDQUFDLENBQUM7S0FDVjs7QUFFRCxhQUFTLGVBQWUsR0FBRztBQUN2QixZQUFJLEtBQUssR0FBRyxJQUFJLENBQUM7O0FBRWpCLGVBQU8sQ0FBQyxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsSUFBSSxFQUFFLFNBQVMscUJBQXFCLENBQUMsR0FBRyxFQUFFO0FBQzNELG1CQUFPLEtBQUssQ0FBQyxhQUFhLENBQUMsR0FBRyxDQUFDLENBQUM7U0FDbkMsQ0FBQyxDQUFDO0tBQ047O0FBRUQsYUFBUyxJQUFJLENBQUMsTUFBTSxFQUFFO0FBQ2xCLFlBQUksQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLE1BQU0sQ0FBQyxFQUFFO0FBQ3JCLGtCQUFNLEdBQUcsRUFBRSxDQUFDO1NBQ2Y7O0FBRUQsWUFBSSxDQUFDLENBQUMsVUFBVSxDQUFDLE1BQU0sQ0FBQyxnQkFBZ0IsQ0FBQyxFQUFFO0FBQ3ZDLGdCQUFJLENBQUMsZ0JBQWdCLEdBQUcsTUFBTSxDQUFDLGdCQUFnQixDQUFDO1NBQ25EOztBQUVELGVBQU8sSUFBSSxDQUNOLGVBQWUsQ0FBQyxNQUFNLENBQUMsV0FBVyxDQUFDLENBQ25DLGFBQWEsRUFBRSxDQUFDO0tBQ3hCOztBQUVELGFBQVMsYUFBYSxDQUFDLEdBQUcsRUFBRTtBQUN4QixlQUFPLElBQUksQ0FBQyxZQUFZLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxXQUFXLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQztLQUM1RDs7QUFFRCxhQUFTLGVBQWUsQ0FBQyxXQUFXLEVBQUU7QUFDbEMsWUFBSSxTQUFTLEdBQUcsSUFBSSxDQUFDLFdBQVcsQ0FBQyxTQUFTO1lBQ3RDLEtBQUssR0FBRyxJQUFJLENBQUM7O0FBRWpCLG1CQUFXLEdBQUcsV0FBVyxJQUFJLFlBQVksQ0FBQzs7QUFFMUMsWUFBSSxDQUFDLG1CQUFtQixDQUFDO0FBQ3JCLGdCQUFJLEVBQUUsV0FBVyxDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUM7QUFDakMsaUJBQUssRUFBRSxXQUFXLENBQUMsU0FBUyxDQUFDLEtBQUssQ0FBQztTQUN0QyxDQUFDLENBQUM7O0FBRUgsWUFBSSxDQUFDLGdCQUFnQixDQUFDLFdBQVcsQ0FBQyxTQUFTLENBQUMsTUFBTSxDQUFDLEVBQUUsV0FBVyxDQUFDLFNBQVMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDOzs7QUFHckYsU0FBQyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsV0FBVyxDQUFDLE9BQU8sRUFBRSxTQUFTLGNBQWMsQ0FBQyxLQUFLLEVBQUU7QUFDNUQsaUJBQUssQ0FBQyxPQUFPLENBQUMsS0FBSyxDQUFDLEdBQUcsV0FBVyxDQUFDLEtBQUssQ0FBQyxDQUFDO1NBQzdDLENBQUMsQ0FBQzs7QUFFSCxlQUFPLElBQUksQ0FBQztLQUNmOztBQUVELGFBQVMsYUFBYSxHQUFHO0FBQ3JCLFlBQUksS0FBSyxHQUFHLElBQUksQ0FBQzs7QUFFakIsWUFBSSxDQUFDLFdBQVcsR0FBRyxDQUFDLElBQUksQ0FBQyxXQUFXLENBQUM7QUFDckMsU0FBQyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsWUFBWSxFQUFFLFNBQVMsaUJBQWlCLENBQUMsS0FBSyxFQUFFLEdBQUcsRUFBRTtBQUM3RCxpQkFBSyxDQUFDLFlBQVksQ0FBQyxHQUFHLENBQUMsR0FBRyxLQUFLLENBQUMsV0FBVyxDQUFDO1NBQy9DLENBQUMsQ0FBQzs7QUFFSCxlQUFPLElBQUksQ0FBQztLQUNmOztBQUVELGFBQVMsbUJBQW1CLENBQUMsVUFBVSxFQUFFO0FBQ3JDLFlBQUksQ0FBQyxVQUFVLEdBQUcsSUFBSSxDQUFDLFVBQVUsSUFBSSxFQUFFLENBQUM7QUFDeEMsU0FBQyxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsVUFBVSxFQUFFLFVBQVUsQ0FBQyxDQUFDOztBQUV0QyxlQUFPLElBQUksQ0FBQztLQUNmOztBQUVELGFBQVMsT0FBTyxDQUFDLElBQUksRUFBRTtBQUNuQixZQUFJLEtBQUssR0FBRyxJQUFJLENBQUM7O0FBRWpCLFlBQUksQ0FBQyxJQUFJLEdBQUcsSUFBSSxDQUFDO0FBQ2pCLFlBQUksQ0FBQyxZQUFZLEdBQUcsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxJQUFJLEVBQUUsU0FBUyw0QkFBNEIsQ0FBQyxLQUFLLEVBQUUsR0FBRyxFQUFFO0FBQ2pGLGlCQUFLLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxXQUFXLENBQUMsUUFBUSxDQUFDLENBQUMsR0FBRyxLQUFLLENBQUM7QUFDL0MsbUJBQU8sS0FBSyxDQUFDO1NBQ2hCLEVBQUUsRUFBRSxDQUFDLENBQUM7O0FBRVAsZUFBTyxJQUFJLENBQUM7S0FDZjs7QUFFRCxhQUFTLGdCQUFnQixDQUFDLE1BQU0sRUFBRSxPQUFPLEVBQUU7QUFDdkMsWUFBSSxDQUFDLE1BQU0sR0FBRyxNQUFNLElBQUksSUFBSSxDQUFDLE1BQU0sQ0FBQztBQUNwQyxZQUFJLENBQUMsT0FBTyxHQUFHLE9BQU8sSUFBSSxJQUFJLENBQUMsT0FBTyxDQUFDOztBQUV2QyxlQUFPLElBQUksQ0FBQztLQUNmOztBQUVELGFBQVMsVUFBVSxDQUFDLElBQUksRUFBRSxLQUFLLEVBQUUsS0FBSyxFQUFFO0FBQ3BDLGVBQU8sSUFBSSxDQUNOLG1CQUFtQixDQUFDLElBQUksRUFBRSxLQUFLLEVBQUUsS0FBSyxDQUFDLENBQ3ZDLFdBQVcsRUFBRSxDQUFDO0tBQ3RCOztBQUVELGFBQVMsVUFBVSxDQUFDLE1BQU0sRUFBRSxPQUFPLEVBQUU7QUFDakMsZUFBTyxJQUFJLENBQ04sZ0JBQWdCLENBQUMsTUFBTSxFQUFFLE9BQU8sQ0FBQyxDQUNqQyxtQkFBbUIsQ0FBQztBQUNqQixnQkFBSSxFQUFFLENBQUM7U0FDVixDQUFDLENBQ0QsV0FBVyxFQUFFLENBQUM7S0FDdEI7O0FBRUQsYUFBUyxXQUFXLEdBQUc7QUFDbkIsWUFBSSxDQUFDLElBQUksQ0FBQyxjQUFjLEVBQUU7QUFDdEIsa0JBQU0sQ0FBQyxFQUFFLENBQUMsTUFBTSxDQUFDLE9BQU8sQ0FBQyxJQUFJLEVBQUUsSUFBSSxDQUFDLGtCQUFrQixFQUFFLENBQUMsQ0FBQztTQUM3RDs7QUFFRCxlQUFPLElBQUksQ0FBQztLQUNmOztBQUVELGFBQVMsZ0JBQWdCLENBQUMsUUFBUSxFQUFFO0FBQ2hDLFlBQUksQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLFFBQVEsQ0FBQyxFQUFFO0FBQ3ZCLGdCQUFJLENBQUMsS0FBSyxDQUFDLG9FQUFvRSxDQUFDLENBQUM7QUFDakYsbUJBQU8sS0FBSyxDQUFDO1NBQ2hCOztBQUVELFlBQUksQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsRUFBRTtBQUMzQixnQkFBSSxDQUFDLEtBQUssQ0FBQywyRkFBMkYsQ0FBQyxDQUFDO0FBQ3hHLG1CQUFPLEtBQUssQ0FBQztTQUNoQjs7QUFFRCxZQUFJLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxRQUFRLENBQUMsVUFBVSxDQUFDLEVBQUU7QUFDbEMsZ0JBQUksQ0FBQyxLQUFLLENBQUMsa0dBQWtHLENBQUMsQ0FBQztBQUMvRyxtQkFBTyxLQUFLLENBQUM7U0FDaEI7O0FBRUQsZUFBTyxJQUFJLENBQUM7S0FDZjs7QUFFRCxXQUFPLFdBQVcsQ0FBQztDQUN0QixDQUFDLENBQUM7OztBQzFPUCxPQUFPLENBQUMsTUFBTSxDQUFDLG1EQUFtRCxFQUFFLENBQ2hFLDJDQUEyQyxDQUM5QyxDQUFDLENBQ0csT0FBTyxDQUFDLHNCQUFzQixFQUFFLFNBQVMsb0JBQW9CLENBQUMsSUFBSSxFQUFFLGFBQWEsRUFBRTtBQUNoRixRQUFJLE1BQU0sR0FBRyxFQUFFO1FBQ1gsT0FBTyxHQUFHO0FBQ04sY0FBTSxFQUFFLE1BQU07QUFDZCxXQUFHLEVBQUUsR0FBRztBQUNSLGNBQU0sRUFBRSxNQUFNO0tBQ2pCLENBQUM7O0FBRU4sYUFBUyxNQUFNLENBQUMsT0FBTyxFQUFFLFdBQVcsRUFBRTtBQUNsQyxZQUFJLE9BQU8sSUFBSSxNQUFNLEVBQUU7QUFDbkIsbUJBQU8sT0FBTyxDQUFDLEdBQUcsQ0FBQyxPQUFPLENBQUMsQ0FBQztTQUMvQjs7QUFFRCxZQUFJLENBQUMsT0FBTyxFQUFFO0FBQ1YsbUJBQU8sR0FBRyxDQUFDLENBQUMsUUFBUSxDQUFDLDJCQUEyQixDQUFDLENBQUM7U0FDckQ7O0FBRUQsY0FBTSxDQUFDLE9BQU8sQ0FBQyxHQUFHLElBQUksYUFBYSxDQUFDLE9BQU8sRUFBRSxXQUFXLENBQUMsQ0FBQzs7QUFFMUQsZUFBTyxNQUFNLENBQUMsT0FBTyxDQUFDLENBQUM7S0FDMUI7O0FBRUQsYUFBUyxHQUFHLENBQUMsT0FBTyxFQUFFO0FBQ2xCLGVBQU8sTUFBTSxDQUFDLE9BQU8sQ0FBQyxDQUFDO0tBQzFCOztBQUVELGFBQVMsTUFBTSxDQUFDLE9BQU8sRUFBRTtBQUNyQixlQUFPLE1BQU0sQ0FBQyxPQUFPLENBQUMsQ0FBQztLQUMxQjs7QUFFRCxXQUFPLE9BQU8sQ0FBQztDQUNsQixDQUFDLENBQUM7Ozs7Ozs7O0FDN0JQLE9BQU8sQ0FBQyxNQUFNLENBQUMsbURBQW1ELEVBQUUsRUFBRSxDQUFDLENBQ2xFLFNBQVMsQ0FBQyxVQUFVLEVBQUUsU0FBUyxjQUFjLENBQUMsT0FBTyxFQUFFO0FBQ3BELFdBQU87QUFDSCxlQUFPLEVBQUUsaUJBQVUsS0FBSyxFQUFFLEtBQUssRUFBRTtBQUM3QixnQkFBTSxxQkFBcUIsR0FBRyxDQUFDLENBQUM7O0FBRWhDLGlCQUFLLENBQUMsSUFBSSxDQUFDLGNBQWMsRUFBRSxRQUFRLENBQUMsQ0FBQztBQUNyQyxpQkFBSyxDQUFDLElBQUksQ0FBQyxXQUFXLEVBQUUscUJBQXFCLENBQUMsQ0FBQztBQUMvQyxpQkFBSyxDQUFDLElBQUksQ0FBQyxTQUFTLEVBQUUsUUFBUSxDQUFDLENBQUM7O0FBRWhDLG1CQUFPLFNBQVMsWUFBWSxDQUFDLEtBQUssRUFBRSxLQUFLLEVBQUUsS0FBSyxFQUFFLFdBQVcsRUFBRTtBQUMzRCxvQkFBSSxFQUFFLENBQUM7O0FBRVAseUJBQVMsSUFBSSxHQUFHO0FBQ1osK0JBQVcsQ0FBQyxRQUFRLENBQUMsT0FBTyxDQUFDLE1BQU0sQ0FBQyxDQUFDO0FBQ3JDLCtCQUFXLENBQUMsV0FBVyxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsQ0FBQztBQUN4QywrQkFBVyxDQUFDLFdBQVcsQ0FBQyxlQUFlLEdBQUcsZUFBZSxDQUFDOztBQUUxRCx5QkFBSyxDQUFDLE1BQU0sQ0FBQyxZQUFZLEVBQUUsbUJBQW1CLENBQUMsQ0FBQztpQkFDbkQ7Ozs7O0FBS0QseUJBQVMsWUFBWSxHQUFHO0FBQ3BCLDJCQUFPLFdBQVcsQ0FBQyxVQUFVLENBQUM7aUJBQ2pDOzs7OztBQUtELHlCQUFTLG1CQUFtQixDQUFDLFNBQVMsRUFBRSxhQUFhLEVBQUU7QUFDbkQsd0JBQUksQ0FBQyxTQUFTLEVBQUU7QUFDWiwrQkFBTztxQkFDVjs7O0FBR0Qsd0JBQU0sVUFBVSxHQUFHLFNBQVMsQ0FBQyxNQUFNLEdBQUcsYUFBYSxDQUFDLE1BQU0sQ0FBQzs7QUFFM0QsK0JBQVcsQ0FBQyxhQUFhLENBQUMsTUFBTSxDQUFDLFNBQVMsRUFBRSxVQUFVLENBQUMsQ0FBQyxDQUFDO0FBQ3pELCtCQUFXLENBQUMsT0FBTyxFQUFFLENBQUM7aUJBQ3pCOzs7OztBQUtELHlCQUFTLGVBQWUsQ0FBQyxVQUFVLEVBQUU7d0JBQzFCLEtBQUssR0FBVSxVQUFVLENBQXpCLEtBQUs7d0JBQUUsSUFBSSxHQUFJLFVBQVUsQ0FBbEIsSUFBSTs7QUFFbEIsMkJBQU8sV0FBVyxDQUFDLEtBQUssRUFBRSxJQUFJLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxLQUFLLEVBQUUsSUFBSSxDQUFDLENBQUM7aUJBQzNEOzs7OztBQUtELHlCQUFTLFdBQVcsQ0FBQyxLQUFLLEVBQUUsSUFBSSxFQUFFO0FBQzlCLHdCQUFNLFVBQVUsR0FBRyxZQUFZLENBQUM7QUFDaEMsd0JBQU0sU0FBUyxHQUFHLFlBQVksQ0FBQzs7QUFFL0IsMkJBQU8sQ0FBQyxDQUFDLFFBQVEsQ0FBQyxLQUFLLENBQUMsSUFDakIsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsSUFDaEIsVUFBVSxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsSUFDdEIsU0FBUyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsSUFDcEIsWUFBWSxDQUFDLEtBQUssQ0FBQyxDQUFDO2lCQUM5Qjs7Ozs7QUFLRCx5QkFBUyxZQUFZLENBQUMsS0FBSyxFQUFFO0FBQ3pCLHlCQUFLLEdBQUcsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxLQUFLLENBQUMsQ0FBQzs7QUFFMUIsMkJBQU8sS0FBSyxHQUFHLENBQUMsSUFBSSxLQUFLLEdBQUcsRUFBRSxDQUFDO2lCQUNsQzs7Ozs7QUFLRCx5QkFBUyxNQUFNLENBQUMsS0FBSyxFQUFFLElBQUksRUFBRTtBQUN6QiwyQkFBTyxnQkFBZ0IsRUFBRSxHQUFHLElBQUksSUFBSSxDQUFDLElBQUksRUFBRSxLQUFLLEdBQUcsQ0FBQyxDQUFDLENBQUM7aUJBQ3pEOzs7OztBQUtELHlCQUFTLGdCQUFnQixHQUFHO0FBQ3hCLHdCQUFNLElBQUksR0FBRyxJQUFJLElBQUksRUFBRSxDQUFDOztBQUV4QiwyQkFBTyxJQUFJLElBQUksQ0FBQyxJQUFJLENBQUMsV0FBVyxFQUFFLEVBQUUsSUFBSSxDQUFDLFFBQVEsRUFBRSxDQUFDLENBQUM7aUJBQ3hEOzs7OztBQUtELHlCQUFTLFNBQVMsR0FBVzt3QkFBVixHQUFHLHlEQUFHLEVBQUU7O0FBQ3ZCLHdCQUFNLEtBQUssR0FBRyxHQUFHLENBQUMsS0FBSyxDQUFDO0FBQ3hCLHdCQUFNLElBQUksR0FBRyxHQUFHLENBQUMsSUFBSSxDQUFDOztBQUV0Qix3QkFBSSxDQUFDLENBQUMsT0FBTyxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLEVBQUU7QUFDckMsK0JBQU8sRUFBRSxDQUFDO3FCQUNiOztBQUVELDJCQUFPLE9BQU8sQ0FBQyxNQUFNLENBQUMsQ0FBQyxJQUFJLElBQUksQ0FBQyxJQUFJLEVBQUUsS0FBSyxHQUFHLENBQUMsQ0FBQyxFQUFFLFNBQVMsQ0FBQyxDQUFDO2lCQUNoRTs7Ozs7O0FBTUQseUJBQVMsTUFBTSxDQUFDLFVBQVUsRUFBRTtBQUN4Qix3QkFBTSxRQUFRLEdBQUcsSUFBSSxJQUFJLEVBQUUsQ0FBQyxXQUFXLEVBQUUsQ0FBQyxRQUFRLEVBQUUsQ0FBQyxLQUFLLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDO0FBQ2pFLHdCQUFNLE1BQU0sR0FBRyxVQUFVLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxDQUFDO0FBQ3JDLHdCQUFNLEtBQUssR0FBRyxNQUFNLENBQUMsQ0FBQyxDQUFDLEdBQUcsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksRUFBRSxHQUFHLEVBQUUsQ0FBQztBQUNoRCx3QkFBTSxJQUFJLEdBQUcsTUFBTSxDQUFDLENBQUMsQ0FBQyxHQUFHLFFBQVEsR0FBRyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxFQUFFLEdBQUcsRUFBRSxDQUFDOztBQUUxRCwyQkFBTyxFQUFFLEtBQUssRUFBTCxLQUFLLEVBQUUsSUFBSSxFQUFKLElBQUksRUFBRSxDQUFDO2lCQUMxQjs7Ozs7QUFLRCx5QkFBUyxNQUFNLENBQUMsTUFBTSxFQUFFLFVBQVUsRUFBRTtBQUNoQyx3QkFBTSxNQUFNLEdBQUcsTUFBTSxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsQ0FBQztBQUNqQyx3QkFBTSxLQUFLLEdBQUcsTUFBTSxDQUFDLENBQUMsQ0FBQyxHQUFHLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLEVBQUUsR0FBRyxFQUFFLENBQUM7QUFDaEQsd0JBQU0sSUFBSSxHQUFHLE1BQU0sQ0FBQyxDQUFDLENBQUMsR0FBRyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxFQUFFLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsRUFBRSxDQUFDOzs7QUFHekQsd0JBQUksQUFBQyxDQUFDLFVBQVUsSUFBSSxDQUFDLElBQUksSUFBSyxLQUFLLENBQUMsTUFBTSxHQUFHLENBQUMsRUFBRTtBQUM1QywrQkFBTyxLQUFLLENBQUM7cUJBQ2hCOzs7QUFHRCx3QkFBSSxVQUFVLElBQUksQ0FBQyxJQUFJLElBQUksS0FBSyxDQUFDLE1BQU0sR0FBRyxDQUFDLEVBQUU7QUFDekMsK0JBQVUsS0FBSyxDQUFDLEtBQUssQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLFdBQU0sS0FBSyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBRztxQkFDckQ7O0FBRUQsMkJBQVUsS0FBSyxXQUFNLElBQUksQ0FBRztpQkFDL0I7YUFDSixDQUFDO1NBQ0w7QUFDRCxlQUFPLEVBQUUsU0FBUztBQUNsQixnQkFBUSxFQUFFLEdBQUc7S0FDaEIsQ0FBQztDQUNMLENBQUMsQ0FBQzs7O0FDcEpQLE9BQU8sQ0FBQyxNQUFNLENBQUMseUNBQXlDLEVBQUUsQ0FDdEQsbURBQW1ELENBQ3RELENBQUMsQ0FBQzs7Ozs7Ozs7O0FDSUgsT0FBTyxDQUFDLE1BQU0sQ0FBQyxzQ0FBc0MsRUFBRSxDQUNuRCxjQUFjLENBQ2pCLENBQUMsQ0FDRyxTQUFTLENBQUMsT0FBTyxFQUFFLFNBQVMsY0FBYyxDQUFDLE1BQU0sRUFBRTtBQUNoRCxXQUFPO0FBQ0gsWUFBSSxFQUFFLFNBQVMsU0FBUyxDQUFDLEtBQUssRUFBRSxPQUFPLEVBQUUsVUFBVSxFQUFFLE9BQU8sRUFBRTs7O0FBRzFELGdCQUFJLENBQUMsTUFBTSxDQUFDLFVBQVUsQ0FBQyxVQUFVLENBQUMsQ0FBQyxLQUFLLENBQUMsRUFBRTtBQUN2Qyx1QkFBTyxDQUFDLFdBQVcsQ0FBQyxLQUFLLEdBQUc7MkJBQU0sSUFBSTtpQkFBQSxDQUFDO2FBQzFDO1NBQ0o7QUFDRCxnQkFBUSxFQUFFLENBQUM7QUFDWCxlQUFPLEVBQUUsU0FBUztBQUNsQixnQkFBUSxFQUFFLEdBQUc7S0FDaEIsQ0FBQztDQUNMLENBQUMsQ0FBQzs7Ozs7Ozs7Ozs7O0FDYlAsT0FBTyxDQUFDLE1BQU0sQ0FBQyxvQ0FBb0MsRUFBRSxFQUFFLENBQUMsQ0FDbkQsTUFBTSxDQUFDLGFBQWEsRUFBRSxTQUFTLFdBQVcsQ0FBQyxJQUFJLEVBQUM7QUFDN0MsV0FBTyxVQUFTLElBQUksRUFBRTtBQUNsQixlQUFPLElBQUksQ0FBQyxXQUFXLENBQUMsSUFBSSxDQUFDLENBQUM7S0FDakMsQ0FBQztDQUNMLENBQUMsQ0FBQyIsImZpbGUiOiJiY2FwcC1wYXR0ZXJuLWxhYi1jb21wb25lbnRzLmpzIiwic291cmNlc0NvbnRlbnQiOlsiYW5ndWxhci5tb2R1bGUoJ2JjYXBwLXBhdHRlcm4tbGFiJywgW1xuICAgICdnZXR0ZXh0JyxcbiAgICAnbmdBbmltYXRlJyxcbiAgICAnbmdNZXNzYWdlcycsXG4gICAgJ21tLmZvdW5kYXRpb24nLFxuICAgICdiY2FwcC1wYXR0ZXJuLWxhYi10ZW1wbGF0ZXMnLFxuICAgICdiY2FwcC1wYXR0ZXJuLWxhYi5iYy1kYXRlcGlja2VyJyxcbiAgICAnYmNhcHAtcGF0dGVybi1sYWIuYmMtZHJvcGRvd24nLFxuICAgICdiY2FwcC1wYXR0ZXJuLWxhYi5iYy1tb2RhbCcsXG4gICAgJ2JjYXBwLXBhdHRlcm4tbGFiLmJjLXBhZ2luYXRpb24nLFxuICAgICdiY2FwcC1wYXR0ZXJuLWxhYi5iYy1zZXJ2ZXItdGFibGUnLFxuICAgICdiY2FwcC1wYXR0ZXJuLWxhYi5jaGVja2JveC1saXN0JyxcbiAgICAnYmNhcHAtcGF0dGVybi1sYWIuY29sb3ItcGlja2VyJyxcbiAgICAnYmNhcHAtcGF0dGVybi1sYWIuY3JlZGl0LWNhcmQnLFxuICAgICdiY2FwcC1wYXR0ZXJuLWxhYi5jcmVkaXQtY2FyZC10eXBlcycsXG4gICAgJ2JjYXBwLXBhdHRlcm4tbGFiLmZvcm0nLFxuICAgICdiY2FwcC1wYXR0ZXJuLWxhYi5mb3JtLWZpZWxkJyxcbiAgICAnYmNhcHAtcGF0dGVybi1sYWIuZm9ybS1pbnB1dC1jb2xvcicsXG4gICAgJ2JjYXBwLXBhdHRlcm4tbGFiLmh0bWw1TW9kZScsXG4gICAgJ2JjYXBwLXBhdHRlcm4tbGFiLmljb24nLFxuICAgICdiY2FwcC1wYXR0ZXJuLWxhYi5sb2FkaW5nLW5vdGlmaWNhdGlvbicsXG4gICAgJ2JjYXBwLXBhdHRlcm4tbGFiLmxvYWRpbmctb3ZlcmxheScsXG4gICAgJ2JjYXBwLXBhdHRlcm4tbGFiLnNwcml0ZScsXG4gICAgJ2JjYXBwLXBhdHRlcm4tbGFiLnN3aXRjaCcsXG4gICAgJ2JjYXBwLXBhdHRlcm4tbGFiLnV0aWwnXG5dKTtcbiIsIi8qIGdsb2JhbHMgbW9tZW50ICovXG5hbmd1bGFyLm1vZHVsZSgnYmNhcHAtcGF0dGVybi1sYWIuYmMtZGF0ZXBpY2tlci5jb25zdGFudHMnLCBbXSlcbiAgICAuY29uc3RhbnQoJ0JDX0RBVEVQSUNLRVJfREVGQVVMVFMnLCB7XG4gICAgICAgIGRheUZvcm1hdDogJ0QnLFxuICAgICAgICBpbnB1dEZvcm1hdDogbW9tZW50LmxvY2FsZURhdGEoKS5sb25nRGF0ZUZvcm1hdCgnTCcpLFxuICAgICAgICBzdHlsZXM6IHtcbiAgICAgICAgICAgIGJhY2s6ICdkYXRlcGlja2VyLWJhY2snLFxuICAgICAgICAgICAgY29udGFpbmVyOiAnZGF0ZXBpY2tlcicsXG4gICAgICAgICAgICBkYXRlOiAnZGF0ZXBpY2tlci1kYXRlJyxcbiAgICAgICAgICAgIGRheUJvZHk6ICdkYXRlcGlja2VyLWRheXMtYm9keScsXG4gICAgICAgICAgICBkYXlCb2R5RWxlbTogJ2RhdGVwaWNrZXItZGF5JyxcbiAgICAgICAgICAgIGRheUNvbmNlYWxlZDogJ2RhdGVwaWNrZXItZGF5LWNvbmNlYWxlZCcsXG4gICAgICAgICAgICBkYXlEaXNhYmxlZDogJ2lzLWRpc2FibGVkJyxcbiAgICAgICAgICAgIGRheUhlYWQ6ICdkYXRlcGlja2VyLWRheXMtaGVhZCcsXG4gICAgICAgICAgICBkYXlIZWFkRWxlbTogJ2RhdGVwaWNrZXItZGF5LW5hbWUnLFxuICAgICAgICAgICAgZGF5UHJldk1vbnRoOiAnZGF0ZXBpY2tlci1kYXktcHJldi1tb250aCcsXG4gICAgICAgICAgICBkYXlOZXh0TW9udGg6ICdkYXRlcGlja2VyLWRheS1uZXh0LW1vbnRoJyxcbiAgICAgICAgICAgIGRheVJvdzogJ2RhdGVwaWNrZXItZGF5cy1yb3cnLFxuICAgICAgICAgICAgZGF5VGFibGU6ICdkYXRlcGlja2VyLWRheXMnLFxuICAgICAgICAgICAgbW9udGg6ICdkYXRlcGlja2VyLW1vbnRoJyxcbiAgICAgICAgICAgIG1vbnRoTGFiZWw6ICdkYXRlcGlja2VyLW1vbnRoJyxcbiAgICAgICAgICAgIG5leHQ6ICdkYXRlcGlja2VyLW5leHQnLFxuICAgICAgICAgICAgcG9zaXRpb25lZDogJ2RhdGVwaWNrZXItYXR0YWNobWVudCcsXG4gICAgICAgICAgICBzZWxlY3RlZERheTogJ2lzLXNlbGVjdGVkJyxcbiAgICAgICAgICAgIHNlbGVjdGVkVGltZTogJ2RhdGVwaWNrZXItdGltZS1zZWxlY3RlZCcsXG4gICAgICAgICAgICB0aW1lOiAnZGF0ZXBpY2tlci10aW1lJyxcbiAgICAgICAgICAgIHRpbWVMaXN0OiAnZGF0ZXBpY2tlci10aW1lLWxpc3QnLFxuICAgICAgICAgICAgdGltZU9wdGlvbjogJ2RhdGVwaWNrZXItdGltZS1vcHRpb24nXG4gICAgICAgIH0sXG4gICAgICAgIHRpbWU6IGZhbHNlLFxuICAgICAgICB3ZWVrZGF5Rm9ybWF0OiAnc2hvcnQnXG4gICAgfSk7XG4iLCIvKiBnbG9iYWxzIHJvbWUgKi9cbmFuZ3VsYXIubW9kdWxlKCdiY2FwcC1wYXR0ZXJuLWxhYi5iYy1kYXRlcGlja2VyLmRpcmVjdGl2ZScsIFtcbiAgICAnYmNhcHAtcGF0dGVybi1sYWIuYmMtZGF0ZXBpY2tlci5jb25zdGFudHMnXG5dKVxuICAgIC5kaXJlY3RpdmUoJ2JjRGF0ZXBpY2tlcicsIGZ1bmN0aW9uIGJjRGF0ZXBpY2tlckRpcmVjdGl2ZShCQ19EQVRFUElDS0VSX0RFRkFVTFRTKSB7XG4gICAgICAgIHJldHVybiB7XG4gICAgICAgICAgICByZXN0cmljdDogJ0EnLFxuICAgICAgICAgICAgcmVxdWlyZTogJ25nTW9kZWwnLFxuICAgICAgICAgICAgc2NvcGU6IHtcbiAgICAgICAgICAgICAgICBvcHRpb25zOiAnPT8nXG4gICAgICAgICAgICB9LFxuXG4gICAgICAgICAgICBsaW5rOiBmdW5jdGlvbiBkYXRlcGlja2VyTGlua0Z1bmN0aW9uKHNjb3BlLCBlbGVtZW50LCBhdHRycywgbmdNb2RlbCkge1xuICAgICAgICAgICAgICAgIGlmIChzY29wZS5vcHRpb25zID09PSB1bmRlZmluZWQpIHtcbiAgICAgICAgICAgICAgICAgICAgc2NvcGUub3B0aW9ucyA9IHt9O1xuICAgICAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgICAgIC8vIEFkZCBkZWZhdWx0cyB0byB0aGUgb3B0aW9ucyBvYmplY3RcbiAgICAgICAgICAgICAgICBfLmRlZmF1bHRzKHNjb3BlLm9wdGlvbnMsIEJDX0RBVEVQSUNLRVJfREVGQVVMVFMpO1xuXG4gICAgICAgICAgICAgICAgLy8gQ3JlYXRlIGEgbmV3IHJvbWUgKGNhbGVuZGFyKSBpbnN0YW5jZVxuICAgICAgICAgICAgICAgIHNjb3BlLmNhbGVuZGFyID0gcm9tZShlbGVtZW50WzBdLCBzY29wZS5vcHRpb25zKTtcblxuICAgICAgICAgICAgICAgIC8vIE9uICdkYXRhJyBldmVudCBzZXQgbmdNb2RlbCB0byB0aGUgcGFzc2VkIHZhbHVlXG4gICAgICAgICAgICAgICAgc2NvcGUuY2FsZW5kYXIub24oJ2RhdGEnLCBmdW5jdGlvbiBvbkRhdGEodmFsdWUpIHtcbiAgICAgICAgICAgICAgICAgICAgbmdNb2RlbC4kc2V0Vmlld1ZhbHVlKHZhbHVlKTtcbiAgICAgICAgICAgICAgICAgICAgc2NvcGUuJGFwcGx5KCk7XG4gICAgICAgICAgICAgICAgfSk7XG5cbiAgICAgICAgICAgICAgICBzY29wZS5jYWxlbmRhci5vbigncmVhZHknLCBmdW5jdGlvbiBvblJlYWR5KG9wdGlvbnMpIHtcbiAgICAgICAgICAgICAgICAgICAgaWYgKGF0dHJzLnBsYWNlaG9sZGVyID09PSB1bmRlZmluZWQpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGF0dHJzLiRzZXQoJ3BsYWNlaG9sZGVyJywgb3B0aW9ucy5pbnB1dEZvcm1hdCk7XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICB9KTtcblxuICAgICAgICAgICAgICAgIC8vIFJlbW92aW5nIGNhbGVuZGFyIGV2ZW50IGxpc3RlbmVyc1xuICAgICAgICAgICAgICAgIGVsZW1lbnQub24oJyRkZXN0cm95JywgZnVuY3Rpb24gb25EZXN0cm95KCkge1xuICAgICAgICAgICAgICAgICAgICBzY29wZS5jYWxlbmRhci5kZXN0cm95KCk7XG4gICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICB9XG4gICAgICAgIH07XG4gICAgfSk7XG4iLCJhbmd1bGFyLm1vZHVsZSgnYmNhcHAtcGF0dGVybi1sYWIuYmMtZGF0ZXBpY2tlcicsIFtcbiAgICAnYmNhcHAtcGF0dGVybi1sYWIuYmMtZGF0ZXBpY2tlci5kaXJlY3RpdmUnXG5dKTtcbiIsImFuZ3VsYXIubW9kdWxlKCdiY2FwcC1wYXR0ZXJuLWxhYi5iYy1kcm9wZG93bi1tZW51LmRpcmVjdGl2ZScsIFtdKVxuICAgIC5kaXJlY3RpdmUoJ2JjRHJvcGRvd25NZW51JywgKCkgPT4ge1xuICAgICAgICByZXR1cm4ge1xuICAgICAgICAgICAgcmVzdHJpY3Q6ICdBJyxcbiAgICAgICAgICAgIHJlcXVpcmU6ICdeYmNEcm9wZG93bicsXG4gICAgICAgICAgICBjb21waWxlOiAodEVsZW1lbnQpID0+IHtcbiAgICAgICAgICAgICAgICB0RWxlbWVudC5hZGRDbGFzcygnZHJvcGRvd24tbWVudScpO1xuICAgICAgICAgICAgICAgIHRFbGVtZW50LmF0dHIoJ3JvbGUnLCAnbGlzdGJveCcpO1xuXG4gICAgICAgICAgICAgICAgcmV0dXJuIChzY29wZSwgZWxlbWVudCwgYXR0cnMsIGJjRHJvcGRvd25DdHJsKSA9PiB7XG4gICAgICAgICAgICAgICAgICAgIGVsZW1lbnQuYXR0cignaWQnLCBiY0Ryb3Bkb3duQ3RybC5nZXRVbmlxdWVJZCgpKTtcbiAgICAgICAgICAgICAgICAgICAgZWxlbWVudC5hdHRyKCdhcmlhLWV4cGFuZGVkJywgYmNEcm9wZG93bkN0cmwuZ2V0SXNPcGVuKCkpO1xuICAgICAgICAgICAgICAgICAgICAvLyBsaXN0ZW4gZm9yIGRyb3Bkb3ducyBiZWluZyBvcGVuZWQgYW5kIHRvZ2dsZSBhcmlhLWV4cGFuZGVkIHRvIHJlZmxlY3QgY3VycmVudCBzdGF0ZVxuICAgICAgICAgICAgICAgICAgICBzY29wZS4kb24oJ3RvZ2dsZVRoaXNEcm9wZG93bicsICgpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGVsZW1lbnQuYXR0cignYXJpYS1leHBhbmRlZCcsIGJjRHJvcGRvd25DdHJsLmdldElzT3BlbigpKTtcbiAgICAgICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgfTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfTtcbiAgICB9KTtcbiIsImFuZ3VsYXIubW9kdWxlKCdiY2FwcC1wYXR0ZXJuLWxhYi5iYy1kcm9wZG93bi10b2dnbGUuZGlyZWN0aXZlJywgW10pXG4gICAgLmRpcmVjdGl2ZSgnYmNEcm9wZG93blRvZ2dsZScsICgkY29tcGlsZSkgPT4ge1xuICAgICAgICByZXR1cm4ge1xuICAgICAgICAgICAgcmVzdHJpY3Q6ICdBJyxcbiAgICAgICAgICAgIHRlcm1pbmFsOiB0cnVlLFxuICAgICAgICAgICAgcHJpb3JpdHk6IDEwMDEsIC8vIHNldCBoaWdoZXIgdGhhbiBuZy1yZXBlYXQgdG8gcHJldmVudCBkb3VibGUgY29tcGlsYXRpb25cbiAgICAgICAgICAgIHJlcXVpcmU6ICdeYmNEcm9wZG93bicsXG4gICAgICAgICAgICBjb21waWxlOiAodEVsZW1lbnQpID0+IHtcbiAgICAgICAgICAgICAgICB0RWxlbWVudC5yZW1vdmVBdHRyKCdiYy1kcm9wZG93bi10b2dnbGUnKTtcblxuICAgICAgICAgICAgICAgIHJldHVybiAoc2NvcGUsIGVsZW1lbnQsIGF0dHJzLCBiY0Ryb3Bkb3duQ3RybCkgPT4ge1xuICAgICAgICAgICAgICAgICAgICBlbGVtZW50LmF0dHIoJ2Ryb3Bkb3duLXRvZ2dsZScsICcjJyArIGJjRHJvcGRvd25DdHJsLmdldFVuaXF1ZUlkKCkpO1xuICAgICAgICAgICAgICAgICAgICBlbGVtZW50LmF0dHIoJ2FyaWEtY29udHJvbHMnLCBiY0Ryb3Bkb3duQ3RybC5nZXRVbmlxdWVJZCgpKTtcbiAgICAgICAgICAgICAgICAgICAgZWxlbWVudC5vbignY2xpY2snLCBiY0Ryb3Bkb3duQ3RybC50b2dnbGVJc09wZW4pO1xuICAgICAgICAgICAgICAgICAgICAkY29tcGlsZShlbGVtZW50KShzY29wZSk7XG4gICAgICAgICAgICAgICAgfTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfTtcbiAgICB9KTtcbiIsImFuZ3VsYXIubW9kdWxlKCdiY2FwcC1wYXR0ZXJuLWxhYi5iYy1kcm9wZG93bi5jb250cm9sbGVyJywgW10pXG4gICAgLmNvbnRyb2xsZXIoJ0JjRHJvcGRvd25Db250cm9sbGVyJywgZnVuY3Rpb24gYmNEcm9wZG93bkNvbnRyb2xsZXIoJHNjb3BlLCAkcm9vdFNjb3BlKSB7XG4gICAgICAgIGNvbnN0IGN0cmwgPSB0aGlzO1xuICAgICAgICBsZXQgaXNPcGVuID0gZmFsc2U7XG4gICAgICAgIGxldCB1bmlxdWVJZDtcblxuICAgICAgICBjdHJsLmNsb3NlRHJvcGRvd24gPSBjbG9zZURyb3Bkb3duO1xuICAgICAgICBjdHJsLmdldElzT3BlbiA9IGdldElzT3BlbjtcbiAgICAgICAgY3RybC5nZXRVbmlxdWVJZCA9IGdldFVuaXF1ZUlkO1xuICAgICAgICBjdHJsLnNldElzT3BlbiA9IHNldElzT3BlbjtcbiAgICAgICAgY3RybC50b2dnbGVJc09wZW4gPSB0b2dnbGVJc09wZW47XG5cbiAgICAgICAgLy8gbGlzdGVuIGZvciBvdGhlciBkcm9wZG93bnMgYmVpbmcgb3BlbmVkIGluIHRoZSBhcHAuXG4gICAgICAgICRzY29wZS4kb24oJ2JjRHJvcGRvd25Ub2dnbGUnLCAoZXZlbnQsIHRyaWdnZXJpbmdJRCkgPT4ge1xuICAgICAgICAgICAgLy8gaWYgSSdtIG9wZW4gYW5kIG5vdCB0aGUgZHJvcGRvd24gYmVpbmcgdHJpZ2dlcmVkLCB0aGVuIEkgc2hvdWxkIGNsb3NlXG4gICAgICAgICAgICBpZiAoaXNPcGVuICYmIHRyaWdnZXJpbmdJRCAhPT0gdW5pcXVlSWQpIHtcbiAgICAgICAgICAgICAgICBjdHJsLmNsb3NlRHJvcGRvd24oKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfSk7XG5cbiAgICAgICAgZnVuY3Rpb24gY2xvc2VEcm9wZG93bigpIHtcbiAgICAgICAgICAgIGN0cmwuc2V0SXNPcGVuKGZhbHNlKTtcbiAgICAgICAgICAgICRzY29wZS4kYnJvYWRjYXN0KCd0b2dnbGVUaGlzRHJvcGRvd24nKTtcbiAgICAgICAgfVxuXG4gICAgICAgIGZ1bmN0aW9uIGdldElzT3BlbigpIHtcbiAgICAgICAgICAgIHJldHVybiBpc09wZW47XG4gICAgICAgIH1cblxuICAgICAgICBmdW5jdGlvbiBnZXRVbmlxdWVJZCgpIHtcbiAgICAgICAgICAgIGlmICghdW5pcXVlSWQpIHtcbiAgICAgICAgICAgICAgICB1bmlxdWVJZCA9IF8udW5pcXVlSWQoJ2JjLWRyb3Bkb3duLScpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgcmV0dXJuIHVuaXF1ZUlkO1xuICAgICAgICB9XG5cbiAgICAgICAgZnVuY3Rpb24gc2V0SXNPcGVuKHZhbCkge1xuICAgICAgICAgICAgaXNPcGVuID0gdmFsO1xuICAgICAgICB9XG5cbiAgICAgICAgZnVuY3Rpb24gdG9nZ2xlSXNPcGVuKCkge1xuICAgICAgICAgICAgaXNPcGVuID0gIWlzT3BlbjtcbiAgICAgICAgICAgIC8vIHRlbGwgY2hpbGQgZGlyZWN0aXZlcyBhIHRvZ2dsZSBpbiBvcGVuIHN0YXR1cyBoYXMgb2NjdXJyZWRcbiAgICAgICAgICAgICRzY29wZS4kYnJvYWRjYXN0KCd0b2dnbGVUaGlzRHJvcGRvd24nKTtcbiAgICAgICAgICAgIC8vIHRlbGwgYXBwbGljYXRpb24gdGhhdCBhIGRyb3Bkb3duIGhhcyBiZWVuIG9wZW5lZCBzbyBvdGhlcnMgY2FuIGNsb3NlXG4gICAgICAgICAgICAkcm9vdFNjb3BlLiRicm9hZGNhc3QoJ2JjRHJvcGRvd25Ub2dnbGUnLCB1bmlxdWVJZCk7XG4gICAgICAgIH1cbiAgICB9KTtcbiIsImFuZ3VsYXIubW9kdWxlKCdiY2FwcC1wYXR0ZXJuLWxhYi5iYy1kcm9wZG93bi5kaXJlY3RpdmUnLCBbXG4gICAgJ2JjYXBwLXBhdHRlcm4tbGFiLmJjLWRyb3Bkb3duLmNvbnRyb2xsZXInXG5dKVxuICAgIC5kaXJlY3RpdmUoJ2JjRHJvcGRvd24nLCAoJGRvY3VtZW50KSA9PiB7XG4gICAgICAgIHJldHVybiB7XG4gICAgICAgICAgICBiaW5kVG9Db250cm9sbGVyOiB0cnVlLFxuICAgICAgICAgICAgY29udHJvbGxlcjogJ0JjRHJvcGRvd25Db250cm9sbGVyJyxcbiAgICAgICAgICAgIGNvbnRyb2xsZXJBczogJ2JjRHJvcGRvd25Db250cm9sbGVyJyxcbiAgICAgICAgICAgIHJlc3RyaWN0OiAnRUEnLFxuICAgICAgICAgICAgY29tcGlsZTogKHRFbGVtZW50KSA9PiB7XG4gICAgICAgICAgICAgICAgdEVsZW1lbnQuYXR0cigncm9sZScsICdjb21ib2JveCcpO1xuXG4gICAgICAgICAgICAgICAgcmV0dXJuICgkc2NvcGUsICRlbGVtZW50LCBhdHRycywgY3RybCkgPT4ge1xuICAgICAgICAgICAgICAgICAgICAvLyBUaGlzIGRpcmVjdGl2ZSBpcyBhIGNvbXBvc2l0ZSBvZiAyIHNlcGFyYXRlIEZvdW5kYXRpb24gZGlyZWN0aXZlc1xuICAgICAgICAgICAgICAgICAgICAvLyB3aGljaCBkb24ndCBwcm92aWRlIGhvb2tzIHRvIGtub3cgd2hlbiBpdCdzIGNsaWNrZWQgb3Igb3BlbmVkXG4gICAgICAgICAgICAgICAgICAgIC8vIHRoZXkgZG8gaG93ZXZlciBkZWFsIHdpdGggcHJvcGFnYXRpb24gb2YgZXZlbnRzIHNvIHRoaXMsIHNvbWV3aGF0IGJsaW5kXG4gICAgICAgICAgICAgICAgICAgIC8vIGRvY3VtZW50IGV2ZW50IGlzIHNhZmUuIEFsbCBpdCBkb2VzIGlzIHN3YXAgYXJpYSBzdGF0ZXMgYXQgdGhlIG1vbWVudFxuICAgICAgICAgICAgICAgICAgICAvLyBpbiBhIGNoZWFwIHdheSB0byBrZWVwIHRoaXMgZGlyZWN0aXZlIGluIHN5bmMgd2l0aCBpdCdzIGNoaWxkIGRpcmVjdGl2ZVxuICAgICAgICAgICAgICAgICAgICAkZG9jdW1lbnQub24oJ2NsaWNrJywgY3RybC5jbG9zZURyb3Bkb3duKTtcblxuICAgICAgICAgICAgICAgICAgICAkZWxlbWVudC5vbignJGRlc3Ryb3knLCAoKSA9PiB7XG4gICAgICAgICAgICAgICAgICAgICAgICAkZG9jdW1lbnQub2ZmKCdjbGljaycsIGN0cmwuY2xvc2VEcm9wZG93bik7XG4gICAgICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICAgIH07XG4gICAgICAgICAgICB9XG4gICAgICAgIH07XG4gICAgfSk7XG4iLCJhbmd1bGFyLm1vZHVsZSgnYmNhcHAtcGF0dGVybi1sYWIuYmMtZHJvcGRvd24nLCBbXG4gICAgJ2JjYXBwLXBhdHRlcm4tbGFiLmJjLWRyb3Bkb3duLmRpcmVjdGl2ZScsXG4gICAgJ2JjYXBwLXBhdHRlcm4tbGFiLmJjLWRyb3Bkb3duLXRvZ2dsZS5kaXJlY3RpdmUnLFxuICAgICdiY2FwcC1wYXR0ZXJuLWxhYi5iYy1kcm9wZG93bi1tZW51LmRpcmVjdGl2ZSdcbl0pO1xuIiwiYW5ndWxhci5tb2R1bGUoJ2JjYXBwLXBhdHRlcm4tbGFiLmJjLXBhZ2luYXRpb24uZGlyZWN0aXZlJywgW10pXG4gICAgLmRpcmVjdGl2ZSgnYmNQYWdpbmF0aW9uJywgZnVuY3Rpb24gYmNQYWdpbmF0aW9uRGlyZWN0aXZlKCRwYXJzZSkge1xuICAgICAgICByZXR1cm4ge1xuICAgICAgICAgICAgcmVzdHJpY3Q6ICdFJyxcbiAgICAgICAgICAgIHNjb3BlOiB0cnVlLFxuICAgICAgICAgICAgdGVtcGxhdGVVcmw6ICdzcmMvanMvYmlnY29tbWVyY2UvYmMtcGFnaW5hdGlvbi9iYy1wYWdpbmF0aW9uLnRwbC5odG1sJyxcblxuICAgICAgICAgICAgY29tcGlsZTogZnVuY3Rpb24gYmNQYWdpbmF0aW9uQ29tcGlsZSh0RWxlbWVudCwgdEF0dHJzKSB7XG4gICAgICAgICAgICAgICAgdmFyIGF0dHJPYmogPSB7fTtcblxuICAgICAgICAgICAgICAgIC8vIFNpbmNlIHRoaXMgaXMgYSB3cmFwcGVyIG9mIGFuZ3VsYXItZm91bmRhdGlvbidzIHBhZ2luYXRpb24gZGlyZWN0aXZlIHdlIG5lZWQgdG8gY29weSBhbGxcbiAgICAgICAgICAgICAgICAvLyBvZiB0aGUgYXR0cmlidXRlcyBwYXNzZWQgdG8gb3VyIGRpcmVjdGl2ZSBhbmQgc3RvcmUgdGhlbSBpbiB0aGUgYXR0ck9iai5cbiAgICAgICAgICAgICAgICBfLmVhY2godEF0dHJzLiRhdHRyLCBmdW5jdGlvbihrZXkpIHtcbiAgICAgICAgICAgICAgICAgICAgaWYgKGtleSAhPT0gJ2NsYXNzJykge1xuICAgICAgICAgICAgICAgICAgICAgICAgYXR0ck9ialtrZXldID0gdEVsZW1lbnQuYXR0cihrZXkpO1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgfSk7XG5cbiAgICAgICAgICAgICAgICAvLyBBZGRpbmcgb3VyIGN1c3RvbSBjYWxsYmFjayB0byB0aGUgYXR0ck9iaiwgYW5ndWxhci1mb3VuZGF0aW9uIHdpbGwgY2FsbCB0aGlzIGZ1bmN0aW9uXG4gICAgICAgICAgICAgICAgLy8gd2hlbiBhIHBhZ2UgbnVtYmVyIGlzIGNsaWNrZWQgaW4gdGhlIHBhZ2luYXRpb24uXG4gICAgICAgICAgICAgICAgYXR0ck9ialsnb24tc2VsZWN0LXBhZ2UnXSA9ICdwYWdpbmF0aW9uQ2FsbGJhY2socGFnZSknO1xuXG4gICAgICAgICAgICAgICAgLy8gQWRkIGFsbCB0aGUgYXR0cmlidXRlcyB0byBhbmd1bGFyLWZvdW5kYXRpb24ncyBwYWdpbmF0aW9uIGRpcmVjdGl2ZVxuICAgICAgICAgICAgICAgIHRFbGVtZW50LmZpbmQoJ3BhZ2luYXRpb24nKS5hdHRyKGF0dHJPYmopO1xuXG4gICAgICAgICAgICAgICAgcmV0dXJuIGZ1bmN0aW9uIGJjUGFnaW5hdGlvbkxpbmsoJHNjb3BlLCBlbGVtZW50LCBhdHRycykge1xuICAgICAgICAgICAgICAgICAgICB2YXIgb25DaGFuZ2VQYXJzZUdldHRlciA9ICRwYXJzZShhdHRycy5vbkNoYW5nZSksXG4gICAgICAgICAgICAgICAgICAgICAgICBkZWZhdWx0TGltaXRzID0gWzEwLCAyMCwgMzAsIDUwLCAxMDBdO1xuXG4gICAgICAgICAgICAgICAgICAgICRzY29wZS5zZXRMaW1pdCA9IGZ1bmN0aW9uKGxpbWl0LCBldmVudCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgZXZlbnQucHJldmVudERlZmF1bHQoKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIGxpbWl0ID0gXy5wYXJzZUludChsaW1pdCk7XG4gICAgICAgICAgICAgICAgICAgICAgICAkcGFyc2UoYXR0cnMuaXRlbXNQZXJQYWdlKS5hc3NpZ24oJHNjb3BlLiRwYXJlbnQsIGxpbWl0KTtcbiAgICAgICAgICAgICAgICAgICAgICAgICRzY29wZS5wYWdpbmF0aW9uQ2FsbGJhY2soMSwgbGltaXQpO1xuICAgICAgICAgICAgICAgICAgICB9O1xuXG4gICAgICAgICAgICAgICAgICAgICRzY29wZS5nZXRDdXJyZW50UGFnZSA9IGZ1bmN0aW9uKCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuICRwYXJzZShhdHRycy5wYWdlKSgkc2NvcGUuJHBhcmVudCk7XG4gICAgICAgICAgICAgICAgICAgIH07XG5cbiAgICAgICAgICAgICAgICAgICAgJHNjb3BlLmdldEN1cnJlbnRMaW1pdCA9IGZ1bmN0aW9uKCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuICRwYXJzZShhdHRycy5pdGVtc1BlclBhZ2UpKCRzY29wZS4kcGFyZW50KTtcbiAgICAgICAgICAgICAgICAgICAgfTtcblxuICAgICAgICAgICAgICAgICAgICAkc2NvcGUuZ2V0SXRlbXNQZXJQYWdlID0gZnVuY3Rpb24oKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gJHBhcnNlKGF0dHJzLml0ZW1zUGVyUGFnZSkoJHNjb3BlLiRwYXJlbnQpIHx8IDA7XG4gICAgICAgICAgICAgICAgICAgIH07XG5cbiAgICAgICAgICAgICAgICAgICAgJHNjb3BlLmdldFRvdGFsSXRlbXMgPSBmdW5jdGlvbigpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiAkcGFyc2UoYXR0cnMudG90YWxJdGVtcykoJHNjb3BlLiRwYXJlbnQpIHx8IDA7XG4gICAgICAgICAgICAgICAgICAgIH07XG5cbiAgICAgICAgICAgICAgICAgICAgJHNjb3BlLnNob3cgPSBmdW5jdGlvbigpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiAkc2NvcGUuZ2V0VG90YWxJdGVtcygpID4gJHNjb3BlLmdldEl0ZW1zUGVyUGFnZSgpO1xuICAgICAgICAgICAgICAgICAgICB9O1xuXG4gICAgICAgICAgICAgICAgICAgICRzY29wZS5zaG93TGltaXRzID0gZnVuY3Rpb24oKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gJHNjb3BlLnNob3coKSAmJiAkcGFyc2UoYXR0cnMuc2hvd0xpbWl0cykoJHNjb3BlLiRwYXJlbnQpICE9PSBmYWxzZTtcbiAgICAgICAgICAgICAgICAgICAgfTtcblxuICAgICAgICAgICAgICAgICAgICAkc2NvcGUuZ2V0TGltaXRzID0gZnVuY3Rpb24oKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICB2YXIgbGltaXRzID0gJHBhcnNlKGF0dHJzLmxpbWl0cykoJHNjb3BlLiRwYXJlbnQpO1xuXG4gICAgICAgICAgICAgICAgICAgICAgICBpZiAoIUFycmF5LmlzQXJyYXkobGltaXRzKSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiBkZWZhdWx0TGltaXRzO1xuICAgICAgICAgICAgICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gbGltaXRzO1xuICAgICAgICAgICAgICAgICAgICB9O1xuXG4gICAgICAgICAgICAgICAgICAgICRzY29wZS5wYWdpbmF0aW9uQ2FsbGJhY2sgPSBmdW5jdGlvbihwYWdlLCBsaW1pdCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgdmFyIGFkZGl0aW9uYWxTY29wZVByb3BlcnRpZXMgPSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGxpbWl0OiBsaW1pdCB8fCAkc2NvcGUuZ2V0Q3VycmVudExpbWl0KCksXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHBhZ2U6IHBhZ2VcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlUGFyc2VSZXN1bHQ7XG5cbiAgICAgICAgICAgICAgICAgICAgICAgICRwYXJzZShhdHRycy5wYWdlKS5hc3NpZ24oJHNjb3BlLiRwYXJlbnQsIHBhZ2UpO1xuXG4gICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZVBhcnNlUmVzdWx0ID0gb25DaGFuZ2VQYXJzZUdldHRlcigkc2NvcGUsIGFkZGl0aW9uYWxTY29wZVByb3BlcnRpZXMpO1xuXG4gICAgICAgICAgICAgICAgICAgICAgICAvLyBpZiB0aGUgb25DaGFuZ2Ugc3RyaW5nIGlzIGEgZnVuY3Rpb24gYW5kIG5vdCBhbiBleHByZXNzaW9uOiBjYWxsIGl0IHdpdGggdGhlIGFkZGl0aW9uYWxTY29wZVByb3BlcnRpZXMgb2JqIChmb3IgYmFja3dhcmRzIGNvbXBhdGFiaWxpdHkpXG4gICAgICAgICAgICAgICAgICAgICAgICAvLyBlbHNlIHRoZSBleHByZXNzaW9uIGhhcyBhbHJlYWR5IGJlZW4gcmFuOiBkbyBub3RoaW5nXG4gICAgICAgICAgICAgICAgICAgICAgICBpZiAodHlwZW9mIG9uQ2hhbmdlUGFyc2VSZXN1bHQgPT09ICdmdW5jdGlvbicpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZVBhcnNlUmVzdWx0KGFkZGl0aW9uYWxTY29wZVByb3BlcnRpZXMpO1xuICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICB9O1xuICAgICAgICAgICAgICAgIH07XG4gICAgICAgICAgICB9XG4gICAgICAgIH07XG4gICAgfSk7XG4iLCJhbmd1bGFyLm1vZHVsZSgnYmNhcHAtcGF0dGVybi1sYWIuYmMtcGFnaW5hdGlvbicsIFtcbiAgICAnYmNhcHAtcGF0dGVybi1sYWIuYmMtcGFnaW5hdGlvbi5kaXJlY3RpdmUnXG5dKTtcbiIsImFuZ3VsYXIubW9kdWxlKCdiY2FwcC1wYXR0ZXJuLWxhYi5iYy1zZXJ2ZXItdGFibGUuY29udHJvbGxlcicsIFtcbiAgICAnYmNhcHAtcGF0dGVybi1sYWIuYmMtc2VydmVyLXRhYmxlLnNlcnZpY2UnXG5dKVxuXG4gICAgLmNvbnRyb2xsZXIoJ0JjU2VydmVyVGFibGVDdHJsJywgZnVuY3Rpb24gQmNTZXJ2ZXJUYWJsZUN0cmwoJGF0dHJzLCAkbG9nLCAkcGFyc2UsICRzY29wZSwgQmNTZXJ2ZXJUYWJsZSkge1xuICAgICAgICB2YXIgY3RybCA9IHRoaXMsXG4gICAgICAgICAgICBiY1NlcnZlclRhYmxlUHJvdG90eXBlID0gQmNTZXJ2ZXJUYWJsZS5wcm90b3R5cGU7XG5cbiAgICAgICAgLy8gQ2FsbCB0aGUgQmNTZXJ2ZXJUYWJsZSBjb25zdHJ1Y3RvciBvbiB0aGUgY29udHJvbGxlclxuICAgICAgICAvLyBpbiBvcmRlciB0byBzZXQgYWxsIHRoZSBjb250cm9sbGVyIHByb3BlcnRpZXMgZGlyZWN0bHkuXG4gICAgICAgIC8vIFRoaXMgaXMgaGVyZSBmb3IgYmFja3dhcmRzIGNvbXBhdGFiaWxpdHkgcHVycG9zZXMuXG4gICAgICAgIEJjU2VydmVyVGFibGUuY2FsbChjdHJsLCBudWxsLCAoJHBhcnNlKCRhdHRycy50YWJsZUNvbmZpZykoJHNjb3BlKSkpO1xuXG4gICAgICAgIC8vIGNvbnRyb2xsZXIgZnVuY3Rpb25zXG4gICAgICAgIGN0cmwuY3JlYXRlUGFyYW1zT2JqZWN0ID0gYmNTZXJ2ZXJUYWJsZVByb3RvdHlwZS5jcmVhdGVQYXJhbXNPYmplY3Q7XG4gICAgICAgIGN0cmwuZmV0Y2hSZXNvdXJjZSA9IGJjU2VydmVyVGFibGVQcm90b3R5cGUuZmV0Y2hSZXNvdXJjZTtcbiAgICAgICAgY3RybC5nZXRTZWxlY3RlZFJvd3MgPSBiY1NlcnZlclRhYmxlUHJvdG90eXBlLmdldFNlbGVjdGVkUm93cztcbiAgICAgICAgY3RybC5pbml0ID0gYmNTZXJ2ZXJUYWJsZVByb3RvdHlwZS5pbml0O1xuICAgICAgICBjdHJsLmlzUm93U2VsZWN0ZWQgPSBiY1NlcnZlclRhYmxlUHJvdG90eXBlLmlzUm93U2VsZWN0ZWQ7XG4gICAgICAgIGN0cmwubG9hZFN0YXRlUGFyYW1zID0gYmNTZXJ2ZXJUYWJsZVByb3RvdHlwZS5sb2FkU3RhdGVQYXJhbXM7XG4gICAgICAgIGN0cmwuc2VsZWN0QWxsUm93cyA9IGJjU2VydmVyVGFibGVQcm90b3R5cGUuc2VsZWN0QWxsUm93cztcbiAgICAgICAgY3RybC5zZXRQYWdpbmF0aW9uVmFsdWVzID0gYmNTZXJ2ZXJUYWJsZVByb3RvdHlwZS5zZXRQYWdpbmF0aW9uVmFsdWVzO1xuICAgICAgICBjdHJsLnNldFJvd3MgPSBiY1NlcnZlclRhYmxlUHJvdG90eXBlLnNldFJvd3M7XG4gICAgICAgIGN0cmwuc2V0U29ydGluZ1ZhbHVlcyA9IGJjU2VydmVyVGFibGVQcm90b3R5cGUuc2V0U29ydGluZ1ZhbHVlcztcbiAgICAgICAgY3RybC51cGRhdGVQYWdlID0gXy5iaW5kKGJjU2VydmVyVGFibGVQcm90b3R5cGUudXBkYXRlUGFnZSwgY3RybCk7XG4gICAgICAgIGN0cmwudXBkYXRlU29ydCA9IGJjU2VydmVyVGFibGVQcm90b3R5cGUudXBkYXRlU29ydDtcbiAgICAgICAgY3RybC51cGRhdGVUYWJsZSA9IGJjU2VydmVyVGFibGVQcm90b3R5cGUudXBkYXRlVGFibGU7XG4gICAgICAgIGN0cmwudmFsaWRhdGVSZXNvdXJjZSA9IGJjU2VydmVyVGFibGVQcm90b3R5cGUudmFsaWRhdGVSZXNvdXJjZTtcblxuICAgICAgICBpbml0KCk7XG5cbiAgICAgICAgZnVuY3Rpb24gaW5pdCgpIHtcbiAgICAgICAgICAgIHZhciByZXNvdXJjZUNhbGxiYWNrO1xuXG4gICAgICAgICAgICByZXNvdXJjZUNhbGxiYWNrID0gJHBhcnNlKCRhdHRycy5yZXNvdXJjZUNhbGxiYWNrKSgkc2NvcGUpO1xuICAgICAgICAgICAgaWYgKCFfLmlzRnVuY3Rpb24ocmVzb3VyY2VDYWxsYmFjaykpIHtcbiAgICAgICAgICAgICAgICAkbG9nLmVycm9yKCdiYy1zZXJ2ZXItdGFibGUgZGlyZWN0aXZlOiByZXNvdXJjZS1jYWxsYmFjayBtdXN0IGJlIGEgZnVuY3Rpb24uJyk7XG4gICAgICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgY3RybC5yZXNvdXJjZUNhbGxiYWNrID0gcmVzb3VyY2VDYWxsYmFjaztcblxuICAgICAgICAgICAgY3RybC5pbml0KCk7XG4gICAgICAgIH1cbiAgICB9KTtcbiIsImFuZ3VsYXIubW9kdWxlKCdiY2FwcC1wYXR0ZXJuLWxhYi5iYy1zZXJ2ZXItdGFibGUuZGlyZWN0aXZlJywgW1xuICAgICdiY2FwcC1wYXR0ZXJuLWxhYi5iYy1zZXJ2ZXItdGFibGUuY29udHJvbGxlcicsXG4gICAgJ2JjYXBwLXBhdHRlcm4tbGFiLmJjLXNlcnZlci10YWJsZS5zb3J0LWJ5LmRpcmVjdGl2ZScsXG4gICAgJ3VpLnJvdXRlcidcbl0pXG4gICAgLyoqXG4gICAgICogVGhlIGJjLXNlcnZlci10YWJsZSBkaXJlY3RpdmUgY3JlYXRlcyBhIGRhdGEgdGFibGUgdGhhdCBoYW5kbGVzXG4gICAgICogc2VydmVyIHNpZGUgcGFnaW5hdGlvbiwgc29ydGluZywgYW5kIGZpbHRlcmluZy4gSXQgZXhwb3NlcyBhIGZldyBzY29wZSB2YXJpYWJsZXMsXG4gICAgICogdGhhdCBjYW4gYmUgdXNlZCB0byBkaXNwbGF5IHRoZSB0YWJsZSBjb250ZW50IHdpdGggY3VzdG9tIG1hcmt1cCAoc2VlIGV4YW1wbGVcbiAgICAgKiBpbiB0aGUgcGF0dGVybiBsYWIgZm9yIGFuIGFjdHVhbCBpbXBsZW1lbnRhdGlvbiBvZiB0aGUgYmMtc2VydmVyLXRhYmxlKS5cbiAgICAgKlxuICAgICAqIFRoZSBmb2xsb3dpbmcgYXR0cmlidXRlcyBjYW4gYmUgcGFzc2VkIGluIG9yZGVyIHRvIGNvbmZpZ3VyZSB0aGUgYmMtc2VydmVyLXRhYmxlOlxuICAgICAqIC0gcmVzb3VyY2UtY2FsbGJhY2sgKHJlcXVpcmVkKVxuICAgICAqIC0gdGFibGVDb25maWcgKG9wdGlvbmFsKVxuICAgICAqXG4gICAgICogLSByZXNvdXJjZS1jYWxsYmFjayAtIGEgZnVuY3Rpb24gdGhhdCByZXR1cm5zIGEgcHJvbWlzZSB3aGljaCBpcyByZXNvdmxlZFxuICAgICAqIHdpdGggYW4gb2JqZWN0IG9mIHRoZSBmb2xsb3dpbmcgZm9ybWF0OlxuICAgICAqICAgICAge1xuICAgICAqICAgICAgICAgIHJvd3M6IEFycmF5LFxuICAgICAqICAgICAgICAgIHBhZ2luYXRpb246IHtcbiAgICAgKiAgICAgICAgICAgICAgcGFnZTogTnVtYmVyLFxuICAgICAqICAgICAgICAgICAgICBsaW1pdDogTnVtYmVyLFxuICAgICAqICAgICAgICAgICAgICB0b3RhbDogTnVtYmVyXG4gICAgICogICAgICAgICAgfVxuICAgICAqICAgICAgfVxuICAgICAqXG4gICAgICogVGhpcyBkaXJlY3RpdmUgZXhwb3NlcyBhIHNjb3BlIHZhcmlhYmxlIGNhbGxlZCBiY1NlcnZlclRhYmxlIHRoYXRcbiAgICAgKiBjYW4gYmUgdXNlZCB0byBkaXNwbGF5IGNvbnRlbnQsIGFuZCBpbXBsZW1lbnQgYWRkaXRpb25hbCBmdW5jdGlvbmFsaXR5XG4gICAgICogdG8gdGhlIHRhYmxlIChzdWNoIGFzIHBhZ2luYXRpb24sIHNvcnRpbmcsIGFuZCBzZWxlY3Rpb24gbG9naWMpLlxuICAgICAqXG4gICAgICogLSBiY1NlcnZlclRhYmxlLnJvd3NcbiAgICAgKiAgICAgIC0gQ2FuIGJlIHVzZWQgd2l0aCBuZy1yZXBlYXQgdG8gZGlzcGxheSB0aGUgZGF0YVxuICAgICAqIC0gYmNTZXJ2ZXJUYWJsZS5maWx0ZXJzXG4gICAgICogICAgICAtIENhbiBiZSB1c2VkIHRvIGNoYW5nZS91cGRhdGUgZmlsdGVycy4gVGhlc2UgZmlsdGVycyBtdXN0IGFwcGVhclxuICAgICAqICAgICAgICBpbiB0aGUgc3RhdGUgZGVmaW5pdGlvbiBpbiBvcmRlciB0byB3b3JrIGNvcnJlY3RseS5cbiAgICAgKiAtIGJjU2VydmVyVGFibGUudXBkYXRlVGFibGUoKVxuICAgICAqICAgICAgLSBQZXJmb3JtIGEgc3RhdGUgdHJhbnNpc3Rpb24gd2l0aCB0aGUgY3VycmVudCB0YWJsZSBpbmZvXG4gICAgICogLSBiY1NlcnZlclRhYmxlLnBhZ2luYXRpb25cbiAgICAgKiAgICAgIC0gZXhwb3NlcyBwYWdlLCBsaW1pdCwgYW5kIHRvdGFsXG4gICAgICogLSBiY1NlcnZlclRhYmxlLnNldFBhZ2luYXRpb25WYWx1ZXMocGFnaW5hdGlvbilcbiAgICAgKiAgICAgIC0gY29udmVuaWVuY2UgbWV0aG9kIGZvciBzZXR0aW5nIHBhZ2luYXRpb24gdmFsdWVzIGF0IG9uY2UuXG4gICAgICpcbiAgICAgKiAtIGJjU2VydmVyVGFibGUuc2VsZWN0ZWRSb3dzXG4gICAgICogICAgICAtIGFuIG1hcCBvYmplY3Qgd2l0aCB1bmlxdWUgaWQncyBhcyBrZXlzIGFuZCBib29sZWFuIHZhbHVlcyBhcyB0aGUgc2VsZWN0ZWQgc3RhdGVcbiAgICAgKiAtIGJjU2VydmVyVGFibGUuYWxsU2VsZWN0ZWRcbiAgICAgKiAgICAgIC0gYSBib29sZWFuIHZhbHVlIHVzZWQgdG8gZGV0ZXJtaW5lIGlmIGFsbCByb3dzIHdlcmUgc2VsZWN0ZWQgb3IgY2xlYXJlZFxuICAgICAqIC0gYmNTZXJ2ZXJUYWJsZS5zZWxlY3RBbGxSb3dzKClcbiAgICAgKiAgICAgIC0gdG9nZ2xlIGFsbCByb3dzIHNlbGVjdGlvbiBzdGF0ZVxuICAgICAqIC0gYmNTZXJ2ZXJUYWJsZS5pc1Jvd1NlbGVjdGVkKHJvdylcbiAgICAgKiAgICAgIC0gaGVscGVyIGZ1bmN0aW9uIHRvIGRldGVybWluZSBpZiBhIHJvdyBpcyBzZWxlY3RlZFxuICAgICAqIC0gYmNTZXJ2ZXJUYWJsZS5nZXRTZWxlY3RlZFJvd3MoKVxuICAgICAqICAgICAgLSBmdW5jdGlvbiB0aGF0IHJldHVybnMgYW4gYXJyYXkgb2Ygcm93IG9iamVjdHMgdGhhdCBhcmUgY3VycmVudGx5IHNlbGVjdGVkXG4gICAgICpcbiAgICAgKi9cbiAgICAuZGlyZWN0aXZlKCdiY1NlcnZlclRhYmxlJywgZnVuY3Rpb24gYmNTZXJ2ZXJUYWJsZURpcmVjdGl2ZSgkcGFyc2UpIHtcbiAgICAgICAgdmFyIGRpcmVjdGl2ZSA9IHtcbiAgICAgICAgICAgIHJlc3RyaWN0OiAnRUEnLFxuICAgICAgICAgICAgY29udHJvbGxlcjogJ0JjU2VydmVyVGFibGVDdHJsIGFzIGJjU2VydmVyVGFibGUnLFxuICAgICAgICAgICAgbGluazogZnVuY3Rpb24gYmNTZXJ2ZXJUYWJsZUxpbmsoJHNjb3BlLCBlbGVtZW50LCBhdHRycywgYmNTZXJ2ZXJUYWJsZUN0cmwpIHtcbiAgICAgICAgICAgICAgICBpZiAoYXR0cnMudGFibGVDb250cm9sbGVyKSB7XG4gICAgICAgICAgICAgICAgICAgIC8vIGV4cG9zZSBiY1NlcnZlclRhYmxlQ3RybCB0byB0YWJsZUNvbnRyb2xsZXIgaWYgaXQgZXhpc3RzXG4gICAgICAgICAgICAgICAgICAgICRwYXJzZShhdHRycy50YWJsZUNvbnRyb2xsZXIpLmFzc2lnbigkc2NvcGUsIGJjU2VydmVyVGFibGVDdHJsKTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgIH07XG5cbiAgICAgICAgcmV0dXJuIGRpcmVjdGl2ZTtcbiAgICB9KTtcbiIsImFuZ3VsYXIubW9kdWxlKCdiY2FwcC1wYXR0ZXJuLWxhYi5iYy1zZXJ2ZXItdGFibGUnLCBbXG4gICAgJ2JjYXBwLXBhdHRlcm4tbGFiLmJjLXNlcnZlci10YWJsZS5kaXJlY3RpdmUnLFxuICAgICdiY2FwcC1wYXR0ZXJuLWxhYi5iYy1zZXJ2ZXItdGFibGUuc29ydC1ieS5kaXJlY3RpdmUnLFxuICAgICdiY2FwcC1wYXR0ZXJuLWxhYi5iYy1zZXJ2ZXItdGFibGUtZmFjdG9yeS5zZXJ2aWNlJ1xuXSk7XG4iLCJhbmd1bGFyLm1vZHVsZSgnYmNhcHAtcGF0dGVybi1sYWIuYmMtc2VydmVyLXRhYmxlLnNvcnQtYnkuZGlyZWN0aXZlJywgW1xuICAgICdiY2FwcC1wYXR0ZXJuLWxhYi5iYy1zZXJ2ZXItdGFibGUtZmFjdG9yeS5zZXJ2aWNlJ1xuXSlcbiAgICAuZGlyZWN0aXZlKCdiY1NvcnRCeScsIGZ1bmN0aW9uIGJjU29ydEJ5RGlyZWN0aXZlKCRsb2csIGJjU2VydmVyVGFibGVGYWN0b3J5KSB7XG4gICAgICAgIHZhciBkaXJlY3RpdmUgPSB7XG4gICAgICAgICAgICB0ZW1wbGF0ZVVybDogJ3NyYy9qcy9iaWdjb21tZXJjZS9iYy1zZXJ2ZXItdGFibGUvYmMtc29ydC1ieS50cGwuaHRtbCcsXG4gICAgICAgICAgICByZXN0cmljdDogJ0UnLFxuICAgICAgICAgICAgdHJhbnNjbHVkZTogdHJ1ZSxcbiAgICAgICAgICAgIHNjb3BlOiB7XG4gICAgICAgICAgICAgICAgc29ydFZhbHVlOiAnQCcsXG4gICAgICAgICAgICAgICAgY29sdW1uTmFtZTogJ0AnLFxuICAgICAgICAgICAgICAgIHRhYmxlSWQ6ICdAJ1xuICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIHJlcXVpcmU6ICc/Xl5iY1NlcnZlclRhYmxlJyxcbiAgICAgICAgICAgIGxpbms6IGJjU29ydEJ5RGlyZWN0aXZlTGlua1xuICAgICAgICB9O1xuXG4gICAgICAgIGZ1bmN0aW9uIGJjU29ydEJ5RGlyZWN0aXZlTGluayhzY29wZSwgZWxlbWVudCwgYXR0cnMsIGJjU2VydmVyVGFibGVDdHJsKSB7XG4gICAgICAgICAgICB2YXIgYmNTZXJ2ZXJUYWJsZSxcbiAgICAgICAgICAgICAgICBzb3J0RGlyVmFsdWVzO1xuXG4gICAgICAgICAgICBpZiAoc2NvcGUudGFibGVJZCkge1xuICAgICAgICAgICAgICAgIGJjU2VydmVyVGFibGUgPSBiY1NlcnZlclRhYmxlRmFjdG9yeS5nZXQoc2NvcGUudGFibGVJZCk7XG4gICAgICAgICAgICB9IGVsc2UgaWYgKGJjU2VydmVyVGFibGVDdHJsKSB7XG4gICAgICAgICAgICAgICAgYmNTZXJ2ZXJUYWJsZSA9IGJjU2VydmVyVGFibGVDdHJsO1xuICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgICAkbG9nLmVycm9yKCdiYy1zb3J0LWJ5IGRpcmVjdGl2ZSByZXF1aXJlcyBhIHRhYmxlLWlkLCBvciBhIHBhcmVudCBiY1NlcnZlclRhYmxlQ3RybCBkaXJlY3RpdmUuJyk7XG4gICAgICAgICAgICB9XG5cbiAgICAgICAgICAgIHNvcnREaXJWYWx1ZXMgPSBiY1NlcnZlclRhYmxlLnRhYmxlQ29uZmlnLnNvcnREaXJWYWx1ZXM7XG5cbiAgICAgICAgICAgIHNjb3BlLmFzYyA9IHNvcnREaXJWYWx1ZXMuYXNjO1xuICAgICAgICAgICAgc2NvcGUuZGVzYyA9IHNvcnREaXJWYWx1ZXMuZGVzYztcbiAgICAgICAgICAgIHNjb3BlLnNvcnRCeSA9IGJjU2VydmVyVGFibGUuc29ydEJ5O1xuICAgICAgICAgICAgc2NvcGUuc29ydERpciA9IGJjU2VydmVyVGFibGUuc29ydERpcjtcbiAgICAgICAgICAgIHNjb3BlLnNvcnQgPSBzb3J0O1xuXG4gICAgICAgICAgICBmdW5jdGlvbiBzb3J0KCRldmVudCkge1xuICAgICAgICAgICAgICAgIHZhciBzb3J0QnksXG4gICAgICAgICAgICAgICAgICAgIHNvcnREaXI7XG5cbiAgICAgICAgICAgICAgICBpZiAoJGV2ZW50KSB7XG4gICAgICAgICAgICAgICAgICAgICRldmVudC5wcmV2ZW50RGVmYXVsdCgpO1xuICAgICAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgICAgIGlmIChiY1NlcnZlclRhYmxlLnNvcnRCeSA9PT0gc2NvcGUuc29ydFZhbHVlKSB7XG4gICAgICAgICAgICAgICAgICAgIHNvcnRCeSA9IGJjU2VydmVyVGFibGUuc29ydEJ5O1xuICAgICAgICAgICAgICAgICAgICBzb3J0RGlyID0gYmNTZXJ2ZXJUYWJsZS5zb3J0RGlyID09PSBzY29wZS5hc2MgPyBzY29wZS5kZXNjIDogc2NvcGUuYXNjO1xuICAgICAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgICAgICAgIHNvcnRCeSA9IHNjb3BlLnNvcnRWYWx1ZTtcbiAgICAgICAgICAgICAgICAgICAgc29ydERpciA9IHNjb3BlLmFzYztcbiAgICAgICAgICAgICAgICB9XG5cbiAgICAgICAgICAgICAgICBiY1NlcnZlclRhYmxlLnVwZGF0ZVNvcnQoc29ydEJ5LCBzb3J0RGlyKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuXG4gICAgICAgIHJldHVybiBkaXJlY3RpdmU7XG4gICAgfSk7XG4iLCJhbmd1bGFyLm1vZHVsZSgnYmNhcHAtcGF0dGVybi1sYWIuY2hlY2tib3gtbGlzdC5jb250cm9sbGVyJywgW10pXG4gICAgLmNvbnRyb2xsZXIoJ0NoZWNrYm94TGlzdEN0cmwnLCBmdW5jdGlvbiBDaGVja2JveExpc3RDdHJsKCRhdHRycywgJGVsZW1lbnQsICRsb2csICRwYXJzZSwgJHNjb3BlKSB7XG4gICAgICAgIHZhciBjdHJsID0gdGhpcyxcbiAgICAgICAgICAgIGZhbHNlVmFsdWUgPSAkcGFyc2UoJGF0dHJzLm5nRmFsc2VWYWx1ZSkoY3RybCkgfHwgZmFsc2UsXG4gICAgICAgICAgICB0cnVlVmFsdWUgPSAkcGFyc2UoJGF0dHJzLm5nVHJ1ZVZhbHVlKShjdHJsKSB8fCB0cnVlLFxuICAgICAgICAgICAgbmdNb2RlbCA9ICRlbGVtZW50LmNvbnRyb2xsZXIoJ25nTW9kZWwnKTtcblxuICAgICAgICBpbml0KCk7XG5cbiAgICAgICAgLy8gR2V0dGVyc1xuICAgICAgICBmdW5jdGlvbiBnZXRNb2RlbFZhbHVlKCkge1xuICAgICAgICAgICAgcmV0dXJuIG5nTW9kZWwuJG1vZGVsVmFsdWU7XG4gICAgICAgIH1cblxuICAgICAgICBmdW5jdGlvbiBnZXRWYWx1ZSgpIHtcbiAgICAgICAgICAgIHJldHVybiBjdHJsLnZhbHVlIHx8IGN0cmwubmdWYWx1ZTtcbiAgICAgICAgfVxuXG4gICAgICAgIGZ1bmN0aW9uIGdldFNlbGVjdGVkVmFsdWVzKCkge1xuICAgICAgICAgICAgcmV0dXJuIGN0cmwuc2VsZWN0ZWRWYWx1ZXM7XG4gICAgICAgIH1cblxuICAgICAgICAvLyBTZXR0ZXJzXG4gICAgICAgIGZ1bmN0aW9uIHVwZGF0ZU1vZGVsVmFsdWUobW9kZWxWYWx1ZSkge1xuICAgICAgICAgICAgbmdNb2RlbC4kc2V0Vmlld1ZhbHVlKG1vZGVsVmFsdWUpO1xuICAgICAgICAgICAgbmdNb2RlbC4kY29tbWl0Vmlld1ZhbHVlKCk7XG4gICAgICAgICAgICBuZ01vZGVsLiRyZW5kZXIoKTtcbiAgICAgICAgfVxuXG4gICAgICAgIGZ1bmN0aW9uIHVwZGF0ZVNlbGVjdGVkVmFsdWVzKG1vZGVsVmFsdWUpIHtcbiAgICAgICAgICAgIGlmIChtb2RlbFZhbHVlID09PSB0cnVlVmFsdWUpIHtcbiAgICAgICAgICAgICAgICBhZGRUb1NlbGVjdGVkVmFsdWVzKCk7XG4gICAgICAgICAgICB9IGVsc2UgaWYgKG1vZGVsVmFsdWUgPT09IGZhbHNlVmFsdWUpIHtcbiAgICAgICAgICAgICAgICByZW1vdmVGcm9tU2VsZWN0ZWRWYWx1ZXMoKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuXG4gICAgICAgIGZ1bmN0aW9uIGFkZFRvU2VsZWN0ZWRWYWx1ZXMoKSB7XG4gICAgICAgICAgICB2YXIgaXNJbmNsdWRlZCA9IF8uaW5jbHVkZShjdHJsLnNlbGVjdGVkVmFsdWVzLCBnZXRWYWx1ZSgpKTtcblxuICAgICAgICAgICAgaWYgKCFpc0luY2x1ZGVkKSB7XG4gICAgICAgICAgICAgICAgY3RybC5zZWxlY3RlZFZhbHVlcy5wdXNoKGdldFZhbHVlKCkpO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG5cbiAgICAgICAgZnVuY3Rpb24gcmVtb3ZlRnJvbVNlbGVjdGVkVmFsdWVzKCkge1xuICAgICAgICAgICAgdmFyIGluZGV4ID0gXy5pbmRleE9mKGN0cmwuc2VsZWN0ZWRWYWx1ZXMsIGdldFZhbHVlKCkpO1xuXG4gICAgICAgICAgICBpZiAoaW5kZXggIT09IC0xKSB7XG4gICAgICAgICAgICAgICAgY3RybC5zZWxlY3RlZFZhbHVlcy5zcGxpY2UoaW5kZXgsIDEpO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG5cbiAgICAgICAgLy8gV2F0Y2hlcnNcbiAgICAgICAgZnVuY3Rpb24gbW9kZWxWYWx1ZVdhdGNoKG1vZGVsVmFsdWUsIG9sZE1vZGVsVmFsdWUpIHtcbiAgICAgICAgICAgIHZhciBvbGRTZWxlY3RlZFZhbHVlcyxcbiAgICAgICAgICAgICAgICBzZWxlY3RlZFZhbHVlc0NoYW5nZWQ7XG5cbiAgICAgICAgICAgIC8vIFdoZW4gbmdNb2RlbCB2YWx1ZSBjaGFuZ2VzXG4gICAgICAgICAgICBpZiAoXy5pc1VuZGVmaW5lZChtb2RlbFZhbHVlKSB8fCBtb2RlbFZhbHVlID09PSBvbGRNb2RlbFZhbHVlKSB7XG4gICAgICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAvLyBSZXRhaW4gYSBzaGFsbG93IGNvcHkgb2Ygc2VsZWN0ZWRWYWx1ZXMgYmVmb3JlIHVwZGF0ZVxuICAgICAgICAgICAgb2xkU2VsZWN0ZWRWYWx1ZXMgPSBjdHJsLnNlbGVjdGVkVmFsdWVzLnNsaWNlKCk7XG5cbiAgICAgICAgICAgIC8vIFVwZGF0ZSBzZWxlY3RlZFZhbHVlc1xuICAgICAgICAgICAgdXBkYXRlU2VsZWN0ZWRWYWx1ZXMobW9kZWxWYWx1ZSk7XG5cbiAgICAgICAgICAgIC8vIERldGVybWluZSBpZiBzZWxlY3RlZFZhbHVlcyBhcnJheSBoYXMgY2hhbmdlZFxuICAgICAgICAgICAgc2VsZWN0ZWRWYWx1ZXNDaGFuZ2VkID0gISFfLnhvcihjdHJsLnNlbGVjdGVkVmFsdWVzLCBvbGRTZWxlY3RlZFZhbHVlcykubGVuZ3RoO1xuXG4gICAgICAgICAgICAvLyBJZiBjaGFuZ2VkLCBldm9rZSBkZWxlZ2F0ZSBtZXRob2QgKGlmIGRlZmluZWQpXG4gICAgICAgICAgICBpZiAoY3RybC5vbkNoYW5nZSAmJiBzZWxlY3RlZFZhbHVlc0NoYW5nZWQpIHtcbiAgICAgICAgICAgICAgICBjdHJsLm9uQ2hhbmdlKHtcbiAgICAgICAgICAgICAgICAgICAgc2VsZWN0ZWRWYWx1ZXM6IGN0cmwuc2VsZWN0ZWRWYWx1ZXMsXG4gICAgICAgICAgICAgICAgICAgIG9sZFNlbGVjdGVkVmFsdWVzOiBvbGRTZWxlY3RlZFZhbHVlc1xuICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG5cbiAgICAgICAgZnVuY3Rpb24gc2VsZWN0ZWRWYWx1ZXNXYXRjaChzZWxlY3RlZFZhbHVlcykge1xuICAgICAgICAgICAgLy8gV2hlbiBzZWxlY3RlZFZhbHVlcyBjb2xsZWN0aW9uIGNoYW5nZXNcbiAgICAgICAgICAgIHZhciBpc0luY2x1ZGVkID0gXy5pbmNsdWRlKHNlbGVjdGVkVmFsdWVzLCBnZXRWYWx1ZSgpKSxcbiAgICAgICAgICAgICAgICBtb2RlbFZhbHVlID0gZ2V0TW9kZWxWYWx1ZSgpO1xuXG4gICAgICAgICAgICBpZiAoaXNJbmNsdWRlZCAmJiBtb2RlbFZhbHVlICE9PSB0cnVlVmFsdWUpIHtcbiAgICAgICAgICAgICAgICB1cGRhdGVNb2RlbFZhbHVlKHRydWVWYWx1ZSk7XG4gICAgICAgICAgICB9IGVsc2UgaWYgKCFpc0luY2x1ZGVkICYmIG1vZGVsVmFsdWUgIT09IGZhbHNlVmFsdWUpIHtcbiAgICAgICAgICAgICAgICB1cGRhdGVNb2RlbFZhbHVlKGZhbHNlVmFsdWUpO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG5cbiAgICAgICAgLy8gSW5pdGlhbGl6ZXJcbiAgICAgICAgZnVuY3Rpb24gaW5pdCgpIHtcbiAgICAgICAgICAgIGlmICgkYXR0cnMudHlwZSAhPT0gJ2NoZWNrYm94Jykge1xuICAgICAgICAgICAgICAgICRsb2cuZXJyb3IoJ2NoZWNrYm94LWxpc3QgZGlyZWN0aXZlOiBlbGVtZW50IG11c3QgYmUgPGlucHV0IHR5cGU9XCJjaGVja2JveFwiPicpO1xuXG4gICAgICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAkc2NvcGUuJHdhdGNoKGdldE1vZGVsVmFsdWUsIG1vZGVsVmFsdWVXYXRjaCk7XG4gICAgICAgICAgICAkc2NvcGUuJHdhdGNoQ29sbGVjdGlvbihnZXRTZWxlY3RlZFZhbHVlcywgc2VsZWN0ZWRWYWx1ZXNXYXRjaCk7XG4gICAgICAgIH1cbiAgICB9KTtcbiIsImFuZ3VsYXIubW9kdWxlKCdiY2FwcC1wYXR0ZXJuLWxhYi5jaGVja2JveC1saXN0LmRpcmVjdGl2ZScsIFtcbiAgICAnYmNhcHAtcGF0dGVybi1sYWIuY2hlY2tib3gtbGlzdC5jb250cm9sbGVyJ1xuXSlcblxuICAgIC8qKlxuICAgICAqIEEgZGlyZWN0aXZlIGZvciBjb2xsYXRpbmcgdmFsdWVzIGZyb20gYW4gYXJyYXkgb2YgY2hlY2tib3hlcy5cbiAgICAgKlxuICAgICAqIEByZXF1aXJlIG5nTW9kZWxcbiAgICAgKiBAcGFyYW0ge0FycmF5LjxzdHJpbmd8bnVtYmVyfE9iamVjdD59IGNoZWNrYm94TGlzdCAtIEFycmF5IHRvIGhvbGQgc2VsZWN0ZWQgdmFsdWVzXG4gICAgICogQHBhcmFtIHsqfSB2YWx1ZSAtIFZhbHVlIHRvIGFkZCB0byBjaGVja2JveExpc3RcbiAgICAgKiBAcGFyYW0ge2Z1bmN0aW9uKHNlbGVjdGVkVmFsdWVzLCBvbGRTZWxlY3RlZFZhbHVlc30gW2NoZWNrYm94TGlzdENoYW5nZV0gLSBPcHRpb25hbCBvbkNoYW5nZSBjYWxsYmFja1xuICAgICAqXG4gICAgICogQGV4YW1wbGU6XG4gICAgICogYGBgaHRtbFxuICAgICAqIDxkaXYgbmctcmVwZWF0PVwib3B0aW9uIGluIG9wdGlvbnNcIj5cbiAgICAgKiAgICAgPGlucHV0IHR5cGU9XCJjaGVja2JveFwiIFxuICAgICAqICAgICAgICAgbmFtZT1cIm9wdGlvbnt7IG9wdGlvbi5pZCB9fVwiXG4gICAgICogICAgICAgICB2YWx1ZT1cIm9wdGlvbi5pZFwiIFxuICAgICAqICAgICAgICAgY2hlY2tib3gtbGlzdD1cInNlbGVjdGVkVmFsdWVzXCIgXG4gICAgICogICAgICAgICBjaGVja2JveC1saXN0LWNoYW5nZT1cIm9uQ2hhbmdlKHNlbGVjdGVkVmFsdWVzKVwiIFxuICAgICAqICAgICAgICAgbmctbW9kZWw9XCJvcHRpb24uY2hlY2tlZFwiXG4gICAgICogICAgIC8+XG4gICAgICogPC9kaXY+XG4gICAgICogYGBgXG4gICAgICogXG4gICAgICogYGBganNcbiAgICAgKiBzY29wZS5zZWxlY3RlZFZhbHVlcyA9IFtdO1xuICAgICAqIHNjb3BlLm9wdGlvbnMgPSBbXG4gICAgICogICAgIHtcbiAgICAgKiAgICAgICAgIGlkOiAxLFxuICAgICAqICAgICAgICAgbGFiZWw6ICdPcHRpb24gMSdcbiAgICAgKiAgICAgfSxcbiAgICAgKiAgICAge1xuICAgICAqICAgICAgICAgaWQ6IDIsXG4gICAgICogICAgICAgICBsYWJlbDogJ09wdGlvbiAyJ1xuICAgICAqICAgICB9LFxuICAgICAqICAgICB7XG4gICAgICogICAgICAgICBpZDogMyxcbiAgICAgKiAgICAgICAgIGxhYmVsOiAnT3B0aW9uIDMnXG4gICAgICogICAgIH1cbiAgICAgKiBdO1xuICAgICAqIFxuICAgICAqIHNjb3BlLm9uQ2hhbmdlID0gZnVuY3Rpb24gb25DaGFuZ2Uoc2VsZWN0ZWRWYWx1ZXMpIHtcbiAgICAgKiAgICAgY29uc29sZS5sb2coc2VsZWN0ZWRWYWx1ZXMpO1xuICAgICAqIH07XG4gICAgICogYGBgXG4gICAgICogXG4gICAgICogV2hlbiBvcHRpb25zWzBdIGFuZCBvcHRpb25zWzFdIGFyZSBjaGVja2VkLCBzZWxlY3RlZFZhbHVlcyBzaG91bGQgYmUgWzEsIDJdXG4gICAgICogYW5kIG9uQ2hhbmdlIHdpbGwgYmUgZXZva2VkLiBUaGlzIGRpcmVjdGl2ZSBhbHNvIHdvcmtzIHdpdGggYW4gYXJyYXkgb2YgcHJpbWl0aXZlIHZhbHVlcy5cbiAgICAgKiBpLmUuOiBzY29wZS5vcHRpb25zID0gW1wiYVwiLCBcImJcIiwgXCJjXCJdLlxuICAgICAqL1xuXG4gICAgLmRpcmVjdGl2ZSgnY2hlY2tib3hMaXN0JywgZnVuY3Rpb24gY2hlY2tib3hMaXN0RGlyZWN0aXZlKCkge1xuICAgICAgICByZXR1cm4ge1xuICAgICAgICAgICAgcmVzdHJpY3Q6ICdBJyxcbiAgICAgICAgICAgIHJlcXVpcmU6ICduZ01vZGVsJyxcbiAgICAgICAgICAgIGNvbnRyb2xsZXI6ICdDaGVja2JveExpc3RDdHJsJyxcbiAgICAgICAgICAgIGNvbnRyb2xsZXJBczogJ2NoZWNrYm94TGlzdEN0cmwnLFxuICAgICAgICAgICAgYmluZFRvQ29udHJvbGxlcjogdHJ1ZSxcbiAgICAgICAgICAgIHNjb3BlOiB7XG4gICAgICAgICAgICAgICAgb25DaGFuZ2U6ICcmY2hlY2tib3hMaXN0Q2hhbmdlJyxcbiAgICAgICAgICAgICAgICBzZWxlY3RlZFZhbHVlczogJz1jaGVja2JveExpc3QnLFxuICAgICAgICAgICAgICAgIHZhbHVlOiAnPScsXG4gICAgICAgICAgICAgICAgbmdWYWx1ZTogJz0nXG4gICAgICAgICAgICB9XG4gICAgICAgIH07XG4gICAgfSk7XG4iLCJhbmd1bGFyLm1vZHVsZSgnYmNhcHAtcGF0dGVybi1sYWIuY2hlY2tib3gtbGlzdCcsIFtcbiAgICAnYmNhcHAtcGF0dGVybi1sYWIuY2hlY2tib3gtbGlzdC5kaXJlY3RpdmUnXG5dKTtcbiIsImFuZ3VsYXIubW9kdWxlKCdiY2FwcC1wYXR0ZXJuLWxhYi5jb2xvci1waWNrZXItcGFsZXR0ZS5jb250cm9sbGVyJywgW10pXG5cbiAgICAuY29udHJvbGxlcignQ29sb3JQaWNrZXJQYWxldHRlQ3RybCcsIGZ1bmN0aW9uKCkge1xuICAgICAgICBsZXQgY3RybCA9IHRoaXM7XG5cbiAgICAgICAgY3RybC5jcmVhdGVOZXdDb2xvciA9IGNyZWF0ZU5ld0NvbG9yO1xuXG4gICAgICAgIGZ1bmN0aW9uIGNyZWF0ZU5ld0NvbG9yKCRldmVudCkge1xuICAgICAgICAgICAgJGV2ZW50LnByZXZlbnREZWZhdWx0KCk7XG5cbiAgICAgICAgICAgIGN0cmwuY3JlYXRlTmV3UGFsZXR0ZUNvbG9yKCk7XG4gICAgICAgIH1cbiAgICB9KTtcbiIsImFuZ3VsYXIubW9kdWxlKCdiY2FwcC1wYXR0ZXJuLWxhYi5jb2xvci1waWNrZXItcGFsZXR0ZS5kaXJlY3RpdmUnLCBbXG4gICAgJ2JjYXBwLXBhdHRlcm4tbGFiLmNvbG9yLXBpY2tlci1wYWxldHRlLmNvbnRyb2xsZXInXG5dKVxuXG4gICAgLmRpcmVjdGl2ZSgnY29sb3JQaWNrZXJQYWxldHRlJywgZnVuY3Rpb24gY29sb3JQaWNrZXJQYWxldHRlRGlyZWN0aXZlKCkge1xuICAgICAgICByZXR1cm4ge1xuICAgICAgICAgICAgYmluZFRvQ29udHJvbGxlcjogdHJ1ZSxcbiAgICAgICAgICAgIGNvbnRyb2xsZXI6ICdDb2xvclBpY2tlclBhbGV0dGVDdHJsJyxcbiAgICAgICAgICAgIGNvbnRyb2xsZXJBczogJ2NvbG9yUGlja2VyUGFsZXR0ZUN0cmwnLFxuICAgICAgICAgICAgcmVzdHJpY3Q6ICdFJyxcbiAgICAgICAgICAgIHNjb3BlOiB7XG4gICAgICAgICAgICAgICAgY29sb3JzOiAnPScsXG4gICAgICAgICAgICAgICAgY3JlYXRlTmV3UGFsZXR0ZUNvbG9yOiAnPScsXG4gICAgICAgICAgICAgICAgc2V0TmV3Q29sb3I6ICc9JyxcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICB0ZW1wbGF0ZVVybDogJ3NyYy9qcy9iaWdjb21tZXJjZS9jb2xvci1waWNrZXIvY29sb3ItcGlja2VyLXBhbGV0dGUudHBsLmh0bWwnLFxuICAgICAgICAgICAgY29tcGlsZTogZnVuY3Rpb24gY29sb3JQaWNrZXJQYWxldHRlRGlyZWN0aXZlQ29tcGlsZSh0RWxlbWVudCkge1xuICAgICAgICAgICAgICAgIHRFbGVtZW50LmFkZENsYXNzKCdjb2xvclBpY2tlci1wYWxldHRlJyk7XG4gICAgICAgICAgICB9XG4gICAgICAgIH07XG4gICAgfSk7XG4iLCIvKiBnbG9iYWxzIENvbG9yUGlja2VyICovXG5hbmd1bGFyLm1vZHVsZSgnYmNhcHAtcGF0dGVybi1sYWIuY29sb3ItcGlja2VyLmNvbnRyb2xsZXInLCBbXSlcbiAgICAuY29udHJvbGxlcignQ29sb3JQaWNrZXJDdHJsJywgZnVuY3Rpb24gQ29sb3JQaWNrZXJDdHJsKCRlbGVtZW50KSB7XG4gICAgICAgIGNvbnN0IGN0cmwgPSB0aGlzO1xuXG4gICAgICAgIGxldCBjb2xvclNlbGVjdGlvbjtcbiAgICAgICAgbGV0IGNvbG9yU2VsZWN0aW9uSW5kaWNhdG9yO1xuICAgICAgICBsZXQgY29sb3JTbGlkZXI7XG4gICAgICAgIGxldCBjb2xvclNsaWRlckluZGljYXRvcjtcblxuICAgICAgICBjdHJsLmNyZWF0ZUNvbG9yUGlja2VyID0gY3JlYXRlQ29sb3JQaWNrZXI7XG4gICAgICAgIGN0cmwuY3JlYXRlTmV3UGFsZXR0ZUNvbG9yID0gY3JlYXRlTmV3UGFsZXR0ZUNvbG9yO1xuICAgICAgICBjdHJsLnNldE1vZGVsQ3RybCA9IHNldE1vZGVsQ3RybDtcbiAgICAgICAgY3RybC5zZXROZXdDb2xvciA9IHNldE5ld0NvbG9yO1xuXG4gICAgICAgIGZ1bmN0aW9uIGNyZWF0ZUNvbG9yUGlja2VyKCkge1xuICAgICAgICAgICAgY29sb3JTZWxlY3Rpb24gPSAkZWxlbWVudFswXS5xdWVyeVNlbGVjdG9yKCdbZGF0YS1iYy1waWNrZXJdJyk7XG4gICAgICAgICAgICBjb2xvclNlbGVjdGlvbkluZGljYXRvciA9ICRlbGVtZW50WzBdLnF1ZXJ5U2VsZWN0b3IoJ1tkYXRhLWJjLXBpY2tlci1pbmRpY2F0b3JdJyk7XG4gICAgICAgICAgICBjb2xvclNsaWRlciA9ICRlbGVtZW50WzBdLnF1ZXJ5U2VsZWN0b3IoJ1tkYXRhLWJjLXNsaWRlcl0nKTtcbiAgICAgICAgICAgIGNvbG9yU2xpZGVySW5kaWNhdG9yID0gJGVsZW1lbnRbMF0ucXVlcnlTZWxlY3RvcignW2RhdGEtYmMtc2xpZGVyLWluZGljYXRvcl0nKTtcblxuICAgICAgICAgICAgQ29sb3JQaWNrZXIuZml4SW5kaWNhdG9ycyhcbiAgICAgICAgICAgICAgICBjb2xvclNsaWRlckluZGljYXRvcixcbiAgICAgICAgICAgICAgICBjb2xvclNlbGVjdGlvbkluZGljYXRvcik7XG5cbiAgICAgICAgICAgIGN0cmwuY3AgPSBuZXcgQ29sb3JQaWNrZXIoXG4gICAgICAgICAgICAgICAgY29sb3JTbGlkZXIsXG4gICAgICAgICAgICAgICAgY29sb3JTZWxlY3Rpb24sXG4gICAgICAgICAgICAgICAgcGlja05ld0NvbG9yXG4gICAgICAgICAgICApO1xuICAgICAgICB9XG5cbiAgICAgICAgZnVuY3Rpb24gY3JlYXRlTmV3UGFsZXR0ZUNvbG9yKCkge1xuICAgICAgICAgICAgaWYgKGN0cmwucGFsZXR0ZS5pbmRleE9mKGdldFNlbGVjdGVkQ29sb3IoKSkgPCAwKSB7XG4gICAgICAgICAgICAgICAgY3RybC5wYWxldHRlLnB1c2goZ2V0U2VsZWN0ZWRDb2xvcigpKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuXG4gICAgICAgIGZ1bmN0aW9uIGdldFNlbGVjdGVkQ29sb3IoKSB7XG4gICAgICAgICAgICByZXR1cm4gY3RybC5jb2xvcjtcbiAgICAgICAgfVxuXG4gICAgICAgIGZ1bmN0aW9uIHBpY2tOZXdDb2xvcihoZXgsIGhzdiwgcmdiLCBwaWNrZXJDb29yZGluYXRlLCBzbGlkZXJDb29yZGluYXRlKSB7XG4gICAgICAgICAgICBDb2xvclBpY2tlci5wb3NpdGlvbkluZGljYXRvcnMoXG4gICAgICAgICAgICAgICAgY29sb3JTbGlkZXJJbmRpY2F0b3IsXG4gICAgICAgICAgICAgICAgY29sb3JTZWxlY3Rpb25JbmRpY2F0b3IsXG4gICAgICAgICAgICAgICAgc2xpZGVyQ29vcmRpbmF0ZSwgcGlja2VyQ29vcmRpbmF0ZVxuICAgICAgICAgICAgKTtcblxuICAgICAgICAgICAgY3RybC5uZ01vZGVsQ3RybC4kc2V0Vmlld1ZhbHVlKGhleCk7XG4gICAgICAgICAgICBjdHJsLm5nTW9kZWxDdHJsLiRyZW5kZXIoKTtcbiAgICAgICAgfVxuXG4gICAgICAgIGZ1bmN0aW9uIHJlbmRlcigpIHtcbiAgICAgICAgICAgIGN0cmwuY29sb3IgPSBjdHJsLm5nTW9kZWxDdHJsLiR2aWV3VmFsdWU7XG4gICAgICAgIH1cblxuICAgICAgICBmdW5jdGlvbiBzZXRNb2RlbEN0cmwobmdNb2RlbEN0cmwpIHtcbiAgICAgICAgICAgIGN0cmwubmdNb2RlbEN0cmwgPSBuZ01vZGVsQ3RybDtcbiAgICAgICAgICAgIGN0cmwubmdNb2RlbEN0cmwuJHJlbmRlciA9IHJlbmRlcjtcbiAgICAgICAgfVxuXG4gICAgICAgIGZ1bmN0aW9uIHNldE5ld0NvbG9yKCRldmVudCwgbmV3Q29sb3IpIHtcbiAgICAgICAgICAgICRldmVudC5wcmV2ZW50RGVmYXVsdCgpO1xuXG4gICAgICAgICAgICBjdHJsLmNwLnNldEhleChuZXdDb2xvcik7XG4gICAgICAgIH1cbiAgICB9KTtcbiIsImFuZ3VsYXIubW9kdWxlKCdiY2FwcC1wYXR0ZXJuLWxhYi5jb2xvci1waWNrZXIuZGlyZWN0aXZlJywgW1xuICAgICdiY2FwcC1wYXR0ZXJuLWxhYi5jb2xvci1waWNrZXIuY29udHJvbGxlcicsXG4gICAgJ2JjYXBwLXBhdHRlcm4tbGFiLmh0bWw1TW9kZScsXG5dKVxuXG4gICAgLmRpcmVjdGl2ZSgnY29sb3JQaWNrZXInLCBmdW5jdGlvbiBjb2xvclBpY2tlckRpcmVjdGl2ZSgkbG9jYXRpb24sIGh0bWw1TW9kZSkge1xuICAgICAgICByZXR1cm4ge1xuICAgICAgICAgICAgYmluZFRvQ29udHJvbGxlcjogdHJ1ZSxcbiAgICAgICAgICAgIGNvbnRyb2xsZXI6ICdDb2xvclBpY2tlckN0cmwnLFxuICAgICAgICAgICAgY29udHJvbGxlckFzOiAnY29sb3JQaWNrZXJDdHJsJyxcbiAgICAgICAgICAgIHJlcXVpcmU6IFsnY29sb3JQaWNrZXInLCAnXm5nTW9kZWwnXSxcbiAgICAgICAgICAgIHJlc3RyaWN0OiAnRScsXG4gICAgICAgICAgICBzY29wZToge1xuICAgICAgICAgICAgICAgIHBhbGV0dGU6ICc9JyxcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICB0ZW1wbGF0ZVVybDogJ3NyYy9qcy9iaWdjb21tZXJjZS9jb2xvci1waWNrZXIvY29sb3ItcGlja2VyLnRwbC5odG1sJyxcblxuICAgICAgICAgICAgY29tcGlsZTogZnVuY3Rpb24gY29sb3JQaWNrZXJEaXJlY3RpdmVDb21waWxlKHRFbGVtZW50KSB7XG4gICAgICAgICAgICAgICAgdEVsZW1lbnQuYWRkQ2xhc3MoJ2NvbG9yUGlja2VyJyk7XG5cbiAgICAgICAgICAgICAgICByZXR1cm4gZnVuY3Rpb24gY29sb3JQaWNrZXJEaXJlY3RpdmVMaW5rKCRzY29wZSwgZWxlbWVudCwgYXR0cnMsIGN0cmxzKSB7XG4gICAgICAgICAgICAgICAgICAgIGNvbnN0IGN0cmwgPSBjdHJsc1swXTtcbiAgICAgICAgICAgICAgICAgICAgY29uc3QgbmdNb2RlbEN0cmwgPSBjdHJsc1sxXTtcblxuICAgICAgICAgICAgICAgICAgICBjdHJsLnNldE1vZGVsQ3RybChuZ01vZGVsQ3RybCk7XG4gICAgICAgICAgICAgICAgICAgIGN0cmwuY3JlYXRlQ29sb3JQaWNrZXIoKTtcblxuICAgICAgICAgICAgICAgICAgICAvLyBBcHBzIHRoYXQgaGF2ZSBhIDxiYXNlPiB0YWcgcmVxdWlyZSB0byBoYXZlIGFic29sdXRlIHBhdGhzXG4gICAgICAgICAgICAgICAgICAgIC8vIHdoZW4gdXNpbmcgc3ZnIHVybCByZWZlcmVuY2VzXG4gICAgICAgICAgICAgICAgICAgIGlmIChodG1sNU1vZGUuZW5hYmxlZCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgXy5lYWNoKGVsZW1lbnRbMF0ucXVlcnlTZWxlY3RvckFsbCgnW2ZpbGxdJyksIGZ1bmN0aW9uKGVsKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY29uc3QgYmV0d2VlblBhcmVudGhlc2lzID0gL1xcKChbXildKylcXCkvO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IGVsZW0gPSBhbmd1bGFyLmVsZW1lbnQoZWwpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IGN1cnJlbnRGaWxsID0gZWxlbS5hdHRyKCdmaWxsJyk7XG5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAoXy5jb250YWlucyhjdXJyZW50RmlsbCwgJ3VybCgjJykpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY29uc3QgbmV3RmlsbCA9IGJldHdlZW5QYXJlbnRoZXNpcy5leGVjKGN1cnJlbnRGaWxsKVsxXTtcblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBlbGVtLmF0dHIoJ2ZpbGwnLCAndXJsKCcgKyAkbG9jYXRpb24ucGF0aCgpICsgbmV3RmlsbCArICcpJyk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgICAgICAgICAkc2NvcGUuJHdhdGNoKGdldE1vZGVsVmFsdWUsIGZ1bmN0aW9uIG1vZGVsV2F0Y2gobmV3VmFsKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICBpZiAobmV3VmFsKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY3RybC5jcC5zZXRIZXgobmV3VmFsKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgfSk7XG5cbiAgICAgICAgICAgICAgICAgICAgZnVuY3Rpb24gZ2V0TW9kZWxWYWx1ZSgpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiBjdHJsLm5nTW9kZWxDdHJsLiRtb2RlbFZhbHVlO1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgfTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfTtcbiAgICB9KTtcbiIsImFuZ3VsYXIubW9kdWxlKCdiY2FwcC1wYXR0ZXJuLWxhYi5jb2xvci1waWNrZXInLCBbXG4gICAgJ2JjYXBwLXBhdHRlcm4tbGFiLmNvbG9yLXBpY2tlci5kaXJlY3RpdmUnLFxuICAgICdiY2FwcC1wYXR0ZXJuLWxhYi5jb2xvci1waWNrZXItcGFsZXR0ZS5kaXJlY3RpdmUnXG5dKTtcbiIsIi8qKlxuICogQG5hbWUgY3JlZGl0LWNhcmQgZGlyZWN0aXZlXG4gKiBAZGVzY3JpcHRpb24gQ29tcG9uZW50IGNvbnRhaW5pbmcgY2MgbnVtYmVyLCBjdmMsIG5hbWUsIGFuZCBleHBpcnkuIEhhcyBhbiBpc29sYXRlZCBzY29wZSB3aXRoIG5vIGNvbnRyb2xsZXIuXG4gKiBAcmVxdWlyZSBmb3JtXG4gKlxuICogQHBhcmFtIGNjRGF0YSB7b2JqZWN0fSBDb250YWlucyBjY051bWJlciwgY2NUeXBlLCBjY0V4cGlyeSwgYW5kIGNjTmFtZVxuICogQHBhcmFtIGNjQ29uZmlnIHtvYmplY3R9IFRoZSBjb25maWd1cmF0aW9uIG9iamVjdC4gQ3VycmVudGx5IHN1cHBvcnRpbmc6XG4gKiAgLSBjYXJkQ29kZSB7Ym9vbGVhbn0gSW5kaWNhdGVzIHdoZXRoZXIgdGhlIGN2diBmaWVsZCBzaG91bGQgYmUgc2hvd24uIERlZmF1bHQgdHJ1ZS5cbiAqICAtIGNhcmRDb2RlUmVxdWlyZWQge2Jvb2xlYW59IEluZGljYXRlcyB3aGV0aGVyIHRoZSBjdnYgZmllbGQgaXMgcmVxdWlyZWQuIFRoaXMgb25seSBtYXR0ZXJzIHdoZW4gY2FyZENvZGUgaXMgc2V0IHRvIHRydWUuIERlZmF1bHQgdHJ1ZS5cbiAqICAtIGZ1bGxOYW1lIHtib29sZWFufSBJbmRpY2F0ZXMgd2hldGhlciB0aGUgbmFtZSBmaWVsZCBzaG91bGQgYmUgc2hvd24uIERlZmF1bHQgdHJ1ZS5cbiAqIEBwYXJhbSBlYWdlclR5cGUge2Jvb2xlYW59IElmIHRoaXMgYXR0cmlidXRlIGlzIHNldCB0byBmYWxzZSwgdGhlbiBkaXNhYmxlIGVhZ2VyIHR5cGUgZGV0ZWN0aW9uLiBEZWZhdWx0cyB0cnVlLlxuICovXG5hbmd1bGFyLm1vZHVsZSgnYmNhcHAtcGF0dGVybi1sYWIuY3JlZGl0LWNhcmQuZGlyZWN0aXZlJywgW1xuICAgICdiY2FwcC1wYXR0ZXJuLWxhYi5pY29uJ1xuXSlcbiAgICAuZGlyZWN0aXZlKCdjcmVkaXRDYXJkJywgZnVuY3Rpb24gY3JlZGl0Q2FyZERpcmVjdGl2ZSgkY29tcGlsZSwgJHBhcnNlLCAkdGVtcGxhdGVDYWNoZSkge1xuICAgICAgICBjb25zdCBjdnZUb29sdGlwVGVtcGxhdGUgPSAkdGVtcGxhdGVDYWNoZS5nZXQoJ3NyYy9qcy9iaWdjb21tZXJjZS9jcmVkaXQtY2FyZC9jcmVkaXQtY2FyZC1jdnYvdG9vbHRpcC50cGwuaHRtbCcpO1xuXG4gICAgICAgIHJldHVybiB7XG4gICAgICAgICAgICBjb21waWxlOiBmdW5jdGlvbiBjcmVkaXRDYXJkQ29tcGlsZSh0RWxlbSwgdEF0dHJzKXtcbiAgICAgICAgICAgICAgICBsZXQgaXNFYWdlclR5cGUgPSB0cnVlO1xuXG4gICAgICAgICAgICAgICAgaWYgKHRBdHRycy5lYWdlclR5cGUgJiYgJHBhcnNlKHRBdHRycy5lYWdlclR5cGUpKCkgPT09IGZhbHNlKSB7XG4gICAgICAgICAgICAgICAgICAgIGNvbnN0IGNjTnVtYmVyID0gdEVsZW1bMF0ucXVlcnlTZWxlY3RvcignI2NjTnVtYmVyJyk7XG5cbiAgICAgICAgICAgICAgICAgICAgY2NOdW1iZXIucmVtb3ZlQXR0cmlidXRlKCdjY0VhZ2VyVHlwZScpO1xuICAgICAgICAgICAgICAgICAgICBpc0VhZ2VyVHlwZSA9IGZhbHNlO1xuICAgICAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgICAgIHJldHVybiBmdW5jdGlvbiBjcmVkaXRDYXJkTGluayhzY29wZSwgZWxlbSwgYXR0ciwgZm9ybUN0cmwpIHtcbiAgICAgICAgICAgICAgICAgICAgY29uc3QgY3Z2VG9vbHRpcEVsZW1lbnQgPSAkY29tcGlsZShjdnZUb29sdGlwVGVtcGxhdGUpKHNjb3BlKTtcbiAgICAgICAgICAgICAgICAgICAgY29uc3QgZGVmYXVsdENvbmZpZyA9IHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGNhcmRDb2RlOiB0cnVlLFxuICAgICAgICAgICAgICAgICAgICAgICAgY2FyZENvZGVSZXF1aXJlZDogdHJ1ZSxcbiAgICAgICAgICAgICAgICAgICAgICAgIGZ1bGxOYW1lOiB0cnVlLFxuICAgICAgICAgICAgICAgICAgICB9O1xuXG4gICAgICAgICAgICAgICAgICAgIHNjb3BlLmdldEN2dlRvb2x0aXBIdG1sID0gZ2V0Q3Z2VG9vbHRpcEh0bWw7XG5cbiAgICAgICAgICAgICAgICAgICAgaW5pdCgpO1xuXG4gICAgICAgICAgICAgICAgICAgIGZ1bmN0aW9uIGluaXQoKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICBzY29wZS5mb3JtQ3RybCA9IGZvcm1DdHJsO1xuICAgICAgICAgICAgICAgICAgICAgICAgc2NvcGUuY2NDb25maWcgPSBfLmRlZmF1bHRzKHNjb3BlLmNjQ29uZmlnLCBkZWZhdWx0Q29uZmlnKTtcblxuICAgICAgICAgICAgICAgICAgICAgICAgLyoqXG4gICAgICAgICAgICAgICAgICAgICAgICAgKiBUaGUgY3JlZGl0IGNhcmQgdHlwZSBpcyBkZWR1Y2VkIGJ5IHRoZSBgY2NOdW1iZXJgIGRpcmVjdGl2ZS4gVGhpcyBpcyBpbiB0dXJuIGV4cG9zZWRcbiAgICAgICAgICAgICAgICAgICAgICAgICAqIGFzIGVpdGhlciBgJGNjRWFnZXJUeXBlYCBvciBgJGNjVHlwZWAgb24gdGhlIGlucHV0IGNvbnRyb2wgZWxlbWVudC4gV2F0Y2ggZm9yIGNoYW5nZXMgYW5kIGJpbmQgdGhlIHR5cGUgdG8gdGhlIGNvcnJlc3BvbmRpbmdcbiAgICAgICAgICAgICAgICAgICAgICAgICAqIHZhbHVlIG9uIGNjRGF0YS5cbiAgICAgICAgICAgICAgICAgICAgICAgICAqL1xuICAgICAgICAgICAgICAgICAgICAgICAgc2NvcGUuJHdhdGNoKGdldERldGVjdGVkQ2NUeXBlLCBzZXRDY1R5cGUpO1xuICAgICAgICAgICAgICAgICAgICB9XG5cbiAgICAgICAgICAgICAgICAgICAgLyoqXG4gICAgICAgICAgICAgICAgICAgICAqIFJldHVybiB0aGUgaHRtbCBmb3IgdGhlIHRvb2x0aXAuIFVzaW5nIG91dGVySFRNTCB0byBhbHNvIGluY2x1ZGUgdGhlIHJvb3QgZWxlbWVudFxuICAgICAgICAgICAgICAgICAgICAgKiBAcmV0dXJuIHtTdHJpbmd9IEh0bWwgc3RyaW5nIGZvciB0aGUgY3Z2IHRvb2x0aXAgdGVtcGxhdGVcbiAgICAgICAgICAgICAgICAgICAgICovXG4gICAgICAgICAgICAgICAgICAgIGZ1bmN0aW9uIGdldEN2dlRvb2x0aXBIdG1sKCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIGN2dlRvb2x0aXBFbGVtZW50WzBdLm91dGVySFRNTDtcbiAgICAgICAgICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAgICAgICAgIC8qKlxuICAgICAgICAgICAgICAgICAgICAgKiBHZXQgdGhlIGRldGVjdGVkIGNyZWRpdCBjYXJkIHR5cGUgZXhwb3NlZCBvbiB0aGUgZm9ybSBjb250cm9sIGJ5IHRoZSBjY051bWJlciBjaGlsZCBkaXJlY3RpdmUuXG4gICAgICAgICAgICAgICAgICAgICAqIFRoaXMgdmFsdWUgd2lsbCBiZSBleHBvc2VkIGFzICRjY0VhZ2VyVHlwZSBvciAkY2NUeXBlIGRlcGVuZGluZyBvbiB3aGV0aGVyIHRoaXMgZmVhdHVyZSBpcyBlbmFibGVkLlxuICAgICAgICAgICAgICAgICAgICAgKiBAcmV0dXJuIHtzdHJpbmd8bnVsbH1cbiAgICAgICAgICAgICAgICAgICAgICovXG4gICAgICAgICAgICAgICAgICAgIGZ1bmN0aW9uIGdldERldGVjdGVkQ2NUeXBlKCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIGlzRWFnZXJUeXBlID8gZm9ybUN0cmwuY2NOdW1iZXIuJGNjRWFnZXJUeXBlIDogZm9ybUN0cmwuY2NOdW1iZXIuJGNjVHlwZTtcbiAgICAgICAgICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAgICAgICAgIC8qKlxuICAgICAgICAgICAgICAgICAgICAgKiBTZXQgY2NEYXRhLmNjVHlwZVxuICAgICAgICAgICAgICAgICAgICAgKiBAcGFyYW0ge3N0cmluZ3xudWxsfSB0eXBlIFRoZSBjcmVkaXQgY2FyZCB0eXBlLCBpLmUuICd2aXNhJ1xuICAgICAgICAgICAgICAgICAgICAgKiBAcmV0dXJuIHtzdHJpbmd8bnVsbH0gdHlwZVxuICAgICAgICAgICAgICAgICAgICAgKi9cbiAgICAgICAgICAgICAgICAgICAgZnVuY3Rpb24gc2V0Q2NUeXBlKHR5cGUpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHNjb3BlLmNjRGF0YS5jY1R5cGUgPSB0eXBlO1xuXG4gICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gdHlwZTtcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIH07XG4gICAgICAgICAgICB9LFxuICAgICAgICAgICAgcmVxdWlyZTogJ15mb3JtJyxcbiAgICAgICAgICAgIHJlc3RyaWN0OiAnRUEnLFxuICAgICAgICAgICAgc2NvcGU6IHtcbiAgICAgICAgICAgICAgICBjY0RhdGE6ICc9JyxcbiAgICAgICAgICAgICAgICBjY0NvbmZpZzogJz0nLFxuICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIHRlbXBsYXRlVXJsOiAnc3JjL2pzL2JpZ2NvbW1lcmNlL2NyZWRpdC1jYXJkL2NyZWRpdC1jYXJkLnRwbC5odG1sJ1xuICAgICAgICB9O1xuICAgIH0pO1xuIiwiYW5ndWxhci5tb2R1bGUoJ2JjYXBwLXBhdHRlcm4tbGFiLmNyZWRpdC1jYXJkJywgW1xuICAgICdjcmVkaXQtY2FyZHMnLFxuICAgICdiY2FwcC1wYXR0ZXJuLWxhYi5jcmVkaXQtY2FyZC5iYy1jdmMnLFxuICAgICdiY2FwcC1wYXR0ZXJuLWxhYi5jcmVkaXQtY2FyZC5jYy1leHBpcnknLFxuICAgICdiY2FwcC1wYXR0ZXJuLWxhYi5jcmVkaXQtY2FyZC5kaXJlY3RpdmUnLFxuICAgICdnZXR0ZXh0Jyxcbl0pO1xuIiwiYW5ndWxhci5tb2R1bGUoJ2JjYXBwLXBhdHRlcm4tbGFiLmNyZWRpdC1jYXJkLXR5cGVzLmNvbnN0YW50JywgW10pXG4gICAgLmNvbnN0YW50KCdDQ19UWVBFUycsIHtcbiAgICAgICAgJ0FtZXJpY2FuIEV4cHJlc3MnOiAnYW1leCcsXG4gICAgICAgICdEaW5lcnMgQ2x1Yic6ICdkaW5lcnNjbHViJyxcbiAgICAgICAgJ0Rpc2NvdmVyJzogJ2Rpc2NvdmVyJyxcbiAgICAgICAgJ01hc3RlckNhcmQnOiAnbWFzdGVyY2FyZCcsXG4gICAgICAgICdWaXNhJzogJ3Zpc2EnLFxuICAgIH0pO1xuIiwiYW5ndWxhci5tb2R1bGUoJ2JjYXBwLXBhdHRlcm4tbGFiLmNyZWRpdC1jYXJkLXR5cGVzLmNvbnRyb2xsZXInLCBbXG4gICAgJ2JjYXBwLXBhdHRlcm4tbGFiLmNyZWRpdC1jYXJkLXR5cGVzLmNvbnN0YW50Jyxcbl0pXG4gICAgLmNvbnRyb2xsZXIoJ0NyZWRpdENhcmRUeXBlc0N0cmwnLCBmdW5jdGlvbiBDcmVkaXRDYXJkVHlwZXNDdHJsKCRlbGVtZW50LCBDQ19UWVBFUykge1xuICAgICAgICBjb25zdCBjdHJsID0gdGhpcztcblxuICAgICAgICBjdHJsLmhhc1NlbGVjdGVkVHlwZSA9IGhhc1NlbGVjdGVkVHlwZTtcbiAgICAgICAgY3RybC5pc1NlbGVjdGVkVHlwZSA9IGlzU2VsZWN0ZWRUeXBlO1xuICAgICAgICBjdHJsLm1hcFRvU3ZnID0gbWFwVG9Tdmc7XG5cbiAgICAgICAgaW5pdCgpO1xuXG4gICAgICAgIGZ1bmN0aW9uIGluaXQoKSB7XG4gICAgICAgICAgICAkZWxlbWVudC5hZGRDbGFzcygnY3JlZGl0Q2FyZFR5cGVzJyk7XG4gICAgICAgIH1cblxuICAgICAgICAvKipcbiAgICAgICAgICogQ2hlY2tzIHdoZXRoZXIgYSB0eXBlIGhhcyBiZWVuIHNlbGVjdGVkIChvciBkZXRlY3RlZCBieSB0aGUgY3JlZGl0LWNhcmQgY29tcG9uZW50KVxuICAgICAgICAgKiBAcmV0dXJuIHtCb29sZWFufVxuICAgICAgICAgKi9cbiAgICAgICAgZnVuY3Rpb24gaGFzU2VsZWN0ZWRUeXBlKCkge1xuICAgICAgICAgICAgcmV0dXJuICFfLmlzRW1wdHkoY3RybC5nZXRTZWxlY3RlZFR5cGUoKSk7XG4gICAgICAgIH1cblxuICAgICAgICAvKipcbiAgICAgICAgICogQ2hlY2tzIGlmIHRoZSBwYXNzZWQgaW4gY2NUeXBlIGlzIHRoZSBzYW1lIGFzIHRoZSBzZWxlY3RlZCBjY1R5cGVcbiAgICAgICAgICogQHBhcmFtIGNjVHlwZSB7U3RyaW5nfVxuICAgICAgICAgKiBAcmV0dXJuIHtCb29sZWFufVxuICAgICAgICAgKi9cbiAgICAgICAgZnVuY3Rpb24gaXNTZWxlY3RlZFR5cGUoY2NUeXBlKSB7XG4gICAgICAgICAgICByZXR1cm4gY2NUeXBlID09PSBjdHJsLmdldFNlbGVjdGVkVHlwZSgpO1xuICAgICAgICB9XG5cbiAgICAgICAgLyoqXG4gICAgICAgICAqIE1hcCB0aGUgY2NUeXBlIHRvIGEgY29ycmVzcG9uZGluZyBzdmcgbmFtZVxuICAgICAgICAgKiBAcGFyYW0gY2NUeXBlIHtTdHJpbmd9XG4gICAgICAgICAqIEByZXR1cm4ge1N0cmluZ31cbiAgICAgICAgICovXG4gICAgICAgIGZ1bmN0aW9uIG1hcFRvU3ZnKGNjVHlwZSkge1xuICAgICAgICAgICAgcmV0dXJuIENDX1RZUEVTW2NjVHlwZV07XG4gICAgICAgIH1cbiAgICB9KTtcbiIsIi8qKlxuICogQG5hbWUgY3JlZGl0LWNhcmQtdHlwZXMgZGlyZWN0aXZlXG4gKiBAZGVzY3JpcHRpb24gQ29tcG9uZW50IGRpc3BsYXlpbmcgYW5kIGdyZXlpbmcgb3V0IGNyZWRpdCBjYXJkIHR5cGUgaWNvbnMgYmFzZWQgb24gdGhlIHNlbGVjdGVkIGNyZWRpdCBjYXJkIHR5cGUuXG4gKiBgLmlzLWFjdGl2ZWAgaXMgYWRkZWQgdG8gdGhlIGNvcnJlc3BvbmRpbmcgc2VsZWN0ZWQgY3JlZGl0IGNhcmQgdHlwZS4gYC5ub3QtYWN0aXZlYCBpcyBhZGRlZCBmb3IgdGhlIG90aGVyXG4gKiB0eXBlcy4gSWYgbm8gY3JlZGl0IGNhcmQgdHlwZXMgaGFzIGJlZW4gc2VsZWN0ZWQsIHRoZW4gbmVpdGhlciBgLmlzLWFjdGl2ZWAgYW5kIGAubm90LWFjdGl2ZWAgd2lsbCBiZSBhZGRlZCBhdCBhbGwuXG4gKlxuICogQHBhcmFtIHNlbGVjdGVkVHlwZSB7U3RyaW5nfSBDcmVkaXQgY2FyZCB0eXBlLiBWYWxpZCB0eXBlcyBhcmUgJ1Zpc2EnLCAnTWFzdGVyQ2FyZCcsICdEaW5lcnMgQ2x1YicsICdEaXNjb3ZlcicsIGFuZCAnQW1lcmljYW4gRXhwcmVzcydcbiAqIEBwYXJhbSBzdXBwb3J0ZWRUeXBlcyB7QXJyYXl9IEFycmF5IG9mIGNyZWRpdCBjYXJkIHR5cGVzIHRvIGRpc3BsYXkuIFRoZSBjYXJkIHR5cGVzIHVzZSB0aGUgc2FtZSBzdHJpbmdzOiAnQW1lcmljYW4gRXhwcmVzcycsICdEaXNjb3ZlcicsICdNYXN0ZXJDYXJkJywgJ1Zpc2EnXG4gKi9cbmFuZ3VsYXIubW9kdWxlKCdiY2FwcC1wYXR0ZXJuLWxhYi5jcmVkaXQtY2FyZC10eXBlcy5kaXJlY3RpdmUnLCBbXG4gICAgJ2JjYXBwLXBhdHRlcm4tbGFiLmNyZWRpdC1jYXJkLXR5cGVzLmNvbnRyb2xsZXInLFxuXSlcbiAgICAuZGlyZWN0aXZlKCdjcmVkaXRDYXJkVHlwZXMnLCBmdW5jdGlvbiBjcmVkaXRDYXJkVHlwZXNEaXJlY3RpdmUoKSB7XG4gICAgICAgIHJldHVybiB7XG4gICAgICAgICAgICBiaW5kVG9Db250cm9sbGVyOiB0cnVlLFxuICAgICAgICAgICAgY29udHJvbGxlcjogJ0NyZWRpdENhcmRUeXBlc0N0cmwgYXMgY3JlZGl0Q2FyZFR5cGVzQ3RybCcsXG4gICAgICAgICAgICByZXN0cmljdDogJ0UnLFxuICAgICAgICAgICAgc2NvcGU6IHtcbiAgICAgICAgICAgICAgICBnZXRTZWxlY3RlZFR5cGU6ICcmc2VsZWN0ZWRUeXBlJyxcbiAgICAgICAgICAgICAgICBnZXRTdXBwb3J0ZWRUeXBlczogJyZzdXBwb3J0ZWRUeXBlcydcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICB0ZW1wbGF0ZVVybDogJ3NyYy9qcy9iaWdjb21tZXJjZS9jcmVkaXQtY2FyZC10eXBlcy9jcmVkaXQtY2FyZC10eXBlcy50cGwuaHRtbCdcbiAgICAgICAgfTtcbiAgICB9KTtcbiIsImFuZ3VsYXIubW9kdWxlKCdiY2FwcC1wYXR0ZXJuLWxhYi5jcmVkaXQtY2FyZC10eXBlcycsIFtcbiAgICAnYmNhcHAtcGF0dGVybi1sYWIuY3JlZGl0LWNhcmQtdHlwZXMuY29uc3RhbnQnLFxuICAgICdiY2FwcC1wYXR0ZXJuLWxhYi5jcmVkaXQtY2FyZC10eXBlcy5jb250cm9sbGVyJyxcbiAgICAnYmNhcHAtcGF0dGVybi1sYWIuY3JlZGl0LWNhcmQtdHlwZXMuZGlyZWN0aXZlJyxcbl0pO1xuIiwiYW5ndWxhci5tb2R1bGUoJ2JjYXBwLXBhdHRlcm4tbGFiLmZvcm0uZGlyZWN0aXZlJywgW10pXG4gICAgLmRpcmVjdGl2ZSgnZm9ybScsIGZ1bmN0aW9uIGZvcm1EaXJlY3RpdmUoKSB7XG4gICAgICAgIHJldHVybiB7XG4gICAgICAgICAgICByZXN0cmljdDogJ0UnLFxuICAgICAgICAgICAgbGluazogZnVuY3Rpb24gZm9ybUxpbmsoc2NvcGUsIGVsZW1lbnQsIGF0dHJzKSB7XG4gICAgICAgICAgICAgICAgZWxlbWVudC5hZGRDbGFzcygnZm9ybScpO1xuICAgICAgICAgICAgICAgIGVsZW1lbnQuYXR0cignbm92YWxpZGF0ZScsICcnKTtcblxuICAgICAgICAgICAgICAgIC8vIFVzZSBkaXNhYmxlLWF1dG8tZm9jdXM9XCJ0cnVlXCIgdG8gdHVybiBvZmYgYXV0b21hdGljIGVycm9yIGZvY3VzaW5nXG4gICAgICAgICAgICAgICAgaWYgKCFhdHRycy5kaXNhYmxlQXV0b0ZvY3VzKSB7XG4gICAgICAgICAgICAgICAgICAgIGVsZW1lbnQub24oJ3N1Ym1pdCcsIGZ1bmN0aW9uIGZvcm1BdXRvRm9jdXNTdWJtaXRIYW5kbGVyKCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgdmFyIGludmFsaWRGaWVsZCA9IGVsZW1lbnRbMF0ucXVlcnlTZWxlY3RvcignLm5nLWludmFsaWQnKTtcblxuICAgICAgICAgICAgICAgICAgICAgICAgaWYgKGludmFsaWRGaWVsZCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGludmFsaWRGaWVsZC5mb2N1cygpO1xuXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgLy8gQXV0by1zZWxlY3QgZXhpc3RpbmcgdGV4dCBmb3IgZmllbGRzIHRoYXQgc3VwcG9ydCBpdCAodGV4dCwgZW1haWwsIHBhc3N3b3JkLCBldGMuKVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmIChpbnZhbGlkRmllbGQuc2VsZWN0KSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGludmFsaWRGaWVsZC5zZWxlY3QoKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgfTtcbiAgICB9KTtcbiIsImFuZ3VsYXIubW9kdWxlKCdiY2FwcC1wYXR0ZXJuLWxhYi5mb3JtJywgW1xuICAgICdiY2FwcC1wYXR0ZXJuLWxhYi5mb3JtLmRpcmVjdGl2ZSdcbl0pO1xuIiwiYW5ndWxhci5tb2R1bGUoJ2JjYXBwLXBhdHRlcm4tbGFiLmZvcm0tZmllbGQuZGlyZWN0aXZlJywgW10pXG4gICAgLmRpcmVjdGl2ZSgnZm9ybUZpZWxkJywgZnVuY3Rpb24gZm9ybUZpZWxkRGlyZWN0aXZlKCRsb2cpIHtcbiAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICAgIHJlcXVpcmU6ICdeZm9ybScsXG4gICAgICAgICAgICByZXN0cmljdDogJ0VBJyxcbiAgICAgICAgICAgIHNjb3BlOiB0cnVlLFxuICAgICAgICAgICAgbGluazoge1xuICAgICAgICAgICAgICAgIHByZTogZnVuY3Rpb24gZm9ybUZpZWxkTGluayhzY29wZSwgZWxlbWVudCwgYXR0cnMpIHtcbiAgICAgICAgICAgICAgICAgICAgLy8gSW5oZXJpdGVkIGJ5IHRoZSBmb3JtLWZpZWxkLWVycm9ycyBkaXJlY3RpdmUgdG8gYXZvaWQgcmVkZWNsYXJhdGlvblxuICAgICAgICAgICAgICAgICAgICBzY29wZS5wcm9wZXJ0eSA9IGF0dHJzLnByb3BlcnR5O1xuICAgICAgICAgICAgICAgIH0sXG5cbiAgICAgICAgICAgICAgICBwb3N0OiBmdW5jdGlvbiBmb3JtRmllbGRMaW5rKHNjb3BlLCBlbGVtZW50LCBhdHRycywgZm9ybUN0cmwpIHtcbiAgICAgICAgICAgICAgICAgICAgLy8gTG9jYXRlcyBhbmQgd2F0Y2hlcyB0aGUgbWF0Y2hpbmcgaW5wdXQvc2VsZWN0L2V0YyAoYmFzZWQgb24gaXRzIG5hbWUgYXR0cmlidXRlKSBpbiB0aGUgcGFyZW50IGZvcm1cbiAgICAgICAgICAgICAgICAgICAgdmFyIHByb3BlcnR5ID0gYXR0cnMucHJvcGVydHksXG4gICAgICAgICAgICAgICAgICAgICAgICBwcm9wZXJ0eVZhbGlkRm4gPSBmdW5jdGlvbiBwcm9wZXJ0eVZhbGlkRm4oKSB7IHJldHVybiBmb3JtQ3RybFtwcm9wZXJ0eV0uJHZhbGlkOyB9LFxuICAgICAgICAgICAgICAgICAgICAgICAgZm9ybVN1Ym1pdHRlZEZuID0gZnVuY3Rpb24gZm9ybVN1Ym1pdHRlZEZuKCkgeyByZXR1cm4gZm9ybUN0cmwuJHN1Ym1pdHRlZDsgfTtcblxuICAgICAgICAgICAgICAgICAgICBlbGVtZW50LmFkZENsYXNzKCdmb3JtLWZpZWxkJyk7XG5cbiAgICAgICAgICAgICAgICAgICAgLy8gSWYgYSBwcm9wZXJ0eSB3YXNuJ3QgcHJvdmlkZWQsIHdlIGNhbid0IGRvIG11Y2ggZWxzZVxuICAgICAgICAgICAgICAgICAgICBpZiAoIXByb3BlcnR5KSB7XG4gICAgICAgICAgICAgICAgICAgICAgICByZXR1cm47XG4gICAgICAgICAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgICAgICAgICAvLyBJZiBhIHByb3BlcnR5IHdhcyBwcm92aWRlZCwgYnV0IG5vIG5nLW1vZGVsIHdhcyBkZWZpbmVkIGZvciB0aGUgZmllbGQsIHZhbGlkYXRpb24gd29uJ3Qgd29ya1xuICAgICAgICAgICAgICAgICAgICBpZiAoIWZvcm1DdHJsW3Byb3BlcnR5XSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuICRsb2cuaW5mbygnRm9ybSBmaWVsZHMgY29udGFpbmluZyBpbnB1dHMgd2l0aG91dCBhbiBuZy1tb2RlbCBwcm9wZXJ0eSB3aWxsIG5vdCBiZSB2YWxpZGF0ZWQnKTtcbiAgICAgICAgICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAgICAgICAgIGluaXQoKTtcblxuICAgICAgICAgICAgICAgICAgICBmdW5jdGlvbiBpbml0KCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgLy8gVXBkYXRlIHRoZSBpbnRlcmZhY2UgaWYgdGhlIGZvcm0gaXMgc3VibWl0dGVkIG9yIHRoZSBwcm9wZXJ0eSdzIHZhbGlkaXR5IHN0YXRlIGNoYW5nZXNcbiAgICAgICAgICAgICAgICAgICAgICAgIHNjb3BlLiR3YXRjaChmb3JtU3VibWl0dGVkRm4sIGNoZWNrVmFsaWRpdHkpO1xuICAgICAgICAgICAgICAgICAgICAgICAgc2NvcGUuJHdhdGNoKHByb3BlcnR5VmFsaWRGbiwgY2hlY2tWYWxpZGl0eSk7XG4gICAgICAgICAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgICAgICAgICBmdW5jdGlvbiBjaGVja1ZhbGlkaXR5KCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgLy8gT25seSBzaG93IGFuIGVycm9yIGlmIHRoZSB1c2VyIGhhcyBhbHJlYWR5IGF0dGVtcHRlZCB0byBzdWJtaXQgdGhlIGZvcm1cbiAgICAgICAgICAgICAgICAgICAgICAgIGVsZW1lbnQudG9nZ2xlQ2xhc3MoJ2Zvcm0tZmllbGQtLWVycm9yJywgZm9ybUN0cmwuJHN1Ym1pdHRlZCAmJiBmb3JtQ3RybFtwcm9wZXJ0eV0uJGludmFsaWQpO1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICB9O1xuICAgIH0pO1xuIiwiYW5ndWxhci5tb2R1bGUoJ2JjYXBwLXBhdHRlcm4tbGFiLmZvcm0tZmllbGQnLCBbXG4gICAgJ2JjYXBwLXBhdHRlcm4tbGFiLmZvcm0tZmllbGQuZGlyZWN0aXZlJyxcbiAgICAnYmNhcHAtcGF0dGVybi1sYWIuZm9ybS1maWVsZC1lcnJvcicsXG4gICAgJ2JjYXBwLXBhdHRlcm4tbGFiLmZvcm0tZmllbGQtZXJyb3JzJ1xuXSk7XG4iLCJhbmd1bGFyLm1vZHVsZSgnYmNhcHAtcGF0dGVybi1sYWIuZm9ybS1maWVsZC1lcnJvci5kaXJlY3RpdmUnLCBbXSlcbiAgICAuZGlyZWN0aXZlKCdmb3JtRmllbGRFcnJvcicsIGZ1bmN0aW9uIGZvcm1GaWVsZEVycm9yRGlyZWN0aXZlKCRjb21waWxlKSB7XG4gICAgICAgIHJldHVybiB7XG4gICAgICAgICAgICBwcmlvcml0eTogMTAsXG4gICAgICAgICAgICByZXBsYWNlOiB0cnVlLFxuICAgICAgICAgICAgcmVzdHJpY3Q6ICdFQScsXG4gICAgICAgICAgICB0ZW1wbGF0ZVVybDogJ3NyYy9qcy9iaWdjb21tZXJjZS9mb3JtLWZpZWxkLWVycm9yL2Zvcm0tZmllbGQtZXJyb3IudHBsLmh0bWwnLFxuICAgICAgICAgICAgdGVybWluYWw6IHRydWUsXG4gICAgICAgICAgICB0cmFuc2NsdWRlOiB0cnVlLFxuICAgICAgICAgICAgY29tcGlsZTogZnVuY3Rpb24gZm9ybUZpZWxkRXJyb3JDb21waWxlKHRFbGVtZW50LCB0QXR0cnMpIHtcbiAgICAgICAgICAgICAgICAvLyBUaGUgdHJhbnNsYXRlIHByb3BlcnR5IHdpcGVzIG91dCBvdXIgbmctbWVzc2FnZSBsb2dpYyBpbiB0aGUgcG9zdCBsaW5rIGZ1bmN0aW9uXG4gICAgICAgICAgICAgICAgLy8gVGhlIHByaW9yaXR5IGFuZCB0ZXJtaW5hbCBwcm9wZXJ0aWVzIGFib3ZlIGVuc3VyZSB0aGlzIGNoZWNrIG9jY3Vyc1xuICAgICAgICAgICAgICAgIGlmICh0RWxlbWVudC5hdHRyKCd0cmFuc2xhdGUnKSAhPT0gdW5kZWZpbmVkKSB7XG4gICAgICAgICAgICAgICAgICAgIHRocm93IG5ldyBTeW50YXhFcnJvcihcbiAgICAgICAgICAgICAgICAgICAgICAgICdUaGUgdHJhbnNsYXRlIGF0dHJpYnV0ZSBjYW5ub3QgYmUgdXNlZCB3aXRoIHRoZSBmb3JtLWZpZWxkLWVycm9yIGRpcmVjdGl2ZS4gJyArXG4gICAgICAgICAgICAgICAgICAgICAgICAnVXNlIHRoZSB0cmFuc2xhdGUgZmlsdGVyIGluc3RlYWQgKGV4YW1wbGU6IHt7IFwibXkgZXJyb3IgbWVzc2FnZVwiIHwgdHJhbnNsYXRlIH19KS4gJyArXG4gICAgICAgICAgICAgICAgICAgICAgICAnVmFsaWRhdG9yOiAnICsgdEF0dHJzLnZhbGlkYXRlXG4gICAgICAgICAgICAgICAgICAgICk7XG4gICAgICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICAgICAgICAgICAgcG9zdDogZnVuY3Rpb24gZm9ybUZpZWxkRXJyb3JQb3N0TGluayhzY29wZSwgZWxlbWVudCwgYXR0cnMsIGNvbnRyb2xsZXJzLCB0cmFuc2NsdWRlKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICBzY29wZS5wcm9wZXJ0eSA9IHNjb3BlLnByb3BlcnR5IHx8IGF0dHJzLnByb3BlcnR5O1xuXG4gICAgICAgICAgICAgICAgICAgICAgICB0cmFuc2NsdWRlKGZ1bmN0aW9uIGZvcm1GaWVsZEVycm9yVHJhbnNjbHVkZShlcnJvckNsb25lKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFyIGxhYmVsRWxlbWVudCA9IGFuZ3VsYXIuZWxlbWVudCgnPGxhYmVsPicpO1xuXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgLy8gbmdNZXNzYWdlIGRvZXNuJ3QgcGxheSB3ZWxsIHdpdGggZHluYW1pYyBtZXNzYWdlIGluc2VydGlvbiwgdHJhbnNsYXRpb24sIG9yXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgLy8gbWVzc2FnZSBleHByZXNzaW9ucywgc28gd2UgYnVpbGQgaXRzIGVsZW1lbnQgdXAgaGVyZSBhbmQgaW5qZWN0IGl0IGludG8gdGhlIERPTVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGxhYmVsRWxlbWVudC5hdHRyKCdmb3InLCBzY29wZS5wcm9wZXJ0eSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgbGFiZWxFbGVtZW50LmF0dHIoJ25nLW1lc3NhZ2UnLCBhdHRycy52YWxpZGF0ZSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgbGFiZWxFbGVtZW50LmF0dHIoJ3JvbGUnLCAnYWxlcnQnKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBsYWJlbEVsZW1lbnQuYWRkQ2xhc3MoJ2Zvcm0taW5saW5lTWVzc2FnZScpO1xuXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgLy8gVGhlIGVycm9yIHNwYW4gc2hvdWxkIGFscmVhZHkgaGF2ZSBhIHRyYW5zbGF0aW9uIHdhdGNoZXIgb24gaXQgYnkgbm93LCB1c2luZyBhIGZpbHRlclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGxhYmVsRWxlbWVudC5hcHBlbmQoZXJyb3JDbG9uZSk7XG5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBlbGVtZW50LmFwcGVuZChsYWJlbEVsZW1lbnQpO1xuXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgJGNvbXBpbGUoZWxlbWVudCkoc2NvcGUpO1xuICAgICAgICAgICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICB9O1xuICAgICAgICAgICAgfVxuICAgICAgICB9O1xuICAgIH0pO1xuIiwiYW5ndWxhci5tb2R1bGUoJ2JjYXBwLXBhdHRlcm4tbGFiLmZvcm0tZmllbGQtZXJyb3InLCBbXG4gICAgJ2JjYXBwLXBhdHRlcm4tbGFiLmZvcm0tZmllbGQtZXJyb3IuZGlyZWN0aXZlJ1xuXSk7XG4iLCJhbmd1bGFyLm1vZHVsZSgnYmNhcHAtcGF0dGVybi1sYWIuZm9ybS1maWVsZC1lcnJvcnMuZGlyZWN0aXZlJywgW10pXG4gICAgLmRpcmVjdGl2ZSgnZm9ybUZpZWxkRXJyb3JzJywgZnVuY3Rpb24gZm9ybUZpZWxkRXJyb3JzRGlyZWN0aXZlKCkge1xuICAgICAgICByZXR1cm4ge1xuICAgICAgICAgICAgcmVwbGFjZTogdHJ1ZSxcbiAgICAgICAgICAgIHJlcXVpcmU6ICdeZm9ybScsXG4gICAgICAgICAgICByZXN0cmljdDogJ0VBJyxcbiAgICAgICAgICAgIHRlbXBsYXRlVXJsOiAnc3JjL2pzL2JpZ2NvbW1lcmNlL2Zvcm0tZmllbGQtZXJyb3JzL2Zvcm0tZmllbGQtZXJyb3JzLnRwbC5odG1sJyxcbiAgICAgICAgICAgIHRyYW5zY2x1ZGU6IHRydWUsXG4gICAgICAgICAgICBsaW5rOiB7XG4gICAgICAgICAgICAgICAgLy8gUHJlLWxpbmsgaXMgcmVxdWlyZWQsIGFzIHdlIGhhdmUgdG8gaW5qZWN0IG91ciBzY29wZSBwcm9wZXJ0aWVzIGJlZm9yZSB0aGUgY2hpbGRcbiAgICAgICAgICAgICAgICAvLyBmb3JtLWZpZWxkLWVycm9yIGRpcmVjdGl2ZSAoYW5kIGl0cyBpbnRlcm5hbCBuZy1tZXNzYWdlIGRpcmVjdGl2ZSdzKSBwb3N0LWxpbmsgZnVuY3Rpb25zXG4gICAgICAgICAgICAgICAgcHJlOiBmdW5jdGlvbiBmb3JtRmllbGRFcnJvcnNQcmVMaW5rKHNjb3BlLCBlbGVtZW50LCBhdHRycywgZm9ybUN0cmwpIHtcbiAgICAgICAgICAgICAgICAgICAgLy8gUHJvcGVydHkgbmFtZSBjYW4gYmUgaW5oZXJpdGVkIGZyb20gcGFyZW50IHNjb3BlLCBzdWNoIGFzIGZyb20gdGhlIGZvcm0tZmllbGQgZGlyZWN0aXZlXG4gICAgICAgICAgICAgICAgICAgIHZhciBwcm9wZXJ0eSA9IHNjb3BlLnByb3BlcnR5IHx8IGF0dHJzLnByb3BlcnR5LFxuICAgICAgICAgICAgICAgICAgICAgICAgcHJvcGVydHlGaWVsZCA9IGZvcm1DdHJsW3Byb3BlcnR5XTtcblxuICAgICAgICAgICAgICAgICAgICAvLyBJbmhlcml0ZWQgYnkgZm9ybS1maWVsZC1lcnJvciBkaXJlY3RpdmUuIExpdmVzIGRpcmVjdGx5IG9uIHNjb3BlIGJlY2F1c2UgdGhlIHJlcXVpcmVcbiAgICAgICAgICAgICAgICAgICAgLy8gcHJvcGVydHkgZG9lcyBub3Qgd29yayB3ZWxsIHdpdGggZGlyZWN0aXZlIGNvbnRyb2xsZXIgaW5zdGFuY2VzXG4gICAgICAgICAgICAgICAgICAgIHNjb3BlLmZvcm1DdHJsID0gZm9ybUN0cmw7XG4gICAgICAgICAgICAgICAgICAgIHNjb3BlLnByb3BlcnR5ID0gcHJvcGVydHk7XG4gICAgICAgICAgICAgICAgICAgIHNjb3BlLnByb3BlcnR5RmllbGQgPSBwcm9wZXJ0eUZpZWxkO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgfTtcbiAgICB9KTtcbiIsImFuZ3VsYXIubW9kdWxlKCdiY2FwcC1wYXR0ZXJuLWxhYi5mb3JtLWZpZWxkLWVycm9ycycsIFtcbiAgICAnYmNhcHAtcGF0dGVybi1sYWIuZm9ybS1maWVsZC1lcnJvcnMuZGlyZWN0aXZlJ1xuXSk7XG4iLCJhbmd1bGFyLm1vZHVsZSgnYmNhcHAtcGF0dGVybi1sYWIuZm9ybS1pbnB1dC1jb2xvci5jb250cm9sbGVyJywgW10pXG5cbiAgICAuY29udHJvbGxlcignRm9ybUlucHV0Q29sb3JDdHJsJywgZnVuY3Rpb24oJGVsZW1lbnQpIHtcbiAgICAgICAgY29uc3QgY3RybCA9IHRoaXM7XG4gICAgICAgIGNvbnN0IGhleENvbG9yUmVnZXggPSAvXiMoKFswLTlhLWZBLUZdezJ9KXszfXwoWzAtOWEtZkEtRl0pezN9KSQvO1xuXG4gICAgICAgIGxldCBpc1Zpc2libGUgPSBmYWxzZTtcblxuICAgICAgICBjdHJsLm9uQ2hhbmdlID0gb25DaGFuZ2U7XG4gICAgICAgIGN0cmwuaGlkZVBpY2tlciA9IGhpZGVQaWNrZXI7XG4gICAgICAgIGN0cmwuaXNQaWNrZXJWaXNpYmxlID0gaXNQaWNrZXJWaXNpYmxlO1xuICAgICAgICBjdHJsLnNldE1vZGVsQ3RybCA9IHNldE1vZGVsQ3RybDtcbiAgICAgICAgY3RybC5zaG93UGlja2VyID0gc2hvd1BpY2tlcjtcbiAgICAgICAgY3RybC51bmlxdWVJZCA9IGdldFVuaXF1ZUlEKCdmb3JtSW5wdXRDb2xvci0nKTtcblxuICAgICAgICBmdW5jdGlvbiBvbkNoYW5nZSgpIHtcbiAgICAgICAgICAgIGlmIChoZXhDb2xvclJlZ2V4LnRlc3QoY3RybC5jb2xvcikpIHtcbiAgICAgICAgICAgICAgICBjdHJsLmxhc3RWYWxpZENvbG9yID0gY3RybC5jb2xvcjtcbiAgICAgICAgICAgICAgICBjdHJsLm5nTW9kZWxDdHJsLiRzZXRWaWV3VmFsdWUoY3RybC5jb2xvcik7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cblxuICAgICAgICBmdW5jdGlvbiBnZXRVbmlxdWVJRChpZFByZWZpeCkge1xuICAgICAgICAgICAgcmV0dXJuIF8udW5pcXVlSWQoaWRQcmVmaXgpO1xuICAgICAgICB9XG5cbiAgICAgICAgZnVuY3Rpb24gaXNQaWNrZXJWaXNpYmxlKGlzVmlzaWJsZVRvU2V0KSB7XG4gICAgICAgICAgICBpZiAoaXNWaXNpYmxlVG9TZXQgIT09IHVuZGVmaW5lZCkge1xuICAgICAgICAgICAgICAgIGlzVmlzaWJsZSA9IGlzVmlzaWJsZVRvU2V0O1xuICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICByZXR1cm4gaXNWaXNpYmxlO1xuICAgICAgICB9XG5cbiAgICAgICAgZnVuY3Rpb24gaGlkZVBpY2tlcigkZXZlbnQpIHtcbiAgICAgICAgICAgIGlmICgkZWxlbWVudFswXS5jb250YWlucygkZXZlbnQudGFyZ2V0KSkge1xuICAgICAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgY3RybC5pc1BpY2tlclZpc2libGUoZmFsc2UpO1xuICAgICAgICB9XG5cbiAgICAgICAgZnVuY3Rpb24gcmVuZGVyKCkge1xuICAgICAgICAgICAgY3RybC5jb2xvciA9IGN0cmwubmdNb2RlbEN0cmwuJHZpZXdWYWx1ZTtcbiAgICAgICAgICAgIGN0cmwubGFzdFZhbGlkQ29sb3IgPSBjdHJsLmNvbG9yO1xuICAgICAgICB9XG5cbiAgICAgICAgZnVuY3Rpb24gc2V0TW9kZWxDdHJsKG5nTW9kZWxDdHJsKSB7XG4gICAgICAgICAgICBjdHJsLm5nTW9kZWxDdHJsID0gbmdNb2RlbEN0cmw7XG4gICAgICAgICAgICBjdHJsLm5nTW9kZWxDdHJsLiRyZW5kZXIgPSByZW5kZXI7XG4gICAgICAgIH1cblxuICAgICAgICBmdW5jdGlvbiBzaG93UGlja2VyKCRldmVudCkge1xuICAgICAgICAgICAgJGV2ZW50LnByZXZlbnREZWZhdWx0KCk7XG5cbiAgICAgICAgICAgIGN0cmwuaXNQaWNrZXJWaXNpYmxlKHRydWUpO1xuICAgICAgICB9XG4gICAgfSk7XG4iLCJhbmd1bGFyLm1vZHVsZSgnYmNhcHAtcGF0dGVybi1sYWIuZm9ybS1pbnB1dC1jb2xvci5kaXJlY3RpdmUnLCBbXG4gICAgJ2JjYXBwLXBhdHRlcm4tbGFiLmZvcm0taW5wdXQtY29sb3IuY29udHJvbGxlcicsXG5dKVxuXG4gICAgLmRpcmVjdGl2ZSgnZm9ybUlucHV0Q29sb3InLCBmdW5jdGlvbiBmb3JtSW5wdXRDb2xvckRpcmVjdGl2ZSgkZG9jdW1lbnQpIHtcbiAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICAgIGJpbmRUb0NvbnRyb2xsZXI6IHRydWUsXG4gICAgICAgICAgICBjb250cm9sbGVyOiAnRm9ybUlucHV0Q29sb3JDdHJsJyxcbiAgICAgICAgICAgIGNvbnRyb2xsZXJBczogJ2Zvcm1JbnB1dENvbG9yQ3RybCcsXG4gICAgICAgICAgICByZXF1aXJlOiBbJ2Zvcm1JbnB1dENvbG9yJywgJ15uZ01vZGVsJ10sXG4gICAgICAgICAgICByZXN0cmljdDogJ0UnLFxuICAgICAgICAgICAgc2NvcGU6IHtcbiAgICAgICAgICAgICAgICBsYWJlbFRleHQ6ICc9JyxcbiAgICAgICAgICAgICAgICBwYWxldHRlOiAnPScsXG4gICAgICAgICAgICAgICAgcGxhY2Vob2xkZXJUZXh0OiAnPScsXG4gICAgICAgICAgICB9LFxuICAgICAgICAgICAgdGVtcGxhdGVVcmw6ICdzcmMvanMvYmlnY29tbWVyY2UvZm9ybS1pbnB1dC1jb2xvci9mb3JtLWlucHV0LWNvbG9yLnRwbC5odG1sJyxcblxuICAgICAgICAgICAgY29tcGlsZTogZnVuY3Rpb24gZm9ybUlucHV0Q29sb3JEaXJlY3RpdmVDb21waWxlKHRFbGVtZW50KSB7XG4gICAgICAgICAgICAgICAgdEVsZW1lbnQuYWRkQ2xhc3MoJ2Zvcm0taW5wdXRDb2xvcicpO1xuXG4gICAgICAgICAgICAgICAgcmV0dXJuIGZ1bmN0aW9uIGZvcm1JbnB1dENvbG9yRGlyZWN0aXZlTGluaygkc2NvcGUsIGVsZW1lbnQsIGF0dHJzLCBjdHJscykge1xuICAgICAgICAgICAgICAgICAgICBjb25zdCBjdHJsID0gY3RybHNbMF07XG4gICAgICAgICAgICAgICAgICAgIGNvbnN0IG5nTW9kZWxDdHJsID0gY3RybHNbMV07XG5cbiAgICAgICAgICAgICAgICAgICAgY3RybC5zZXRNb2RlbEN0cmwobmdNb2RlbEN0cmwpO1xuXG4gICAgICAgICAgICAgICAgICAgICRkb2N1bWVudC5vbignbW91c2Vkb3duJywgZnVuY3Rpb24gaGlkZVBpY2tlcihldmVudCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgJHNjb3BlLiRhcHBseShmdW5jdGlvbigpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjdHJsLmhpZGVQaWNrZXIoZXZlbnQpO1xuICAgICAgICAgICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICAgIH07XG4gICAgICAgICAgICB9XG4gICAgICAgIH07XG4gICAgfSk7XG4iLCJhbmd1bGFyLm1vZHVsZSgnYmNhcHAtcGF0dGVybi1sYWIuZm9ybS1pbnB1dC1jb2xvcicsIFtcbiAgICAnYmNhcHAtcGF0dGVybi1sYWIuZm9ybS1pbnB1dC1jb2xvci5kaXJlY3RpdmUnXG5dKTtcbiIsImFuZ3VsYXIubW9kdWxlKCdiY2FwcC1wYXR0ZXJuLWxhYi5odG1sNU1vZGUnLCBbXG4gICAgJ2JjYXBwLXBhdHRlcm4tbGFiLmh0bWw1TW9kZS5zZXJ2aWNlJ1xuXSk7XG4iLCJhbmd1bGFyLm1vZHVsZSgnYmNhcHAtcGF0dGVybi1sYWIuaHRtbDVNb2RlLnNlcnZpY2UnLCBbXSlcbiAgICAucHJvdmlkZXIoJ2h0bWw1TW9kZScsIGZ1bmN0aW9uIGh0bWw1TW9kZVByb3ZpZGVyKCRsb2NhdGlvblByb3ZpZGVyKSB7XG4gICAgICAgIHRoaXMuJGdldCA9IGZ1bmN0aW9uIGh0bWw1TW9kZVNlcnZpY2UoKSB7XG4gICAgICAgICAgICByZXR1cm4gJGxvY2F0aW9uUHJvdmlkZXIuaHRtbDVNb2RlKCk7XG4gICAgICAgIH07XG4gICAgfSk7XG4iLCJhbmd1bGFyLm1vZHVsZSgnYmNhcHAtcGF0dGVybi1sYWIuaWNvbi5jb250cm9sbGVyJywgW1xuICAgICdiY2FwcC1wYXR0ZXJuLWxhYi5pY29uLnN2Z1Jvb3RQYXRoJ1xuXSlcbiAgICAuY29udHJvbGxlcignSWNvbkN0cmwnLCBmdW5jdGlvbiBpY29uRGlyZWN0aXZlQ29udHJvbGxlcigkaHR0cCwgJHRlbXBsYXRlQ2FjaGUsIHN2Z1Jvb3RQYXRoKSB7XG4gICAgICAgIHZhciBjdHJsID0gdGhpcztcblxuICAgICAgICBjdHJsLnVwZGF0ZUdseXBoID0gdXBkYXRlR2x5cGg7XG5cbiAgICAgICAgZnVuY3Rpb24gdXBkYXRlR2x5cGgoZ2x5cGgpIHtcbiAgICAgICAgICAgIHZhciBmdWxsU3ZnUGF0aCA9IHN2Z1Jvb3RQYXRoICsgZ2x5cGggKyAnLnN2Zyc7XG5cbiAgICAgICAgICAgIHJldHVybiAkaHR0cC5nZXQoZnVsbFN2Z1BhdGgsIHsgY2FjaGU6ICR0ZW1wbGF0ZUNhY2hlIH0pXG4gICAgICAgICAgICAgICAgLnRoZW4oZnVuY3Rpb24gaWNvbkRpcmVjdGl2ZUh0dHBTdWNjZXNzKHJlc3BvbnNlKSB7XG4gICAgICAgICAgICAgICAgICAgIHJldHVybiByZXNwb25zZS5kYXRhO1xuICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICB9XG4gICAgfSk7XG4iLCIvKipcbiAqIEBkZXNjcmlwdGlvbiBJY29uIGRpcmVjdGl2ZSB1c2VkIHRvIGxvYWQgYW4gaW5saW5lIHN2ZyBpY29uLCBzaW1saWFyIHRvIGljb25cbiAqICAgICAgICAgICAgICBmb250IG1ldGhvZHMgb2YgcGFzdCA8aSBjbGFzcz1cImljb24tZm9vLWJhclwiPjwvaT5cbiAqIEBleGFtcGxlXG4gKiA8aWNvbiBnbHlwaD1cImljLWFkZC1jaXJjbGVcIj48L2ljb24+XG4gKi9cbmFuZ3VsYXIubW9kdWxlKCdiY2FwcC1wYXR0ZXJuLWxhYi5pY29uLmRpcmVjdGl2ZScsIFtcbiAgICAnYmNhcHAtcGF0dGVybi1sYWIuaWNvbi5jb250cm9sbGVyJ1xuXSlcbiAgICAuZGlyZWN0aXZlKCdpY29uJywgZnVuY3Rpb24gaWNvbkRpcmVjdGl2ZSgpIHtcbiAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICAgIGJpbmRUb0NvbnRyb2xsZXI6IHRydWUsXG4gICAgICAgICAgICBjb250cm9sbGVyOiAnSWNvbkN0cmwgYXMgaWNvbkN0cmwnLFxuICAgICAgICAgICAgcmVzdHJpY3Q6ICdFJyxcbiAgICAgICAgICAgIHNjb3BlOiB7XG4gICAgICAgICAgICAgICAgZ2x5cGg6ICdAJ1xuICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIGNvbXBpbGU6IGZ1bmN0aW9uIGljb25EaXJlY3RpdmVDb21waWxlKHRFbGVtZW50KSB7XG4gICAgICAgICAgICAgICAgdEVsZW1lbnQuYWRkQ2xhc3MoJ2ljb24nKTtcbiAgICAgICAgICAgICAgICB0RWxlbWVudC5hdHRyKCdhcmlhLWhpZGRlbicsIHRydWUpO1xuXG4gICAgICAgICAgICAgICAgcmV0dXJuIGZ1bmN0aW9uIGljb25EaXJlY3RpdmVMaW5rKCRzY29wZSwgZWxlbWVudCwgYXR0cnMsIGN0cmwpIHtcbiAgICAgICAgICAgICAgICAgICAgJHNjb3BlLiR3YXRjaCgnaWNvbkN0cmwuZ2x5cGgnLCBmdW5jdGlvbiBpY29uRGlyZWN0aXZlTGlua1dhdGNoKG5ld1ZhbHVlKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICBjdHJsLnVwZGF0ZUdseXBoKG5ld1ZhbHVlKVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIC50aGVuKGZ1bmN0aW9uIGljb25VcGRhdGVHbHlwaFRoZW4oc3ZnKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGVsZW1lbnQuaHRtbChzdmcpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgICB9O1xuICAgICAgICAgICAgfVxuICAgICAgICB9O1xuICAgIH0pO1xuIiwiYW5ndWxhci5tb2R1bGUoJ2JjYXBwLXBhdHRlcm4tbGFiLmljb24nLCBbXG4gICAgJ2JjYXBwLXBhdHRlcm4tbGFiLmljb24uZGlyZWN0aXZlJ1xuXSk7XG4iLCJhbmd1bGFyLm1vZHVsZSgnYmNhcHAtcGF0dGVybi1sYWIuaWNvbi5zdmdSb290UGF0aCcsIFtdKVxuICAgIC5wcm92aWRlcignc3ZnUm9vdFBhdGgnLCBmdW5jdGlvbiBzdmdSb290UGF0aFByb3ZpZGVyQ29uZmlnKCkge1xuICAgICAgICB0aGlzLnNldFJvb3RQYXRoID0gc2V0Um9vdFBhdGg7XG4gICAgICAgIHRoaXMuJGdldCA9IGZ1bmN0aW9uIHN2Z1Jvb3RQYXRoUHJvdmlkZXJHZXQoJGxvZykge1xuICAgICAgICAgICAgaWYgKHRoaXMuc3ZnUm9vdFBhdGggPT09IHVuZGVmaW5lZCkge1xuICAgICAgICAgICAgICAgICRsb2cuZXJyb3IoJ05vIHN2Z1Jvb3RQYXRoIHByb3ZpZGVkLiBQbGVhc2UgY29uZmlndXJlIHRoaXMgdXNpbmcgdGhlIHN2Z1Jvb3RQYXRoUHJvdmlkZXInKTtcbiAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgcmV0dXJuIHRoaXMuc3ZnUm9vdFBhdGg7XG4gICAgICAgIH07XG5cbiAgICAgICAgZnVuY3Rpb24gc2V0Um9vdFBhdGgobmV3Um9vdFBhdGgpIHtcbiAgICAgICAgICAgIHRoaXMuc3ZnUm9vdFBhdGggPSBuZXdSb290UGF0aDtcbiAgICAgICAgfVxuICAgIH0pO1xuIiwiYW5ndWxhci5tb2R1bGUoJ2JjYXBwLXBhdHRlcm4tbGFiLmxvYWRpbmctbm90aWZpY2F0aW9uLmRpcmVjdGl2ZScsIFtdKVxuICAgIC5kaXJlY3RpdmUoJ2xvYWRpbmdOb3RpZmljYXRpb24nLCBmdW5jdGlvbiBsb2FkaW5nTm90aWZpY2F0aW9uRGlyZWN0aXZlKCRyb290U2NvcGUpIHtcbiAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICAgIHJlc3RyaWN0OiAnRScsXG4gICAgICAgICAgICB0ZW1wbGF0ZVVybDogJ3NyYy9qcy9iaWdjb21tZXJjZS9sb2FkaW5nLW5vdGlmaWNhdGlvbi9sb2FkaW5nLW5vdGlmaWNhdGlvbi50cGwuaHRtbCcsXG5cbiAgICAgICAgICAgIGxpbms6IGZ1bmN0aW9uKHNjb3BlKSB7XG4gICAgICAgICAgICAgICAgJHJvb3RTY29wZS4kb24oJ2FqYXhSZXF1ZXN0UnVubmluZycsIGZ1bmN0aW9uKGV2ZW50LCB2YWwpIHtcbiAgICAgICAgICAgICAgICAgICAgc2NvcGUucmVxdWVzdEluUHJvZ3Jlc3MgPSB2YWw7XG4gICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICB9XG4gICAgICAgIH07XG4gICAgfSk7XG4iLCJhbmd1bGFyLm1vZHVsZSgnYmNhcHAtcGF0dGVybi1sYWIubG9hZGluZy1ub3RpZmljYXRpb24nLCBbXG4gICAgJ2JjYXBwLXBhdHRlcm4tbGFiLmxvYWRpbmctbm90aWZpY2F0aW9uLmRpcmVjdGl2ZSdcbl0pO1xuIiwiYW5ndWxhci5tb2R1bGUoJ2JjYXBwLXBhdHRlcm4tbGFiLmxvYWRpbmctb3ZlcmxheS5jb250cm9sbGVyJywgW10pXG4gICAgLmNvbnRyb2xsZXIoJ0xvYWRpbmdPdmVybGF5Q3RybCcsIGZ1bmN0aW9uIExvYWRpbmdPdmVybGF5Q3RybCgkcm9vdFNjb3BlLCAkdGltZW91dCkge1xuICAgICAgICB2YXIgY3RybCA9IHRoaXMsXG4gICAgICAgICAgICBkZWZhdWx0RGVib3VuY2UgPSAxMDAsXG4gICAgICAgICAgICB0aW1lb3V0O1xuXG4gICAgICAgIGlmIChjdHJsLmRlYm91bmNlID09PSB1bmRlZmluZWQpIHtcbiAgICAgICAgICAgIGN0cmwuZGVib3VuY2UgPSBkZWZhdWx0RGVib3VuY2U7XG4gICAgICAgIH1cblxuICAgICAgICBpZiAoY3RybC51c2VVaVJvdXRlcikge1xuICAgICAgICAgICAgJHJvb3RTY29wZS4kb24oJyRzdGF0ZUNoYW5nZVN0YXJ0Jywgc3RhcnRMb2FkaW5nKTtcbiAgICAgICAgICAgICRyb290U2NvcGUuJG9uKCckc3RhdGVDaGFuZ2VTdWNjZXNzJywgc3RvcExvYWRpbmcpO1xuICAgICAgICAgICAgJHJvb3RTY29wZS4kb24oJyRzdGF0ZUNoYW5nZUVycm9yJywgc3RvcExvYWRpbmcpO1xuICAgICAgICB9XG5cbiAgICAgICAgZnVuY3Rpb24gc3RhcnRMb2FkaW5nKGV2ZW50KSB7XG4gICAgICAgICAgICBpZiAoZXZlbnQuZGVmYXVsdFByZXZlbnRlZCkge1xuICAgICAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgdGltZW91dCA9ICR0aW1lb3V0KGZ1bmN0aW9uIHN0YXJ0TG9hZGluZ1RpbWVyKCkge1xuICAgICAgICAgICAgICAgIGN0cmwubG9hZGluZyA9IHRydWU7XG4gICAgICAgICAgICB9LCBjdHJsLmRlYm91bmNlKTtcbiAgICAgICAgfVxuXG4gICAgICAgIGZ1bmN0aW9uIHN0b3BMb2FkaW5nKGV2ZW50KSB7XG4gICAgICAgICAgICBpZiAoZXZlbnQuZGVmYXVsdFByZXZlbnRlZCkge1xuICAgICAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgJHRpbWVvdXQuY2FuY2VsKHRpbWVvdXQpO1xuICAgICAgICAgICAgY3RybC5sb2FkaW5nID0gZmFsc2U7XG4gICAgICAgIH1cbiAgICB9KTtcbiIsImFuZ3VsYXIubW9kdWxlKCdiY2FwcC1wYXR0ZXJuLWxhYi5sb2FkaW5nLW92ZXJsYXkuZGlyZWN0aXZlJywgW1xuICAgICdiY2FwcC1wYXR0ZXJuLWxhYi5sb2FkaW5nLW92ZXJsYXkuY29udHJvbGxlcidcbl0pXG4gICAgLmRpcmVjdGl2ZSgnbG9hZGluZ092ZXJsYXknLCBmdW5jdGlvbiBsb2FkaW5nT3ZlcmxheSgkY29tcGlsZSkge1xuICAgICAgICByZXR1cm4ge1xuICAgICAgICAgICAgYmluZFRvQ29udHJvbGxlcjogdHJ1ZSxcbiAgICAgICAgICAgIGNvbnRyb2xsZXI6ICdMb2FkaW5nT3ZlcmxheUN0cmwgYXMgbG9hZGluZ092ZXJsYXlDdHJsJyxcbiAgICAgICAgICAgIHJlc3RyaWN0OiAnQScsXG4gICAgICAgICAgICBzY29wZToge1xuICAgICAgICAgICAgICAgIGRlYm91bmNlOiAnPT8nLFxuICAgICAgICAgICAgICAgIGxvYWRpbmc6ICc9P2xvYWRpbmdPdmVybGF5JyxcbiAgICAgICAgICAgICAgICB1c2VVaVJvdXRlcjogJz0/J1xuICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIGNvbXBpbGU6IGZ1bmN0aW9uIGxvYWRpbmdPdmVybGF5Q29tcGlsZShlbGVtZW50KSB7XG4gICAgICAgICAgICAgICAgZWxlbWVudC5hZGRDbGFzcygnbG9hZGluZ092ZXJsYXktY29udGFpbmVyJyk7XG5cbiAgICAgICAgICAgICAgICByZXR1cm4gZnVuY3Rpb24gbG9hZGluZ092ZXJsYXlMaW5rKHNjb3BlLCBlbGVtZW50KSB7XG4gICAgICAgICAgICAgICAgICAgIGNvbnN0IG92ZXJsYXkgPSAkY29tcGlsZSgnPGRpdiBjbGFzcz1cImxvYWRpbmdPdmVybGF5XCIgbmctaWY9XCJsb2FkaW5nT3ZlcmxheUN0cmwubG9hZGluZ1wiPjwvZGl2PicpKHNjb3BlKTtcbiAgICAgICAgICAgICAgICAgICAgZWxlbWVudC5hcHBlbmQob3ZlcmxheSk7XG4gICAgICAgICAgICAgICAgfTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfTtcbiAgICB9KTtcbiIsImFuZ3VsYXIubW9kdWxlKCdiY2FwcC1wYXR0ZXJuLWxhYi5sb2FkaW5nLW92ZXJsYXknLCBbXG4gICAgJ2JjYXBwLXBhdHRlcm4tbGFiLmxvYWRpbmctb3ZlcmxheS5kaXJlY3RpdmUnXG5dKTtcbiIsIi8qXG4gKiBPdmVycmlkZSBhbmd1bGFyIGZvdW5kYXRpb24ncyAkbW9kYWxTdGFjayBzZXJ2aWNlIHRvIHJlbW92ZSB0aGUgYHRvcGAgY3NzIHByb3BlcnR5LlxuICogY2Fubm90IHVzZSBhIGRlY29yYXRvciBiZWNhdXNlIHRoZSBgb3BlbmAgcmVsaWVzIG9uIGNsb3N1cmVzIGFuZCBkb2VzIG5vdCByZXR1cm4gdGhlIGNvbXBpbGVkIGVsZW1lbnQuXG4gKiBDaGFuZ2VzIGFyZSBiZXR3ZWVuIGAvLyBDaGFuZ2VzYCBjb21tZW50c1xuKi9cbmFuZ3VsYXIubW9kdWxlKCdiY2FwcC1wYXR0ZXJuLWxhYi5iYy1tb2RhbC5tb2RhbFN0YWNrLnNlcnZpY2UnLCBbXG5cbl0pXG4gIC5mYWN0b3J5KCckbW9kYWxTdGFjaycsIFsnJHdpbmRvdycsICckdHJhbnNpdGlvbicsICckdGltZW91dCcsICckZG9jdW1lbnQnLCAnJGNvbXBpbGUnLCAnJHJvb3RTY29wZScsICckJHN0YWNrZWRNYXAnLFxuICAgIGZ1bmN0aW9uICgkd2luZG93LCAkdHJhbnNpdGlvbiwgJHRpbWVvdXQsICRkb2N1bWVudCwgJGNvbXBpbGUsICRyb290U2NvcGUsICQkc3RhY2tlZE1hcCkge1xuICAgICAgLy8gQ2hhbmdlczogY2hhbmdlIGZyb20gYG1vZGFsLW9wZW5gIHRvIGBoYXMtYWN0aXZlTW9kYWxgXG4gICAgICB2YXIgT1BFTkVEX01PREFMX0NMQVNTID0gJ2hhcy1hY3RpdmVNb2RhbCc7XG4gICAgICAvLyBDaGFuZ2VzXG5cbiAgICAgIHZhciBiYWNrZHJvcERvbUVsLCBiYWNrZHJvcFNjb3BlO1xuICAgICAgdmFyIG9wZW5lZFdpbmRvd3MgPSAkJHN0YWNrZWRNYXAuY3JlYXRlTmV3KCk7XG4gICAgICB2YXIgJG1vZGFsU3RhY2sgPSB7fTtcblxuICAgICAgZnVuY3Rpb24gYmFja2Ryb3BJbmRleCgpIHtcbiAgICAgICAgdmFyIHRvcEJhY2tkcm9wSW5kZXggPSAtMTtcbiAgICAgICAgdmFyIG9wZW5lZCA9IG9wZW5lZFdpbmRvd3Mua2V5cygpO1xuICAgICAgICBmb3IgKHZhciBpID0gMDsgaSA8IG9wZW5lZC5sZW5ndGg7IGkrKykge1xuICAgICAgICAgIGlmIChvcGVuZWRXaW5kb3dzLmdldChvcGVuZWRbaV0pLnZhbHVlLmJhY2tkcm9wKSB7XG4gICAgICAgICAgICB0b3BCYWNrZHJvcEluZGV4ID0gaTtcbiAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIHRvcEJhY2tkcm9wSW5kZXg7XG4gICAgICB9XG5cbiAgICAgICRyb290U2NvcGUuJHdhdGNoKGJhY2tkcm9wSW5kZXgsIGZ1bmN0aW9uKG5ld0JhY2tkcm9wSW5kZXgpe1xuICAgICAgICBpZiAoYmFja2Ryb3BTY29wZSkge1xuICAgICAgICAgIGJhY2tkcm9wU2NvcGUuaW5kZXggPSBuZXdCYWNrZHJvcEluZGV4O1xuICAgICAgICB9XG4gICAgICB9KTtcblxuICAgICAgZnVuY3Rpb24gcmVtb3ZlTW9kYWxXaW5kb3cobW9kYWxJbnN0YW5jZSkge1xuICAgICAgICB2YXIgYm9keSA9ICRkb2N1bWVudC5maW5kKCdib2R5JykuZXEoMCk7XG4gICAgICAgIHZhciBtb2RhbFdpbmRvdyA9IG9wZW5lZFdpbmRvd3MuZ2V0KG1vZGFsSW5zdGFuY2UpLnZhbHVlO1xuXG4gICAgICAgIC8vY2xlYW4gdXAgdGhlIHN0YWNrXG4gICAgICAgIG9wZW5lZFdpbmRvd3MucmVtb3ZlKG1vZGFsSW5zdGFuY2UpO1xuXG4gICAgICAgIC8vcmVtb3ZlIHdpbmRvdyBET00gZWxlbWVudFxuICAgICAgICByZW1vdmVBZnRlckFuaW1hdGUobW9kYWxXaW5kb3cubW9kYWxEb21FbCwgbW9kYWxXaW5kb3cubW9kYWxTY29wZSwgMzAwLCBmdW5jdGlvbigpIHtcbiAgICAgICAgICBtb2RhbFdpbmRvdy5tb2RhbFNjb3BlLiRkZXN0cm95KCk7XG4gICAgICAgICAgYm9keS50b2dnbGVDbGFzcyhPUEVORURfTU9EQUxfQ0xBU1MsIG9wZW5lZFdpbmRvd3MubGVuZ3RoKCkgPiAwKTtcbiAgICAgICAgICBjaGVja1JlbW92ZUJhY2tkcm9wKCk7XG4gICAgICAgIH0pO1xuICAgICAgfVxuXG4gICAgICBmdW5jdGlvbiBjaGVja1JlbW92ZUJhY2tkcm9wKCkge1xuICAgICAgICAvL3JlbW92ZSBiYWNrZHJvcCBpZiBubyBsb25nZXIgbmVlZGVkXG4gICAgICAgIGlmIChiYWNrZHJvcERvbUVsICYmIGJhY2tkcm9wSW5kZXgoKSA9PSAtMSkge1xuICAgICAgICAgIHZhciBiYWNrZHJvcFNjb3BlUmVmID0gYmFja2Ryb3BTY29wZTtcbiAgICAgICAgICByZW1vdmVBZnRlckFuaW1hdGUoYmFja2Ryb3BEb21FbCwgYmFja2Ryb3BTY29wZSwgMTUwLCBmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICBiYWNrZHJvcFNjb3BlUmVmLiRkZXN0cm95KCk7XG4gICAgICAgICAgICBiYWNrZHJvcFNjb3BlUmVmID0gbnVsbDtcbiAgICAgICAgICB9KTtcbiAgICAgICAgICBiYWNrZHJvcERvbUVsID0gdW5kZWZpbmVkO1xuICAgICAgICAgIGJhY2tkcm9wU2NvcGUgPSB1bmRlZmluZWQ7XG4gICAgICAgIH1cbiAgICAgIH1cblxuICAgICAgZnVuY3Rpb24gcmVtb3ZlQWZ0ZXJBbmltYXRlKGRvbUVsLCBzY29wZSwgZW11bGF0ZVRpbWUsIGRvbmUpIHtcbiAgICAgICAgLy8gQ2xvc2luZyBhbmltYXRpb25cbiAgICAgICAgc2NvcGUuYW5pbWF0ZSA9IGZhbHNlO1xuXG4gICAgICAgIHZhciB0cmFuc2l0aW9uRW5kRXZlbnROYW1lID0gJHRyYW5zaXRpb24udHJhbnNpdGlvbkVuZEV2ZW50TmFtZTtcbiAgICAgICAgaWYgKHRyYW5zaXRpb25FbmRFdmVudE5hbWUpIHtcbiAgICAgICAgICAvLyB0cmFuc2l0aW9uIG91dFxuICAgICAgICAgIHZhciB0aW1lb3V0ID0gJHRpbWVvdXQoYWZ0ZXJBbmltYXRpbmcsIGVtdWxhdGVUaW1lKTtcblxuICAgICAgICAgIGRvbUVsLmJpbmQodHJhbnNpdGlvbkVuZEV2ZW50TmFtZSwgZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgJHRpbWVvdXQuY2FuY2VsKHRpbWVvdXQpO1xuICAgICAgICAgICAgYWZ0ZXJBbmltYXRpbmcoKTtcbiAgICAgICAgICAgIHNjb3BlLiRhcHBseSgpO1xuICAgICAgICAgIH0pO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgIC8vIEVuc3VyZSB0aGlzIGNhbGwgaXMgYXN5bmNcbiAgICAgICAgICAkdGltZW91dChhZnRlckFuaW1hdGluZywgMCk7XG4gICAgICAgIH1cblxuICAgICAgICBmdW5jdGlvbiBhZnRlckFuaW1hdGluZygpIHtcbiAgICAgICAgICBpZiAoYWZ0ZXJBbmltYXRpbmcuZG9uZSkge1xuICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICAgIH1cbiAgICAgICAgICBhZnRlckFuaW1hdGluZy5kb25lID0gdHJ1ZTtcblxuICAgICAgICAgIGRvbUVsLnJlbW92ZSgpO1xuICAgICAgICAgIGlmIChkb25lKSB7XG4gICAgICAgICAgICBkb25lKCk7XG4gICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICB9XG5cbiAgICAgICRkb2N1bWVudC5iaW5kKCdrZXlkb3duJywgZnVuY3Rpb24gKGV2dCkge1xuICAgICAgICB2YXIgbW9kYWw7XG5cbiAgICAgICAgaWYgKGV2dC53aGljaCA9PT0gMjcpIHtcbiAgICAgICAgICBtb2RhbCA9IG9wZW5lZFdpbmRvd3MudG9wKCk7XG4gICAgICAgICAgaWYgKG1vZGFsICYmIG1vZGFsLnZhbHVlLmtleWJvYXJkKSB7XG4gICAgICAgICAgICAkcm9vdFNjb3BlLiRhcHBseShmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICAgICRtb2RhbFN0YWNrLmRpc21pc3MobW9kYWwua2V5KTtcbiAgICAgICAgICAgIH0pO1xuICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgfSk7XG5cbiAgICAgICRtb2RhbFN0YWNrLm9wZW4gPSBmdW5jdGlvbiAobW9kYWxJbnN0YW5jZSwgbW9kYWwpIHtcblxuICAgICAgICBvcGVuZWRXaW5kb3dzLmFkZChtb2RhbEluc3RhbmNlLCB7XG4gICAgICAgICAgZGVmZXJyZWQ6IG1vZGFsLmRlZmVycmVkLFxuICAgICAgICAgIG1vZGFsU2NvcGU6IG1vZGFsLnNjb3BlLFxuICAgICAgICAgIGJhY2tkcm9wOiBtb2RhbC5iYWNrZHJvcCxcbiAgICAgICAgICBrZXlib2FyZDogbW9kYWwua2V5Ym9hcmRcbiAgICAgICAgfSk7XG5cbiAgICAgICAgdmFyIGJvZHkgPSAkZG9jdW1lbnQuZmluZCgnYm9keScpLmVxKDApLFxuICAgICAgICAgICAgY3VyckJhY2tkcm9wSW5kZXggPSBiYWNrZHJvcEluZGV4KCk7XG5cbiAgICAgICAgaWYgKGN1cnJCYWNrZHJvcEluZGV4ID49IDAgJiYgIWJhY2tkcm9wRG9tRWwpIHtcbiAgICAgICAgICBiYWNrZHJvcFNjb3BlID0gJHJvb3RTY29wZS4kbmV3KHRydWUpO1xuICAgICAgICAgIGJhY2tkcm9wU2NvcGUuaW5kZXggPSBjdXJyQmFja2Ryb3BJbmRleDtcbiAgICAgICAgICBiYWNrZHJvcERvbUVsID0gJGNvbXBpbGUoJzxkaXYgbW9kYWwtYmFja2Ryb3A+PC9kaXY+JykoYmFja2Ryb3BTY29wZSk7XG4gICAgICAgICAgYm9keS5hcHBlbmQoYmFja2Ryb3BEb21FbCk7XG4gICAgICAgIH1cblxuICAgICAgICAvLyBDaGFuZ2VzOiBkZWxldGlvbiBvZiBjc3MgdG9wIHByb3BlcnR5IGNhbGN1bGF0aW9uXG4gICAgICAgIHZhciBhbmd1bGFyRG9tRWwgPSBhbmd1bGFyLmVsZW1lbnQoJzxkaXYgbW9kYWwtd2luZG93IHN0eWxlPVwidmlzaWJpbGl0eTogdmlzaWJsZTsgZGlzcGxheTogYmxvY2tcIj48L2Rpdj4nKTtcbiAgICAgICAgYW5ndWxhckRvbUVsLmF0dHIoJ3dpbmRvdy1jbGFzcycsIG1vZGFsLndpbmRvd0NsYXNzKTtcbiAgICAgICAgYW5ndWxhckRvbUVsLmF0dHIoJ2luZGV4Jywgb3BlbmVkV2luZG93cy5sZW5ndGgoKSAtIDEpO1xuICAgICAgICBhbmd1bGFyRG9tRWwuYXR0cignYW5pbWF0ZScsICdhbmltYXRlJyk7XG4gICAgICAgIGFuZ3VsYXJEb21FbC5odG1sKG1vZGFsLmNvbnRlbnQpO1xuXG4gICAgICAgIHZhciBtb2RhbERvbUVsID0gJGNvbXBpbGUoYW5ndWxhckRvbUVsKShtb2RhbC5zY29wZSk7XG4gICAgICAgIG9wZW5lZFdpbmRvd3MudG9wKCkudmFsdWUubW9kYWxEb21FbCA9IG1vZGFsRG9tRWw7XG4gICAgICAgIGJvZHkuYXBwZW5kKG1vZGFsRG9tRWwpO1xuICAgICAgICBib2R5LmFkZENsYXNzKE9QRU5FRF9NT0RBTF9DTEFTUyk7XG4gICAgICB9O1xuXG4gICAgICAkbW9kYWxTdGFjay5jbG9zZSA9IGZ1bmN0aW9uIChtb2RhbEluc3RhbmNlLCByZXN1bHQpIHtcbiAgICAgICAgdmFyIG1vZGFsV2luZG93ID0gb3BlbmVkV2luZG93cy5nZXQobW9kYWxJbnN0YW5jZSkudmFsdWU7XG4gICAgICAgIGlmIChtb2RhbFdpbmRvdykge1xuICAgICAgICAgIG1vZGFsV2luZG93LmRlZmVycmVkLnJlc29sdmUocmVzdWx0KTtcbiAgICAgICAgICByZW1vdmVNb2RhbFdpbmRvdyhtb2RhbEluc3RhbmNlKTtcbiAgICAgICAgfVxuICAgICAgfTtcblxuICAgICAgJG1vZGFsU3RhY2suZGlzbWlzcyA9IGZ1bmN0aW9uIChtb2RhbEluc3RhbmNlLCByZWFzb24pIHtcbiAgICAgICAgdmFyIG1vZGFsV2luZG93ID0gb3BlbmVkV2luZG93cy5nZXQobW9kYWxJbnN0YW5jZSkudmFsdWU7XG4gICAgICAgIGlmIChtb2RhbFdpbmRvdykge1xuICAgICAgICAgIG1vZGFsV2luZG93LmRlZmVycmVkLnJlamVjdChyZWFzb24pO1xuICAgICAgICAgIHJlbW92ZU1vZGFsV2luZG93KG1vZGFsSW5zdGFuY2UpO1xuICAgICAgICB9XG4gICAgICB9O1xuXG4gICAgICAkbW9kYWxTdGFjay5kaXNtaXNzQWxsID0gZnVuY3Rpb24gKHJlYXNvbikge1xuICAgICAgICB2YXIgdG9wTW9kYWwgPSB0aGlzLmdldFRvcCgpO1xuICAgICAgICB3aGlsZSAodG9wTW9kYWwpIHtcbiAgICAgICAgICB0aGlzLmRpc21pc3ModG9wTW9kYWwua2V5LCByZWFzb24pO1xuICAgICAgICAgIHRvcE1vZGFsID0gdGhpcy5nZXRUb3AoKTtcbiAgICAgICAgfVxuICAgICAgfTtcblxuICAgICAgJG1vZGFsU3RhY2suZ2V0VG9wID0gZnVuY3Rpb24gKCkge1xuICAgICAgICByZXR1cm4gb3BlbmVkV2luZG93cy50b3AoKTtcbiAgICAgIH07XG5cbiAgICAgIHJldHVybiAkbW9kYWxTdGFjaztcbiAgICB9XSk7XG5cbiIsIi8qXG4gKiBUaGlzIG1vZHVsZSBtb2RpZmllcyBhbmd1bGFyIGZvdW5kYXRpb24ncyBtb2RhbCBpbXBsZW1lbnRhdGlvbi4gVGhpcyBkb2VzIG5vdCBjcmVhdGUgYSBuZXcgbW9kYWwgc2VydmljZS9kaXJlY3RpdmUuXG4gKiBcbiovXG5hbmd1bGFyLm1vZHVsZSgnYmNhcHAtcGF0dGVybi1sYWIuYmMtbW9kYWwnLCBbXG4gICAgJ2JjYXBwLXBhdHRlcm4tbGFiLmJjLW1vZGFsLm1vZGFsU3RhY2suc2VydmljZSdcbl0pO1xuIiwiLyoqXG4gKiBAZGVzY3JpcHRpb24gVXNlZCB0byBjcmVhdGUgYSB0b2dnbGUgc3dpdGNoIGZvciBmb3Jtc1xuICogQGV4YW1wbGVcbiAgICA8c3dpdGNoIG5nLW1vZGVsPVwiY3RybC5zd2l0Y2hNb2RlbDFcIj48L3N3aXRjaD5cblxuICAgIDxzd2l0Y2hcbiAgICAgICAgdG9nZ2xlLW9mZi10ZXh0PVwiT2ZmXCJcbiAgICAgICAgdG9nZ2xlLW9uLXRleHQ9XCJPblwiXG4gICAgICAgIG5nLW1vZGVsPVwiY3RybC5zd2l0Y2hNb2RlbDJcIj5cbiAgICA8L3N3aXRjaD5cblxuICAgIDxzd2l0Y2hcbiAgICAgICAgaGFzLWljb25cbiAgICAgICAgbmctbW9kZWw9XCJjdHJsLnN3aXRjaE1vZGVsM1wiPlxuICAgIDwvc3dpdGNoPlxuXG4gICAgPHN3aXRjaFxuICAgICAgICBpcy1pbXBvcnRhbnRcbiAgICAgICAgbGVmdC1sYWJlbD1cIkRvd24gZm9yIE1haW50ZW5hbmNlXCJcbiAgICAgICAgcmlnaHQtbGFiZWw9XCJPcGVuXCJcbiAgICAgICAgbmctbW9kZWw9XCJjdHJsLnN3aXRjaE1vZGVsNFwiPlxuICAgIDwvc3dpdGNoPlxuICovXG5hbmd1bGFyLm1vZHVsZSgnYmNhcHAtcGF0dGVybi1sYWIuc3dpdGNoLmRpcmVjdGl2ZScsIFtdKVxuICAgIC5kaXJlY3RpdmUoJ3N3aXRjaCcsIGZ1bmN0aW9uIHN3aXRjaERpcmVjdGl2ZSgpIHtcblxuICAgICAgICBmdW5jdGlvbiBnZXRVbmlxdWVJRChpZFByZWZpeCkge1xuICAgICAgICAgICAgcmV0dXJuIF8udW5pcXVlSWQoaWRQcmVmaXgpO1xuICAgICAgICB9XG5cbiAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICAgIHJlc3RyaWN0OiAnRScsXG4gICAgICAgICAgICB0ZW1wbGF0ZVVybDogJ3NyYy9qcy9iaWdjb21tZXJjZS9zd2l0Y2gvc3dpdGNoLnRwbC5odG1sJyxcbiAgICAgICAgICAgIHJlcXVpcmU6ICduZ01vZGVsJyxcbiAgICAgICAgICAgIHNjb3BlOiB7XG4gICAgICAgICAgICAgICAgYXJpYURlc2NyaXB0aW9uOiAnQCcsXG4gICAgICAgICAgICAgICAgbGFiZWxUZXh0OiAnQCcsXG4gICAgICAgICAgICAgICAgbGVmdERlc2NyaXB0aW9uOiAnQCcsXG4gICAgICAgICAgICAgICAgbmdGYWxzZVZhbHVlOiAnQCcsXG4gICAgICAgICAgICAgICAgbmdUcnVlVmFsdWU6ICdAJyxcbiAgICAgICAgICAgICAgICByaWdodERlc2NyaXB0aW9uOiAnQCcsXG4gICAgICAgICAgICAgICAgdG9nZ2xlT2ZmTGFiZWw6ICdAJyxcbiAgICAgICAgICAgICAgICB0b2dnbGVPbkxhYmVsOiAnQCcsXG4gICAgICAgICAgICAgICAgdW5pcXVlSWQ6ICdAJ1xuICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIGJpbmRUb0NvbnRyb2xsZXI6IHRydWUsXG4gICAgICAgICAgICBjb250cm9sbGVyQXM6ICdzd2l0Y2hDdHJsJyxcbiAgICAgICAgICAgIGNvbXBpbGU6IGZ1bmN0aW9uIHN3aXRjaERpcmVjdGl2ZUNvbXBpbGUodEVsZW0sIHRBdHRycykge1xuICAgICAgICAgICAgICAgIHZhciBjaGVja2JveEVsZW0gPSB0RWxlbS5maW5kKCdpbnB1dCcpO1xuXG4gICAgICAgICAgICAgICAgaWYgKHRBdHRycy5uZ0ZhbHNlVmFsdWUpIHtcbiAgICAgICAgICAgICAgICAgICAgY2hlY2tib3hFbGVtLmF0dHIoJ25nLWZhbHNlLXZhbHVlJywgdEF0dHJzLm5nRmFsc2VWYWx1ZSk7XG4gICAgICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAgICAgaWYgKHRBdHRycy5uZ1RydWVWYWx1ZSkge1xuICAgICAgICAgICAgICAgICAgICBjaGVja2JveEVsZW0uYXR0cignbmctdHJ1ZS12YWx1ZScsIHRBdHRycy5uZ1RydWVWYWx1ZSk7XG4gICAgICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAgICAgcmV0dXJuIGZ1bmN0aW9uIHN3aXRjaERpcmVjdGl2ZVBvc3RMaW5rKHNjb3BlLCBlbGVtZW50LCBhdHRycywgbmdNb2RlbEN0cmwpIHtcbiAgICAgICAgICAgICAgICAgICAgc2NvcGUuc3dpdGNoQ3RybC5pbml0KG5nTW9kZWxDdHJsKTtcbiAgICAgICAgICAgICAgICB9O1xuICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIGNvbnRyb2xsZXI6IGZ1bmN0aW9uIHN3aXRjaERpcmVjdGl2ZUN0cmwoJHNjb3BlLCAkZWxlbWVudCwgJGF0dHJzKSB7XG4gICAgICAgICAgICAgICAgdmFyIGN0cmwgPSB0aGlzO1xuXG4gICAgICAgICAgICAgICAgLy8gc3RhdGVcbiAgICAgICAgICAgICAgICBjdHJsLmlzSW1wb3J0YW50ID0gYW5ndWxhci5pc0RlZmluZWQoJGF0dHJzLmlzSW1wb3J0YW50KSAmJiAkYXR0cnMuaXNJbXBvcnRhbnQgIT09ICdmYWxzZSc7XG4gICAgICAgICAgICAgICAgY3RybC5oYXNJY29uID0gYW5ndWxhci5pc0RlZmluZWQoJGF0dHJzLmhhc0ljb24pICYmICRhdHRycy5oYXNJY29uICE9PSAnZmFsc2UnO1xuXG4gICAgICAgICAgICAgICAgLy8gbGFiZWxzXG4gICAgICAgICAgICAgICAgY3RybC5sYWJlbFRleHQgPSAkYXR0cnMudG9nZ2xlT2ZmTGFiZWw7XG5cbiAgICAgICAgICAgICAgICAvLyBpZHNcbiAgICAgICAgICAgICAgICBjdHJsLnVuaXF1ZUlkID0gZ2V0VW5pcXVlSUQoJ3N3aXRjaC0nKTtcbiAgICAgICAgICAgICAgICBjdHJsLmFyaWFEZXNjcmlwdGlvbklEID0gZ2V0VW5pcXVlSUQoJ3N3aXRjaC1hcmlhRGVzY3JpcHRpb24tJyk7XG5cbiAgICAgICAgICAgICAgICBjdHJsLmluaXQgPSBpbml0O1xuICAgICAgICAgICAgICAgIGN0cmwudXBkYXRlTW9kZWwgPSB1cGRhdGVNb2RlbDtcblxuICAgICAgICAgICAgICAgIGZ1bmN0aW9uIGluaXQobmdNb2RlbEN0cmwpIHtcbiAgICAgICAgICAgICAgICAgICAgY3RybC5uZ01vZGVsQ3RybCA9IG5nTW9kZWxDdHJsO1xuICAgICAgICAgICAgICAgICAgICBjdHJsLnZhbHVlID0gY3RybC5uZ01vZGVsQ3RybC4kbW9kZWxWYWx1ZTtcblxuICAgICAgICAgICAgICAgICAgICAkc2NvcGUuJHdhdGNoKCdzd2l0Y2hDdHJsLm5nTW9kZWxDdHJsLiRtb2RlbFZhbHVlJywgZnVuY3Rpb24gc3dpdGNoVmFsdWVDaGFuZ2VkKG5ld1ZhbHVlKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICBjdHJsLnZhbHVlID0gbmV3VmFsdWU7XG5cbiAgICAgICAgICAgICAgICAgICAgICAgIGN0cmwuaXNDaGVja2VkID0gXy5pc1N0cmluZyhuZXdWYWx1ZSkgPyBcIidcIiArIG5ld1ZhbHVlICsgXCInXCIgPT09IGN0cmwubmdUcnVlVmFsdWUgOiBuZXdWYWx1ZTtcbiAgICAgICAgICAgICAgICAgICAgICAgIGN0cmwubGFiZWxUZXh0ID0gISFjdHJsLmlzQ2hlY2tlZCA/IGN0cmwudG9nZ2xlT25MYWJlbDogY3RybC50b2dnbGVPZmZMYWJlbDtcbiAgICAgICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAgICAgZnVuY3Rpb24gdXBkYXRlTW9kZWwoKSB7XG4gICAgICAgICAgICAgICAgICAgIGN0cmwubmdNb2RlbEN0cmwuJHNldFZpZXdWYWx1ZShjdHJsLnZhbHVlKTtcbiAgICAgICAgICAgICAgICB9XG5cbiAgICAgICAgICAgIH1cbiAgICAgICAgfTtcbiAgICB9KTtcbiIsImFuZ3VsYXIubW9kdWxlKCdiY2FwcC1wYXR0ZXJuLWxhYi5zd2l0Y2gnLCBbXG4gICAgJ2JjYXBwLXBhdHRlcm4tbGFiLnN3aXRjaC5kaXJlY3RpdmUnXG5dKTtcbiIsIi8qKlxuICogQGRlc2NyaXB0aW9uIFNwcml0ZSBkaXJlY3RpdmUgdXNlZCB0byBsb2FkIGFuIGljb24gZnJvbSBhbiBpbWFnZSBzcHJpdGUsXG4gKiAgICAgICAgICAgICAgc2ltbGlhciB0byB0aGUgaWNvbiBkaXJlY3RpdmUgYnV0IGxlc3MgU1ZHXG4gKiBAZXhhbXBsZVxuICogPHNwcml0ZSBnbHlwaD1cImljLWFtZXhcIj48L3Nwcml0ZT5cbiAqL1xuXG5hbmd1bGFyLm1vZHVsZSgnYmNhcHAtcGF0dGVybi1sYWIuc3ByaXRlLmRpcmVjdGl2ZScsIFtdKVxuICAgIC5kaXJlY3RpdmUoJ3Nwcml0ZScsIGZ1bmN0aW9uIHNwcml0ZURpcmVjdGl2ZSgpIHtcbiAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICAgIHJlc3RyaWN0OiAnRScsXG4gICAgICAgICAgICBzY29wZToge1xuICAgICAgICAgICAgICAgIGdseXBoOiAnQCdcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICBjb21waWxlOiBzcHJpdGVEaXJlY3RpdmVDb21waWxlXG4gICAgICAgIH07XG5cbiAgICAgICAgZnVuY3Rpb24gc3ByaXRlRGlyZWN0aXZlQ29tcGlsZSh0RWxlbWVudCkge1xuICAgICAgICAgICAgdEVsZW1lbnQuYWRkQ2xhc3MoJ3Nwcml0ZScpO1xuICAgICAgICAgICAgdEVsZW1lbnQuYXR0cignYXJpYS1oaWRkZW4nLCB0cnVlKTtcblxuICAgICAgICAgICAgcmV0dXJuIGZ1bmN0aW9uIHNwcml0ZURpcmVjdGl2ZUxpbmsoJHNjb3BlLCBlbGVtZW50LCBhdHRycykge1xuICAgICAgICAgICAgICAgIGF0dHJzLiRvYnNlcnZlKCdnbHlwaCcsIChuZXdWYWx1ZSkgPT4ge1xuICAgICAgICAgICAgICAgICAgICBlbGVtZW50LmF0dHIoJ2NsYXNzJywgJ3Nwcml0ZSBzcHJpdGUtLScgKyBuZXdWYWx1ZSk7XG4gICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICB9O1xuICAgICAgICB9XG4gICAgfSk7XG4iLCJhbmd1bGFyLm1vZHVsZSgnYmNhcHAtcGF0dGVybi1sYWIuc3ByaXRlJywgW1xuICAgICdiY2FwcC1wYXR0ZXJuLWxhYi5zcHJpdGUuZGlyZWN0aXZlJ1xuXSk7XG4iLCJhbmd1bGFyLm1vZHVsZSgnYmNhcHAtcGF0dGVybi1sYWIudXRpbCcsIFtcbiAgICAnYmNhcHAtcGF0dGVybi1sYWIudXRpbC50cnVzdEFzSHRtbCdcbl0pO1xuIiwiYW5ndWxhci5tb2R1bGUoJ2JjYXBwLXBhdHRlcm4tbGFiLmJjLXNlcnZlci10YWJsZS5zZXJ2aWNlJywgW1xuICAgICd1aS5yb3V0ZXInXG5dKVxuICAgIC5mYWN0b3J5KCdCY1NlcnZlclRhYmxlJywgZnVuY3Rpb24gYmNTZXJ2ZXJUYWJsZSgkbG9nLCAkcSwgJHN0YXRlLCAkc3RhdGVQYXJhbXMpIHtcbiAgICAgICAgdmFyIGRlZmF1bHRUYWJsZUNvbmZpZyA9IHtcbiAgICAgICAgICAgIGZpbHRlcnM6IFtdLFxuICAgICAgICAgICAgcXVlcnlLZXlzOiB7XG4gICAgICAgICAgICAgICAgcGFnZTogJ3BhZ2UnLFxuICAgICAgICAgICAgICAgIGxpbWl0OiAnbGltaXQnLFxuICAgICAgICAgICAgICAgIHNvcnRCeTogJ3NvcnQtYnknLFxuICAgICAgICAgICAgICAgIHNvcnREaXI6ICdzb3J0LW9yZGVyJ1xuICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIHJvd0lkS2V5OiAnaWQnLFxuICAgICAgICAgICAgc29ydERpclZhbHVlczoge1xuICAgICAgICAgICAgICAgIGFzYzogJ2FzYycsXG4gICAgICAgICAgICAgICAgZGVzYzogJ2Rlc2MnXG4gICAgICAgICAgICB9XG4gICAgICAgIH07XG5cbiAgICAgICAgZnVuY3Rpb24gU2VydmVyVGFibGUodGFibGVJZCwgdGFibGVDb25maWcpIHtcbiAgICAgICAgICAgIHRoaXMuYWxsU2VsZWN0ZWQgPSBmYWxzZTtcbiAgICAgICAgICAgIHRoaXMuZmlsdGVycyA9IHt9O1xuICAgICAgICAgICAgdGhpcy5pZCA9IHRhYmxlSWQ7XG4gICAgICAgICAgICB0aGlzLnBhZ2luYXRpb24gPSB7XG4gICAgICAgICAgICAgICAgcGFnZTogbnVsbCxcbiAgICAgICAgICAgICAgICBsaW1pdDogbnVsbCxcbiAgICAgICAgICAgICAgICB0b3RhbDogbnVsbFxuICAgICAgICAgICAgfTtcbiAgICAgICAgICAgIHRoaXMucGVuZGluZ1JlcXVlc3QgPSBmYWxzZTtcbiAgICAgICAgICAgIHRoaXMucmVzb3VyY2VDYWxsYmFjayA9IGFuZ3VsYXIubm9vcDtcbiAgICAgICAgICAgIHRoaXMucm93cyA9IFtdO1xuICAgICAgICAgICAgdGhpcy5zZWxlY3RlZFJvd3MgPSB7fTtcbiAgICAgICAgICAgIHRoaXMuc29ydEJ5ID0gJyc7XG4gICAgICAgICAgICB0aGlzLnNvcnREaXIgPSAnJztcbiAgICAgICAgICAgIFxuICAgICAgICAgICAgdGhpcy50YWJsZUNvbmZpZyA9IF8uaXNPYmplY3QodGFibGVDb25maWcpID8gdGFibGVDb25maWcgOiB7fTtcbiAgICAgICAgICAgIHRoaXMudGFibGVDb25maWcgPSBfLmRlZmF1bHRzKHRoaXMudGFibGVDb25maWcsIGRlZmF1bHRUYWJsZUNvbmZpZyk7XG4gICAgICAgIH1cblxuICAgICAgICBTZXJ2ZXJUYWJsZS5wcm90b3R5cGUgPSB7XG4gICAgICAgICAgICBjcmVhdGVQYXJhbXNPYmplY3Q6IGNyZWF0ZVBhcmFtc09iamVjdCxcbiAgICAgICAgICAgIGZldGNoUmVzb3VyY2U6IGZldGNoUmVzb3VyY2UsXG4gICAgICAgICAgICBnZXRTZWxlY3RlZFJvd3M6IGdldFNlbGVjdGVkUm93cyxcbiAgICAgICAgICAgIGluaXQ6IGluaXQsXG4gICAgICAgICAgICBpc1Jvd1NlbGVjdGVkOiBpc1Jvd1NlbGVjdGVkLFxuICAgICAgICAgICAgbG9hZFN0YXRlUGFyYW1zOiBsb2FkU3RhdGVQYXJhbXMsXG4gICAgICAgICAgICBzZWxlY3RBbGxSb3dzOiBzZWxlY3RBbGxSb3dzLFxuICAgICAgICAgICAgc2V0UGFnaW5hdGlvblZhbHVlczogc2V0UGFnaW5hdGlvblZhbHVlcyxcbiAgICAgICAgICAgIHNldFJvd3M6IHNldFJvd3MsXG4gICAgICAgICAgICBzZXRTb3J0aW5nVmFsdWVzOiBzZXRTb3J0aW5nVmFsdWVzLFxuICAgICAgICAgICAgdXBkYXRlUGFnZTogdXBkYXRlUGFnZSxcbiAgICAgICAgICAgIHVwZGF0ZVNvcnQ6IHVwZGF0ZVNvcnQsXG4gICAgICAgICAgICB1cGRhdGVUYWJsZTogdXBkYXRlVGFibGUsXG4gICAgICAgICAgICB2YWxpZGF0ZVJlc291cmNlOiB2YWxpZGF0ZVJlc291cmNlXG4gICAgICAgIH07XG5cbiAgICAgICAgZnVuY3Rpb24gY3JlYXRlUGFyYW1zT2JqZWN0KCkge1xuICAgICAgICAgICAgdmFyIHBhcmFtcyA9IHt9LFxuICAgICAgICAgICAgICAgIHF1ZXJ5S2V5cyA9IHRoaXMudGFibGVDb25maWcucXVlcnlLZXlzLFxuICAgICAgICAgICAgICAgIHF1ZXJ5UGFyYW1NYXAgPSBbe1xuICAgICAgICAgICAgICAgICAgICAgICAgcXVlcnlLZXk6IHF1ZXJ5S2V5cy5wYWdlLFxuICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU6IHRoaXMucGFnaW5hdGlvbi5wYWdlXG4gICAgICAgICAgICAgICAgICAgIH0sIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHF1ZXJ5S2V5OiBxdWVyeUtleXMubGltaXQsXG4gICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZTogdGhpcy5wYWdpbmF0aW9uLmxpbWl0XG4gICAgICAgICAgICAgICAgICAgIH0sIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHF1ZXJ5S2V5OiBxdWVyeUtleXMuc29ydEJ5LFxuICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU6IHRoaXMuc29ydEJ5XG4gICAgICAgICAgICAgICAgICAgIH0sIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHF1ZXJ5S2V5OiBxdWVyeUtleXMuc29ydERpcixcbiAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlOiB0aGlzLnNvcnREaXJcbiAgICAgICAgICAgICAgICAgICAgfV07XG5cbiAgICAgICAgICAgIF8uZWFjaChxdWVyeVBhcmFtTWFwLCBmdW5jdGlvbiBxdWVyeVBhcmFtTWFwRWFjaChwYXJhbSkge1xuICAgICAgICAgICAgICAgIGlmIChwYXJhbS5xdWVyeUtleSAhPT0gdW5kZWZpbmVkKSB7XG4gICAgICAgICAgICAgICAgICAgIHBhcmFtc1twYXJhbS5xdWVyeUtleV0gPSBwYXJhbS52YWx1ZTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9KTtcblxuICAgICAgICAgICAgXy5leHRlbmQocGFyYW1zLCB0aGlzLmZpbHRlcnMpO1xuXG4gICAgICAgICAgICByZXR1cm4gcGFyYW1zO1xuICAgICAgICB9XG5cbiAgICAgICAgZnVuY3Rpb24gZmV0Y2hSZXNvdXJjZSgpIHtcbiAgICAgICAgICAgIHZhciBfdGhpcyA9IHRoaXM7XG5cbiAgICAgICAgICAgIHRoaXMucGVuZGluZ1JlcXVlc3QgPSB0cnVlO1xuICAgICAgICAgICAgcmV0dXJuIHRoaXMucmVzb3VyY2VDYWxsYmFjayh0aGlzLmNyZWF0ZVBhcmFtc09iamVjdCgpKVxuICAgICAgICAgICAgICAgIC50aGVuKGZ1bmN0aW9uIHJlc291cmNlQ2FsbGJhY2tUaGVuKHJlc291cmNlKSB7XG4gICAgICAgICAgICAgICAgICAgIGlmIChfdGhpcy52YWxpZGF0ZVJlc291cmNlKHJlc291cmNlKSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgX3RoaXMuc2V0Um93cyhyZXNvdXJjZS5yb3dzKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIF90aGlzLnNldFBhZ2luYXRpb25WYWx1ZXMocmVzb3VyY2UucGFnaW5hdGlvbik7XG4gICAgICAgICAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgICAgICAgICByZXR1cm4gX3RoaXM7XG4gICAgICAgICAgICAgICAgfSlcbiAgICAgICAgICAgICAgICAuY2F0Y2goZnVuY3Rpb24gcmVzb3VyY2VDYWxsYmFja0NhdGNoKGVycm9yKSB7XG4gICAgICAgICAgICAgICAgICAgICRsb2cuZXJyb3IoJ2JjLXNlcnZlci10YWJsZSBkaXJlY3RpdmU6IGZhaWxlZCB0byBmZXRjaCByZXNvdXJjZScpO1xuXG4gICAgICAgICAgICAgICAgICAgIHJldHVybiAkcS5yZWplY3QoZXJyb3IpO1xuICAgICAgICAgICAgICAgIH0pXG4gICAgICAgICAgICAgICAgLmZpbmFsbHkoZnVuY3Rpb24gcmVzb3VyY2VDYWxsYmFja0ZpbmFsbHkoKSB7XG4gICAgICAgICAgICAgICAgICAgIF90aGlzLnBlbmRpbmdSZXF1ZXN0ID0gZmFsc2U7XG4gICAgICAgICAgICAgICAgfSk7XG4gICAgICAgIH1cblxuICAgICAgICBmdW5jdGlvbiBnZXRTZWxlY3RlZFJvd3MoKSB7XG4gICAgICAgICAgICB2YXIgX3RoaXMgPSB0aGlzO1xuXG4gICAgICAgICAgICByZXR1cm4gXy5maWx0ZXIodGhpcy5yb3dzLCBmdW5jdGlvbiBnZXRTZWxlY3RlZFJvd3NGaWx0ZXIocm93KSB7XG4gICAgICAgICAgICAgICAgcmV0dXJuIF90aGlzLmlzUm93U2VsZWN0ZWQocm93KTtcbiAgICAgICAgICAgIH0pO1xuICAgICAgICB9XG5cbiAgICAgICAgZnVuY3Rpb24gaW5pdChjb25maWcpIHtcbiAgICAgICAgICAgIGlmICghXy5pc09iamVjdChjb25maWcpKSB7XG4gICAgICAgICAgICAgICAgY29uZmlnID0ge307XG4gICAgICAgICAgICB9XG5cbiAgICAgICAgICAgIGlmIChfLmlzRnVuY3Rpb24oY29uZmlnLnJlc291cmNlQ2FsbGJhY2spKSB7XG4gICAgICAgICAgICAgICAgdGhpcy5yZXNvdXJjZUNhbGxiYWNrID0gY29uZmlnLnJlc291cmNlQ2FsbGJhY2s7XG4gICAgICAgICAgICB9XG5cbiAgICAgICAgICAgIHJldHVybiB0aGlzXG4gICAgICAgICAgICAgICAgLmxvYWRTdGF0ZVBhcmFtcyhjb25maWcuc3RhdGVQYXJhbXMpXG4gICAgICAgICAgICAgICAgLmZldGNoUmVzb3VyY2UoKTtcbiAgICAgICAgfVxuXG4gICAgICAgIGZ1bmN0aW9uIGlzUm93U2VsZWN0ZWQocm93KSB7XG4gICAgICAgICAgICByZXR1cm4gdGhpcy5zZWxlY3RlZFJvd3Nbcm93W3RoaXMudGFibGVDb25maWcucm93SWRLZXldXTtcbiAgICAgICAgfVxuXG4gICAgICAgIGZ1bmN0aW9uIGxvYWRTdGF0ZVBhcmFtcyhzdGF0ZVBhcmFtcykge1xuICAgICAgICAgICAgdmFyIHF1ZXJ5S2V5cyA9IHRoaXMudGFibGVDb25maWcucXVlcnlLZXlzLFxuICAgICAgICAgICAgICAgIF90aGlzID0gdGhpcztcblxuICAgICAgICAgICAgc3RhdGVQYXJhbXMgPSBzdGF0ZVBhcmFtcyB8fCAkc3RhdGVQYXJhbXM7XG5cbiAgICAgICAgICAgIHRoaXMuc2V0UGFnaW5hdGlvblZhbHVlcyh7XG4gICAgICAgICAgICAgICAgcGFnZTogc3RhdGVQYXJhbXNbcXVlcnlLZXlzLnBhZ2VdLFxuICAgICAgICAgICAgICAgIGxpbWl0OiBzdGF0ZVBhcmFtc1txdWVyeUtleXMubGltaXRdXG4gICAgICAgICAgICB9KTtcblxuICAgICAgICAgICAgdGhpcy5zZXRTb3J0aW5nVmFsdWVzKHN0YXRlUGFyYW1zW3F1ZXJ5S2V5cy5zb3J0QnldLCBzdGF0ZVBhcmFtc1txdWVyeUtleXMuc29ydERpcl0pO1xuXG4gICAgICAgICAgICAvLyBzZXQgZmlsdGVycyBmcm9tIHF1ZXJ5IHBhcmFtc1xuICAgICAgICAgICAgXy5lYWNoKHRoaXMudGFibGVDb25maWcuZmlsdGVycywgZnVuY3Rpb24gc2V0RmlsdGVyc0VhY2godmFsdWUpIHtcbiAgICAgICAgICAgICAgICBfdGhpcy5maWx0ZXJzW3ZhbHVlXSA9IHN0YXRlUGFyYW1zW3ZhbHVlXTtcbiAgICAgICAgICAgIH0pO1xuXG4gICAgICAgICAgICByZXR1cm4gdGhpcztcbiAgICAgICAgfVxuXG4gICAgICAgIGZ1bmN0aW9uIHNlbGVjdEFsbFJvd3MoKSB7XG4gICAgICAgICAgICB2YXIgX3RoaXMgPSB0aGlzO1xuXG4gICAgICAgICAgICB0aGlzLmFsbFNlbGVjdGVkID0gIXRoaXMuYWxsU2VsZWN0ZWQ7XG4gICAgICAgICAgICBfLmVhY2godGhpcy5zZWxlY3RlZFJvd3MsIGZ1bmN0aW9uIHNlbGVjdEFsbFJvd3NFYWNoKHZhbHVlLCBrZXkpIHtcbiAgICAgICAgICAgICAgICBfdGhpcy5zZWxlY3RlZFJvd3Nba2V5XSA9IF90aGlzLmFsbFNlbGVjdGVkO1xuICAgICAgICAgICAgfSk7XG5cbiAgICAgICAgICAgIHJldHVybiB0aGlzO1xuICAgICAgICB9XG5cbiAgICAgICAgZnVuY3Rpb24gc2V0UGFnaW5hdGlvblZhbHVlcyhwYWdpbmF0aW9uKSB7XG4gICAgICAgICAgICB0aGlzLnBhZ2luYXRpb24gPSB0aGlzLnBhZ2luYXRpb24gfHwge307XG4gICAgICAgICAgICBfLmV4dGVuZCh0aGlzLnBhZ2luYXRpb24sIHBhZ2luYXRpb24pO1xuXG4gICAgICAgICAgICByZXR1cm4gdGhpcztcbiAgICAgICAgfVxuXG4gICAgICAgIGZ1bmN0aW9uIHNldFJvd3Mocm93cykge1xuICAgICAgICAgICAgdmFyIF90aGlzID0gdGhpcztcblxuICAgICAgICAgICAgdGhpcy5yb3dzID0gcm93cztcbiAgICAgICAgICAgIHRoaXMuc2VsZWN0ZWRSb3dzID0gXy5yZWR1Y2Uocm93cywgZnVuY3Rpb24gaW5pdGlhbGl6ZVNlbGVjdGVkUm93c09iamVjdChhY2N1bSwgcm93KSB7XG4gICAgICAgICAgICAgICAgYWNjdW1bcm93W190aGlzLnRhYmxlQ29uZmlnLnJvd0lkS2V5XV0gPSBmYWxzZTtcbiAgICAgICAgICAgICAgICByZXR1cm4gYWNjdW07XG4gICAgICAgICAgICB9LCB7fSk7XG5cbiAgICAgICAgICAgIHJldHVybiB0aGlzO1xuICAgICAgICB9XG5cbiAgICAgICAgZnVuY3Rpb24gc2V0U29ydGluZ1ZhbHVlcyhzb3J0QnksIHNvcnREaXIpIHtcbiAgICAgICAgICAgIHRoaXMuc29ydEJ5ID0gc29ydEJ5IHx8IHRoaXMuc29ydEJ5O1xuICAgICAgICAgICAgdGhpcy5zb3J0RGlyID0gc29ydERpciB8fCB0aGlzLnNvcnREaXI7XG5cbiAgICAgICAgICAgIHJldHVybiB0aGlzO1xuICAgICAgICB9XG5cbiAgICAgICAgZnVuY3Rpb24gdXBkYXRlUGFnZShwYWdlLCBsaW1pdCwgdG90YWwpIHtcbiAgICAgICAgICAgIHJldHVybiB0aGlzXG4gICAgICAgICAgICAgICAgLnNldFBhZ2luYXRpb25WYWx1ZXMocGFnZSwgbGltaXQsIHRvdGFsKVxuICAgICAgICAgICAgICAgIC51cGRhdGVUYWJsZSgpO1xuICAgICAgICB9XG5cbiAgICAgICAgZnVuY3Rpb24gdXBkYXRlU29ydChzb3J0QnksIHNvcnREaXIpIHtcbiAgICAgICAgICAgIHJldHVybiB0aGlzXG4gICAgICAgICAgICAgICAgLnNldFNvcnRpbmdWYWx1ZXMoc29ydEJ5LCBzb3J0RGlyKVxuICAgICAgICAgICAgICAgIC5zZXRQYWdpbmF0aW9uVmFsdWVzKHtcbiAgICAgICAgICAgICAgICAgICAgcGFnZTogMVxuICAgICAgICAgICAgICAgIH0pXG4gICAgICAgICAgICAgICAgLnVwZGF0ZVRhYmxlKCk7XG4gICAgICAgIH1cblxuICAgICAgICBmdW5jdGlvbiB1cGRhdGVUYWJsZSgpIHtcbiAgICAgICAgICAgIGlmICghdGhpcy5wZW5kaW5nUmVxdWVzdCkge1xuICAgICAgICAgICAgICAgICRzdGF0ZS5nbygkc3RhdGUuY3VycmVudC5uYW1lLCB0aGlzLmNyZWF0ZVBhcmFtc09iamVjdCgpKTtcbiAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgcmV0dXJuIHRoaXM7XG4gICAgICAgIH1cblxuICAgICAgICBmdW5jdGlvbiB2YWxpZGF0ZVJlc291cmNlKHJlc291cmNlKSB7XG4gICAgICAgICAgICBpZiAoIV8uaXNPYmplY3QocmVzb3VyY2UpKSB7XG4gICAgICAgICAgICAgICAgJGxvZy5lcnJvcignYmMtc2VydmVyLXRhYmxlIGRpcmVjdGl2ZTogUmVzb3VyY2UgY2FsbGJhY2sgbXVzdCByZXR1cm4gYW4gb2JqZWN0Jyk7XG4gICAgICAgICAgICAgICAgcmV0dXJuIGZhbHNlO1xuICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICBpZiAoIV8uaXNBcnJheShyZXNvdXJjZS5yb3dzKSkge1xuICAgICAgICAgICAgICAgICRsb2cuZXJyb3IoJ2JjLXNlcnZlci10YWJsZSBkaXJlY3RpdmU6IHJldHVybmVkIG9iamVjdCBtdXN0IGNvbnRhaW4gYSByb3dzIHByb3BlcnR5IHRoYXQgaXMgYW4gYXJyYXkuJyk7XG4gICAgICAgICAgICAgICAgcmV0dXJuIGZhbHNlO1xuICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICBpZiAoIV8uaXNPYmplY3QocmVzb3VyY2UucGFnaW5hdGlvbikpIHtcbiAgICAgICAgICAgICAgICAkbG9nLmVycm9yKCdiYy1zZXJ2ZXItdGFibGUgZGlyZWN0aXZlOiByZXR1cm5lZCBvYmplY3QgbXVzdCBjb250YWluIGEgcGFnaW5hdGlvbiBwcm9wZXJ0eSB0aGF0IGlzIGFuIG9iamVjdC4nKTtcbiAgICAgICAgICAgICAgICByZXR1cm4gZmFsc2U7XG4gICAgICAgICAgICB9XG5cbiAgICAgICAgICAgIHJldHVybiB0cnVlO1xuICAgICAgICB9XG5cbiAgICAgICAgcmV0dXJuIFNlcnZlclRhYmxlO1xuICAgIH0pO1xuIiwiYW5ndWxhci5tb2R1bGUoJ2JjYXBwLXBhdHRlcm4tbGFiLmJjLXNlcnZlci10YWJsZS1mYWN0b3J5LnNlcnZpY2UnLCBbXG4gICAgJ2JjYXBwLXBhdHRlcm4tbGFiLmJjLXNlcnZlci10YWJsZS5zZXJ2aWNlJ1xuXSlcbiAgICAuZmFjdG9yeSgnYmNTZXJ2ZXJUYWJsZUZhY3RvcnknLCBmdW5jdGlvbiBiY1NlcnZlclRhYmxlRmFjdG9yeSgkbG9nLCBCY1NlcnZlclRhYmxlKSB7XG4gICAgICAgIHZhciB0YWJsZXMgPSB7fSxcbiAgICAgICAgICAgIHNlcnZpY2UgPSB7XG4gICAgICAgICAgICAgICAgY3JlYXRlOiBjcmVhdGUsXG4gICAgICAgICAgICAgICAgZ2V0OiBnZXQsXG4gICAgICAgICAgICAgICAgcmVtb3ZlOiByZW1vdmVcbiAgICAgICAgICAgIH07XG5cbiAgICAgICAgZnVuY3Rpb24gY3JlYXRlKHRhYmxlSWQsIHRhYmxlQ29uZmlnKSB7XG4gICAgICAgICAgICBpZiAodGFibGVJZCBpbiB0YWJsZXMpIHtcbiAgICAgICAgICAgICAgICByZXR1cm4gc2VydmljZS5nZXQodGFibGVJZCk7XG4gICAgICAgICAgICB9XG5cbiAgICAgICAgICAgIGlmICghdGFibGVJZCkge1xuICAgICAgICAgICAgICAgIHRhYmxlSWQgPSBfLnVuaXF1ZUlkKCdiYy1zZXJ2ZXItdGFibGUtaW5zdGFuY2UtJyk7XG4gICAgICAgICAgICB9XG5cbiAgICAgICAgICAgIHRhYmxlc1t0YWJsZUlkXSA9IG5ldyBCY1NlcnZlclRhYmxlKHRhYmxlSWQsIHRhYmxlQ29uZmlnKTtcblxuICAgICAgICAgICAgcmV0dXJuIHRhYmxlc1t0YWJsZUlkXTtcbiAgICAgICAgfVxuXG4gICAgICAgIGZ1bmN0aW9uIGdldCh0YWJsZUlkKSB7XG4gICAgICAgICAgICByZXR1cm4gdGFibGVzW3RhYmxlSWRdO1xuICAgICAgICB9XG5cbiAgICAgICAgZnVuY3Rpb24gcmVtb3ZlKHRhYmxlSWQpIHtcbiAgICAgICAgICAgIGRlbGV0ZSB0YWJsZXNbdGFibGVJZF07XG4gICAgICAgIH1cblxuICAgICAgICByZXR1cm4gc2VydmljZTtcbiAgICB9KTtcbiIsIi8qKlxuICogQG5hbWUgY2MtZXhwaXJ5IGRpcmVjdGl2ZVxuICogQGRlc2NyaXB0aW9uIEEgZGlyZWN0aXZlIGZvbGxvd2luZyBhbmd1bGFyLWNyZWRpdC1jYXJkJ3MgYXBwcm9hY2ggdG8gdmFsaWRhdGluZy9mb3JtYXR0aW5nIGNyZWRpdCBjYXJkIGV4cGlyYXRpb24gZGF0ZS5cbiAqIEV4cGVjdCB0aGUgY2MtZXhwaXJ5IG5nTW9kZWwgdG8gYmUgaW4gdGhlIGZvcm1hdCBvZiBgeyBtb250aDogJzA1JywgeWVhcjogJzIwMTcnfWAuXG4gKi9cbmFuZ3VsYXIubW9kdWxlKCdiY2FwcC1wYXR0ZXJuLWxhYi5jcmVkaXQtY2FyZC5jYy1leHBpcnkuZGlyZWN0aXZlJywgW10pXG4gICAgLmRpcmVjdGl2ZSgnY2NFeHBpcnknLCBmdW5jdGlvbiBjY0V4cERpcmVjdGl2ZSgkZmlsdGVyKSB7XG4gICAgICAgIHJldHVybiB7XG4gICAgICAgICAgICBjb21waWxlOiBmdW5jdGlvbiAodEVsZW0sIHRBdHRyKSB7XG4gICAgICAgICAgICAgICAgY29uc3QgRVhQSVJBVElPTl9NQVhfTEVOR1RIID0gNzsgLy8gbGVuZ3RoIG9mIGBNTSAvIHl5YFxuXG4gICAgICAgICAgICAgICAgdEF0dHIuJHNldCgnYXV0b2NvbXBsZXRlJywgJ2NjLWV4cCcpO1xuICAgICAgICAgICAgICAgIHRBdHRyLiRzZXQoJ21heGxlbmd0aCcsIEVYUElSQVRJT05fTUFYX0xFTkdUSCk7XG4gICAgICAgICAgICAgICAgdEF0dHIuJHNldCgncGF0dGVybicsICdbMC05XSonKTsgLy8gZm9yIG1vYmlsZSBrZXlib2FyZCBkaXNwbGF5XG5cbiAgICAgICAgICAgICAgICByZXR1cm4gZnVuY3Rpb24gY2NFeHBpcnlMaW5rKHNjb3BlLCB0RWxlbSwgdEF0dHIsIG5nTW9kZWxDdHJsKSB7XG4gICAgICAgICAgICAgICAgICAgIGluaXQoKTtcblxuICAgICAgICAgICAgICAgICAgICBmdW5jdGlvbiBpbml0KCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgbmdNb2RlbEN0cmwuJHBhcnNlcnMudW5zaGlmdChwYXJzZXIpO1xuICAgICAgICAgICAgICAgICAgICAgICAgbmdNb2RlbEN0cmwuJGZvcm1hdHRlcnMucHVzaChmb3JtYXR0ZXIpO1xuICAgICAgICAgICAgICAgICAgICAgICAgbmdNb2RlbEN0cmwuJHZhbGlkYXRvcnMudmFsaWRGdXR1cmVEYXRlID0gdmFsaWRGdXR1cmVEYXRlO1xuXG4gICAgICAgICAgICAgICAgICAgICAgICBzY29wZS4kd2F0Y2goZ2V0Vmlld1ZhbHVlLCByZW5kZXJGb3JtYXR0ZWRWaWV3KTtcbiAgICAgICAgICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAgICAgICAgIC8qKlxuICAgICAgICAgICAgICAgICAgICAgKiBnZXQgdGhlIGlucHV0J3MgdmlldyB2YWx1ZVxuICAgICAgICAgICAgICAgICAgICAgKi9cbiAgICAgICAgICAgICAgICAgICAgZnVuY3Rpb24gZ2V0Vmlld1ZhbHVlKCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIG5nTW9kZWxDdHJsLiR2aWV3VmFsdWU7XG4gICAgICAgICAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgICAgICAgICAvKipcbiAgICAgICAgICAgICAgICAgICAgICogZm9ybWF0cyB0aGUgaW5wdXQgdmlldyB2YWx1ZSB0byBiZSB0aGUgZm9ybWF0IGBNTSAvIHl5YCBhbmQgcmUtcmVuZGVycyB2aWV3XG4gICAgICAgICAgICAgICAgICAgICAqL1xuICAgICAgICAgICAgICAgICAgICBmdW5jdGlvbiByZW5kZXJGb3JtYXR0ZWRWaWV3KHZpZXdWYWx1ZSwgcHJldlZpZXdWYWx1ZSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgaWYgKCF2aWV3VmFsdWUpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICByZXR1cm47XG4gICAgICAgICAgICAgICAgICAgICAgICB9XG5cbiAgICAgICAgICAgICAgICAgICAgICAgIC8vIGEgbmV3IHZhbHVlIGlzIGFkZGVkIChhcyBvcHBvc2VkIHRvIHByZXNzaW5nIGJhY2tzcGFjZSlcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IGlzQWRkaXRpb24gPSB2aWV3VmFsdWUubGVuZ3RoID4gcHJldlZpZXdWYWx1ZS5sZW5ndGg7XG5cbiAgICAgICAgICAgICAgICAgICAgICAgIG5nTW9kZWxDdHJsLiRzZXRWaWV3VmFsdWUoZm9ybWF0KHZpZXdWYWx1ZSwgaXNBZGRpdGlvbikpO1xuICAgICAgICAgICAgICAgICAgICAgICAgbmdNb2RlbEN0cmwuJHJlbmRlcigpO1xuICAgICAgICAgICAgICAgICAgICB9XG5cbiAgICAgICAgICAgICAgICAgICAgLyoqXG4gICAgICAgICAgICAgICAgICAgICAqIFZhbGlkYXRlcyB3aGV0aGVyIHRoZSBlbnRlcmVkIGV4cGlyYXRpb24gZGF0ZSBpcyB2YWxpZFxuICAgICAgICAgICAgICAgICAgICAgKi9cbiAgICAgICAgICAgICAgICAgICAgZnVuY3Rpb24gdmFsaWRGdXR1cmVEYXRlKG1vZGVsVmFsdWUpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IHttb250aCwgeWVhcn0gPSBtb2RlbFZhbHVlO1xuXG4gICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gaXNWYWxpZERhdGUobW9udGgsIHllYXIpICYmICFpc1Bhc3QobW9udGgsIHllYXIpO1xuICAgICAgICAgICAgICAgICAgICB9XG5cbiAgICAgICAgICAgICAgICAgICAgLyoqXG4gICAgICAgICAgICAgICAgICAgICAqIFZhbGlkYXRlcyB3aGV0aGVyIHRoZSBnaXZlbiBtb250aCBhbmQgeWVhciBhcmUgbnVtYmVyIHN0cmluZ3Mgd2l0aCBsZW5ndGggb2YgMiBhbmQgNCByZXNwZWN0aXZlbHlcbiAgICAgICAgICAgICAgICAgICAgICovXG4gICAgICAgICAgICAgICAgICAgIGZ1bmN0aW9uIGlzVmFsaWREYXRlKG1vbnRoLCB5ZWFyKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICBjb25zdCBtb250aFJlZ2V4ID0gL15bMC05XXsyfSQvO1xuICAgICAgICAgICAgICAgICAgICAgICAgY29uc3QgeWVhclJlZ2V4ID0gL15bMC05XXs0fSQvO1xuXG4gICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gXy5pc1N0cmluZyhtb250aCkgJiZcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBfLmlzU3RyaW5nKHllYXIpICYmXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbW9udGhSZWdleC50ZXN0KG1vbnRoKSAmJlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHllYXJSZWdleC50ZXN0KHllYXIpICYmXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaXNWYWxpZE1vbnRoKG1vbnRoKTtcbiAgICAgICAgICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAgICAgICAgIC8qKlxuICAgICAgICAgICAgICAgICAgICAgKiBDaGVja3Mgd2hldGhlciB0aGUgbW9udGggaXMgdmFsaWRcbiAgICAgICAgICAgICAgICAgICAgICovXG4gICAgICAgICAgICAgICAgICAgIGZ1bmN0aW9uIGlzVmFsaWRNb250aChtb250aCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgbW9udGggPSBfLnBhcnNlSW50KG1vbnRoKTtcblxuICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIG1vbnRoID4gMCAmJiBtb250aCA8IDEzO1xuICAgICAgICAgICAgICAgICAgICB9XG5cbiAgICAgICAgICAgICAgICAgICAgLyoqXG4gICAgICAgICAgICAgICAgICAgICAqIENoZWNrcyB3aGV0aGVyIHRoZSBnaXZlbiBtb250aCBhbmQgZGF0ZSBpcyBpbiB0aGUgcGFzdFxuICAgICAgICAgICAgICAgICAgICAgKi9cbiAgICAgICAgICAgICAgICAgICAgZnVuY3Rpb24gaXNQYXN0KG1vbnRoLCB5ZWFyKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gZ2V0Q3Vyck1vbnRoRGF0ZSgpID4gbmV3IERhdGUoeWVhciwgbW9udGggLSAxKTtcbiAgICAgICAgICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAgICAgICAgIC8qKlxuICAgICAgICAgICAgICAgICAgICAgKiBHZXQgdGhlIGRhdGUgb2JqZWN0IGJhc2VkIG9uIGN1cnJlbnQgbW9udGggYW5kIHllYXJcbiAgICAgICAgICAgICAgICAgICAgICovXG4gICAgICAgICAgICAgICAgICAgIGZ1bmN0aW9uIGdldEN1cnJNb250aERhdGUoKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICBjb25zdCBkYXRlID0gbmV3IERhdGUoKTtcblxuICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIG5ldyBEYXRlKGRhdGUuZ2V0RnVsbFllYXIoKSwgZGF0ZS5nZXRNb250aCgpKTtcbiAgICAgICAgICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAgICAgICAgIC8qKlxuICAgICAgICAgICAgICAgICAgICAgKiBVc2VzIGFuZ3VsYXIgZGF0ZSBmaWx0ZXIgdG8gZm9ybWF0IGRhdGUgbW9kZWwgdG8gY29ycmVzcG9uZGluZyB2aWV3IGZvcm1hdFxuICAgICAgICAgICAgICAgICAgICAgKi9cbiAgICAgICAgICAgICAgICAgICAgZnVuY3Rpb24gZm9ybWF0dGVyKGV4cCA9IHt9KSB7XG4gICAgICAgICAgICAgICAgICAgICAgICBjb25zdCBtb250aCA9IGV4cC5tb250aDtcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IHllYXIgPSBleHAueWVhcjtcblxuICAgICAgICAgICAgICAgICAgICAgICAgaWYgKF8uaXNFbXB0eShtb250aCkgJiYgXy5pc0VtcHR5KHllYXIpKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuICcnO1xuICAgICAgICAgICAgICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gJGZpbHRlcignZGF0ZScpKG5ldyBEYXRlKHllYXIsIG1vbnRoIC0gMSksICdNTSAvIHl5Jyk7XG4gICAgICAgICAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgICAgICAgICAvKipcbiAgICAgICAgICAgICAgICAgICAgICogUGFyc2VzIHRoZSBmb3JtYXR0ZWQgdmlldyB2YWx1ZXMgdG8gbW9kZWwuIENvbnZlcnRzIDIgZGlnaXQgeWVhciB0byBmdWxsIDQgZGlnaXQgeWVhclxuICAgICAgICAgICAgICAgICAgICAgKiBAcGFyYW0gZXhwaXJhdGlvbiB7b2JqZWN0fSBUaGUgZXhwaXJhdGlvbiBvYmplY3Qge21vbnRoLCB5ZWFyfVxuICAgICAgICAgICAgICAgICAgICAgKi9cbiAgICAgICAgICAgICAgICAgICAgZnVuY3Rpb24gcGFyc2VyKGV4cGlyYXRpb24pIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IGJhc2VZZWFyID0gbmV3IERhdGUoKS5nZXRGdWxsWWVhcigpLnRvU3RyaW5nKCkuc2xpY2UoMCwgMik7IC8vIGAnMjAnYFxuICAgICAgICAgICAgICAgICAgICAgICAgY29uc3QgdmFsdWVzID0gZXhwaXJhdGlvbi5zcGxpdCgnLycpO1xuICAgICAgICAgICAgICAgICAgICAgICAgY29uc3QgbW9udGggPSB2YWx1ZXNbMF0gPyB2YWx1ZXNbMF0udHJpbSgpIDogJyc7XG4gICAgICAgICAgICAgICAgICAgICAgICBjb25zdCB5ZWFyID0gdmFsdWVzWzFdID8gYmFzZVllYXIgKyB2YWx1ZXNbMV0udHJpbSgpIDogJyc7XG5cbiAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiB7IG1vbnRoLCB5ZWFyIH07XG4gICAgICAgICAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgICAgICAgICAvKipcbiAgICAgICAgICAgICAgICAgICAgICogZm9ybWF0cyB0aGUgdmlldyB2YWx1ZSB0byB0aGUgZm9ybSAnTU0gLyB5eSdcbiAgICAgICAgICAgICAgICAgICAgICovXG4gICAgICAgICAgICAgICAgICAgIGZ1bmN0aW9uIGZvcm1hdChleHBTdHIsIGlzQWRkaXRpb24pIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IHZhbHVlcyA9IGV4cFN0ci5zcGxpdCgnLycpO1xuICAgICAgICAgICAgICAgICAgICAgICAgY29uc3QgbW9udGggPSB2YWx1ZXNbMF0gPyB2YWx1ZXNbMF0udHJpbSgpIDogJyc7XG4gICAgICAgICAgICAgICAgICAgICAgICBjb25zdCB5ZWFyID0gdmFsdWVzWzFdID8gdmFsdWVzWzFdLnRyaW0oKS5zbGljZSgtMikgOiAnJztcblxuICAgICAgICAgICAgICAgICAgICAgICAgLy8gZG9uJ3QgYWRkIHNsYXNoXG4gICAgICAgICAgICAgICAgICAgICAgICBpZiAoKCFpc0FkZGl0aW9uICYmICF5ZWFyKSB8fCBtb250aC5sZW5ndGggPCAyKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIG1vbnRoO1xuICAgICAgICAgICAgICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAgICAgICAgICAgICAvLyBhZGQgc2xhc2ggaW4gdGhlIHJpZ2h0IHNwb3RcbiAgICAgICAgICAgICAgICAgICAgICAgIGlmIChpc0FkZGl0aW9uICYmICF5ZWFyICYmIG1vbnRoLmxlbmd0aCA+IDIpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gYCR7bW9udGguc2xpY2UoMCwgMil9IC8gJHttb250aC5zbGljZSgyKX1gO1xuICAgICAgICAgICAgICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gYCR7bW9udGh9IC8gJHt5ZWFyfWA7XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICB9O1xuICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIHJlcXVpcmU6ICduZ01vZGVsJyxcbiAgICAgICAgICAgIHJlc3RyaWN0OiAnQScsXG4gICAgICAgIH07XG4gICAgfSk7XG4iLCJhbmd1bGFyLm1vZHVsZSgnYmNhcHAtcGF0dGVybi1sYWIuY3JlZGl0LWNhcmQuY2MtZXhwaXJ5JywgW1xuICAgICdiY2FwcC1wYXR0ZXJuLWxhYi5jcmVkaXQtY2FyZC5jYy1leHBpcnkuZGlyZWN0aXZlJyxcbl0pO1xuIiwiLyoqXG4gKiBAbmFtZSBiYy1jdmMgZGlyZWN0aXZlXG4gKiBAZGVzY3JpcHRpb24gQSBjdXN0b20gY29tcGxlbWVudGFyeSBkaXJlY3RpdmUgdG8gYW5ndWxhci1jcmVkaXQtY2FyZCdzIGBjY0N2Y2AgZGlyZWN0aXZlLlxuICogVG8gc3VwcG9ydCBhbGxvd2luZyBhbiBvcHRpb25hbCBjdmMgZmllbGQgKGkuZS4gU2VjdXJlbmV0KSwgdGhpcyBkaXJlY3RpdmUgbXVzdCBvdmVycmlkZVxuICogdGhlIHZhbGlkYXRpb24gcHJvdmlkZWQgYnkgY2NDdmMgZGlyZWN0aXZlLlxuICovXG5hbmd1bGFyLm1vZHVsZSgnYmNhcHAtcGF0dGVybi1sYWIuY3JlZGl0LWNhcmQuYmMtY3ZjJywgW1xuICAgICdjcmVkaXQtY2FyZHMnLFxuXSlcbiAgICAuZGlyZWN0aXZlKCdiY0N2YycsIGZ1bmN0aW9uIGJjQ3ZjRGlyZWN0aXZlKCRwYXJzZSkge1xuICAgICAgICByZXR1cm4ge1xuICAgICAgICAgICAgbGluazogZnVuY3Rpb24gYmNDdmNMaW5rKHNjb3BlLCBlbGVtZW50LCBhdHRyaWJ1dGVzLCBuZ01vZGVsKSB7XG4gICAgICAgICAgICAgICAgLy8gb3ZlcnJpZGUgdGhlIHZhbGlkYXRpb24gdG8gYWx3YXlzIHJldHVybiB2YWxpZFxuICAgICAgICAgICAgICAgIC8vIGlmIGN2YyBpcyBub3QgcmVxdWlyZWRcbiAgICAgICAgICAgICAgICBpZiAoISRwYXJzZShhdHRyaWJ1dGVzLm5nUmVxdWlyZWQpKHNjb3BlKSkge1xuICAgICAgICAgICAgICAgICAgICBuZ01vZGVsLiR2YWxpZGF0b3JzLmNjQ3ZjID0gKCkgPT4gdHJ1ZTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9LFxuICAgICAgICAgICAgcHJpb3JpdHk6IDUsIC8vIGhpZ2hlciBwcmlvcml0eSB0byBlbnN1cmUgY2NDdmMncyBsaW5rIGlzIHJhbiBmaXJzdFxuICAgICAgICAgICAgcmVxdWlyZTogJ25nTW9kZWwnLFxuICAgICAgICAgICAgcmVzdHJpY3Q6ICdBJyxcbiAgICAgICAgfTtcbiAgICB9KTtcbiIsIi8qKlxuICogQG5hbWUgdHJ1c3RBc0h0bWxcbiAqIEBkZXNjcmlwdGlvbiBTaW1wbGUgdXRpbGl0eSBmaWx0ZXIgdG8gcnVuIHRoZSBnaXZlbiBodG1sIHN0cmluZyB0aHJvdWdoIGFuZ3VsYXIncyAkc2NlLnRydXN0QXNIdG1sIGZ1bmN0aW9uLlxuICpcbiAqIEBwYXJhbSB7U3RyaW5nfSB0ZXh0IFRoZSBodG1sIHN0cmluZyB0byB0cnVzdFxuICogQHJldHVybiB7U3RyaW5nfSBBbiBhbmd1bGFyLXRydXN0ZWQgb2JqZWN0IGNvbnRhaW5pbmcgdGhlIGh0bWxcbiAqXG4gKiBAZXhhbXBsZSBgPHAgbmctYmluZC1odG1sPVwicmF3SHRtbCB8IHRydXN0QXNIdG1sXCI+PC9wPmBcbiAqL1xuYW5ndWxhci5tb2R1bGUoJ2JjYXBwLXBhdHRlcm4tbGFiLnV0aWwudHJ1c3RBc0h0bWwnLCBbXSlcbiAgICAuZmlsdGVyKCd0cnVzdEFzSHRtbCcsIGZ1bmN0aW9uIHRydXN0QXNIdG1sKCRzY2Upe1xuICAgICAgICByZXR1cm4gZnVuY3Rpb24odGV4dCkge1xuICAgICAgICAgICAgcmV0dXJuICRzY2UudHJ1c3RBc0h0bWwodGV4dCk7XG4gICAgICAgIH07XG4gICAgfSk7XG4iXSwic291cmNlUm9vdCI6Ii9zb3VyY2UvIn0=