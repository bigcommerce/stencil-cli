/* */ 
angular.module('website.accordion', [
    'website.accordion.state'
]);
