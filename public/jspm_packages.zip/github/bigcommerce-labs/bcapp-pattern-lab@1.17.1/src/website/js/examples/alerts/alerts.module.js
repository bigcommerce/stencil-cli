/* */ 
angular.module('website.alerts', [
    'website.alerts.state'
]);
