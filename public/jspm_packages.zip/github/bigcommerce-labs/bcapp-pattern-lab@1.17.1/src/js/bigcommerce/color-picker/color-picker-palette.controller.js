/* */ 
angular.module('bcapp-pattern-lab.color-picker-palette.controller', [])

    .controller('ColorPickerPaletteCtrl', function() {
        let ctrl = this;

        ctrl.createNewColor = createNewColor;

        function createNewColor($event) {
            $event.preventDefault();

            ctrl.createNewPaletteColor();
        }
    });
