/* */ 
describe('Credit card types directive', function() {
    var $compile,
        $scope,
        element,
        isolateScope;

    beforeEach(function() {
        module('bcapp-pattern-lab-templates');
        module('bcapp-pattern-lab.credit-card-types');
    });

    beforeEach(inject(function($injector) {
        $compile = $injector.get('$compile');
        $scope = $injector.get('$rootScope').$new();

        $scope.selectedType = null;

        $scope.supportedTypes = ['Visa', 'MasterCard'];
    }));

    beforeEach(function() {
        element = compileDirective($scope);
        isolateScope = element.find('credit-card-types').isolateScope();
    });

    function compileDirective(scope, tpl) {
        var element = angular.element(tpl || '<credit-card-types selected-type="selectedType" supported-types="supportedTypes"></credit-card-types>'),
            compiledElement = $compile(element)(scope);

        scope.$digest();

        return compiledElement;
    }

    describe('compiled markup', function() {
        it('should have a list of items corresponding to the number of supportedTypes', function() {
            expect(element.find('ul').length).toEqual(1);
            expect(element.find('li').length).toEqual($scope.supportedTypes.length);
        });
    });

    describe('functionality', function() {
        it('should not have `.is-active` or `.not-active` classes when a type is not yet selected', function() {
            $scope.selectedType = null;
            $scope.$digest();

            expect(element[0].getElementsByClassName('is-active').length).toEqual(0);
            expect(element[0].getElementsByClassName('not-active').length).toEqual(0);
        });

        it('should have only one list item with the "is-active" class', function() {
            $scope.selectedType = 'Visa';

            $scope.$digest();

            expect(element[0].getElementsByClassName('is-active').length).toEqual(1);
            expect(element[0].getElementsByClassName('not-active').length).toEqual($scope.supportedTypes.length - 1);
        });

        it('should not have any list item with the "is-active" class when an unsupported type is selected', function() {
            $scope.selectedType = 'Discover';

            $scope.$digest();

            expect(element[0].getElementsByClassName('is-active').length).toEqual(0);
            expect(element[0].getElementsByClassName('not-active').length).toEqual($scope.supportedTypes.length);
        });
    });
});
