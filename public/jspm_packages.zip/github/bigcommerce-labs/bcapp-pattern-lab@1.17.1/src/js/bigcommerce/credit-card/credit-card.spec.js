/* */ 
describe('Credit card directive', function() {
    var $compile,
        $httpBackend,
        $scope,
        element,
        isolateScope;

    beforeEach(function() {
        angular.module('testModule', [
            'bcapp-pattern-lab.icon',
            'bcapp-pattern-lab-templates',
            'bcapp-pattern-lab.credit-card'
        ])
            .config(function(svgRootPathProvider) {
                svgRootPathProvider.setRootPath('/svg/icons/');
            });

        module('testModule');
    });

    beforeEach(inject(function($injector) {
        $compile = $injector.get('$compile');
        $httpBackend = $injector.get('$httpBackend');
        $scope = $injector.get('$rootScope').$new();

        $scope.ccData = {
            ccNumber: '',
            ccCvv: '',
            ccName: '',
            ccExpiry: {
                month: '',
                year: ''
            },
            ccType: ''
        };

        $scope.ccConfig = {
            cardCode: true,
            fullName: true
        };
    }));

    beforeEach(function() {
        $httpBackend.whenGET(/\/svg\/icons\/*/).respond({});

        element = compileDirective($scope);
        isolateScope = element.find('credit-card').isolateScope();
    });

    function compileDirective(scope, tpl) {
        var element = angular.element(tpl || '<form><credit-card cc-data="ccData" cc-config="ccConfig"></credit-card></form>'),
            compiledElement = $compile(element)(scope);

        scope.$digest();

        return compiledElement;
    }

    describe('compiled markup', function() {
        it('should contain 4 form-field elements', function() {
            expect(element.find('form-field').length).toEqual(4);
        });

        it('should have autocomplete attribute in all inputs', function() {
            var elements = element.find('input');

            _.each(elements, function(input) {
                expect(angular.element(input).attr('autocomplete')).not.toBe(undefined);
            });
        });
    });

    describe('functionality', function() {
        it('should get the correct scope values', function() {
            expect(isolateScope.ccData).toEqual($scope.ccData);
            expect(isolateScope.ccConfig).toEqual($scope.ccConfig);
        });

        it('should have the card type reflect $ccEagerType when this feature is enabled (default)', function() {
            var type = 'visa';

            isolateScope.formCtrl.ccNumber.$ccEagerType = type;
            isolateScope.$digest();

            expect(isolateScope.ccData.ccType).toBe(type);

            type = 'Master Card';
            isolateScope.formCtrl.ccNumber.$ccEagerType = type;
            isolateScope.$digest();

            expect(isolateScope.ccData.ccType).toBe(type);
        });

        it('should have the card type reflect $ccType when eager-type is disabled', function() {
            var eagerTypeDisabledTpl = '<form><credit-card cc-data="ccData" cc-config="ccConfig" eager-type="false"></credit-card></form>';
            var type = 'visa';

            element = compileDirective($scope, eagerTypeDisabledTpl);
            isolateScope = element.find('credit-card').isolateScope();

            isolateScope.formCtrl.ccNumber.$ccType = type;
            isolateScope.$digest();

            expect(isolateScope.ccData.ccType).toBe(type);

            type = 'Master Card';
            isolateScope.formCtrl.ccNumber.$ccType = type;
            isolateScope.$digest();

            expect(isolateScope.ccData.ccType).toBe(type);
        });

        it('should contain form-field-errors with form-field-error', function() {
            var formField = element.find('form-field'),
                fieldErrors;

            _.each(formField, function(field) {
                fieldErrors = angular.element(field).find('form-field-errors')[0];

                expect(fieldErrors).not.toBe(undefined);
                expect(angular.element(fieldErrors).find('form-field-error')).not.toBe(undefined);
            });
        });
    });

    describe('ccCvv field', function() {
        var cvvInput;

        it('should be shown and required if the ccConfig.cardCode and cardCodeRequired are true (default)', function() {
            cvvInput = element[0].querySelector('#ccCvv');

            expect(cvvInput).not.toBe(null);
            expect(angular.element(cvvInput).attr('required')).toBeDefined();
        });

        it('should be shown but not required if the ccConfig.cardCode is true and cardCodeRequired is false', function() {
            $scope.ccConfig.cardCodeRequired = false;
            $scope.$digest();

            cvvInput = element[0].querySelector('#ccCvv');

            expect(cvvInput).not.toBe(null);
            expect(angular.element(cvvInput).attr('required')).toBeUndefined();
        });

        it('should not be shown at all if the ccConfig.cardCode is false', function() {
            $scope.ccConfig.cardCode = false;
            $scope.$digest();

            cvvInput = element[0].querySelector('#ccCvv');

            expect(cvvInput).toBe(null);
        });
    });
});
