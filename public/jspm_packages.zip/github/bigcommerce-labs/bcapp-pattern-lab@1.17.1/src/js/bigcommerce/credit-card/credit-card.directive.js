/**
 * @name credit-card directive
 * @description Component containing cc number, cvc, name, and expiry. Has an isolated scope with no controller.
 * @require form
 *
 * @param ccData {object} Contains ccNumber, ccType, ccExpiry, and ccName
 * @param ccConfig {object} The configuration object. Currently supporting:
 *  - cardCode {boolean} Indicates whether the cvv field should be shown. Default true.
 *  - cardCodeRequired {boolean} Indicates whether the cvv field is required. This only matters when cardCode is set to true. Default true.
 *  - fullName {boolean} Indicates whether the name field should be shown. Default true.
 * @param eagerType {boolean} If this attribute is set to false, then disable eager type detection. Defaults true.
 */
angular.module('bcapp-pattern-lab.credit-card.directive', [
    'bcapp-pattern-lab.icon'
])
    .directive('creditCard', function creditCardDirective($compile, $parse, $templateCache) {
        const cvvTooltipTemplate = $templateCache.get('src/js/bigcommerce/credit-card/credit-card-cvv/tooltip.tpl.html');

        return {
            compile: function creditCardCompile(tElem, tAttrs){
                let isEagerType = true;

                if (tAttrs.eagerType && $parse(tAttrs.eagerType)() === false) {
                    const ccNumber = tElem[0].querySelector('#ccNumber');

                    ccNumber.removeAttribute('ccEagerType');
                    isEagerType = false;
                }

                return function creditCardLink(scope, elem, attr, formCtrl) {
                    const cvvTooltipElement = $compile(cvvTooltipTemplate)(scope);
                    const defaultConfig = {
                        cardCode: true,
                        cardCodeRequired: true,
                        fullName: true,
                    };

                    scope.getCvvTooltipHtml = getCvvTooltipHtml;

                    init();

                    function init() {
                        scope.formCtrl = formCtrl;
                        scope.ccConfig = _.defaults(scope.ccConfig, defaultConfig);

                        /**
                         * The credit card type is deduced by the `ccNumber` directive. This is in turn exposed
                         * as either `$ccEagerType` or `$ccType` on the input control element. Watch for changes and bind the type to the corresponding
                         * value on ccData.
                         */
                        scope.$watch(getDetectedCcType, setCcType);
                    }

                    /**
                     * Return the html for the tooltip. Using outerHTML to also include the root element
                     * @return {String} Html string for the cvv tooltip template
                     */
                    function getCvvTooltipHtml() {
                        return cvvTooltipElement[0].outerHTML;
                    }

                    /**
                     * Get the detected credit card type exposed on the form control by the ccNumber child directive.
                     * This value will be exposed as $ccEagerType or $ccType depending on whether this feature is enabled.
                     * @return {string|null}
                     */
                    function getDetectedCcType() {
                        return isEagerType ? formCtrl.ccNumber.$ccEagerType : formCtrl.ccNumber.$ccType;
                    }

                    /**
                     * Set ccData.ccType
                     * @param {string|null} type The credit card type, i.e. 'visa'
                     * @return {string|null} type
                     */
                    function setCcType(type) {
                        scope.ccData.ccType = type;

                        return type;
                    }
                };
            },
            require: '^form',
            restrict: 'EA',
            scope: {
                ccData: '=',
                ccConfig: '=',
            },
            templateUrl: 'src/js/bigcommerce/credit-card/credit-card.tpl.html'
        };
    });
