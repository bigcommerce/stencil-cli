/* */ 
angular.module('bcapp-pattern-lab.util', [
    'bcapp-pattern-lab.util.trustAsHtml'
]);
