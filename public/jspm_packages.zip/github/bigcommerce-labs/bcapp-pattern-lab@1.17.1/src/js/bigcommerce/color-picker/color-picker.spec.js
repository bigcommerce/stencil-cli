/* */ 
describe('Color picker directive', function() {
    var $compile,
        $rootScope,
        scope,
        elementWithPalette,
        elementWithoutPalette,
        mockPalette = [
            '#00ABC9',
            '#E5F6F9',
            '#95DB89',
            '#FFB800'
        ];

    beforeEach(module('bcapp-pattern-lab-templates'));
    beforeEach(module('bcapp-pattern-lab.color-picker.directive'));

    beforeEach(inject(function($injector) {
        $compile = $injector.get('$compile');
        $rootScope = $injector.get('$rootScope');
    }));

    function compileDirective(scope) {

        var tplWithPalette = angular.element(
                '<color-picker palette="palette" ng-model="modelValue">' +
                '</color-picker>'
            ),
            tplWithoutPalette = angular.element(
                '<color-picker ng-model="modelValue">' +
                '</color-picker>'
            );

        scope = scope || $rootScope.$new();

        elementWithPalette = $compile(tplWithPalette)(scope);
        elementWithoutPalette = $compile(tplWithoutPalette)(scope);

        scope.$digest();

        return scope;
    }

     // before each test, create a new fresh scope
    beforeEach(inject(function($rootScope) {
        scope = $rootScope.$new();
        scope.palette = mockPalette;
        scope.modelValue = '#ffffff';
    }));

    beforeEach(function() {
        compileDirective(scope);
    });

    describe('color-picker element' , function() {
        it('should include the standard class', function() {
            expect(elementWithPalette.hasClass('colorPicker')).toBe(true);
        });
    });

    describe('color-picker selection pane' , function() {
        it('should initialise the color picker selection svg element', function() {
            var el = elementWithPalette[0].querySelector('[data-bc-picker]');
            expect(el.firstElementChild.nodeName).toBe('svg');
        });
    });

    describe('color-picker slider pane' , function() {
        it('should initialise the color picker slider svg element', function() {
            var el = elementWithPalette[0].querySelector('[data-bc-slider]');
            expect(el.firstElementChild.nodeName).toBe('svg');
        });
    });

    describe('color-picker-palette' , function() {
        it('should create the color-picker-palette element when palette data present', function() {
            var el = elementWithPalette[0].querySelector('color-picker-palette');
            expect(el).not.toBe(null);
        });
    });

    describe('color-picker ngModel' , function() {
        it('should set ngModel on initialisation', function() {
            expect(elementWithPalette.isolateScope().colorPickerCtrl.color).toBe(scope.modelValue);
        });

        it('should update color when new color is picked', function() {
            var newColor = '#000000';
            elementWithPalette.isolateScope().colorPickerCtrl.cp.setHex(newColor);
            expect(elementWithPalette.isolateScope().colorPickerCtrl.color).toBe(newColor);
        });
    });
});
