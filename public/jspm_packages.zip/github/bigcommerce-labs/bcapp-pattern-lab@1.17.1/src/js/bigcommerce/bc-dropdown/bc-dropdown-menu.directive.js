/* */ 
angular.module('bcapp-pattern-lab.bc-dropdown-menu.directive', [])
    .directive('bcDropdownMenu', () => {
        return {
            restrict: 'A',
            require: '^bcDropdown',
            compile: (tElement) => {
                tElement.addClass('dropdown-menu');
                tElement.attr('role', 'listbox');

                return (scope, element, attrs, bcDropdownCtrl) => {
                    element.attr('id', bcDropdownCtrl.getUniqueId());
                    element.attr('aria-expanded', bcDropdownCtrl.getIsOpen());
                    // listen for dropdowns being opened and toggle aria-expanded to reflect current state
                    scope.$on('toggleThisDropdown', () => {
                        element.attr('aria-expanded', bcDropdownCtrl.getIsOpen());
                    });
                };
            }
        };
    });
