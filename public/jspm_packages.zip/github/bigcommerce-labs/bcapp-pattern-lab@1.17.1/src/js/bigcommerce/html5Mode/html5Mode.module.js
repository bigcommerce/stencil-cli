/* */ 
angular.module('bcapp-pattern-lab.html5Mode', [
    'bcapp-pattern-lab.html5Mode.service'
]);
