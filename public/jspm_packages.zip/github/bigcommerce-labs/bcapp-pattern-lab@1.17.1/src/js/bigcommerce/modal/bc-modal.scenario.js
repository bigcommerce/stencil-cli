/* */ 
describe('modal', function() {
    var modalButton;

    beforeEach(function() {
        browser.get('/js-components.html#/components/modal');
    });

    beforeEach(function() {
        modalButton = $('#openModal--formatted'); // the anchor to open the formatted modal
    });

    describe('Open modal', function() {
        it('should add a class to the body element', function() {
            expect($('body')).not.toHaveClass('has-activeModal');

            modalButton.click();

            expect($('body')).toHaveClass('has-activeModal');
        });

        it('should attach the modal element', function() {
            expect($('.modal').isPresent()).toBe(false);

            modalButton.click();

            expect($('.modal').isPresent()).toBe(true);
        });

        it('should attach the modal background element', function() {
            expect($('.modal-background').isPresent()).toBe(false);

            modalButton.click();

            expect($('.modal-background').isPresent()).toBe(true);
        });
    });

    describe('Close modal', function() {
        beforeEach(function() {
            modalButton.click();
        });

        afterEach(function() {
            expect($('.modal-background').isPresent()).toBe(false);
            expect($('.modal').isPresent()).toBe(false);
            expect($('body')).not.toHaveClass('has-activeModal');
        });

        it('should close modal when outside of the modal element is clicked', function() {
            browser.actions().mouseMove({x: 0, y: 0}).click().perform();
        });

        it('should close modal when the close-modal icon is clicked', function() {
            $('.modal-close').click();
        });

        it('should close modal when the ok button is clicked', function() {
            $('.modal-footer-link').click();
        });

        it('should close modal when the cancel button is clicked', function() {
            $('.modal-footer .button').click();
        });
    });
});
