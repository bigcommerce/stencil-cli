/* */ 
"format global";
var gulp = require('gulp'),
    runSequence = require('run-sequence');

gulp.task('run', function(callback) {
    runSequence(
        'build',
        'watch',
        callback
    );
});

gulp.task('run:browser', function(callback) {
    runSequence(
        'run',
        [
            'connect',
            'browsersync'
        ],
        callback
    );
});

gulp.task('run:bcapp', function(callback) {
    runSequence('run',
        'copy:transclude',
        callback
    );
});
