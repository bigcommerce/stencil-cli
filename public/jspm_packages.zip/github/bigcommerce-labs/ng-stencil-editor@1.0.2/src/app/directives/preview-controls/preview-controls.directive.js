import PreviewControlsController from 'src/app/directives/preview-controls/preview-controls.controller.js';

class PreviewControls {
    constructor() {
        this.bindToController = true;
        this.controller = PreviewControlsController;
        this.controllerAs = 'previewControlsCtrl';
        this.restrict = 'AE';
        this.templateUrl = 'app/directives/preview-controls/preview-controls.tpl.html';
    }

    /** @ngInject */
    static directiveFactory() {
        return new PreviewControls();
    }
}

PreviewControls.directiveFactory.$inject = [];

export default PreviewControls.directiveFactory;
