export default class {
    /*@ngInject*/
    constructor(previewControls, stencilConfig) {
        this._previewControls = previewControls;
        this._stencilConfig = stencilConfig;
    }

    setSize(size) {
        if (this._previewControls.canFlip(size) && this._previewControls.getSize() === size) {
            this._previewControls.flip();
        }

        this._previewControls.setSize(size);
    }

    getSize() {
        return this._previewControls.getSize();
    }

    isFlipped() {
        return this._previewControls.isFlipped();
    }
}
