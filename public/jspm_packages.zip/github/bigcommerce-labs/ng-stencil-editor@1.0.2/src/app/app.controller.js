export default class AppCtrl {
    /*@ngInject*/
    constructor($cookies, $scope, $window, gettextCatalog, stencilConfig) {
        this._$cookies = $cookies;
        this._$scope = $scope;
        this._gettextCatalog = gettextCatalog;
        this._stencilConfig = stencilConfig;

        $window.addEventListener('mouseover', _.bind(_.throttle(this.emitActive, 2000), this));
        $window.addEventListener('beforeunload', _.bind(this.confirmExit, this));
        $window.addEventListener('unload', _.bind(this.removeCookie, this));
        $window.addEventListener('unload', _.bind(this.resetConfig, this));

        // Set initial cookie
        $cookies.stencil_editor_enabled = stencilConfig.getEditorToken();
    }

    confirmExit(event) {
        if (this._stencilConfig.hasChanges()) {
            const confirmationMessage = this._gettextCatalog.getString('You will lose all unsaved changes.');

            // Cross-browser compatibility
            event.returnValue = confirmationMessage;

            // beforeunload expects any return to trigger the confirmation alert
            return confirmationMessage;
        }
    }

    emitActive() {
        this._$scope.$emit('themeRelay', {
            method: 'window-active'
        });
    }

    removeCookie() {
        this._$scope.$apply(() => {
            delete this._$cookies['stencil_editor_enabled'];
        });
    }

    resetConfig() {
        if (this._stencilConfig.hasChanges()) {
            this._stencilConfig.reset();
            this._stencilConfig.saveNative();
        }
    }
}
