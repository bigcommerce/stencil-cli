export default class Fonts {
    /*@ngInject*/
    constructor($rootScope, stencilConfig) {
        this._$rootScope = $rootScope;
        this._stencilConfig = stencilConfig;
        this._loadedFonts = {};

        this.setInitialFonts();
    }

    emitInjectFont(fontUrl) {
        if (fontUrl) {
            this._$rootScope.$emit('themeRelay', {
                method: 'add-font',
                params: {
                    fontUrl: fontUrl
                }
            });
        }
    }

    setInitialFonts() {
        const fontKeyFormat = new RegExp(/\w+-font$/);
        const settings = this._stencilConfig.getConfig().settings;

        _.each(settings, (value, key) => {
            if (fontKeyFormat.test(key)) {
                this._loadedFonts[value] = true;
            }
        });
    }

    addFont(font) {
        if (!this._loadedFonts[font])  {
            this._loadedFonts[font] = true;

            this.emitInjectFont(this.parseFont(font));
        }
    }

    parseFont(font) {
        const provider = font.split('_')[0];

        switch (provider) {
            case 'Google':
                return this.parseGoogleFont(font);
            default:
                return;
        }
    }

    parseGoogleFont(font) {
        const split = font.split('_');

        let formattedFont = '';
        let family = split[1];
        let weight = split[2];

        if (split.length === 2) {
            formattedFont += family + '|';
        } else if (split.length > 2) {
            weight = weight.split(',')[0];
            formattedFont += family + ':' + weight + '|';
        }

        return '//fonts.googleapis.com/css?family=' + formattedFont;
    }
}
