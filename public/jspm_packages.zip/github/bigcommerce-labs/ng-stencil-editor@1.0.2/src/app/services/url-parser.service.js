export default class UrlParser {

    /**
     * Gets a query param by name (RegExp code from StackOverflow)
     * @param url
     * @param name
     * @returns {string}
     */
    getParam(url, name) {
        const search = new URL(url).search;

        name = name.replace(/[\[]/, '\\[').replace(/[\]]/, '\\]');
        const regex = new RegExp('[\\?&]' + name + '=([^&#]*)');
        const results = regex.exec(search);

        return results === null ? '' : decodeURIComponent(results[1].replace(/\+/g, ' '));
    }
}
