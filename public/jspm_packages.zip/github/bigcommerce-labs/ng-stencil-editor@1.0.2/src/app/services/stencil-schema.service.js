import _ from 'lodash';

export default class StencilSchema {
    /*@ngInject*/
    constructor($http, API) {
        this._$http = $http;
        this._API = API;
    }

    fetch() {
        return this._$http.get(this._API.BASE_PATH + this._API.SCHEMA_PATH)
            .then((resp) => {
                return this.map(resp.data);
            });
    }

    map(schema) {
        return _.map(schema, (fieldset) => {
            return {
                name: fieldset.name,
                settings: _.map(fieldset.settings, (setting) => {
                    return {
                        key: setting.id,
                        type: this.mapType(setting),
                        data: {
                            content: setting.content
                        },
                        templateOptions: {
                            label: setting.label,
                            max: setting.max,
                            min: setting.min,
                            options: setting.options || [],
                            placeholder: setting.placeholder,
                            step: setting.step,
                            type: setting.type
                        }
                    };
                })
            };
        });
    }

    mapType(setting) {
        let type = setting.type;

        if (type === 'text') {
            type = 'input';
        }

        if (type === 'image') {
            type = 'upload';
        }

        return type;
    }
}
