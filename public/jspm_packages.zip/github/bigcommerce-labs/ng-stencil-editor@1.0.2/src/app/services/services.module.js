import FontsService from 'src/app/services/fonts.service.js';
import StencilConfigService from 'src/app/services/stencil-config.service.js';
import StencilSchemaService from 'src/app/services/stencil-schema.service.js';
import UrlParserService from 'src/app/services/url-parser.service.js';

export default angular.module('ng-stencil-editor.services', [])
    .service('fonts', FontsService)
    .service('stencilConfig', StencilConfigService)
    .service('stencilSchema', StencilSchemaService)
    .service('urlParser', UrlParserService);
