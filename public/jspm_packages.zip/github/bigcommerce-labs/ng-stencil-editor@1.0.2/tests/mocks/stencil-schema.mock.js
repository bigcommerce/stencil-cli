export default [
    {
        "name": "Test",
        "settings": [
            {
                "type": "heading",
                "content": "General"
            },
            {
                "type": "color",
                "label": "Text Color",
                "id": "body-font-color"
            },
            {
                "type": "heading",
                "content": "Buttons"
            },
            {
                "type": "color",
                "label": "Primary Button Background Color",
                "id": "buttonStyle-primary-backgroundColor"
            },
            {
                "type": "heading",
                "content": "Forms"
            },
            {
                "type": "color",
                "label": "Border Color",
                "id": " input-background-color"
            },
            {
                "type": "heading",
                "content": "Panels"
            },
            {
                "type": "color",
                "label": "Border Color",
                "id": "container-border-global-color-dark"
            },
            {
                "type": "heading",
                "content": "Base typeface"
            },
            {
                "type": "font",
                "label": "Font Family",
                "id": "body-font-family"
            },
            {
                "type": "select",
                "label": "Font Size",
                "id": "fontSize-base",
                "options": [
                    {
                        "value": 10,
                        "label": "10px"
                    },
                    {
                        "value": 11,
                        "label": "11px"
                    },
                    {
                        "value": 12,
                        "label": "12px"
                    }
                ]
            },
            {
                "type": "select",
                "label": "Number of Featured Products",
                "id": "homepage_featured_products_count",
                "force_reload": true,
                "options": [
                    {
                        "value": 0,
                        "label": "Disable"
                    },
                    {
                        "value": 1,
                        "label": "1"
                    },
                    {
                        "value": 2,
                        "label": "2"
                    },
                    {
                        "value": 3,
                        "label": "3"
                    }
                ]
            },
            {
                "type": "checkbox",
                "label": "Checkbox Test",
                "id": "checkbox_test"
            },
            {
                "type": "radio",
                "id": "radio_test",
                "options": [
                    {
                        "value": 0,
                        "label": "False"
                    },
                    {
                        "value": 1,
                        "label": "True"
                    }
                ]
            }
        ]
    }
];
