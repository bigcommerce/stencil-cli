/* */ 
describe('bcServerTable directive', function() {
    var rows = [{ id: 1 }, { id: 2 }, { id: 3 }, { id: 4 }],
        elem,
        scope,
        ctrl;

    function compileDirective(tpl) {
        tpl = tpl || '<bc-server-table table-config="tableConfig" resource-callback="resourceCallback"></bc-server-table>';
        inject(function($compile) {
            elem = $compile(tpl)(scope);
        });
        // $digest to finalize the directive generation
        scope.$digest();
        ctrl = scope.bcServerTable;
    }

    beforeEach(module('bcapp-pattern-lab.bc-server-table.directive'));
    beforeEach(module(function($provide) {
        $provide.value('$stateParams', {
            page: 7,
            limit: 13,
            sortField: 'test',
            sortOrder: 'desc'
        });
    }));

    // before each test, create a new fresh scope
    beforeEach(inject(function($rootScope, $q) {
        scope = $rootScope.$new();
        scope.tableConfig = {
            queryKeys: {
                page: 'page',
                limit: 'limit',
                sortBy: 'sortField',
                sortDir: 'sortOrder'
            },
            sortDirValues: {
                asc: 'asc',
                desc: 'desc'
            },
            rowIdKey: 'id'
        };
        scope.resourceCallback = resourceCallback;

        function resourceCallback(params) {
            return $q.when({
                rows: rows,
                pagination: {
                    page: params.page,
                    limit: params.limit,
                    total: 4
                }
            });
        }
    }));

    describe('initialization', function() {
        it('should use the default tableConfig if none are passed', function() {
            compileDirective('<bc-server-table resource-callback="resourceCallback"></bc-server-table>');
            expect(ctrl.tableConfig).toBeDefined();
            expect(ctrl.tableConfig.queryKeys).toBeDefined();
            expect(ctrl.tableConfig.sortDirValues).toBeDefined();
        });

        it('should log an error if a function is not passed as the resourceCallback', inject(function($log) {
            spyOn($log, 'error');
            compileDirective('<bc-server-table></bc-server-table>');
            expect($log.error).toHaveBeenCalled();
        }));

        it('should call the resource-callback function', function() {
            spyOn(scope, 'resourceCallback').and.callThrough();
            compileDirective();
            expect(scope.resourceCallback).toHaveBeenCalled();
        });

        it('should log an error if the resource-callback function does not return an object in the correct format.', inject(function($log, $q) {
            spyOn($log, 'error');
            scope.resourceCallback = function() {
                return $q.when(4);
            };
            compileDirective();
            scope.resourceCallback = function() {
                return $q.when({});
            };
            compileDirective();
            scope.resourceCallback = function() {
                return $q.when({rows: []});
            };
            compileDirective();
            scope.resourceCallback = function() {
                return $q.reject({});
            };
            compileDirective();
            expect($log.error.calls.count()).toBe(4);
        }));

        it('should set the pagination values according the the stateParams and the returned resource', function() {
            compileDirective();
            expect(ctrl.pagination).toEqual({
                page: 7,
                limit: 13,
                total: 4
            });
        });

        it('should set the pagination values according the the stateParams', function() {
            compileDirective();
            expect(ctrl.sortBy).toEqual('test');
            expect(ctrl.sortDir).toEqual('desc');
        });

        it('should expose the rows object on the controller', function() {
            compileDirective();
            expect(scope.bcServerTable.rows).toEqual(rows);
        });

        it('should populate the selectedRows controller object', function() {
            expect(ctrl.selectedRows).toEqual({
                '1': false,
                '2': false,
                '3': false,
                '4': false
            });
        });
    });

    describe('updateTable method', function() {
        it('should initiate a stateTransition when called', inject(function($state) {
            spyOn($state, 'transitionTo');
            compileDirective();
            ctrl.updateTable();
            expect($state.transitionTo).toHaveBeenCalled();
        }));

        it('should pass the correct state params', inject(function($state) {
            spyOn($state, 'transitionTo');
            scope.tableConfig.filters = ['hello'];
            compileDirective();
            ctrl.setPaginationValues({
                page: 9,
                limit: 88
            });
            ctrl.sortBy = 'name';
            ctrl.sortDir = 'asc';
            ctrl.filters = {
                hello: 'World'
            };
            ctrl.updateTable();
            expect($state.transitionTo).toHaveBeenCalled();
            expect($state.transitionTo.calls.mostRecent().args[1]).toEqual({
                page: 9,
                limit: 88,
                sortField: 'name',
                sortOrder: 'asc',
                hello: 'World'
            });
        }));
    });

    describe('updatePage method', function() {
        it('should call setPaginationValues and updateTable', inject(function($state) {
            compileDirective();
            spyOn(ctrl, 'setPaginationValues').and.callThrough();
            spyOn($state, 'transitionTo');

            ctrl.updatePage(1, 2, 3);
            expect(ctrl.setPaginationValues).toHaveBeenCalledWith(1, 2, 3);
            expect($state.transitionTo).toHaveBeenCalled();
        }));
    });

    describe('setPaginationValues method', function() {
        it('should create a pagination object on the controller if is undefined', function() {
            var pageInfo = {
                page: 1
            };
            compileDirective();

            delete ctrl.pagination;
            ctrl.setPaginationValues(pageInfo);
            expect(ctrl.pagination).toEqual(pageInfo);
        });

        it('should correctly extend the properties on ctrl.pagination', function() {
            compileDirective();
            ctrl.pagination = {
                page: 5,
                limit: 6,
                total: 7
            };

            ctrl.setPaginationValues({
                page: 10,
                limit: 15
            });
            expect(ctrl.pagination).toEqual({
                page: 10,
                limit: 15,
                total: 7
            });
        });
    });

    describe('selection logic', function() {
        beforeEach(function() {
            compileDirective();
        });

        describe('selectAllRows method', function() {
            it('should toggle the allSelected variable', function() {
                expect(ctrl.allSelected).toBe(false);
                ctrl.selectAllRows();
                expect(ctrl.allSelected).toBe(true);
                ctrl.selectAllRows();
                expect(ctrl.allSelected).toBe(false);
            });

            it('should toggle all the rows in the selectedRows object', function() {
                ctrl.selectAllRows();
                expect(ctrl.selectedRows).toEqual({
                    '1': true,
                    '2': true,
                    '3': true,
                    '4': true
                });
                ctrl.selectAllRows();
                expect(ctrl.selectedRows).toEqual({
                    '1': false,
                    '2': false,
                    '3': false,
                    '4': false
                });
            });
        });

        describe('getSelectedRows method', function() {
            it('should return only the selected rows', function() {
                expect(ctrl.getSelectedRows()).toEqual([]);
                ctrl.selectedRows['1'] = true;
                expect(ctrl.getSelectedRows()).toEqual([rows[0]]);
                ctrl.selectAllRows();
                expect(ctrl.getSelectedRows()).toEqual(rows);
            });
        });

        describe('isRowSelected method', function() {
            it('should return the correct state of the selection', function() {
                console.log(ctrl.selectedRows);
                expect(ctrl.isRowSelected(rows[0])).toBe(false);
                ctrl.selectedRows['1'] = true;
                expect(ctrl.isRowSelected(rows[0])).toBe(true);
            });
        });
    });
});
