/* */ 
describe('Credit card directive', function() {
    var $compile,
        $scope,
        element,
        isolateScope;

    beforeEach(function() {
        module('bcapp-pattern-lab-templates');
        module('bcapp-pattern-lab.credit-card');
    });

    beforeEach(inject(function($injector) {
        $compile = $injector.get('$compile');
        $scope = $injector.get('$rootScope').$new();

        $scope.ccData = {
            ccNumber: '',
            ccCvv: '',
            ccName: '',
            ccExpiry: {
                month: '',
                year: ''
            },
            ccType: ''
        };

        $scope.ccConfig = {
            cardCode: true,
            fullName: true
        };
    }));

    beforeEach(function() {
        element = compileDirective($scope);
        isolateScope = element.find('credit-card').isolateScope();
    });

    function compileDirective(scope, tpl) {
        var element = angular.element(tpl || '<form><credit-card cc-data="ccData" cc-config="ccConfig"></credit-card></form>'),
            compiledElement = $compile(element)(scope);

        scope.$digest();

        return compiledElement;
    }

    describe('compiled markup', function() {
        it('should contain 4 form-field elements', function() {
            expect(element.find('form-field').length).toEqual(4);
        });

        it('should have autocomplete attribute in all inputs', function() {
            var elements = element.find('input');

            _.each(elements, function(input) {
                expect(angular.element(input).attr('autocomplete')).not.toBe(undefined);
            });
        });
    });

    describe('functionality', function() {
        it('should get the correct scope values', function() {
            expect(isolateScope.ccData).toEqual($scope.ccData);
            expect(isolateScope.ccConfig).toEqual($scope.ccConfig);
        });

        it('should change the type of card when $ccEagerType changes', function() {
            var type = 'visa';

            isolateScope.formCtrl.ccNumber.$ccEagerType = type;
            isolateScope.$digest();

            expect(isolateScope.ccData.ccType).toBe(type);

            type = 'Master Card';
            isolateScope.formCtrl.ccNumber.$ccEagerType = type;
            isolateScope.$digest();

            expect(isolateScope.ccData.ccType).toBe(type);
        });

        it('should contain form-field-errors with form-field-error', function() {
            var formField = element.find('form-field'),
                fieldErrors;

            _.each(formField, function(field) {
                fieldErrors = angular.element(field).find('form-field-errors')[0];

                expect(fieldErrors).not.toBe(undefined);
                expect(angular.element(fieldErrors).find('form-field-error')).not.toBe(undefined);
            });
        });
    });
});
