/* */ 
"format global";
var fs = require('fs'),
    config = require('../../../gulp/config');

function getIconSVGFileNames(path) {
    return fs.readdirSync(path, function (err, files) {
        return files;
    });
}

function getIcons() {
    return getIconSVGFileNames(config.svg.src + '/icons/material-design-icons').map(function(fileName) {
        return {
            name: fileName.replace('.svg', ''),
            src: fileName
        };
    });
}

module.exports = {
    icons: getIcons()
};
