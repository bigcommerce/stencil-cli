/* */ 
"format global";
var gulp = require('gulp'),
    config = require('../config'),
    handleErrors = require('../util/handleErrors'),
    csso = require('gulp-csso');

gulp.task('css-min', function() {
    var dest = config.css.build;

    var stream = gulp.src(dest + '/*.css')
        .pipe(csso()) // Optimize
        .on('error', handleErrors)
        .pipe(gulp.dest(config.css.build));

    return stream;
});
