/* */ 
'use strict';

angular.module('bcapp-pattern-lab', ['gettext', 'ngAnimate', 'ngMessages', 'mm.foundation', 'bcapp-pattern-lab-templates', 'bcapp-pattern-lab.bc-datepicker', 'bcapp-pattern-lab.bc-dropdown', 'bcapp-pattern-lab.bc-modal', 'bcapp-pattern-lab.bc-pagination', 'bcapp-pattern-lab.bc-server-table', 'bcapp-pattern-lab.checkbox-list', 'bcapp-pattern-lab.credit-card', 'bcapp-pattern-lab.form', 'bcapp-pattern-lab.form-field', 'bcapp-pattern-lab.icon', 'bcapp-pattern-lab.loading-notification', 'bcapp-pattern-lab.loading-overlay', 'bcapp-pattern-lab.sprite', 'bcapp-pattern-lab.switch']);
/* globals moment */
'use strict';

angular.module('bcapp-pattern-lab.bc-datepicker.constants', []).constant('BC_DATEPICKER_DEFAULTS', {
    dayFormat: 'D',
    inputFormat: moment.localeData().longDateFormat('L'),
    styles: {
        back: 'datepicker-back',
        container: 'datepicker',
        date: 'datepicker-date',
        dayBody: 'datepicker-days-body',
        dayBodyElem: 'datepicker-day',
        dayConcealed: 'datepicker-day-concealed',
        dayDisabled: 'is-disabled',
        dayHead: 'datepicker-days-head',
        dayHeadElem: 'datepicker-day-name',
        dayPrevMonth: 'datepicker-day-prev-month',
        dayNextMonth: 'datepicker-day-next-month',
        dayRow: 'datepicker-days-row',
        dayTable: 'datepicker-days',
        month: 'datepicker-month',
        monthLabel: 'datepicker-month',
        next: 'datepicker-next',
        positioned: 'datepicker-attachment',
        selectedDay: 'is-selected',
        selectedTime: 'datepicker-time-selected',
        time: 'datepicker-time',
        timeList: 'datepicker-time-list',
        timeOption: 'datepicker-time-option'
    },
    time: false,
    weekdayFormat: 'short'
});
/* globals rome */
'use strict';

angular.module('bcapp-pattern-lab.bc-datepicker.directive', ['bcapp-pattern-lab.bc-datepicker.constants']).directive('bcDatepicker', function bcDatepickerDirective(BC_DATEPICKER_DEFAULTS) {
    return {
        restrict: 'A',
        require: 'ngModel',
        scope: {
            options: '=?'
        },

        link: function datepickerLinkFunction(scope, element, attrs, ngModel) {
            if (scope.options === undefined) {
                scope.options = {};
            }

            // Add defaults to the options object
            _.defaults(scope.options, BC_DATEPICKER_DEFAULTS);

            // Create a new rome (calendar) instance
            scope.calendar = rome(element[0], scope.options);

            // On 'data' event set ngModel to the passed value
            scope.calendar.on('data', function onData(value) {
                ngModel.$setViewValue(value);
                scope.$apply();
            });

            scope.calendar.on('ready', function onReady(options) {
                if (attrs.placeholder === undefined) {
                    attrs.$set('placeholder', options.inputFormat);
                }
            });

            // Removing calendar event listeners
            element.on('$destroy', function onDestroy() {
                scope.calendar.destroy();
            });
        }
    };
});
'use strict';

angular.module('bcapp-pattern-lab.bc-datepicker', ['bcapp-pattern-lab.bc-datepicker.directive']);
'use strict';

angular.module('bcapp-pattern-lab.bc-dropdown-menu.directive', []).directive('bcDropdownMenu', function bcDropdownMenuDirective() {
    return {
        restrict: 'A',
        require: '^bcDropdown',
        compile: function bcDropdownMenuDirectiveCompile(tElement) {
            tElement.addClass('dropdown-menu');

            return function bcDropdownMenuDirectiveLink(scope, element, attrs, bcDropdownCtrl) {
                element.attr('id', bcDropdownCtrl.getUniqueId());
            };
        }
    };
});
'use strict';

angular.module('bcapp-pattern-lab.bc-dropdown-toggle.directive', []).directive('bcDropdownToggle', function bcDropdownToggleDirective($compile) {
    return {
        restrict: 'A',
        terminal: true,
        priority: 1001, // set higher than ng-repeat to prevent double compilation
        require: '^bcDropdown',
        compile: function bcDropdownToggleDirectiveCompile(tElement) {
            tElement.removeAttr('bc-dropdown-toggle');

            return function bcDropdownToggleDirectiveLink(scope, element, attrs, bcDropdownCtrl) {
                element.attr('dropdown-toggle', '#' + bcDropdownCtrl.getUniqueId());
                $compile(element)(scope);
            };
        }
    };
});
'use strict';

angular.module('bcapp-pattern-lab.bc-dropdown.directive', []).directive('bcDropdown', function bcDropdownDirective() {
    return {
        restrict: 'EA',
        controller: function bcDropdownDirectiveController() {
            var ctrl = this,
                uniqueId;

            ctrl.getUniqueId = getUniqueId;

            function getUniqueId() {
                if (!uniqueId) {
                    uniqueId = _.uniqueId('bc-dropdown-');
                }
                return uniqueId;
            }
        }
    };
});
'use strict';

angular.module('bcapp-pattern-lab.bc-dropdown', ['bcapp-pattern-lab.bc-dropdown.directive', 'bcapp-pattern-lab.bc-dropdown-toggle.directive', 'bcapp-pattern-lab.bc-dropdown-menu.directive']);
'use strict';

angular.module('bcapp-pattern-lab.bc-pagination.directive', []).directive('bcPagination', function bcPaginationDirective($parse) {
    return {
        restrict: 'E',
        scope: true,
        templateUrl: 'src/js/bigcommerce/bc-pagination/bc-pagination.tpl.html',

        compile: function bcPaginationCompile(tElement, tAttrs) {
            var attrObj = {};

            // Since this is a wrapper of angular-foundation's pagination directive we need to copy all
            // of the attributes passed to our directive and store them in the attrObj.
            _.each(tAttrs.$attr, function (key) {
                if (key !== 'class') {
                    attrObj[key] = tElement.attr(key);
                }
            });

            // Adding our custom callback to the attrObj, angular-foundation will call this function
            // when a page number is clicked in the pagination.
            attrObj['on-select-page'] = 'paginationCallback(page)';

            // Add all the attributes to angular-foundation's pagination directive
            tElement.find('pagination').attr(attrObj);

            return function bcPaginationLink($scope, element, attrs) {
                var onChangeParseGetter = $parse(attrs.onChange),
                    defaultLimits = [10, 20, 30, 50, 100];

                $scope.setLimit = function (limit, event) {
                    event.preventDefault();
                    limit = _.parseInt(limit);
                    $parse(attrs.itemsPerPage).assign($scope.$parent, limit);
                    $scope.paginationCallback(1, limit);
                };

                $scope.getCurrentPage = function () {
                    return $parse(attrs.page)($scope.$parent);
                };

                $scope.getCurrentLimit = function () {
                    return $parse(attrs.itemsPerPage)($scope.$parent);
                };

                $scope.showLimits = function () {
                    return $parse(attrs.showLimits)($scope.$parent) !== false;
                };

                $scope.getLimits = function () {
                    var limits = $parse(attrs.limits)($scope.$parent);

                    if (!Array.isArray(limits)) {
                        return defaultLimits;
                    }

                    return limits;
                };

                $scope.paginationCallback = function (page, limit) {
                    var additionalScopeProperties = {
                        limit: limit || $scope.getCurrentLimit(),
                        page: page
                    },
                        onChangeParseResult;

                    $parse(attrs.page).assign($scope.$parent, page);

                    onChangeParseResult = onChangeParseGetter($scope, additionalScopeProperties);

                    // if the onChange string is a function and not an expression: call it with the additionalScopeProperties obj (for backwards compatability)
                    // else the expression has already been ran: do nothing
                    if (typeof onChangeParseResult === 'function') {
                        onChangeParseResult(additionalScopeProperties);
                    }
                };
            };
        }
    };
});
'use strict';

angular.module('bcapp-pattern-lab.bc-pagination', ['bcapp-pattern-lab.bc-pagination.directive']);
'use strict';

angular.module('bcapp-pattern-lab.bc-server-table.controller', ['bcapp-pattern-lab.bc-server-table.service']).controller('BcServerTableCtrl', function BcServerTableCtrl($attrs, $log, $parse, $scope, BcServerTable) {
    var ctrl = this,
        bcServerTablePrototype = BcServerTable.prototype;

    // Call the BcServerTable constructor on the controller
    // in order to set all the controller properties directly.
    // This is here for backwards compatability purposes.
    BcServerTable.call(ctrl, null, $parse($attrs.tableConfig)($scope));

    // controller functions
    ctrl.createParamsObject = bcServerTablePrototype.createParamsObject;
    ctrl.fetchResource = bcServerTablePrototype.fetchResource;
    ctrl.getSelectedRows = bcServerTablePrototype.getSelectedRows;
    ctrl.init = bcServerTablePrototype.init;
    ctrl.isRowSelected = bcServerTablePrototype.isRowSelected;
    ctrl.loadStateParams = bcServerTablePrototype.loadStateParams;
    ctrl.selectAllRows = bcServerTablePrototype.selectAllRows;
    ctrl.setPaginationValues = bcServerTablePrototype.setPaginationValues;
    ctrl.setRows = bcServerTablePrototype.setRows;
    ctrl.setSortingValues = bcServerTablePrototype.setSortingValues;
    ctrl.updatePage = _.bind(bcServerTablePrototype.updatePage, ctrl);
    ctrl.updateSort = bcServerTablePrototype.updateSort;
    ctrl.updateTable = bcServerTablePrototype.updateTable;
    ctrl.validateResource = bcServerTablePrototype.validateResource;

    init();

    function init() {
        var resourceCallback;

        resourceCallback = $parse($attrs.resourceCallback)($scope);
        if (!_.isFunction(resourceCallback)) {
            $log.error('bc-server-table directive: resource-callback must be a function.');
            return;
        }
        ctrl.resourceCallback = resourceCallback;

        ctrl.init();
    }
});
'use strict';

angular.module('bcapp-pattern-lab.bc-server-table.directive', ['bcapp-pattern-lab.bc-server-table.controller', 'bcapp-pattern-lab.bc-server-table.sort-by.directive', 'ui.router'])
/**
 * The bc-server-table directive creates a data table that handles
 * server side pagination, sorting, and filtering. It exposes a few scope variables,
 * that can be used to display the table content with custom markup (see example
 * in the pattern lab for an actual implementation of the bc-server-table).
 *
 * The following attributes can be passed in order to configure the bc-server-table:
 * - resource-callback (required)
 * - tableConfig (optional)
 *
 * - resource-callback - a function that returns a promise which is resovled
 * with an object of the following format:
 *      {
 *          rows: Array,
 *          pagination: {
 *              page: Number,
 *              limit: Number,
 *              total: Number
 *          }
 *      }
 *
 * This directive exposes a scope variable called bcServerTable that
 * can be used to display content, and implement additional functionality
 * to the table (such as pagination, sorting, and selection logic).
 *
 * - bcServerTable.rows
 *      - Can be used with ng-repeat to display the data
 * - bcServerTable.filters
 *      - Can be used to change/update filters. These filters must appear
 *        in the state definition in order to work correctly.
 * - bcServerTable.updateTable()
 *      - Perform a state transistion with the current table info
 * - bcServerTable.pagination
 *      - exposes page, limit, and total
 * - bcServerTable.setPaginationValues(pagination)
 *      - convenience method for setting pagination values at once.
 *
 * - bcServerTable.selectedRows
 *      - an map object with unique id's as keys and boolean values as the selected state
 * - bcServerTable.allSelected
 *      - a boolean value used to determine if all rows were selected or cleared
 * - bcServerTable.selectAllRows()
 *      - toggle all rows selection state
 * - bcServerTable.isRowSelected(row)
 *      - helper function to determine if a row is selected
 * - bcServerTable.getSelectedRows()
 *      - function that returns an array of row objects that are currently selected
 *
 */
.directive('bcServerTable', function bcServerTableDirective($parse) {
    var directive = {
        restrict: 'EA',
        controller: 'BcServerTableCtrl as bcServerTable',
        link: function bcServerTableLink($scope, element, attrs, bcServerTableCtrl) {
            if (attrs.tableController) {
                // expose bcServerTableCtrl to tableController if it exists
                $parse(attrs.tableController).assign($scope, bcServerTableCtrl);
            }
        }
    };

    return directive;
});
'use strict';

angular.module('bcapp-pattern-lab.bc-server-table', ['bcapp-pattern-lab.bc-server-table.directive', 'bcapp-pattern-lab.bc-server-table.sort-by.directive', 'bcapp-pattern-lab.bc-server-table-factory.service']);
'use strict';

angular.module('bcapp-pattern-lab.bc-server-table.sort-by.directive', ['bcapp-pattern-lab.bc-server-table-factory.service']).directive('bcSortBy', function bcSortByDirective($log, bcServerTableFactory) {
    var directive = {
        templateUrl: 'src/js/bigcommerce/bc-server-table/bc-sort-by.tpl.html',
        restrict: 'E',
        transclude: true,
        scope: {
            sortValue: '@',
            columnName: '@',
            tableId: '@'
        },
        require: '?^^bcServerTable',
        link: bcSortByDirectiveLink
    };

    function bcSortByDirectiveLink(scope, element, attrs, bcServerTableCtrl) {
        var bcServerTable, sortDirValues;

        if (scope.tableId) {
            bcServerTable = bcServerTableFactory.get(scope.tableId);
        } else if (bcServerTableCtrl) {
            bcServerTable = bcServerTableCtrl;
        } else {
            $log.error('bc-sort-by directive requires a table-id, or a parent bcServerTableCtrl directive.');
        }

        sortDirValues = bcServerTable.tableConfig.sortDirValues;

        scope.asc = sortDirValues.asc;
        scope.desc = sortDirValues.desc;
        scope.sortBy = bcServerTable.sortBy;
        scope.sortDir = bcServerTable.sortDir;
        scope.sort = sort;

        function sort($event) {
            var sortBy, sortDir;

            if ($event) {
                $event.preventDefault();
            }

            if (bcServerTable.sortBy === scope.sortValue) {
                sortBy = bcServerTable.sortBy;
                sortDir = bcServerTable.sortDir === scope.asc ? scope.desc : scope.asc;
            } else {
                sortBy = scope.sortValue;
                sortDir = scope.asc;
            }

            bcServerTable.updateSort(sortBy, sortDir);
        }
    }

    return directive;
});
'use strict';

angular.module('bcapp-pattern-lab.checkbox-list.controller', []).controller('CheckboxListCtrl', function CheckboxListCtrl($attrs, $element, $log, $parse, $scope) {
    var ctrl = this,
        falseValue = $parse($attrs.ngFalseValue)(ctrl) || false,
        trueValue = $parse($attrs.ngTrueValue)(ctrl) || true,
        ngModel = $element.controller('ngModel');

    init();

    // Getters
    function getModelValue() {
        return ngModel.$modelValue;
    }

    function getValue() {
        return ctrl.value || ctrl.ngValue;
    }

    function getSelectedValues() {
        return ctrl.selectedValues;
    }

    // Setters
    function updateModelValue(modelValue) {
        ngModel.$setViewValue(modelValue);
        ngModel.$commitViewValue();
        ngModel.$render();
    }

    function updateSelectedValues(modelValue) {
        if (modelValue === trueValue) {
            addToSelectedValues();
        } else if (modelValue === falseValue) {
            removeFromSelectedValues();
        }
    }

    function addToSelectedValues() {
        var isIncluded = _.include(ctrl.selectedValues, getValue());

        if (!isIncluded) {
            ctrl.selectedValues.push(getValue());
        }
    }

    function removeFromSelectedValues() {
        var index = _.indexOf(ctrl.selectedValues, getValue());

        if (index !== -1) {
            ctrl.selectedValues.splice(index, 1);
        }
    }

    // Watchers
    function modelValueWatch(modelValue, oldModelValue) {
        var oldSelectedValues, selectedValuesChanged;

        // When ngModel value changes
        if (_.isUndefined(modelValue) || modelValue === oldModelValue) {
            return;
        }

        // Retain a shallow copy of selectedValues before update
        oldSelectedValues = ctrl.selectedValues.slice();

        // Update selectedValues
        updateSelectedValues(modelValue);

        // Determine if selectedValues array has changed
        selectedValuesChanged = !!_.xor(ctrl.selectedValues, oldSelectedValues).length;

        // If changed, evoke delegate method (if defined)
        if (ctrl.onChange && selectedValuesChanged) {
            ctrl.onChange({
                selectedValues: ctrl.selectedValues,
                oldSelectedValues: oldSelectedValues
            });
        }
    }

    function selectedValuesWatch(selectedValues) {
        // When selectedValues collection changes
        var isIncluded = _.include(selectedValues, getValue()),
            modelValue = getModelValue();

        if (isIncluded && modelValue !== trueValue) {
            updateModelValue(trueValue);
        } else if (!isIncluded && modelValue !== falseValue) {
            updateModelValue(falseValue);
        }
    }

    // Initializer
    function init() {
        if ($attrs.type !== 'checkbox') {
            $log.error('checkbox-list directive: element must be <input type="checkbox">');

            return;
        }

        $scope.$watch(getModelValue, modelValueWatch);
        $scope.$watchCollection(getSelectedValues, selectedValuesWatch);
    }
});
'use strict';

angular.module('bcapp-pattern-lab.checkbox-list.directive', ['bcapp-pattern-lab.checkbox-list.controller'])

/**
 * A directive for collating values from an array of checkboxes.
 *
 * @require ngModel
 * @param {Array.<string|number|Object>} checkboxList - Array to hold selected values
 * @param {*} value - Value to add to checkboxList
 * @param {function(selectedValues, oldSelectedValues} [checkboxListChange] - Optional onChange callback
 *
 * @example:
 * ```html
 * <div ng-repeat="option in options">
 *     <input type="checkbox" 
 *         name="option{{ option.id }}"
 *         value="option.id" 
 *         checkbox-list="selectedValues" 
 *         checkbox-list-change="onChange(selectedValues)" 
 *         ng-model="option.checked"
 *     />
 * </div>
 * ```
 * 
 * ```js
 * scope.selectedValues = [];
 * scope.options = [
 *     {
 *         id: 1,
 *         label: 'Option 1'
 *     },
 *     {
 *         id: 2,
 *         label: 'Option 2'
 *     },
 *     {
 *         id: 3,
 *         label: 'Option 3'
 *     }
 * ];
 * 
 * scope.onChange = function onChange(selectedValues) {
 *     console.log(selectedValues);
 * };
 * ```
 * 
 * When options[0] and options[1] are checked, selectedValues should be [1, 2]
 * and onChange will be evoked. This directive also works with an array of primitive values.
 * i.e.: scope.options = ["a", "b", "c"].
 */

.directive('checkboxList', function checkboxListDirective() {
    return {
        restrict: 'A',
        require: 'ngModel',
        controller: 'CheckboxListCtrl',
        controllerAs: 'checkboxListCtrl',
        bindToController: true,
        scope: {
            onChange: '&checkboxListChange',
            selectedValues: '=checkboxList',
            value: '=',
            ngValue: '='
        }
    };
});
'use strict';

angular.module('bcapp-pattern-lab.checkbox-list', ['bcapp-pattern-lab.checkbox-list.directive']);
/**
 * @name credit-card directive
 * @description Component containing cc number, cvc, name, and expiry. Has an isolated scope with no controller.
 * @require form
 *
 * @param ccData {object} Contains ccNumber, ccType, ccExpiry, and ccName
 * @param ccConfig {object} The configuration object. Currently supporting `cardCode` and `fullName`, both boolean to indicate
 * whether the respective fields should be shown
 */
'use strict';

angular.module('bcapp-pattern-lab.credit-card.directive', []).directive('creditCard', function creditCardDirective() {
    return {
        link: function creditCardLink(scope, elem, attr, formCtrl) {
            var defaultConfig = {
                cardCode: true,
                fullName: true
            };

            scope.ccConfig = _.defaults(scope.ccConfig, defaultConfig);

            /**
             * The credit card type is deduced by the `ccNumber` directive. This is in turn exposed
             * as `$ccEagerType` on the input control element. Watch for changes and bind the type to the corresponding
             * value on ccData.
             */
            scope.$watch(getCcType, setCcType);

            scope.formCtrl = formCtrl;

            function getCcType() {
                return formCtrl.ccNumber.$ccEagerType;
            }

            function setCcType(type) {
                scope.ccData.ccType = type;
            }
        },
        require: '^form',
        restrict: 'EA',
        scope: {
            ccData: '=',
            ccConfig: '='
        },
        templateUrl: 'src/js/bigcommerce/credit-card/credit-card.tpl.html'
    };
});
'use strict';

angular.module('bcapp-pattern-lab.credit-card', ['credit-cards', 'bcapp-pattern-lab.credit-card.cc-expiry', 'bcapp-pattern-lab.credit-card.directive', 'gettext']);
'use strict';

angular.module('bcapp-pattern-lab.form.directive', []).directive('form', function formDirective() {
    return {
        restrict: 'E',
        link: function formLink(scope, element, attrs) {
            element.addClass('form');
            element.attr('novalidate', '');

            // Use disable-auto-focus="true" to turn off automatic error focusing
            if (!attrs.disableAutoFocus) {
                element.on('submit', function formAutoFocusSubmitHandler() {
                    var invalidField = element[0].querySelector('.ng-invalid');

                    if (invalidField) {
                        invalidField.focus();

                        // Auto-select existing text for fields that support it (text, email, password, etc.)
                        if (invalidField.select) {
                            invalidField.select();
                        }
                    }
                });
            }
        }
    };
});
'use strict';

angular.module('bcapp-pattern-lab.form', ['bcapp-pattern-lab.form.directive']);
'use strict';

angular.module('bcapp-pattern-lab.form-field.directive', []).directive('formField', function formFieldDirective($log) {
    return {
        require: '^form',
        restrict: 'EA',
        scope: true,
        link: {
            pre: function formFieldLink(scope, element, attrs) {
                // Inherited by the form-field-errors directive to avoid redeclaration
                scope.property = attrs.property;
            },

            post: function formFieldLink(scope, element, attrs, formCtrl) {
                // Locates and watches the matching input/select/etc (based on its name attribute) in the parent form
                var property = attrs.property,
                    propertyValidFn = function propertyValidFn() {
                    return formCtrl[property].$valid;
                },
                    formSubmittedFn = function formSubmittedFn() {
                    return formCtrl.$submitted;
                };

                element.addClass('form-field');

                // If a property wasn't provided, we can't do much else
                if (!property) {
                    return;
                }

                // If a property was provided, but no ng-model was defined for the field, validation won't work
                if (!formCtrl[property]) {
                    return $log.info('Form fields containing inputs without an ng-model property will not be validated');
                }

                init();

                function init() {
                    // Update the interface if the form is submitted or the property's validity state changes
                    scope.$watch(formSubmittedFn, checkValidity);
                    scope.$watch(propertyValidFn, checkValidity);
                }

                function checkValidity() {
                    // Only show an error if the user has already attempted to submit the form
                    element.toggleClass('form-field--error', formCtrl.$submitted && formCtrl[property].$invalid);
                }
            }
        }
    };
});
'use strict';

angular.module('bcapp-pattern-lab.form-field', ['bcapp-pattern-lab.form-field.directive', 'bcapp-pattern-lab.form-field-error', 'bcapp-pattern-lab.form-field-errors']);
'use strict';

angular.module('bcapp-pattern-lab.form-field-errors.directive', []).directive('formFieldErrors', function formFieldErrorsDirective() {
    return {
        replace: true,
        require: '^form',
        restrict: 'EA',
        templateUrl: 'src/js/bigcommerce/form-field-errors/form-field-errors.tpl.html',
        transclude: true,
        link: {
            // Pre-link is required, as we have to inject our scope properties before the child
            // form-field-error directive (and its internal ng-message directive's) post-link functions
            pre: function formFieldErrorsPreLink(scope, element, attrs, formCtrl) {
                // Property name can be inherited from parent scope, such as from the form-field directive
                var property = scope.property || attrs.property,
                    propertyField = formCtrl[property];

                // Inherited by form-field-error directive. Lives directly on scope because the require
                // property does not work well with directive controller instances
                scope.formCtrl = formCtrl;
                scope.property = property;
                scope.propertyField = propertyField;
            }
        }
    };
});
'use strict';

angular.module('bcapp-pattern-lab.form-field-errors', ['bcapp-pattern-lab.form-field-errors.directive']);
'use strict';

angular.module('bcapp-pattern-lab.form-field-error.directive', []).directive('formFieldError', function formFieldErrorDirective($compile) {
    return {
        priority: 10,
        replace: true,
        restrict: 'EA',
        templateUrl: 'src/js/bigcommerce/form-field-error/form-field-error.tpl.html',
        terminal: true,
        transclude: true,
        compile: function formFieldErrorCompile(tElement, tAttrs) {
            // The translate property wipes out our ng-message logic in the post link function
            // The priority and terminal properties above ensure this check occurs
            if (tElement.attr('translate') !== undefined) {
                throw new SyntaxError('The translate attribute cannot be used with the form-field-error directive. ' + 'Use the translate filter instead (example: {{ "my error message" | translate }}). ' + 'Validator: ' + tAttrs.validate);
            }

            return {
                post: function formFieldErrorPostLink(scope, element, attrs, controllers, transclude) {
                    scope.property = scope.property || attrs.property;

                    transclude(function formFieldErrorTransclude(errorClone) {
                        var labelElement = angular.element('<label>');

                        // ngMessage doesn't play well with dynamic message insertion, translation, or
                        // message expressions, so we build its element up here and inject it into the DOM
                        labelElement.attr('for', scope.property);
                        labelElement.attr('ng-message', attrs.validate);
                        labelElement.attr('role', 'alert');
                        labelElement.addClass('form-inlineMessage');

                        // The error span should already have a translation watcher on it by now, using a filter
                        labelElement.append(errorClone);

                        element.append(labelElement);

                        $compile(element)(scope);
                    });
                }
            };
        }
    };
});
'use strict';

angular.module('bcapp-pattern-lab.form-field-error', ['bcapp-pattern-lab.form-field-error.directive']);
'use strict';

angular.module('bcapp-pattern-lab.icon.controller', ['bcapp-pattern-lab.icon.svgRootPath']).controller('IconCtrl', function iconDirectiveController($http, $templateCache, svgRootPath) {
    var ctrl = this;

    ctrl.updateGlyph = updateGlyph;

    function updateGlyph(glyph) {
        var fullSvgPath = svgRootPath + glyph + '.svg';

        return $http.get(fullSvgPath, { cache: $templateCache }).then(function iconDirectiveHttpSuccess(response) {
            return response.data;
        });
    }
});
/**
 * @description Icon directive used to load an inline svg icon, simliar to icon
 *              font methods of past <i class="icon-foo-bar"></i>
 * @example
 * <icon glyph="ic-add-circle"></icon>
 */
'use strict';

angular.module('bcapp-pattern-lab.icon.directive', ['bcapp-pattern-lab.icon.controller']).directive('icon', function iconDirective() {
    return {
        bindToController: true,
        controller: 'IconCtrl as iconCtrl',
        restrict: 'E',
        scope: {
            glyph: '@'
        },
        compile: function iconDirectiveCompile(tElement) {
            tElement.addClass('icon');
            tElement.attr('aria-hidden', true);

            return function iconDirectiveLink($scope, element, attrs, ctrl) {
                $scope.$watch('iconCtrl.glyph', function iconDirectiveLinkWatch(newValue) {
                    ctrl.updateGlyph(newValue).then(function iconUpdateGlyphThen(svg) {
                        element.html(svg);
                    });
                });
            };
        }
    };
});
'use strict';

angular.module('bcapp-pattern-lab.icon', ['bcapp-pattern-lab.icon.directive']);
'use strict';

angular.module('bcapp-pattern-lab.icon.svgRootPath', []).provider('svgRootPath', function svgRootPathProviderConfig() {
    this.setRootPath = setRootPath;
    this.$get = function svgRootPathProviderGet($log) {
        if (this.svgRootPath === undefined) {
            $log.error('No svgRootPath provided. Please configure this using the svgRootPathProvider');
        }

        return this.svgRootPath;
    };

    function setRootPath(newRootPath) {
        this.svgRootPath = newRootPath;
    }
});
'use strict';

angular.module('bcapp-pattern-lab.loading-overlay.controller', []).controller('LoadingOverlayCtrl', function LoadingOverlayCtrl($rootScope, $timeout) {
    var ctrl = this,
        defaultDebounce = 100,
        timeout;

    if (ctrl.debounce === undefined) {
        ctrl.debounce = defaultDebounce;
    }

    if (ctrl.useUiRouter) {
        $rootScope.$on('$stateChangeStart', startLoading);
        $rootScope.$on('$stateChangeSuccess', stopLoading);
        $rootScope.$on('$stateChangeError', stopLoading);
    }

    function startLoading(event) {
        if (event.defaultPrevented) {
            return;
        }

        timeout = $timeout(function startLoadingTimer() {
            ctrl.loading = true;
        }, ctrl.debounce);
    }

    function stopLoading(event) {
        if (event.defaultPrevented) {
            return;
        }

        $timeout.cancel(timeout);
        ctrl.loading = false;
    }
});
'use strict';

angular.module('bcapp-pattern-lab.loading-overlay.directive', ['bcapp-pattern-lab.loading-overlay.controller']).directive('loadingOverlay', function loadingOverlay() {
    return {
        bindToController: true,
        controller: 'LoadingOverlayCtrl as loadingOverlayCtrl',
        restrict: 'A',
        scope: {
            debounce: '=?',
            loading: '=?loadingOverlay',
            useUiRouter: '=?'
        },
        templateUrl: 'src/js/bigcommerce/loading-overlay/loading-overlay.tpl.html',
        transclude: true,
        compile: function loadingOverlayCompile(element) {
            element.addClass('loadingOverlay-container');
        }
    };
});
'use strict';

angular.module('bcapp-pattern-lab.loading-overlay', ['bcapp-pattern-lab.loading-overlay.directive']);
'use strict';

angular.module('bcapp-pattern-lab.loading-notification.directive', []).directive('loadingNotification', function loadingNotificationDirective($rootScope) {
    return {
        restrict: 'E',
        templateUrl: 'src/js/bigcommerce/loading-notification/loading-notification.tpl.html',

        link: function link(scope) {
            $rootScope.$on('ajaxRequestRunning', function (event, val) {
                scope.requestInProgress = val;
            });
        }
    };
});
'use strict';

angular.module('bcapp-pattern-lab.loading-notification', ['bcapp-pattern-lab.loading-notification.directive']);
/*
 * Override angular foundation's $modalStack service to remove the `top` css property.
 * cannot use a decorator because the `open` relies on closures and does not return the compiled element.
 * Changes are between `// Changes` comments
*/
'use strict';

angular.module('bcapp-pattern-lab.bc-modal.modalStack.service', []).factory('$modalStack', ['$window', '$transition', '$timeout', '$document', '$compile', '$rootScope', '$$stackedMap', function ($window, $transition, $timeout, $document, $compile, $rootScope, $$stackedMap) {
  // Changes: change from `modal-open` to `has-activeModal`
  var OPENED_MODAL_CLASS = 'has-activeModal';
  // Changes

  var backdropDomEl, backdropScope;
  var openedWindows = $$stackedMap.createNew();
  var $modalStack = {};

  function backdropIndex() {
    var topBackdropIndex = -1;
    var opened = openedWindows.keys();
    for (var i = 0; i < opened.length; i++) {
      if (openedWindows.get(opened[i]).value.backdrop) {
        topBackdropIndex = i;
      }
    }
    return topBackdropIndex;
  }

  $rootScope.$watch(backdropIndex, function (newBackdropIndex) {
    if (backdropScope) {
      backdropScope.index = newBackdropIndex;
    }
  });

  function removeModalWindow(modalInstance) {
    var body = $document.find('body').eq(0);
    var modalWindow = openedWindows.get(modalInstance).value;

    //clean up the stack
    openedWindows.remove(modalInstance);

    //remove window DOM element
    removeAfterAnimate(modalWindow.modalDomEl, modalWindow.modalScope, 300, function () {
      modalWindow.modalScope.$destroy();
      body.toggleClass(OPENED_MODAL_CLASS, openedWindows.length() > 0);
      checkRemoveBackdrop();
    });
  }

  function checkRemoveBackdrop() {
    //remove backdrop if no longer needed
    if (backdropDomEl && backdropIndex() == -1) {
      var backdropScopeRef = backdropScope;
      removeAfterAnimate(backdropDomEl, backdropScope, 150, function () {
        backdropScopeRef.$destroy();
        backdropScopeRef = null;
      });
      backdropDomEl = undefined;
      backdropScope = undefined;
    }
  }

  function removeAfterAnimate(domEl, scope, emulateTime, done) {
    // Closing animation
    scope.animate = false;

    var transitionEndEventName = $transition.transitionEndEventName;
    if (transitionEndEventName) {
      // transition out
      var timeout = $timeout(afterAnimating, emulateTime);

      domEl.bind(transitionEndEventName, function () {
        $timeout.cancel(timeout);
        afterAnimating();
        scope.$apply();
      });
    } else {
      // Ensure this call is async
      $timeout(afterAnimating, 0);
    }

    function afterAnimating() {
      if (afterAnimating.done) {
        return;
      }
      afterAnimating.done = true;

      domEl.remove();
      if (done) {
        done();
      }
    }
  }

  $document.bind('keydown', function (evt) {
    var modal;

    if (evt.which === 27) {
      modal = openedWindows.top();
      if (modal && modal.value.keyboard) {
        $rootScope.$apply(function () {
          $modalStack.dismiss(modal.key);
        });
      }
    }
  });

  $modalStack.open = function (modalInstance, modal) {

    openedWindows.add(modalInstance, {
      deferred: modal.deferred,
      modalScope: modal.scope,
      backdrop: modal.backdrop,
      keyboard: modal.keyboard
    });

    var body = $document.find('body').eq(0),
        currBackdropIndex = backdropIndex();

    if (currBackdropIndex >= 0 && !backdropDomEl) {
      backdropScope = $rootScope.$new(true);
      backdropScope.index = currBackdropIndex;
      backdropDomEl = $compile('<div modal-backdrop></div>')(backdropScope);
      body.append(backdropDomEl);
    }

    // Changes: deletion of css top property calculation
    var angularDomEl = angular.element('<div modal-window style="visibility: visible; display: block"></div>');
    angularDomEl.attr('window-class', modal.windowClass);
    angularDomEl.attr('index', openedWindows.length() - 1);
    angularDomEl.attr('animate', 'animate');
    angularDomEl.html(modal.content);

    var modalDomEl = $compile(angularDomEl)(modal.scope);
    openedWindows.top().value.modalDomEl = modalDomEl;
    body.append(modalDomEl);
    body.addClass(OPENED_MODAL_CLASS);
  };

  $modalStack.close = function (modalInstance, result) {
    var modalWindow = openedWindows.get(modalInstance).value;
    if (modalWindow) {
      modalWindow.deferred.resolve(result);
      removeModalWindow(modalInstance);
    }
  };

  $modalStack.dismiss = function (modalInstance, reason) {
    var modalWindow = openedWindows.get(modalInstance).value;
    if (modalWindow) {
      modalWindow.deferred.reject(reason);
      removeModalWindow(modalInstance);
    }
  };

  $modalStack.dismissAll = function (reason) {
    var topModal = this.getTop();
    while (topModal) {
      this.dismiss(topModal.key, reason);
      topModal = this.getTop();
    }
  };

  $modalStack.getTop = function () {
    return openedWindows.top();
  };

  return $modalStack;
}]);
/*
 * This module modifies angular foundation's modal implementation. This does not create a new modal service/directive.
 * 
*/
'use strict';

angular.module('bcapp-pattern-lab.bc-modal', ['bcapp-pattern-lab.bc-modal.modalStack.service']);
/**
 * @description Sprite directive used to load an icon from an image sprite,
 *              simliar to the icon directive but less SVG
 * @example
 * <sprite glyph="ic-amex"></sprite>
 */

'use strict';

angular.module('bcapp-pattern-lab.sprite.directive', []).directive('sprite', function spriteDirective() {
    return {
        restrict: 'E',
        scope: {
            glyph: '@'
        },
        compile: spriteDirectiveCompile
    };

    function spriteDirectiveCompile(tElement) {
        tElement.addClass('sprite');
        tElement.attr('aria-hidden', true);

        return function spriteDirectiveLink($scope, element, attrs) {
            attrs.$observe('glyph', function (newValue) {
                element.attr('class', 'sprite sprite--' + newValue);
            });
        };
    }
});
'use strict';

angular.module('bcapp-pattern-lab.sprite', ['bcapp-pattern-lab.sprite.directive']);
/**
 * @description Used to create a toggle switch for forms
 * @example
    <switch ng-model="ctrl.switchModel1"></switch>

    <switch
        toggle-off-text="Off"
        toggle-on-text="On"
        ng-model="ctrl.switchModel2">
    </switch>

    <switch
        has-icon
        ng-model="ctrl.switchModel3">
    </switch>

    <switch
        is-important
        left-label="Down for Maintenance"
        right-label="Open"
        ng-model="ctrl.switchModel4">
    </switch>
 */
'use strict';

angular.module('bcapp-pattern-lab.switch.directive', []).directive('switch', function switchDirective() {

    function getUniqueID(idPrefix) {
        return _.uniqueId(idPrefix);
    }

    return {
        restrict: 'E',
        templateUrl: 'src/js/bigcommerce/switch/switch.tpl.html',
        require: 'ngModel',
        scope: {
            ariaDescription: '@',
            labelText: '@',
            leftDescription: '@',
            ngFalseValue: '@',
            ngTrueValue: '@',
            rightDescription: '@',
            toggleOffLabel: '@',
            toggleOnLabel: '@',
            uniqueId: '@'
        },
        bindToController: true,
        controllerAs: 'switchCtrl',
        compile: function switchDirectiveCompile(tElem, tAttrs) {
            var checkboxElem = tElem.find('input');

            if (tAttrs.ngFalseValue) {
                checkboxElem.attr('ng-false-value', tAttrs.ngFalseValue);
            }

            if (tAttrs.ngTrueValue) {
                checkboxElem.attr('ng-true-value', tAttrs.ngTrueValue);
            }

            return function switchDirectivePostLink(scope, element, attrs, ngModelCtrl) {
                scope.switchCtrl.init(ngModelCtrl);
            };
        },
        controller: function switchDirectiveCtrl($scope, $element, $attrs) {
            var ctrl = this;

            // state
            ctrl.isImportant = angular.isDefined($attrs.isImportant) && $attrs.isImportant !== 'false';
            ctrl.hasIcon = angular.isDefined($attrs.hasIcon) && $attrs.hasIcon !== 'false';

            // labels
            ctrl.labelText = $attrs.toggleOffLabel;

            // ids
            ctrl.uniqueId = getUniqueID('switch-');
            ctrl.ariaDescriptionID = getUniqueID('switch-ariaDescription-');

            ctrl.init = init;
            ctrl.updateModel = updateModel;

            function init(ngModelCtrl) {
                ctrl.ngModelCtrl = ngModelCtrl;
                ctrl.value = ctrl.ngModelCtrl.$modelValue;

                $scope.$watch('switchCtrl.ngModelCtrl.$modelValue', function switchValueChanged(newValue) {
                    ctrl.value = newValue;

                    ctrl.isChecked = _.isString(newValue) ? "'" + newValue + "'" === ctrl.ngTrueValue : newValue;
                    ctrl.labelText = !!ctrl.isChecked ? ctrl.toggleOnLabel : ctrl.toggleOffLabel;
                });
            }

            function updateModel() {
                ctrl.ngModelCtrl.$setViewValue(ctrl.value);
            }
        }
    };
});
'use strict';

angular.module('bcapp-pattern-lab.switch', ['bcapp-pattern-lab.switch.directive']);
'use strict';

angular.module('bcapp-pattern-lab.bc-server-table-factory.service', ['bcapp-pattern-lab.bc-server-table.service']).factory('bcServerTableFactory', function bcServerTableFactory($log, BcServerTable) {
    var tables = {},
        service = {
        create: create,
        get: get,
        remove: remove
    };

    function create(tableId, tableConfig) {
        if (tableId in tables) {
            return service.get(tableId);
        }

        if (!tableId) {
            tableId = _.uniqueId('bc-server-table-instance-');
        }

        tables[tableId] = new BcServerTable(tableId, tableConfig);

        return tables[tableId];
    }

    function get(tableId) {
        return tables[tableId];
    }

    function remove(tableId) {
        delete tables[tableId];
    }

    return service;
});
'use strict';

angular.module('bcapp-pattern-lab.bc-server-table.service', ['ui.router']).factory('BcServerTable', function bcServerTable($log, $state, $stateParams) {
    var defaultTableConfig = {
        filters: [],
        queryKeys: {
            page: 'page',
            limit: 'limit',
            sortBy: 'sort-by',
            sortDir: 'sort-order'
        },
        rowIdKey: 'id',
        sortDirValues: {
            asc: 'asc',
            desc: 'desc'
        }
    };

    function ServerTable(tableId, tableConfig) {
        this.allSelected = false;
        this.filters = {};
        this.id = tableId;
        this.pagination = {
            page: null,
            limit: null,
            total: null
        };
        this.pendingRequest = false;
        this.resourceCallback = angular.noop;
        this.rows = [];
        this.selectedRows = {};
        this.sortBy = '';
        this.sortDir = '';

        this.tableConfig = _.isObject(tableConfig) ? tableConfig : {};
        this.tableConfig = _.defaults(this.tableConfig, defaultTableConfig);
    }

    ServerTable.prototype = {
        createParamsObject: createParamsObject,
        fetchResource: fetchResource,
        getSelectedRows: getSelectedRows,
        init: init,
        isRowSelected: isRowSelected,
        loadStateParams: loadStateParams,
        selectAllRows: selectAllRows,
        setPaginationValues: setPaginationValues,
        setRows: setRows,
        setSortingValues: setSortingValues,
        updatePage: updatePage,
        updateSort: updateSort,
        updateTable: updateTable,
        validateResource: validateResource
    };

    function createParamsObject() {
        var params = {},
            queryKeys = this.tableConfig.queryKeys,
            queryParamMap = [{
            queryKey: queryKeys.page,
            value: this.pagination.page
        }, {
            queryKey: queryKeys.limit,
            value: this.pagination.limit
        }, {
            queryKey: queryKeys.sortBy,
            value: this.sortBy
        }, {
            queryKey: queryKeys.sortDir,
            value: this.sortDir
        }];

        _.each(queryParamMap, function queryParamMapEach(param) {
            if (param.queryKey !== undefined) {
                params[param.queryKey] = param.value;
            }
        });

        _.extend(params, this.filters);

        return params;
    }

    function fetchResource() {
        var _this = this;

        this.pendingRequest = true;
        return this.resourceCallback(this.createParamsObject()).then(function resourceCallbackThen(resource) {
            if (_this.validateResource(resource)) {
                _this.setRows(resource.rows);
                _this.setPaginationValues(resource.pagination);
            }

            return _this;
        })['catch'](function resourceCallbackCatch() {
            $log.error('bc-server-table directive: failed to fetch resource');
        })['finally'](function resourceCallbackFinally() {
            _this.pendingRequest = false;
        });
    }

    function getSelectedRows() {
        var _this = this;

        return _.filter(this.rows, function getSelectedRowsFilter(row) {
            return _this.isRowSelected(row);
        });
    }

    function init(config) {
        if (!_.isObject(config)) {
            config = {};
        }

        if (_.isFunction(config.resourceCallback)) {
            this.resourceCallback = config.resourceCallback;
        }

        return this.loadStateParams(config.stateParams).fetchResource();
    }

    function isRowSelected(row) {
        return this.selectedRows[row[this.tableConfig.rowIdKey]];
    }

    function loadStateParams(stateParams) {
        var queryKeys = this.tableConfig.queryKeys,
            _this = this;

        stateParams = stateParams || $stateParams;

        this.setPaginationValues({
            page: stateParams[queryKeys.page],
            limit: stateParams[queryKeys.limit]
        });

        this.setSortingValues(stateParams[queryKeys.sortBy], stateParams[queryKeys.sortDir]);

        // set filters from query params
        _.each(this.tableConfig.filters, function setFiltersEach(value) {
            _this.filters[value] = stateParams[value];
        });

        return this;
    }

    function selectAllRows() {
        var _this = this;

        this.allSelected = !this.allSelected;
        _.each(this.selectedRows, function selectAllRowsEach(value, key) {
            _this.selectedRows[key] = _this.allSelected;
        });

        return this;
    }

    function setPaginationValues(pagination) {
        this.pagination = this.pagination || {};
        _.extend(this.pagination, pagination);

        return this;
    }

    function setRows(rows) {
        var _this = this;

        this.rows = rows;
        this.selectedRows = _.reduce(rows, function initializeSelectedRowsObject(accum, row) {
            accum[row[_this.tableConfig.rowIdKey]] = false;
            return accum;
        }, {});

        return this;
    }

    function setSortingValues(sortBy, sortDir) {
        this.sortBy = sortBy || this.sortBy;
        this.sortDir = sortDir || this.sortDir;

        return this;
    }

    function updatePage(page, limit, total) {
        return this.setPaginationValues(page, limit, total).updateTable();
    }

    function updateSort(sortBy, sortDir) {
        return this.setSortingValues(sortBy, sortDir).setPaginationValues({
            page: 1
        }).updateTable();
    }

    function updateTable() {
        if (!this.pendingRequest) {
            $state.go($state.current.name, this.createParamsObject());
        }

        return this;
    }

    function validateResource(resource) {
        if (!_.isObject(resource)) {
            $log.error('bc-server-table directive: Resource callback must return an object');
            return false;
        }

        if (!_.isArray(resource.rows)) {
            $log.error('bc-server-table directive: returned object must contain a rows property that is an array.');
            return false;
        }

        if (!_.isObject(resource.pagination)) {
            $log.error('bc-server-table directive: returned object must contain a pagination property that is an object.');
            return false;
        }

        return true;
    }

    return ServerTable;
});
/**
 * @name cc-expiry directive
 * @description A directive following angular-credit-card's approach to validating/formatting credit card expiration date.
 * Expect the cc-expiry ngModel to be in the format of `{ month: '05', year: '2017'}`.
 */
'use strict';

angular.module('bcapp-pattern-lab.credit-card.cc-expiry.directive', []).directive('ccExpiry', function ccExpDirective($filter) {
    return {
        compile: function compile(tElem, tAttr) {
            var EXPIRATION_MAX_LENGTH = 7; // length of `MM / yy`

            tAttr.$set('autocomplete', 'cc-exp');
            tAttr.$set('maxlength', EXPIRATION_MAX_LENGTH);
            tAttr.$set('pattern', '[0-9]*'); // for mobile keyboard display

            return function ccExpiryLink(scope, tElem, tAttr, ngModelCtrl) {
                init();

                function init() {
                    ngModelCtrl.$parsers.unshift(parser);
                    ngModelCtrl.$formatters.push(formatter);
                    ngModelCtrl.$validators.validFutureDate = validFutureDate;

                    scope.$watch(getViewValue, renderFormattedView);
                }

                /**
                 * get the input's view value
                 */
                function getViewValue() {
                    return ngModelCtrl.$viewValue;
                }

                /**
                 * formats the input view value to be the format `MM / yy` and re-renders view
                 */
                function renderFormattedView(viewValue, prevViewValue) {
                    if (!viewValue) {
                        return;
                    }

                    // a new value is added (as opposed to pressing backspace)
                    var isAddition = viewValue.length > prevViewValue.length;

                    ngModelCtrl.$setViewValue(format(viewValue, isAddition));
                    ngModelCtrl.$render();
                }

                /**
                 * Validates whether the entered expiration date is valid
                 */
                function validFutureDate(modelValue) {
                    var month = modelValue.month;
                    var year = modelValue.year;

                    return isValidDate(month, year) && !isPast(month, year);
                }

                /**
                 * Validates whether the given month and year are number strings with length of 2 and 4 respectively
                 */
                function isValidDate(month, year) {
                    var monthRegex = /^[0-9]{2}$/;
                    var yearRegex = /^[0-9]{4}$/;

                    return _.isString(month) && _.isString(year) && monthRegex.test(month) && yearRegex.test(year) && isValidMonth(month);
                }

                /**
                 * Checks whether the month is valid
                 */
                function isValidMonth(month) {
                    month = _.parseInt(month);

                    return month > 0 && month < 13;
                }

                /**
                 * Checks whether the given month and date is in the past
                 */
                function isPast(month, year) {
                    return getCurrMonthDate() > new Date(year, month - 1);
                }

                /**
                 * Get the date object based on current month and year
                 */
                function getCurrMonthDate() {
                    var date = new Date();

                    return new Date(date.getFullYear(), date.getMonth());
                }

                /**
                 * Uses angular date filter to format date model to corresponding view format
                 */
                function formatter() {
                    var exp = arguments.length <= 0 || arguments[0] === undefined ? {} : arguments[0];

                    var month = exp.month;
                    var year = exp.year;

                    if (_.isEmpty(month) && _.isEmpty(year)) {
                        return '';
                    }

                    return $filter('date')(new Date(year, month - 1), 'MM / yy');
                }

                /**
                 * Parses the formatted view values to model. Converts 2 digit year to full 4 digit year
                 * @param expiration {object} The expiration object {month, year}
                 */
                function parser(expiration) {
                    var baseYear = new Date().getFullYear().toString().slice(0, 2); // `'20'`
                    var values = expiration.split('/');
                    var month = values[0] ? values[0].trim() : '';
                    var year = values[1] ? baseYear + values[1].trim() : '';

                    return { month: month, year: year };
                }

                /**
                 * formats the view value to the form 'MM / yy'
                 */
                function format(expStr, isAddition) {
                    var values = expStr.split('/');
                    var month = values[0] ? values[0].trim() : '';
                    var year = values[1] ? values[1].trim().slice(-2) : '';

                    // don't add slash
                    if (!isAddition && !year || month.length < 2) {
                        return month;
                    }

                    // add slash in the right spot
                    if (isAddition && !year && month.length > 2) {
                        return month.slice(0, 2) + ' / ' + month.slice(2);
                    }

                    return month + ' / ' + year;
                }
            };
        },
        require: 'ngModel',
        restrict: 'A'
    };
});
'use strict';

angular.module('bcapp-pattern-lab.credit-card.cc-expiry', ['bcapp-pattern-lab.credit-card.cc-expiry.directive']);
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImJpZ2NvbW1lcmNlL2JjYXBwLXBhdHRlcm4tbGFiLm1vZHVsZS5qcyIsImJpZ2NvbW1lcmNlL2JjLWRhdGVwaWNrZXIvYmMtZGF0ZXBpY2tlci5jb25zdGFudHMuanMiLCJiaWdjb21tZXJjZS9iYy1kYXRlcGlja2VyL2JjLWRhdGVwaWNrZXIuZGlyZWN0aXZlLmpzIiwiYmlnY29tbWVyY2UvYmMtZGF0ZXBpY2tlci9iYy1kYXRlcGlja2VyLmpzIiwiYmlnY29tbWVyY2UvYmMtZHJvcGRvd24vYmMtZHJvcGRvd24tbWVudS5kaXJlY3RpdmUuanMiLCJiaWdjb21tZXJjZS9iYy1kcm9wZG93bi9iYy1kcm9wZG93bi10b2dnbGUuZGlyZWN0aXZlLmpzIiwiYmlnY29tbWVyY2UvYmMtZHJvcGRvd24vYmMtZHJvcGRvd24uZGlyZWN0aXZlLmpzIiwiYmlnY29tbWVyY2UvYmMtZHJvcGRvd24vYmMtZHJvcGRvd24ubW9kdWxlLmpzIiwiYmlnY29tbWVyY2UvYmMtcGFnaW5hdGlvbi9iYy1wYWdpbmF0aW9uLmRpcmVjdGl2ZS5qcyIsImJpZ2NvbW1lcmNlL2JjLXBhZ2luYXRpb24vYmMtcGFnaW5hdGlvbi5tb2R1bGUuanMiLCJiaWdjb21tZXJjZS9iYy1zZXJ2ZXItdGFibGUvYmMtc2VydmVyLXRhYmxlLmNvbnRyb2xsZXIuanMiLCJiaWdjb21tZXJjZS9iYy1zZXJ2ZXItdGFibGUvYmMtc2VydmVyLXRhYmxlLmRpcmVjdGl2ZS5qcyIsImJpZ2NvbW1lcmNlL2JjLXNlcnZlci10YWJsZS9iYy1zZXJ2ZXItdGFibGUubW9kdWxlLmpzIiwiYmlnY29tbWVyY2UvYmMtc2VydmVyLXRhYmxlL2JjLXNvcnQtYnkuZGlyZWN0aXZlLmpzIiwiYmlnY29tbWVyY2UvY2hlY2tib3gtbGlzdC9jaGVja2JveC1saXN0LmNvbnRyb2xsZXIuanMiLCJiaWdjb21tZXJjZS9jaGVja2JveC1saXN0L2NoZWNrYm94LWxpc3QuZGlyZWN0aXZlLmpzIiwiYmlnY29tbWVyY2UvY2hlY2tib3gtbGlzdC9jaGVja2JveC1saXN0Lm1vZHVsZS5qcyIsImJpZ2NvbW1lcmNlL2NyZWRpdC1jYXJkL2NyZWRpdC1jYXJkLmRpcmVjdGl2ZS5qcyIsImJpZ2NvbW1lcmNlL2NyZWRpdC1jYXJkL2NyZWRpdC1jYXJkLm1vZHVsZS5qcyIsImJpZ2NvbW1lcmNlL2Zvcm0vZm9ybS5kaXJlY3RpdmUuanMiLCJiaWdjb21tZXJjZS9mb3JtL2Zvcm0ubW9kdWxlLmpzIiwiYmlnY29tbWVyY2UvZm9ybS1maWVsZC9mb3JtLWZpZWxkLmRpcmVjdGl2ZS5qcyIsImJpZ2NvbW1lcmNlL2Zvcm0tZmllbGQvZm9ybS1maWVsZC5tb2R1bGUuanMiLCJiaWdjb21tZXJjZS9mb3JtLWZpZWxkLWVycm9ycy9mb3JtLWZpZWxkLWVycm9ycy5kaXJlY3RpdmUuanMiLCJiaWdjb21tZXJjZS9mb3JtLWZpZWxkLWVycm9ycy9mb3JtLWZpZWxkLWVycm9ycy5tb2R1bGUuanMiLCJiaWdjb21tZXJjZS9mb3JtLWZpZWxkLWVycm9yL2Zvcm0tZmllbGQtZXJyb3IuZGlyZWN0aXZlLmpzIiwiYmlnY29tbWVyY2UvZm9ybS1maWVsZC1lcnJvci9mb3JtLWZpZWxkLWVycm9yLm1vZHVsZS5qcyIsImJpZ2NvbW1lcmNlL2ljb24vaWNvbi5jb250cm9sbGVyLmpzIiwiYmlnY29tbWVyY2UvaWNvbi9pY29uLmRpcmVjdGl2ZS5qcyIsImJpZ2NvbW1lcmNlL2ljb24vaWNvbi5qcyIsImJpZ2NvbW1lcmNlL2ljb24vaWNvbi5zdmdSb290UGF0aC5qcyIsImJpZ2NvbW1lcmNlL2xvYWRpbmctb3ZlcmxheS9sb2FkaW5nLW92ZXJsYXkuY29udHJvbGxlci5qcyIsImJpZ2NvbW1lcmNlL2xvYWRpbmctb3ZlcmxheS9sb2FkaW5nLW92ZXJsYXkuZGlyZWN0aXZlLmpzIiwiYmlnY29tbWVyY2UvbG9hZGluZy1vdmVybGF5L2xvYWRpbmctb3ZlcmxheS5qcyIsImJpZ2NvbW1lcmNlL2xvYWRpbmctbm90aWZpY2F0aW9uL2xvYWRpbmctbm90aWZpY2F0aW9uLmRpcmVjdGl2ZS5qcyIsImJpZ2NvbW1lcmNlL2xvYWRpbmctbm90aWZpY2F0aW9uL2xvYWRpbmctbm90aWZpY2F0aW9uLmpzIiwiYmlnY29tbWVyY2UvbW9kYWwvYmMtbW9kYWwubW9kYWxTdGFjay5zZXJ2aWNlLmpzIiwiYmlnY29tbWVyY2UvbW9kYWwvYmMtbW9kYWwubW9kdWxlLmpzIiwiYmlnY29tbWVyY2Uvc3ByaXRlL3Nwcml0ZS5kaXJlY3RpdmUuanMiLCJiaWdjb21tZXJjZS9zcHJpdGUvc3ByaXRlLmpzIiwiYmlnY29tbWVyY2Uvc3dpdGNoL3N3aXRjaC5kaXJlY3RpdmUuanMiLCJiaWdjb21tZXJjZS9zd2l0Y2gvc3dpdGNoLm1vZHVsZS5qcyIsImJpZ2NvbW1lcmNlL2JjLXNlcnZlci10YWJsZS9iYy1zZXJ2ZXItdGFibGUtZmFjdG9yeS9iYy1zZXJ2ZXItdGFibGUtZmFjdG9yeS5zZXJ2aWNlLmpzIiwiYmlnY29tbWVyY2UvYmMtc2VydmVyLXRhYmxlL2JjLXNlcnZlci10YWJsZS9iYy1zZXJ2ZXItdGFibGUuc2VydmljZS5qcyIsImJpZ2NvbW1lcmNlL2NyZWRpdC1jYXJkL2NjLWV4cGlyeS9jYy1leHBpcnkuZGlyZWN0aXZlLmpzIiwiYmlnY29tbWVyY2UvY3JlZGl0LWNhcmQvY2MtZXhwaXJ5L2NjLWV4cGlyeS5tb2R1bGUuanMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7QUFBQSxPQUFPLENBQUMsTUFBTSxDQUFDLG1CQUFtQixFQUFFLENBQ2hDLFNBQVMsRUFDVCxXQUFXLEVBQ1gsWUFBWSxFQUNaLGVBQWUsRUFDZiw2QkFBNkIsRUFDN0IsaUNBQWlDLEVBQ2pDLCtCQUErQixFQUMvQiw0QkFBNEIsRUFDNUIsaUNBQWlDLEVBQ2pDLG1DQUFtQyxFQUNuQyxpQ0FBaUMsRUFDakMsK0JBQStCLEVBQy9CLHdCQUF3QixFQUN4Qiw4QkFBOEIsRUFDOUIsd0JBQXdCLEVBQ3hCLHdDQUF3QyxFQUN4QyxtQ0FBbUMsRUFDbkMsMEJBQTBCLEVBQzFCLDBCQUEwQixDQUM3QixDQUFDLENBQUM7Ozs7QUNuQkgsT0FBTyxDQUFDLE1BQU0sQ0FBQywyQ0FBMkMsRUFBRSxFQUFFLENBQUMsQ0FDMUQsUUFBUSxDQUFDLHdCQUF3QixFQUFFO0FBQ2hDLGFBQVMsRUFBRSxHQUFHO0FBQ2QsZUFBVyxFQUFFLE1BQU0sQ0FBQyxVQUFVLEVBQUUsQ0FBQyxjQUFjLENBQUMsR0FBRyxDQUFDO0FBQ3BELFVBQU0sRUFBRTtBQUNKLFlBQUksRUFBRSxpQkFBaUI7QUFDdkIsaUJBQVMsRUFBRSxZQUFZO0FBQ3ZCLFlBQUksRUFBRSxpQkFBaUI7QUFDdkIsZUFBTyxFQUFFLHNCQUFzQjtBQUMvQixtQkFBVyxFQUFFLGdCQUFnQjtBQUM3QixvQkFBWSxFQUFFLDBCQUEwQjtBQUN4QyxtQkFBVyxFQUFFLGFBQWE7QUFDMUIsZUFBTyxFQUFFLHNCQUFzQjtBQUMvQixtQkFBVyxFQUFFLHFCQUFxQjtBQUNsQyxvQkFBWSxFQUFFLDJCQUEyQjtBQUN6QyxvQkFBWSxFQUFFLDJCQUEyQjtBQUN6QyxjQUFNLEVBQUUscUJBQXFCO0FBQzdCLGdCQUFRLEVBQUUsaUJBQWlCO0FBQzNCLGFBQUssRUFBRSxrQkFBa0I7QUFDekIsa0JBQVUsRUFBRSxrQkFBa0I7QUFDOUIsWUFBSSxFQUFFLGlCQUFpQjtBQUN2QixrQkFBVSxFQUFFLHVCQUF1QjtBQUNuQyxtQkFBVyxFQUFFLGFBQWE7QUFDMUIsb0JBQVksRUFBRSwwQkFBMEI7QUFDeEMsWUFBSSxFQUFFLGlCQUFpQjtBQUN2QixnQkFBUSxFQUFFLHNCQUFzQjtBQUNoQyxrQkFBVSxFQUFFLHdCQUF3QjtLQUN2QztBQUNELFFBQUksRUFBRSxLQUFLO0FBQ1gsaUJBQWEsRUFBRSxPQUFPO0NBQ3pCLENBQUMsQ0FBQzs7OztBQzlCUCxPQUFPLENBQUMsTUFBTSxDQUFDLDJDQUEyQyxFQUFFLENBQ3hELDJDQUEyQyxDQUM5QyxDQUFDLENBQ0csU0FBUyxDQUFDLGNBQWMsRUFBRSxTQUFTLHFCQUFxQixDQUFDLHNCQUFzQixFQUFFO0FBQzlFLFdBQU87QUFDSCxnQkFBUSxFQUFFLEdBQUc7QUFDYixlQUFPLEVBQUUsU0FBUztBQUNsQixhQUFLLEVBQUU7QUFDSCxtQkFBTyxFQUFFLElBQUk7U0FDaEI7O0FBRUQsWUFBSSxFQUFFLFNBQVMsc0JBQXNCLENBQUMsS0FBSyxFQUFFLE9BQU8sRUFBRSxLQUFLLEVBQUUsT0FBTyxFQUFFO0FBQ2xFLGdCQUFJLEtBQUssQ0FBQyxPQUFPLEtBQUssU0FBUyxFQUFFO0FBQzdCLHFCQUFLLENBQUMsT0FBTyxHQUFHLEVBQUUsQ0FBQzthQUN0Qjs7O0FBR0QsYUFBQyxDQUFDLFFBQVEsQ0FBQyxLQUFLLENBQUMsT0FBTyxFQUFFLHNCQUFzQixDQUFDLENBQUM7OztBQUdsRCxpQkFBSyxDQUFDLFFBQVEsR0FBRyxJQUFJLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxFQUFFLEtBQUssQ0FBQyxPQUFPLENBQUMsQ0FBQzs7O0FBR2pELGlCQUFLLENBQUMsUUFBUSxDQUFDLEVBQUUsQ0FBQyxNQUFNLEVBQUUsU0FBUyxNQUFNLENBQUMsS0FBSyxFQUFFO0FBQzdDLHVCQUFPLENBQUMsYUFBYSxDQUFDLEtBQUssQ0FBQyxDQUFDO0FBQzdCLHFCQUFLLENBQUMsTUFBTSxFQUFFLENBQUM7YUFDbEIsQ0FBQyxDQUFDOztBQUVILGlCQUFLLENBQUMsUUFBUSxDQUFDLEVBQUUsQ0FBQyxPQUFPLEVBQUUsU0FBUyxPQUFPLENBQUMsT0FBTyxFQUFFO0FBQ2pELG9CQUFJLEtBQUssQ0FBQyxXQUFXLEtBQUssU0FBUyxFQUFFO0FBQ2pDLHlCQUFLLENBQUMsSUFBSSxDQUFDLGFBQWEsRUFBRSxPQUFPLENBQUMsV0FBVyxDQUFDLENBQUM7aUJBQ2xEO2FBQ0osQ0FBQyxDQUFDOzs7QUFHSCxtQkFBTyxDQUFDLEVBQUUsQ0FBQyxVQUFVLEVBQUUsU0FBUyxTQUFTLEdBQUc7QUFDeEMscUJBQUssQ0FBQyxRQUFRLENBQUMsT0FBTyxFQUFFLENBQUM7YUFDNUIsQ0FBQyxDQUFDO1NBQ047S0FDSixDQUFDO0NBQ0wsQ0FBQyxDQUFDOzs7QUN6Q1AsT0FBTyxDQUFDLE1BQU0sQ0FBQyxpQ0FBaUMsRUFBRSxDQUM5QywyQ0FBMkMsQ0FDOUMsQ0FBQyxDQUFDOzs7QUNGSCxPQUFPLENBQUMsTUFBTSxDQUFDLDhDQUE4QyxFQUFFLEVBQUUsQ0FBQyxDQUM3RCxTQUFTLENBQUMsZ0JBQWdCLEVBQUUsU0FBUyx1QkFBdUIsR0FBRztBQUM1RCxXQUFPO0FBQ0gsZ0JBQVEsRUFBRSxHQUFHO0FBQ2IsZUFBTyxFQUFFLGFBQWE7QUFDdEIsZUFBTyxFQUFFLFNBQVMsOEJBQThCLENBQUMsUUFBUSxFQUFFO0FBQ3ZELG9CQUFRLENBQUMsUUFBUSxDQUFDLGVBQWUsQ0FBQyxDQUFDOztBQUVuQyxtQkFBTyxTQUFTLDJCQUEyQixDQUFDLEtBQUssRUFBRSxPQUFPLEVBQUUsS0FBSyxFQUFFLGNBQWMsRUFBRTtBQUMvRSx1QkFBTyxDQUFDLElBQUksQ0FBQyxJQUFJLEVBQUUsY0FBYyxDQUFDLFdBQVcsRUFBRSxDQUFDLENBQUM7YUFDcEQsQ0FBQztTQUNMO0tBQ0osQ0FBQztDQUNMLENBQUMsQ0FBQzs7O0FDYlAsT0FBTyxDQUFDLE1BQU0sQ0FBQyxnREFBZ0QsRUFBRSxFQUFFLENBQUMsQ0FDL0QsU0FBUyxDQUFDLGtCQUFrQixFQUFFLFNBQVMseUJBQXlCLENBQUMsUUFBUSxFQUFFO0FBQ3hFLFdBQU87QUFDSCxnQkFBUSxFQUFFLEdBQUc7QUFDYixnQkFBUSxFQUFFLElBQUk7QUFDZCxnQkFBUSxFQUFFLElBQUk7QUFDZCxlQUFPLEVBQUUsYUFBYTtBQUN0QixlQUFPLEVBQUUsU0FBUyxnQ0FBZ0MsQ0FBQyxRQUFRLEVBQUU7QUFDekQsb0JBQVEsQ0FBQyxVQUFVLENBQUMsb0JBQW9CLENBQUMsQ0FBQzs7QUFFMUMsbUJBQU8sU0FBUyw2QkFBNkIsQ0FBQyxLQUFLLEVBQUUsT0FBTyxFQUFFLEtBQUssRUFBRSxjQUFjLEVBQUU7QUFDakYsdUJBQU8sQ0FBQyxJQUFJLENBQUMsaUJBQWlCLEVBQUUsR0FBRyxHQUFHLGNBQWMsQ0FBQyxXQUFXLEVBQUUsQ0FBQyxDQUFDO0FBQ3BFLHdCQUFRLENBQUMsT0FBTyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUM7YUFDNUIsQ0FBQztTQUNMO0tBQ0osQ0FBQztDQUNMLENBQUMsQ0FBQzs7O0FDaEJQLE9BQU8sQ0FBQyxNQUFNLENBQUMseUNBQXlDLEVBQUUsRUFBRSxDQUFDLENBQ3hELFNBQVMsQ0FBQyxZQUFZLEVBQUUsU0FBUyxtQkFBbUIsR0FBRztBQUNwRCxXQUFPO0FBQ0gsZ0JBQVEsRUFBRSxJQUFJO0FBQ2Qsa0JBQVUsRUFBRSxTQUFTLDZCQUE2QixHQUFHO0FBQ2pELGdCQUFJLElBQUksR0FBRyxJQUFJO2dCQUNYLFFBQVEsQ0FBQzs7QUFFYixnQkFBSSxDQUFDLFdBQVcsR0FBRyxXQUFXLENBQUM7O0FBRS9CLHFCQUFTLFdBQVcsR0FBRztBQUNuQixvQkFBSSxDQUFDLFFBQVEsRUFBRTtBQUNYLDRCQUFRLEdBQUcsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxjQUFjLENBQUMsQ0FBQztpQkFDekM7QUFDRCx1QkFBTyxRQUFRLENBQUM7YUFDbkI7U0FDSjtLQUNKLENBQUM7Q0FDTCxDQUFDLENBQUM7OztBQ2xCUCxPQUFPLENBQUMsTUFBTSxDQUFDLCtCQUErQixFQUFFLENBQzVDLHlDQUF5QyxFQUN6QyxnREFBZ0QsRUFDaEQsOENBQThDLENBQ2pELENBQUMsQ0FBQzs7O0FDSkgsT0FBTyxDQUFDLE1BQU0sQ0FBQywyQ0FBMkMsRUFBRSxFQUFFLENBQUMsQ0FDMUQsU0FBUyxDQUFDLGNBQWMsRUFBRSxTQUFTLHFCQUFxQixDQUFDLE1BQU0sRUFBRTtBQUM5RCxXQUFPO0FBQ0gsZ0JBQVEsRUFBRSxHQUFHO0FBQ2IsYUFBSyxFQUFFLElBQUk7QUFDWCxtQkFBVyxFQUFFLHlEQUF5RDs7QUFFdEUsZUFBTyxFQUFFLFNBQVMsbUJBQW1CLENBQUMsUUFBUSxFQUFFLE1BQU0sRUFBRTtBQUNwRCxnQkFBSSxPQUFPLEdBQUcsRUFBRSxDQUFDOzs7O0FBSWpCLGFBQUMsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLEtBQUssRUFBRSxVQUFTLEdBQUcsRUFBRTtBQUMvQixvQkFBSSxHQUFHLEtBQUssT0FBTyxFQUFFO0FBQ2pCLDJCQUFPLENBQUMsR0FBRyxDQUFDLEdBQUcsUUFBUSxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsQ0FBQztpQkFDckM7YUFDSixDQUFDLENBQUM7Ozs7QUFJSCxtQkFBTyxDQUFDLGdCQUFnQixDQUFDLEdBQUcsMEJBQTBCLENBQUM7OztBQUd2RCxvQkFBUSxDQUFDLElBQUksQ0FBQyxZQUFZLENBQUMsQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLENBQUM7O0FBRTFDLG1CQUFPLFNBQVMsZ0JBQWdCLENBQUMsTUFBTSxFQUFFLE9BQU8sRUFBRSxLQUFLLEVBQUU7QUFDckQsb0JBQUksbUJBQW1CLEdBQUcsTUFBTSxDQUFDLEtBQUssQ0FBQyxRQUFRLENBQUM7b0JBQzVDLGFBQWEsR0FBRyxDQUFDLEVBQUUsRUFBRSxFQUFFLEVBQUUsRUFBRSxFQUFFLEVBQUUsRUFBRSxHQUFHLENBQUMsQ0FBQzs7QUFFMUMsc0JBQU0sQ0FBQyxRQUFRLEdBQUcsVUFBUyxLQUFLLEVBQUUsS0FBSyxFQUFFO0FBQ3JDLHlCQUFLLENBQUMsY0FBYyxFQUFFLENBQUM7QUFDdkIseUJBQUssR0FBRyxDQUFDLENBQUMsUUFBUSxDQUFDLEtBQUssQ0FBQyxDQUFDO0FBQzFCLDBCQUFNLENBQUMsS0FBSyxDQUFDLFlBQVksQ0FBQyxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsT0FBTyxFQUFFLEtBQUssQ0FBQyxDQUFDO0FBQ3pELDBCQUFNLENBQUMsa0JBQWtCLENBQUMsQ0FBQyxFQUFFLEtBQUssQ0FBQyxDQUFDO2lCQUN2QyxDQUFDOztBQUVGLHNCQUFNLENBQUMsY0FBYyxHQUFHLFlBQVc7QUFDL0IsMkJBQU8sTUFBTSxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsQ0FBQyxNQUFNLENBQUMsT0FBTyxDQUFDLENBQUM7aUJBQzdDLENBQUM7O0FBRUYsc0JBQU0sQ0FBQyxlQUFlLEdBQUcsWUFBVztBQUNoQywyQkFBTyxNQUFNLENBQUMsS0FBSyxDQUFDLFlBQVksQ0FBQyxDQUFDLE1BQU0sQ0FBQyxPQUFPLENBQUMsQ0FBQztpQkFDckQsQ0FBQzs7QUFFRixzQkFBTSxDQUFDLFVBQVUsR0FBRyxZQUFXO0FBQzNCLDJCQUFPLE1BQU0sQ0FBQyxLQUFLLENBQUMsVUFBVSxDQUFDLENBQUMsTUFBTSxDQUFDLE9BQU8sQ0FBQyxLQUFLLEtBQUssQ0FBQztpQkFDN0QsQ0FBQzs7QUFFRixzQkFBTSxDQUFDLFNBQVMsR0FBRyxZQUFXO0FBQzFCLHdCQUFJLE1BQU0sR0FBRyxNQUFNLENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQyxDQUFDLE1BQU0sQ0FBQyxPQUFPLENBQUMsQ0FBQzs7QUFFbEQsd0JBQUksQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLE1BQU0sQ0FBQyxFQUFFO0FBQ3hCLCtCQUFPLGFBQWEsQ0FBQztxQkFDeEI7O0FBRUQsMkJBQU8sTUFBTSxDQUFDO2lCQUNqQixDQUFDOztBQUVGLHNCQUFNLENBQUMsa0JBQWtCLEdBQUcsVUFBUyxJQUFJLEVBQUUsS0FBSyxFQUFFO0FBQzlDLHdCQUFJLHlCQUF5QixHQUFHO0FBQ3hCLDZCQUFLLEVBQUUsS0FBSyxJQUFJLE1BQU0sQ0FBQyxlQUFlLEVBQUU7QUFDeEMsNEJBQUksRUFBRSxJQUFJO3FCQUNiO3dCQUNELG1CQUFtQixDQUFDOztBQUV4QiwwQkFBTSxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDLE9BQU8sRUFBRSxJQUFJLENBQUMsQ0FBQzs7QUFFaEQsdUNBQW1CLEdBQUcsbUJBQW1CLENBQUMsTUFBTSxFQUFFLHlCQUF5QixDQUFDLENBQUM7Ozs7QUFJN0Usd0JBQUksT0FBTyxtQkFBbUIsS0FBSyxVQUFVLEVBQUU7QUFDM0MsMkNBQW1CLENBQUMseUJBQXlCLENBQUMsQ0FBQztxQkFDbEQ7aUJBQ0osQ0FBQzthQUNMLENBQUM7U0FDTDtLQUNKLENBQUM7Q0FDTCxDQUFDLENBQUM7OztBQzlFUCxPQUFPLENBQUMsTUFBTSxDQUFDLGlDQUFpQyxFQUFFLENBQzlDLDJDQUEyQyxDQUM5QyxDQUFDLENBQUM7OztBQ0ZILE9BQU8sQ0FBQyxNQUFNLENBQUMsOENBQThDLEVBQUUsQ0FDM0QsMkNBQTJDLENBQzlDLENBQUMsQ0FFRyxVQUFVLENBQUMsbUJBQW1CLEVBQUUsU0FBUyxpQkFBaUIsQ0FBQyxNQUFNLEVBQUUsSUFBSSxFQUFFLE1BQU0sRUFBRSxNQUFNLEVBQUUsYUFBYSxFQUFFO0FBQ3JHLFFBQUksSUFBSSxHQUFHLElBQUk7UUFDWCxzQkFBc0IsR0FBRyxhQUFhLENBQUMsU0FBUyxDQUFDOzs7OztBQUtyRCxpQkFBYSxDQUFDLElBQUksQ0FBQyxJQUFJLEVBQUUsSUFBSSxFQUFHLE1BQU0sQ0FBQyxNQUFNLENBQUMsV0FBVyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUUsQ0FBQzs7O0FBR3JFLFFBQUksQ0FBQyxrQkFBa0IsR0FBRyxzQkFBc0IsQ0FBQyxrQkFBa0IsQ0FBQztBQUNwRSxRQUFJLENBQUMsYUFBYSxHQUFHLHNCQUFzQixDQUFDLGFBQWEsQ0FBQztBQUMxRCxRQUFJLENBQUMsZUFBZSxHQUFHLHNCQUFzQixDQUFDLGVBQWUsQ0FBQztBQUM5RCxRQUFJLENBQUMsSUFBSSxHQUFHLHNCQUFzQixDQUFDLElBQUksQ0FBQztBQUN4QyxRQUFJLENBQUMsYUFBYSxHQUFHLHNCQUFzQixDQUFDLGFBQWEsQ0FBQztBQUMxRCxRQUFJLENBQUMsZUFBZSxHQUFHLHNCQUFzQixDQUFDLGVBQWUsQ0FBQztBQUM5RCxRQUFJLENBQUMsYUFBYSxHQUFHLHNCQUFzQixDQUFDLGFBQWEsQ0FBQztBQUMxRCxRQUFJLENBQUMsbUJBQW1CLEdBQUcsc0JBQXNCLENBQUMsbUJBQW1CLENBQUM7QUFDdEUsUUFBSSxDQUFDLE9BQU8sR0FBRyxzQkFBc0IsQ0FBQyxPQUFPLENBQUM7QUFDOUMsUUFBSSxDQUFDLGdCQUFnQixHQUFHLHNCQUFzQixDQUFDLGdCQUFnQixDQUFDO0FBQ2hFLFFBQUksQ0FBQyxVQUFVLEdBQUcsQ0FBQyxDQUFDLElBQUksQ0FBQyxzQkFBc0IsQ0FBQyxVQUFVLEVBQUUsSUFBSSxDQUFDLENBQUM7QUFDbEUsUUFBSSxDQUFDLFVBQVUsR0FBRyxzQkFBc0IsQ0FBQyxVQUFVLENBQUM7QUFDcEQsUUFBSSxDQUFDLFdBQVcsR0FBRyxzQkFBc0IsQ0FBQyxXQUFXLENBQUM7QUFDdEQsUUFBSSxDQUFDLGdCQUFnQixHQUFHLHNCQUFzQixDQUFDLGdCQUFnQixDQUFDOztBQUVoRSxRQUFJLEVBQUUsQ0FBQzs7QUFFUCxhQUFTLElBQUksR0FBRztBQUNaLFlBQUksZ0JBQWdCLENBQUM7O0FBRXJCLHdCQUFnQixHQUFHLE1BQU0sQ0FBQyxNQUFNLENBQUMsZ0JBQWdCLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQztBQUMzRCxZQUFJLENBQUMsQ0FBQyxDQUFDLFVBQVUsQ0FBQyxnQkFBZ0IsQ0FBQyxFQUFFO0FBQ2pDLGdCQUFJLENBQUMsS0FBSyxDQUFDLGtFQUFrRSxDQUFDLENBQUM7QUFDL0UsbUJBQU87U0FDVjtBQUNELFlBQUksQ0FBQyxnQkFBZ0IsR0FBRyxnQkFBZ0IsQ0FBQzs7QUFFekMsWUFBSSxDQUFDLElBQUksRUFBRSxDQUFDO0tBQ2Y7Q0FDSixDQUFDLENBQUM7OztBQzNDUCxPQUFPLENBQUMsTUFBTSxDQUFDLDZDQUE2QyxFQUFFLENBQzFELDhDQUE4QyxFQUM5QyxxREFBcUQsRUFDckQsV0FBVyxDQUNkLENBQUM7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0NBa0RHLFNBQVMsQ0FBQyxlQUFlLEVBQUUsU0FBUyxzQkFBc0IsQ0FBQyxNQUFNLEVBQUU7QUFDaEUsUUFBSSxTQUFTLEdBQUc7QUFDWixnQkFBUSxFQUFFLElBQUk7QUFDZCxrQkFBVSxFQUFFLG9DQUFvQztBQUNoRCxZQUFJLEVBQUUsU0FBUyxpQkFBaUIsQ0FBQyxNQUFNLEVBQUUsT0FBTyxFQUFFLEtBQUssRUFBRSxpQkFBaUIsRUFBRTtBQUN4RSxnQkFBSSxLQUFLLENBQUMsZUFBZSxFQUFFOztBQUV2QixzQkFBTSxDQUFDLEtBQUssQ0FBQyxlQUFlLENBQUMsQ0FBQyxNQUFNLENBQUMsTUFBTSxFQUFFLGlCQUFpQixDQUFDLENBQUM7YUFDbkU7U0FDSjtLQUNKLENBQUM7O0FBRUYsV0FBTyxTQUFTLENBQUM7Q0FDcEIsQ0FBQyxDQUFDOzs7QUNuRVAsT0FBTyxDQUFDLE1BQU0sQ0FBQyxtQ0FBbUMsRUFBRSxDQUNoRCw2Q0FBNkMsRUFDN0MscURBQXFELEVBQ3JELG1EQUFtRCxDQUN0RCxDQUFDLENBQUM7OztBQ0pILE9BQU8sQ0FBQyxNQUFNLENBQUMscURBQXFELEVBQUUsQ0FDbEUsbURBQW1ELENBQ3RELENBQUMsQ0FDRyxTQUFTLENBQUMsVUFBVSxFQUFFLFNBQVMsaUJBQWlCLENBQUMsSUFBSSxFQUFFLG9CQUFvQixFQUFFO0FBQzFFLFFBQUksU0FBUyxHQUFHO0FBQ1osbUJBQVcsRUFBRSx3REFBd0Q7QUFDckUsZ0JBQVEsRUFBRSxHQUFHO0FBQ2Isa0JBQVUsRUFBRSxJQUFJO0FBQ2hCLGFBQUssRUFBRTtBQUNILHFCQUFTLEVBQUUsR0FBRztBQUNkLHNCQUFVLEVBQUUsR0FBRztBQUNmLG1CQUFPLEVBQUUsR0FBRztTQUNmO0FBQ0QsZUFBTyxFQUFFLGtCQUFrQjtBQUMzQixZQUFJLEVBQUUscUJBQXFCO0tBQzlCLENBQUM7O0FBRUYsYUFBUyxxQkFBcUIsQ0FBQyxLQUFLLEVBQUUsT0FBTyxFQUFFLEtBQUssRUFBRSxpQkFBaUIsRUFBRTtBQUNyRSxZQUFJLGFBQWEsRUFDYixhQUFhLENBQUM7O0FBRWxCLFlBQUksS0FBSyxDQUFDLE9BQU8sRUFBRTtBQUNmLHlCQUFhLEdBQUcsb0JBQW9CLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsQ0FBQztTQUMzRCxNQUFNLElBQUksaUJBQWlCLEVBQUU7QUFDMUIseUJBQWEsR0FBRyxpQkFBaUIsQ0FBQztTQUNyQyxNQUFNO0FBQ0gsZ0JBQUksQ0FBQyxLQUFLLENBQUMsb0ZBQW9GLENBQUMsQ0FBQztTQUNwRzs7QUFFRCxxQkFBYSxHQUFHLGFBQWEsQ0FBQyxXQUFXLENBQUMsYUFBYSxDQUFDOztBQUV4RCxhQUFLLENBQUMsR0FBRyxHQUFHLGFBQWEsQ0FBQyxHQUFHLENBQUM7QUFDOUIsYUFBSyxDQUFDLElBQUksR0FBRyxhQUFhLENBQUMsSUFBSSxDQUFDO0FBQ2hDLGFBQUssQ0FBQyxNQUFNLEdBQUcsYUFBYSxDQUFDLE1BQU0sQ0FBQztBQUNwQyxhQUFLLENBQUMsT0FBTyxHQUFHLGFBQWEsQ0FBQyxPQUFPLENBQUM7QUFDdEMsYUFBSyxDQUFDLElBQUksR0FBRyxJQUFJLENBQUM7O0FBRWxCLGlCQUFTLElBQUksQ0FBQyxNQUFNLEVBQUU7QUFDbEIsZ0JBQUksTUFBTSxFQUNOLE9BQU8sQ0FBQzs7QUFFWixnQkFBSSxNQUFNLEVBQUU7QUFDUixzQkFBTSxDQUFDLGNBQWMsRUFBRSxDQUFDO2FBQzNCOztBQUVELGdCQUFJLGFBQWEsQ0FBQyxNQUFNLEtBQUssS0FBSyxDQUFDLFNBQVMsRUFBRTtBQUMxQyxzQkFBTSxHQUFHLGFBQWEsQ0FBQyxNQUFNLENBQUM7QUFDOUIsdUJBQU8sR0FBRyxhQUFhLENBQUMsT0FBTyxLQUFLLEtBQUssQ0FBQyxHQUFHLEdBQUcsS0FBSyxDQUFDLElBQUksR0FBRyxLQUFLLENBQUMsR0FBRyxDQUFDO2FBQzFFLE1BQU07QUFDSCxzQkFBTSxHQUFHLEtBQUssQ0FBQyxTQUFTLENBQUM7QUFDekIsdUJBQU8sR0FBRyxLQUFLLENBQUMsR0FBRyxDQUFDO2FBQ3ZCOztBQUVELHlCQUFhLENBQUMsVUFBVSxDQUFDLE1BQU0sRUFBRSxPQUFPLENBQUMsQ0FBQztTQUM3QztLQUNKOztBQUVELFdBQU8sU0FBUyxDQUFDO0NBQ3BCLENBQUMsQ0FBQzs7O0FDMURQLE9BQU8sQ0FBQyxNQUFNLENBQUMsNENBQTRDLEVBQUUsRUFBRSxDQUFDLENBQzNELFVBQVUsQ0FBQyxrQkFBa0IsRUFBRSxTQUFTLGdCQUFnQixDQUFDLE1BQU0sRUFBRSxRQUFRLEVBQUUsSUFBSSxFQUFFLE1BQU0sRUFBRSxNQUFNLEVBQUU7QUFDOUYsUUFBSSxJQUFJLEdBQUcsSUFBSTtRQUNYLFVBQVUsR0FBRyxNQUFNLENBQUMsTUFBTSxDQUFDLFlBQVksQ0FBQyxDQUFDLElBQUksQ0FBQyxJQUFJLEtBQUs7UUFDdkQsU0FBUyxHQUFHLE1BQU0sQ0FBQyxNQUFNLENBQUMsV0FBVyxDQUFDLENBQUMsSUFBSSxDQUFDLElBQUksSUFBSTtRQUNwRCxPQUFPLEdBQUcsUUFBUSxDQUFDLFVBQVUsQ0FBQyxTQUFTLENBQUMsQ0FBQzs7QUFFN0MsUUFBSSxFQUFFLENBQUM7OztBQUdQLGFBQVMsYUFBYSxHQUFHO0FBQ3JCLGVBQU8sT0FBTyxDQUFDLFdBQVcsQ0FBQztLQUM5Qjs7QUFFRCxhQUFTLFFBQVEsR0FBRztBQUNoQixlQUFPLElBQUksQ0FBQyxLQUFLLElBQUksSUFBSSxDQUFDLE9BQU8sQ0FBQztLQUNyQzs7QUFFRCxhQUFTLGlCQUFpQixHQUFHO0FBQ3pCLGVBQU8sSUFBSSxDQUFDLGNBQWMsQ0FBQztLQUM5Qjs7O0FBR0QsYUFBUyxnQkFBZ0IsQ0FBQyxVQUFVLEVBQUU7QUFDbEMsZUFBTyxDQUFDLGFBQWEsQ0FBQyxVQUFVLENBQUMsQ0FBQztBQUNsQyxlQUFPLENBQUMsZ0JBQWdCLEVBQUUsQ0FBQztBQUMzQixlQUFPLENBQUMsT0FBTyxFQUFFLENBQUM7S0FDckI7O0FBRUQsYUFBUyxvQkFBb0IsQ0FBQyxVQUFVLEVBQUU7QUFDdEMsWUFBSSxVQUFVLEtBQUssU0FBUyxFQUFFO0FBQzFCLCtCQUFtQixFQUFFLENBQUM7U0FDekIsTUFBTSxJQUFJLFVBQVUsS0FBSyxVQUFVLEVBQUU7QUFDbEMsb0NBQXdCLEVBQUUsQ0FBQztTQUM5QjtLQUNKOztBQUVELGFBQVMsbUJBQW1CLEdBQUc7QUFDM0IsWUFBSSxVQUFVLEdBQUcsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsY0FBYyxFQUFFLFFBQVEsRUFBRSxDQUFDLENBQUM7O0FBRTVELFlBQUksQ0FBQyxVQUFVLEVBQUU7QUFDYixnQkFBSSxDQUFDLGNBQWMsQ0FBQyxJQUFJLENBQUMsUUFBUSxFQUFFLENBQUMsQ0FBQztTQUN4QztLQUNKOztBQUVELGFBQVMsd0JBQXdCLEdBQUc7QUFDaEMsWUFBSSxLQUFLLEdBQUcsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsY0FBYyxFQUFFLFFBQVEsRUFBRSxDQUFDLENBQUM7O0FBRXZELFlBQUksS0FBSyxLQUFLLENBQUMsQ0FBQyxFQUFFO0FBQ2QsZ0JBQUksQ0FBQyxjQUFjLENBQUMsTUFBTSxDQUFDLEtBQUssRUFBRSxDQUFDLENBQUMsQ0FBQztTQUN4QztLQUNKOzs7QUFHRCxhQUFTLGVBQWUsQ0FBQyxVQUFVLEVBQUUsYUFBYSxFQUFFO0FBQ2hELFlBQUksaUJBQWlCLEVBQ2pCLHFCQUFxQixDQUFDOzs7QUFHMUIsWUFBSSxDQUFDLENBQUMsV0FBVyxDQUFDLFVBQVUsQ0FBQyxJQUFJLFVBQVUsS0FBSyxhQUFhLEVBQUU7QUFDM0QsbUJBQU87U0FDVjs7O0FBR0QseUJBQWlCLEdBQUcsSUFBSSxDQUFDLGNBQWMsQ0FBQyxLQUFLLEVBQUUsQ0FBQzs7O0FBR2hELDRCQUFvQixDQUFDLFVBQVUsQ0FBQyxDQUFDOzs7QUFHakMsNkJBQXFCLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLGNBQWMsRUFBRSxpQkFBaUIsQ0FBQyxDQUFDLE1BQU0sQ0FBQzs7O0FBRy9FLFlBQUksSUFBSSxDQUFDLFFBQVEsSUFBSSxxQkFBcUIsRUFBRTtBQUN4QyxnQkFBSSxDQUFDLFFBQVEsQ0FBQztBQUNWLDhCQUFjLEVBQUUsSUFBSSxDQUFDLGNBQWM7QUFDbkMsaUNBQWlCLEVBQUUsaUJBQWlCO2FBQ3ZDLENBQUMsQ0FBQztTQUNOO0tBQ0o7O0FBRUQsYUFBUyxtQkFBbUIsQ0FBQyxjQUFjLEVBQUU7O0FBRXpDLFlBQUksVUFBVSxHQUFHLENBQUMsQ0FBQyxPQUFPLENBQUMsY0FBYyxFQUFFLFFBQVEsRUFBRSxDQUFDO1lBQ2xELFVBQVUsR0FBRyxhQUFhLEVBQUUsQ0FBQzs7QUFFakMsWUFBSSxVQUFVLElBQUksVUFBVSxLQUFLLFNBQVMsRUFBRTtBQUN4Qyw0QkFBZ0IsQ0FBQyxTQUFTLENBQUMsQ0FBQztTQUMvQixNQUFNLElBQUksQ0FBQyxVQUFVLElBQUksVUFBVSxLQUFLLFVBQVUsRUFBRTtBQUNqRCw0QkFBZ0IsQ0FBQyxVQUFVLENBQUMsQ0FBQztTQUNoQztLQUNKOzs7QUFHRCxhQUFTLElBQUksR0FBRztBQUNaLFlBQUksTUFBTSxDQUFDLElBQUksS0FBSyxVQUFVLEVBQUU7QUFDNUIsZ0JBQUksQ0FBQyxLQUFLLENBQUMsa0VBQWtFLENBQUMsQ0FBQzs7QUFFL0UsbUJBQU87U0FDVjs7QUFFRCxjQUFNLENBQUMsTUFBTSxDQUFDLGFBQWEsRUFBRSxlQUFlLENBQUMsQ0FBQztBQUM5QyxjQUFNLENBQUMsZ0JBQWdCLENBQUMsaUJBQWlCLEVBQUUsbUJBQW1CLENBQUMsQ0FBQztLQUNuRTtDQUNKLENBQUMsQ0FBQzs7O0FDeEdQLE9BQU8sQ0FBQyxNQUFNLENBQUMsMkNBQTJDLEVBQUUsQ0FDeEQsNENBQTRDLENBQy9DLENBQUM7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0NBa0RHLFNBQVMsQ0FBQyxjQUFjLEVBQUUsU0FBUyxxQkFBcUIsR0FBRztBQUN4RCxXQUFPO0FBQ0gsZ0JBQVEsRUFBRSxHQUFHO0FBQ2IsZUFBTyxFQUFFLFNBQVM7QUFDbEIsa0JBQVUsRUFBRSxrQkFBa0I7QUFDOUIsb0JBQVksRUFBRSxrQkFBa0I7QUFDaEMsd0JBQWdCLEVBQUUsSUFBSTtBQUN0QixhQUFLLEVBQUU7QUFDSCxvQkFBUSxFQUFFLHFCQUFxQjtBQUMvQiwwQkFBYyxFQUFFLGVBQWU7QUFDL0IsaUJBQUssRUFBRSxHQUFHO0FBQ1YsbUJBQU8sRUFBRSxHQUFHO1NBQ2Y7S0FDSixDQUFDO0NBQ0wsQ0FBQyxDQUFDOzs7QUNsRVAsT0FBTyxDQUFDLE1BQU0sQ0FBQyxpQ0FBaUMsRUFBRSxDQUM5QywyQ0FBMkMsQ0FDOUMsQ0FBQyxDQUFDOzs7Ozs7Ozs7Ozs7QUNPSCxPQUFPLENBQUMsTUFBTSxDQUFDLHlDQUF5QyxFQUFFLEVBQUUsQ0FBQyxDQUN4RCxTQUFTLENBQUMsWUFBWSxFQUFFLFNBQVMsbUJBQW1CLEdBQUc7QUFDcEQsV0FBTztBQUNILFlBQUksRUFBRSxTQUFTLGNBQWMsQ0FBQyxLQUFLLEVBQUUsSUFBSSxFQUFFLElBQUksRUFBRSxRQUFRLEVBQUU7QUFDdkQsZ0JBQU0sYUFBYSxHQUFHO0FBQ2xCLHdCQUFRLEVBQUUsSUFBSTtBQUNkLHdCQUFRLEVBQUUsSUFBSTthQUNqQixDQUFDOztBQUVGLGlCQUFLLENBQUMsUUFBUSxHQUFHLENBQUMsQ0FBQyxRQUFRLENBQUMsS0FBSyxDQUFDLFFBQVEsRUFBRSxhQUFhLENBQUMsQ0FBQzs7Ozs7OztBQU8zRCxpQkFBSyxDQUFDLE1BQU0sQ0FBQyxTQUFTLEVBQUUsU0FBUyxDQUFDLENBQUM7O0FBRW5DLGlCQUFLLENBQUMsUUFBUSxHQUFHLFFBQVEsQ0FBQzs7QUFFMUIscUJBQVMsU0FBUyxHQUFHO0FBQ2pCLHVCQUFPLFFBQVEsQ0FBQyxRQUFRLENBQUMsWUFBWSxDQUFDO2FBQ3pDOztBQUVELHFCQUFTLFNBQVMsQ0FBQyxJQUFJLEVBQUU7QUFDckIscUJBQUssQ0FBQyxNQUFNLENBQUMsTUFBTSxHQUFHLElBQUksQ0FBQzthQUM5QjtTQUNKO0FBQ0QsZUFBTyxFQUFFLE9BQU87QUFDaEIsZ0JBQVEsRUFBRSxJQUFJO0FBQ2QsYUFBSyxFQUFFO0FBQ0gsa0JBQU0sRUFBRSxHQUFHO0FBQ1gsb0JBQVEsRUFBRSxHQUFHO1NBQ2hCO0FBQ0QsbUJBQVcsRUFBRSxxREFBcUQ7S0FDckUsQ0FBQztDQUNMLENBQUMsQ0FBQzs7O0FDN0NQLE9BQU8sQ0FBQyxNQUFNLENBQUMsK0JBQStCLEVBQUUsQ0FDNUMsY0FBYyxFQUNkLHlDQUF5QyxFQUN6Qyx5Q0FBeUMsRUFDekMsU0FBUyxDQUNaLENBQUMsQ0FBQzs7O0FDTEgsT0FBTyxDQUFDLE1BQU0sQ0FBQyxrQ0FBa0MsRUFBRSxFQUFFLENBQUMsQ0FDakQsU0FBUyxDQUFDLE1BQU0sRUFBRSxTQUFTLGFBQWEsR0FBRztBQUN4QyxXQUFPO0FBQ0gsZ0JBQVEsRUFBRSxHQUFHO0FBQ2IsWUFBSSxFQUFFLFNBQVMsUUFBUSxDQUFDLEtBQUssRUFBRSxPQUFPLEVBQUUsS0FBSyxFQUFFO0FBQzNDLG1CQUFPLENBQUMsUUFBUSxDQUFDLE1BQU0sQ0FBQyxDQUFDO0FBQ3pCLG1CQUFPLENBQUMsSUFBSSxDQUFDLFlBQVksRUFBRSxFQUFFLENBQUMsQ0FBQzs7O0FBRy9CLGdCQUFJLENBQUMsS0FBSyxDQUFDLGdCQUFnQixFQUFFO0FBQ3pCLHVCQUFPLENBQUMsRUFBRSxDQUFDLFFBQVEsRUFBRSxTQUFTLDBCQUEwQixHQUFHO0FBQ3ZELHdCQUFJLFlBQVksR0FBRyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsYUFBYSxDQUFDLGFBQWEsQ0FBQyxDQUFDOztBQUUzRCx3QkFBSSxZQUFZLEVBQUU7QUFDZCxvQ0FBWSxDQUFDLEtBQUssRUFBRSxDQUFDOzs7QUFHckIsNEJBQUksWUFBWSxDQUFDLE1BQU0sRUFBRTtBQUNyQix3Q0FBWSxDQUFDLE1BQU0sRUFBRSxDQUFDO3lCQUN6QjtxQkFDSjtpQkFDSixDQUFDLENBQUM7YUFDTjtTQUNKO0tBQ0osQ0FBQztDQUNMLENBQUMsQ0FBQzs7O0FDekJQLE9BQU8sQ0FBQyxNQUFNLENBQUMsd0JBQXdCLEVBQUUsQ0FDckMsa0NBQWtDLENBQ3JDLENBQUMsQ0FBQzs7O0FDRkgsT0FBTyxDQUFDLE1BQU0sQ0FBQyx3Q0FBd0MsRUFBRSxFQUFFLENBQUMsQ0FDdkQsU0FBUyxDQUFDLFdBQVcsRUFBRSxTQUFTLGtCQUFrQixDQUFDLElBQUksRUFBRTtBQUN0RCxXQUFPO0FBQ0gsZUFBTyxFQUFFLE9BQU87QUFDaEIsZ0JBQVEsRUFBRSxJQUFJO0FBQ2QsYUFBSyxFQUFFLElBQUk7QUFDWCxZQUFJLEVBQUU7QUFDRixlQUFHLEVBQUUsU0FBUyxhQUFhLENBQUMsS0FBSyxFQUFFLE9BQU8sRUFBRSxLQUFLLEVBQUU7O0FBRS9DLHFCQUFLLENBQUMsUUFBUSxHQUFHLEtBQUssQ0FBQyxRQUFRLENBQUM7YUFDbkM7O0FBRUQsZ0JBQUksRUFBRSxTQUFTLGFBQWEsQ0FBQyxLQUFLLEVBQUUsT0FBTyxFQUFFLEtBQUssRUFBRSxRQUFRLEVBQUU7O0FBRTFELG9CQUFJLFFBQVEsR0FBRyxLQUFLLENBQUMsUUFBUTtvQkFDekIsZUFBZSxHQUFHLFNBQVMsZUFBZSxHQUFHO0FBQUUsMkJBQU8sUUFBUSxDQUFDLFFBQVEsQ0FBQyxDQUFDLE1BQU0sQ0FBQztpQkFBRTtvQkFDbEYsZUFBZSxHQUFHLFNBQVMsZUFBZSxHQUFHO0FBQUUsMkJBQU8sUUFBUSxDQUFDLFVBQVUsQ0FBQztpQkFBRSxDQUFDOztBQUVqRix1QkFBTyxDQUFDLFFBQVEsQ0FBQyxZQUFZLENBQUMsQ0FBQzs7O0FBRy9CLG9CQUFJLENBQUMsUUFBUSxFQUFFO0FBQ1gsMkJBQU87aUJBQ1Y7OztBQUdELG9CQUFJLENBQUMsUUFBUSxDQUFDLFFBQVEsQ0FBQyxFQUFFO0FBQ3JCLDJCQUFPLElBQUksQ0FBQyxJQUFJLENBQUMsa0ZBQWtGLENBQUMsQ0FBQztpQkFDeEc7O0FBRUQsb0JBQUksRUFBRSxDQUFDOztBQUVQLHlCQUFTLElBQUksR0FBRzs7QUFFWix5QkFBSyxDQUFDLE1BQU0sQ0FBQyxlQUFlLEVBQUUsYUFBYSxDQUFDLENBQUM7QUFDN0MseUJBQUssQ0FBQyxNQUFNLENBQUMsZUFBZSxFQUFFLGFBQWEsQ0FBQyxDQUFDO2lCQUNoRDs7QUFFRCx5QkFBUyxhQUFhLEdBQUc7O0FBRXJCLDJCQUFPLENBQUMsV0FBVyxDQUFDLG1CQUFtQixFQUFFLFFBQVEsQ0FBQyxVQUFVLElBQUksUUFBUSxDQUFDLFFBQVEsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDO2lCQUNoRzthQUNKO1NBQ0o7S0FDSixDQUFDO0NBQ0wsQ0FBQyxDQUFDOzs7QUM3Q1AsT0FBTyxDQUFDLE1BQU0sQ0FBQyw4QkFBOEIsRUFBRSxDQUMzQyx3Q0FBd0MsRUFDeEMsb0NBQW9DLEVBQ3BDLHFDQUFxQyxDQUN4QyxDQUFDLENBQUM7OztBQ0pILE9BQU8sQ0FBQyxNQUFNLENBQUMsK0NBQStDLEVBQUUsRUFBRSxDQUFDLENBQzlELFNBQVMsQ0FBQyxpQkFBaUIsRUFBRSxTQUFTLHdCQUF3QixHQUFHO0FBQzlELFdBQU87QUFDSCxlQUFPLEVBQUUsSUFBSTtBQUNiLGVBQU8sRUFBRSxPQUFPO0FBQ2hCLGdCQUFRLEVBQUUsSUFBSTtBQUNkLG1CQUFXLEVBQUUsaUVBQWlFO0FBQzlFLGtCQUFVLEVBQUUsSUFBSTtBQUNoQixZQUFJLEVBQUU7OztBQUdGLGVBQUcsRUFBRSxTQUFTLHNCQUFzQixDQUFDLEtBQUssRUFBRSxPQUFPLEVBQUUsS0FBSyxFQUFFLFFBQVEsRUFBRTs7QUFFbEUsb0JBQUksUUFBUSxHQUFHLEtBQUssQ0FBQyxRQUFRLElBQUksS0FBSyxDQUFDLFFBQVE7b0JBQzNDLGFBQWEsR0FBRyxRQUFRLENBQUMsUUFBUSxDQUFDLENBQUM7Ozs7QUFJdkMscUJBQUssQ0FBQyxRQUFRLEdBQUcsUUFBUSxDQUFDO0FBQzFCLHFCQUFLLENBQUMsUUFBUSxHQUFHLFFBQVEsQ0FBQztBQUMxQixxQkFBSyxDQUFDLGFBQWEsR0FBRyxhQUFhLENBQUM7YUFDdkM7U0FDSjtLQUNKLENBQUM7Q0FDTCxDQUFDLENBQUM7OztBQ3hCUCxPQUFPLENBQUMsTUFBTSxDQUFDLHFDQUFxQyxFQUFFLENBQ2xELCtDQUErQyxDQUNsRCxDQUFDLENBQUM7OztBQ0ZILE9BQU8sQ0FBQyxNQUFNLENBQUMsOENBQThDLEVBQUUsRUFBRSxDQUFDLENBQzdELFNBQVMsQ0FBQyxnQkFBZ0IsRUFBRSxTQUFTLHVCQUF1QixDQUFDLFFBQVEsRUFBRTtBQUNwRSxXQUFPO0FBQ0gsZ0JBQVEsRUFBRSxFQUFFO0FBQ1osZUFBTyxFQUFFLElBQUk7QUFDYixnQkFBUSxFQUFFLElBQUk7QUFDZCxtQkFBVyxFQUFFLCtEQUErRDtBQUM1RSxnQkFBUSxFQUFFLElBQUk7QUFDZCxrQkFBVSxFQUFFLElBQUk7QUFDaEIsZUFBTyxFQUFFLFNBQVMscUJBQXFCLENBQUMsUUFBUSxFQUFFLE1BQU0sRUFBRTs7O0FBR3RELGdCQUFJLFFBQVEsQ0FBQyxJQUFJLENBQUMsV0FBVyxDQUFDLEtBQUssU0FBUyxFQUFFO0FBQzFDLHNCQUFNLElBQUksV0FBVyxDQUNqQiw4RUFBOEUsR0FDOUUsb0ZBQW9GLEdBQ3BGLGFBQWEsR0FBRyxNQUFNLENBQUMsUUFBUSxDQUNsQyxDQUFDO2FBQ0w7O0FBRUQsbUJBQU87QUFDSCxvQkFBSSxFQUFFLFNBQVMsc0JBQXNCLENBQUMsS0FBSyxFQUFFLE9BQU8sRUFBRSxLQUFLLEVBQUUsV0FBVyxFQUFFLFVBQVUsRUFBRTtBQUNsRix5QkFBSyxDQUFDLFFBQVEsR0FBRyxLQUFLLENBQUMsUUFBUSxJQUFJLEtBQUssQ0FBQyxRQUFRLENBQUM7O0FBRWxELDhCQUFVLENBQUMsU0FBUyx3QkFBd0IsQ0FBQyxVQUFVLEVBQUU7QUFDckQsNEJBQUksWUFBWSxHQUFHLE9BQU8sQ0FBQyxPQUFPLENBQUMsU0FBUyxDQUFDLENBQUM7Ozs7QUFJOUMsb0NBQVksQ0FBQyxJQUFJLENBQUMsS0FBSyxFQUFFLEtBQUssQ0FBQyxRQUFRLENBQUMsQ0FBQztBQUN6QyxvQ0FBWSxDQUFDLElBQUksQ0FBQyxZQUFZLEVBQUUsS0FBSyxDQUFDLFFBQVEsQ0FBQyxDQUFDO0FBQ2hELG9DQUFZLENBQUMsSUFBSSxDQUFDLE1BQU0sRUFBRSxPQUFPLENBQUMsQ0FBQztBQUNuQyxvQ0FBWSxDQUFDLFFBQVEsQ0FBQyxvQkFBb0IsQ0FBQyxDQUFDOzs7QUFHNUMsb0NBQVksQ0FBQyxNQUFNLENBQUMsVUFBVSxDQUFDLENBQUM7O0FBRWhDLCtCQUFPLENBQUMsTUFBTSxDQUFDLFlBQVksQ0FBQyxDQUFDOztBQUU3QixnQ0FBUSxDQUFDLE9BQU8sQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDO3FCQUM1QixDQUFDLENBQUM7aUJBQ047YUFDSixDQUFDO1NBQ0w7S0FDSixDQUFDO0NBQ0wsQ0FBQyxDQUFDOzs7QUM3Q1AsT0FBTyxDQUFDLE1BQU0sQ0FBQyxvQ0FBb0MsRUFBRSxDQUNqRCw4Q0FBOEMsQ0FDakQsQ0FBQyxDQUFDOzs7QUNGSCxPQUFPLENBQUMsTUFBTSxDQUFDLG1DQUFtQyxFQUFFLENBQ2hELG9DQUFvQyxDQUN2QyxDQUFDLENBQ0csVUFBVSxDQUFDLFVBQVUsRUFBRSxTQUFTLHVCQUF1QixDQUFDLEtBQUssRUFBRSxjQUFjLEVBQUUsV0FBVyxFQUFFO0FBQ3pGLFFBQUksSUFBSSxHQUFHLElBQUksQ0FBQzs7QUFFaEIsUUFBSSxDQUFDLFdBQVcsR0FBRyxXQUFXLENBQUM7O0FBRS9CLGFBQVMsV0FBVyxDQUFDLEtBQUssRUFBRTtBQUN4QixZQUFJLFdBQVcsR0FBRyxXQUFXLEdBQUcsS0FBSyxHQUFHLE1BQU0sQ0FBQzs7QUFFL0MsZUFBTyxLQUFLLENBQUMsR0FBRyxDQUFDLFdBQVcsRUFBRSxFQUFFLEtBQUssRUFBRSxjQUFjLEVBQUUsQ0FBQyxDQUNuRCxJQUFJLENBQUMsU0FBUyx3QkFBd0IsQ0FBQyxRQUFRLEVBQUU7QUFDOUMsbUJBQU8sUUFBUSxDQUFDLElBQUksQ0FBQztTQUN4QixDQUFDLENBQUM7S0FDVjtDQUNKLENBQUMsQ0FBQzs7Ozs7Ozs7O0FDVlAsT0FBTyxDQUFDLE1BQU0sQ0FBQyxrQ0FBa0MsRUFBRSxDQUMvQyxtQ0FBbUMsQ0FDdEMsQ0FBQyxDQUNHLFNBQVMsQ0FBQyxNQUFNLEVBQUUsU0FBUyxhQUFhLEdBQUc7QUFDeEMsV0FBTztBQUNILHdCQUFnQixFQUFFLElBQUk7QUFDdEIsa0JBQVUsRUFBRSxzQkFBc0I7QUFDbEMsZ0JBQVEsRUFBRSxHQUFHO0FBQ2IsYUFBSyxFQUFFO0FBQ0gsaUJBQUssRUFBRSxHQUFHO1NBQ2I7QUFDRCxlQUFPLEVBQUUsU0FBUyxvQkFBb0IsQ0FBQyxRQUFRLEVBQUU7QUFDN0Msb0JBQVEsQ0FBQyxRQUFRLENBQUMsTUFBTSxDQUFDLENBQUM7QUFDMUIsb0JBQVEsQ0FBQyxJQUFJLENBQUMsYUFBYSxFQUFFLElBQUksQ0FBQyxDQUFDOztBQUVuQyxtQkFBTyxTQUFTLGlCQUFpQixDQUFDLE1BQU0sRUFBRSxPQUFPLEVBQUUsS0FBSyxFQUFFLElBQUksRUFBRTtBQUM1RCxzQkFBTSxDQUFDLE1BQU0sQ0FBQyxnQkFBZ0IsRUFBRSxTQUFTLHNCQUFzQixDQUFDLFFBQVEsRUFBRTtBQUN0RSx3QkFBSSxDQUFDLFdBQVcsQ0FBQyxRQUFRLENBQUMsQ0FDckIsSUFBSSxDQUFDLFNBQVMsbUJBQW1CLENBQUMsR0FBRyxFQUFFO0FBQ3BDLCtCQUFPLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxDQUFDO3FCQUNyQixDQUFDLENBQUM7aUJBQ1YsQ0FBQyxDQUFDO2FBQ04sQ0FBQztTQUNMO0tBQ0osQ0FBQztDQUNMLENBQUMsQ0FBQzs7O0FDL0JQLE9BQU8sQ0FBQyxNQUFNLENBQUMsd0JBQXdCLEVBQUUsQ0FDckMsa0NBQWtDLENBQ3JDLENBQUMsQ0FBQzs7O0FDRkgsT0FBTyxDQUFDLE1BQU0sQ0FBQyxvQ0FBb0MsRUFBRSxFQUFFLENBQUMsQ0FDbkQsUUFBUSxDQUFDLGFBQWEsRUFBRSxTQUFTLHlCQUF5QixHQUFHO0FBQzFELFFBQUksQ0FBQyxXQUFXLEdBQUcsV0FBVyxDQUFDO0FBQy9CLFFBQUksQ0FBQyxJQUFJLEdBQUcsU0FBUyxzQkFBc0IsQ0FBQyxJQUFJLEVBQUU7QUFDOUMsWUFBSSxJQUFJLENBQUMsV0FBVyxLQUFLLFNBQVMsRUFBRTtBQUNoQyxnQkFBSSxDQUFDLEtBQUssQ0FBQyw4RUFBOEUsQ0FBQyxDQUFDO1NBQzlGOztBQUVELGVBQU8sSUFBSSxDQUFDLFdBQVcsQ0FBQztLQUMzQixDQUFDOztBQUVGLGFBQVMsV0FBVyxDQUFDLFdBQVcsRUFBRTtBQUM5QixZQUFJLENBQUMsV0FBVyxHQUFHLFdBQVcsQ0FBQztLQUNsQztDQUNKLENBQUMsQ0FBQzs7O0FDZFAsT0FBTyxDQUFDLE1BQU0sQ0FBQyw4Q0FBOEMsRUFBRSxFQUFFLENBQUMsQ0FDN0QsVUFBVSxDQUFDLG9CQUFvQixFQUFFLFNBQVMsa0JBQWtCLENBQUMsVUFBVSxFQUFFLFFBQVEsRUFBRTtBQUNoRixRQUFJLElBQUksR0FBRyxJQUFJO1FBQ1gsZUFBZSxHQUFHLEdBQUc7UUFDckIsT0FBTyxDQUFDOztBQUVaLFFBQUksSUFBSSxDQUFDLFFBQVEsS0FBSyxTQUFTLEVBQUU7QUFDN0IsWUFBSSxDQUFDLFFBQVEsR0FBRyxlQUFlLENBQUM7S0FDbkM7O0FBRUQsUUFBSSxJQUFJLENBQUMsV0FBVyxFQUFFO0FBQ2xCLGtCQUFVLENBQUMsR0FBRyxDQUFDLG1CQUFtQixFQUFFLFlBQVksQ0FBQyxDQUFDO0FBQ2xELGtCQUFVLENBQUMsR0FBRyxDQUFDLHFCQUFxQixFQUFFLFdBQVcsQ0FBQyxDQUFDO0FBQ25ELGtCQUFVLENBQUMsR0FBRyxDQUFDLG1CQUFtQixFQUFFLFdBQVcsQ0FBQyxDQUFDO0tBQ3BEOztBQUVELGFBQVMsWUFBWSxDQUFDLEtBQUssRUFBRTtBQUN6QixZQUFJLEtBQUssQ0FBQyxnQkFBZ0IsRUFBRTtBQUN4QixtQkFBTztTQUNWOztBQUVELGVBQU8sR0FBRyxRQUFRLENBQUMsU0FBUyxpQkFBaUIsR0FBRztBQUM1QyxnQkFBSSxDQUFDLE9BQU8sR0FBRyxJQUFJLENBQUM7U0FDdkIsRUFBRSxJQUFJLENBQUMsUUFBUSxDQUFDLENBQUM7S0FDckI7O0FBRUQsYUFBUyxXQUFXLENBQUMsS0FBSyxFQUFFO0FBQ3hCLFlBQUksS0FBSyxDQUFDLGdCQUFnQixFQUFFO0FBQ3hCLG1CQUFPO1NBQ1Y7O0FBRUQsZ0JBQVEsQ0FBQyxNQUFNLENBQUMsT0FBTyxDQUFDLENBQUM7QUFDekIsWUFBSSxDQUFDLE9BQU8sR0FBRyxLQUFLLENBQUM7S0FDeEI7Q0FDSixDQUFDLENBQUM7OztBQ2xDUCxPQUFPLENBQUMsTUFBTSxDQUFDLDZDQUE2QyxFQUFFLENBQzFELDhDQUE4QyxDQUNqRCxDQUFDLENBQ0csU0FBUyxDQUFDLGdCQUFnQixFQUFFLFNBQVMsY0FBYyxHQUFHO0FBQ25ELFdBQU87QUFDSCx3QkFBZ0IsRUFBRSxJQUFJO0FBQ3RCLGtCQUFVLEVBQUUsMENBQTBDO0FBQ3RELGdCQUFRLEVBQUUsR0FBRztBQUNiLGFBQUssRUFBRTtBQUNILG9CQUFRLEVBQUUsSUFBSTtBQUNkLG1CQUFPLEVBQUUsa0JBQWtCO0FBQzNCLHVCQUFXLEVBQUUsSUFBSTtTQUNwQjtBQUNELG1CQUFXLEVBQUUsNkRBQTZEO0FBQzFFLGtCQUFVLEVBQUUsSUFBSTtBQUNoQixlQUFPLEVBQUUsU0FBUyxxQkFBcUIsQ0FBQyxPQUFPLEVBQUU7QUFDN0MsbUJBQU8sQ0FBQyxRQUFRLENBQUMsMEJBQTBCLENBQUMsQ0FBQztTQUNoRDtLQUNKLENBQUM7Q0FDTCxDQUFDLENBQUM7OztBQ25CUCxPQUFPLENBQUMsTUFBTSxDQUFDLG1DQUFtQyxFQUFFLENBQ2hELDZDQUE2QyxDQUNoRCxDQUFDLENBQUM7OztBQ0ZILE9BQU8sQ0FBQyxNQUFNLENBQUMsa0RBQWtELEVBQUUsRUFBRSxDQUFDLENBQ2pFLFNBQVMsQ0FBQyxxQkFBcUIsRUFBRSxTQUFTLDRCQUE0QixDQUFDLFVBQVUsRUFBRTtBQUNoRixXQUFPO0FBQ0gsZ0JBQVEsRUFBRSxHQUFHO0FBQ2IsbUJBQVcsRUFBRSx1RUFBdUU7O0FBRXBGLFlBQUksRUFBRSxjQUFTLEtBQUssRUFBRTtBQUNsQixzQkFBVSxDQUFDLEdBQUcsQ0FBQyxvQkFBb0IsRUFBRSxVQUFTLEtBQUssRUFBRSxHQUFHLEVBQUU7QUFDdEQscUJBQUssQ0FBQyxpQkFBaUIsR0FBRyxHQUFHLENBQUM7YUFDakMsQ0FBQyxDQUFDO1NBQ047S0FDSixDQUFDO0NBQ0wsQ0FBQyxDQUFDOzs7QUNaUCxPQUFPLENBQUMsTUFBTSxDQUFDLHdDQUF3QyxFQUFFLENBQ3JELGtEQUFrRCxDQUNyRCxDQUFDLENBQUM7Ozs7Ozs7O0FDR0gsT0FBTyxDQUFDLE1BQU0sQ0FBQywrQ0FBK0MsRUFBRSxFQUUvRCxDQUFDLENBQ0MsT0FBTyxDQUFDLGFBQWEsRUFBRSxDQUFDLFNBQVMsRUFBRSxhQUFhLEVBQUUsVUFBVSxFQUFFLFdBQVcsRUFBRSxVQUFVLEVBQUUsWUFBWSxFQUFFLGNBQWMsRUFDbEgsVUFBVSxPQUFPLEVBQUUsV0FBVyxFQUFFLFFBQVEsRUFBRSxTQUFTLEVBQUUsUUFBUSxFQUFFLFVBQVUsRUFBRSxZQUFZLEVBQUU7O0FBRXZGLE1BQUksa0JBQWtCLEdBQUcsaUJBQWlCLENBQUM7OztBQUczQyxNQUFJLGFBQWEsRUFBRSxhQUFhLENBQUM7QUFDakMsTUFBSSxhQUFhLEdBQUcsWUFBWSxDQUFDLFNBQVMsRUFBRSxDQUFDO0FBQzdDLE1BQUksV0FBVyxHQUFHLEVBQUUsQ0FBQzs7QUFFckIsV0FBUyxhQUFhLEdBQUc7QUFDdkIsUUFBSSxnQkFBZ0IsR0FBRyxDQUFDLENBQUMsQ0FBQztBQUMxQixRQUFJLE1BQU0sR0FBRyxhQUFhLENBQUMsSUFBSSxFQUFFLENBQUM7QUFDbEMsU0FBSyxJQUFJLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxHQUFHLE1BQU0sQ0FBQyxNQUFNLEVBQUUsQ0FBQyxFQUFFLEVBQUU7QUFDdEMsVUFBSSxhQUFhLENBQUMsR0FBRyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxRQUFRLEVBQUU7QUFDL0Msd0JBQWdCLEdBQUcsQ0FBQyxDQUFDO09BQ3RCO0tBQ0Y7QUFDRCxXQUFPLGdCQUFnQixDQUFDO0dBQ3pCOztBQUVELFlBQVUsQ0FBQyxNQUFNLENBQUMsYUFBYSxFQUFFLFVBQVMsZ0JBQWdCLEVBQUM7QUFDekQsUUFBSSxhQUFhLEVBQUU7QUFDakIsbUJBQWEsQ0FBQyxLQUFLLEdBQUcsZ0JBQWdCLENBQUM7S0FDeEM7R0FDRixDQUFDLENBQUM7O0FBRUgsV0FBUyxpQkFBaUIsQ0FBQyxhQUFhLEVBQUU7QUFDeEMsUUFBSSxJQUFJLEdBQUcsU0FBUyxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDeEMsUUFBSSxXQUFXLEdBQUcsYUFBYSxDQUFDLEdBQUcsQ0FBQyxhQUFhLENBQUMsQ0FBQyxLQUFLLENBQUM7OztBQUd6RCxpQkFBYSxDQUFDLE1BQU0sQ0FBQyxhQUFhLENBQUMsQ0FBQzs7O0FBR3BDLHNCQUFrQixDQUFDLFdBQVcsQ0FBQyxVQUFVLEVBQUUsV0FBVyxDQUFDLFVBQVUsRUFBRSxHQUFHLEVBQUUsWUFBVztBQUNqRixpQkFBVyxDQUFDLFVBQVUsQ0FBQyxRQUFRLEVBQUUsQ0FBQztBQUNsQyxVQUFJLENBQUMsV0FBVyxDQUFDLGtCQUFrQixFQUFFLGFBQWEsQ0FBQyxNQUFNLEVBQUUsR0FBRyxDQUFDLENBQUMsQ0FBQztBQUNqRSx5QkFBbUIsRUFBRSxDQUFDO0tBQ3ZCLENBQUMsQ0FBQztHQUNKOztBQUVELFdBQVMsbUJBQW1CLEdBQUc7O0FBRTdCLFFBQUksYUFBYSxJQUFJLGFBQWEsRUFBRSxJQUFJLENBQUMsQ0FBQyxFQUFFO0FBQzFDLFVBQUksZ0JBQWdCLEdBQUcsYUFBYSxDQUFDO0FBQ3JDLHdCQUFrQixDQUFDLGFBQWEsRUFBRSxhQUFhLEVBQUUsR0FBRyxFQUFFLFlBQVk7QUFDaEUsd0JBQWdCLENBQUMsUUFBUSxFQUFFLENBQUM7QUFDNUIsd0JBQWdCLEdBQUcsSUFBSSxDQUFDO09BQ3pCLENBQUMsQ0FBQztBQUNILG1CQUFhLEdBQUcsU0FBUyxDQUFDO0FBQzFCLG1CQUFhLEdBQUcsU0FBUyxDQUFDO0tBQzNCO0dBQ0Y7O0FBRUQsV0FBUyxrQkFBa0IsQ0FBQyxLQUFLLEVBQUUsS0FBSyxFQUFFLFdBQVcsRUFBRSxJQUFJLEVBQUU7O0FBRTNELFNBQUssQ0FBQyxPQUFPLEdBQUcsS0FBSyxDQUFDOztBQUV0QixRQUFJLHNCQUFzQixHQUFHLFdBQVcsQ0FBQyxzQkFBc0IsQ0FBQztBQUNoRSxRQUFJLHNCQUFzQixFQUFFOztBQUUxQixVQUFJLE9BQU8sR0FBRyxRQUFRLENBQUMsY0FBYyxFQUFFLFdBQVcsQ0FBQyxDQUFDOztBQUVwRCxXQUFLLENBQUMsSUFBSSxDQUFDLHNCQUFzQixFQUFFLFlBQVk7QUFDN0MsZ0JBQVEsQ0FBQyxNQUFNLENBQUMsT0FBTyxDQUFDLENBQUM7QUFDekIsc0JBQWMsRUFBRSxDQUFDO0FBQ2pCLGFBQUssQ0FBQyxNQUFNLEVBQUUsQ0FBQztPQUNoQixDQUFDLENBQUM7S0FDSixNQUFNOztBQUVMLGNBQVEsQ0FBQyxjQUFjLEVBQUUsQ0FBQyxDQUFDLENBQUM7S0FDN0I7O0FBRUQsYUFBUyxjQUFjLEdBQUc7QUFDeEIsVUFBSSxjQUFjLENBQUMsSUFBSSxFQUFFO0FBQ3ZCLGVBQU87T0FDUjtBQUNELG9CQUFjLENBQUMsSUFBSSxHQUFHLElBQUksQ0FBQzs7QUFFM0IsV0FBSyxDQUFDLE1BQU0sRUFBRSxDQUFDO0FBQ2YsVUFBSSxJQUFJLEVBQUU7QUFDUixZQUFJLEVBQUUsQ0FBQztPQUNSO0tBQ0Y7R0FDRjs7QUFFRCxXQUFTLENBQUMsSUFBSSxDQUFDLFNBQVMsRUFBRSxVQUFVLEdBQUcsRUFBRTtBQUN2QyxRQUFJLEtBQUssQ0FBQzs7QUFFVixRQUFJLEdBQUcsQ0FBQyxLQUFLLEtBQUssRUFBRSxFQUFFO0FBQ3BCLFdBQUssR0FBRyxhQUFhLENBQUMsR0FBRyxFQUFFLENBQUM7QUFDNUIsVUFBSSxLQUFLLElBQUksS0FBSyxDQUFDLEtBQUssQ0FBQyxRQUFRLEVBQUU7QUFDakMsa0JBQVUsQ0FBQyxNQUFNLENBQUMsWUFBWTtBQUM1QixxQkFBVyxDQUFDLE9BQU8sQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLENBQUM7U0FDaEMsQ0FBQyxDQUFDO09BQ0o7S0FDRjtHQUNGLENBQUMsQ0FBQzs7QUFFSCxhQUFXLENBQUMsSUFBSSxHQUFHLFVBQVUsYUFBYSxFQUFFLEtBQUssRUFBRTs7QUFFakQsaUJBQWEsQ0FBQyxHQUFHLENBQUMsYUFBYSxFQUFFO0FBQy9CLGNBQVEsRUFBRSxLQUFLLENBQUMsUUFBUTtBQUN4QixnQkFBVSxFQUFFLEtBQUssQ0FBQyxLQUFLO0FBQ3ZCLGNBQVEsRUFBRSxLQUFLLENBQUMsUUFBUTtBQUN4QixjQUFRLEVBQUUsS0FBSyxDQUFDLFFBQVE7S0FDekIsQ0FBQyxDQUFDOztBQUVILFFBQUksSUFBSSxHQUFHLFNBQVMsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQztRQUNuQyxpQkFBaUIsR0FBRyxhQUFhLEVBQUUsQ0FBQzs7QUFFeEMsUUFBSSxpQkFBaUIsSUFBSSxDQUFDLElBQUksQ0FBQyxhQUFhLEVBQUU7QUFDNUMsbUJBQWEsR0FBRyxVQUFVLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDO0FBQ3RDLG1CQUFhLENBQUMsS0FBSyxHQUFHLGlCQUFpQixDQUFDO0FBQ3hDLG1CQUFhLEdBQUcsUUFBUSxDQUFDLDRCQUE0QixDQUFDLENBQUMsYUFBYSxDQUFDLENBQUM7QUFDdEUsVUFBSSxDQUFDLE1BQU0sQ0FBQyxhQUFhLENBQUMsQ0FBQztLQUM1Qjs7O0FBR0QsUUFBSSxZQUFZLEdBQUcsT0FBTyxDQUFDLE9BQU8sQ0FBQyxzRUFBc0UsQ0FBQyxDQUFDO0FBQzNHLGdCQUFZLENBQUMsSUFBSSxDQUFDLGNBQWMsRUFBRSxLQUFLLENBQUMsV0FBVyxDQUFDLENBQUM7QUFDckQsZ0JBQVksQ0FBQyxJQUFJLENBQUMsT0FBTyxFQUFFLGFBQWEsQ0FBQyxNQUFNLEVBQUUsR0FBRyxDQUFDLENBQUMsQ0FBQztBQUN2RCxnQkFBWSxDQUFDLElBQUksQ0FBQyxTQUFTLEVBQUUsU0FBUyxDQUFDLENBQUM7QUFDeEMsZ0JBQVksQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyxDQUFDOztBQUVqQyxRQUFJLFVBQVUsR0FBRyxRQUFRLENBQUMsWUFBWSxDQUFDLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxDQUFDO0FBQ3JELGlCQUFhLENBQUMsR0FBRyxFQUFFLENBQUMsS0FBSyxDQUFDLFVBQVUsR0FBRyxVQUFVLENBQUM7QUFDbEQsUUFBSSxDQUFDLE1BQU0sQ0FBQyxVQUFVLENBQUMsQ0FBQztBQUN4QixRQUFJLENBQUMsUUFBUSxDQUFDLGtCQUFrQixDQUFDLENBQUM7R0FDbkMsQ0FBQzs7QUFFRixhQUFXLENBQUMsS0FBSyxHQUFHLFVBQVUsYUFBYSxFQUFFLE1BQU0sRUFBRTtBQUNuRCxRQUFJLFdBQVcsR0FBRyxhQUFhLENBQUMsR0FBRyxDQUFDLGFBQWEsQ0FBQyxDQUFDLEtBQUssQ0FBQztBQUN6RCxRQUFJLFdBQVcsRUFBRTtBQUNmLGlCQUFXLENBQUMsUUFBUSxDQUFDLE9BQU8sQ0FBQyxNQUFNLENBQUMsQ0FBQztBQUNyQyx1QkFBaUIsQ0FBQyxhQUFhLENBQUMsQ0FBQztLQUNsQztHQUNGLENBQUM7O0FBRUYsYUFBVyxDQUFDLE9BQU8sR0FBRyxVQUFVLGFBQWEsRUFBRSxNQUFNLEVBQUU7QUFDckQsUUFBSSxXQUFXLEdBQUcsYUFBYSxDQUFDLEdBQUcsQ0FBQyxhQUFhLENBQUMsQ0FBQyxLQUFLLENBQUM7QUFDekQsUUFBSSxXQUFXLEVBQUU7QUFDZixpQkFBVyxDQUFDLFFBQVEsQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDLENBQUM7QUFDcEMsdUJBQWlCLENBQUMsYUFBYSxDQUFDLENBQUM7S0FDbEM7R0FDRixDQUFDOztBQUVGLGFBQVcsQ0FBQyxVQUFVLEdBQUcsVUFBVSxNQUFNLEVBQUU7QUFDekMsUUFBSSxRQUFRLEdBQUcsSUFBSSxDQUFDLE1BQU0sRUFBRSxDQUFDO0FBQzdCLFdBQU8sUUFBUSxFQUFFO0FBQ2YsVUFBSSxDQUFDLE9BQU8sQ0FBQyxRQUFRLENBQUMsR0FBRyxFQUFFLE1BQU0sQ0FBQyxDQUFDO0FBQ25DLGNBQVEsR0FBRyxJQUFJLENBQUMsTUFBTSxFQUFFLENBQUM7S0FDMUI7R0FDRixDQUFDOztBQUVGLGFBQVcsQ0FBQyxNQUFNLEdBQUcsWUFBWTtBQUMvQixXQUFPLGFBQWEsQ0FBQyxHQUFHLEVBQUUsQ0FBQztHQUM1QixDQUFDOztBQUVGLFNBQU8sV0FBVyxDQUFDO0NBQ3BCLENBQUMsQ0FBQyxDQUFDOzs7Ozs7O0FDcktSLE9BQU8sQ0FBQyxNQUFNLENBQUMsNEJBQTRCLEVBQUUsQ0FDekMsK0NBQStDLENBQ2xELENBQUMsQ0FBQzs7Ozs7Ozs7OztBQ0NILE9BQU8sQ0FBQyxNQUFNLENBQUMsb0NBQW9DLEVBQUUsRUFBRSxDQUFDLENBQ25ELFNBQVMsQ0FBQyxRQUFRLEVBQUUsU0FBUyxlQUFlLEdBQUc7QUFDNUMsV0FBTztBQUNILGdCQUFRLEVBQUUsR0FBRztBQUNiLGFBQUssRUFBRTtBQUNILGlCQUFLLEVBQUUsR0FBRztTQUNiO0FBQ0QsZUFBTyxFQUFFLHNCQUFzQjtLQUNsQyxDQUFDOztBQUVGLGFBQVMsc0JBQXNCLENBQUMsUUFBUSxFQUFFO0FBQ3RDLGdCQUFRLENBQUMsUUFBUSxDQUFDLFFBQVEsQ0FBQyxDQUFDO0FBQzVCLGdCQUFRLENBQUMsSUFBSSxDQUFDLGFBQWEsRUFBRSxJQUFJLENBQUMsQ0FBQzs7QUFFbkMsZUFBTyxTQUFTLG1CQUFtQixDQUFDLE1BQU0sRUFBRSxPQUFPLEVBQUUsS0FBSyxFQUFFO0FBQ3hELGlCQUFLLENBQUMsUUFBUSxDQUFDLE9BQU8sRUFBRSxVQUFDLFFBQVEsRUFBSztBQUNsQyx1QkFBTyxDQUFDLElBQUksQ0FBQyxPQUFPLEVBQUUsaUJBQWlCLEdBQUcsUUFBUSxDQUFDLENBQUM7YUFDdkQsQ0FBQyxDQUFDO1NBQ04sQ0FBQztLQUNMO0NBQ0osQ0FBQyxDQUFDOzs7QUMzQlAsT0FBTyxDQUFDLE1BQU0sQ0FBQywwQkFBMEIsRUFBRSxDQUN2QyxvQ0FBb0MsQ0FDdkMsQ0FBQyxDQUFDOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ3FCSCxPQUFPLENBQUMsTUFBTSxDQUFDLG9DQUFvQyxFQUFFLEVBQUUsQ0FBQyxDQUNuRCxTQUFTLENBQUMsUUFBUSxFQUFFLFNBQVMsZUFBZSxHQUFHOztBQUU1QyxhQUFTLFdBQVcsQ0FBQyxRQUFRLEVBQUU7QUFDM0IsZUFBTyxDQUFDLENBQUMsUUFBUSxDQUFDLFFBQVEsQ0FBQyxDQUFDO0tBQy9COztBQUVELFdBQU87QUFDSCxnQkFBUSxFQUFFLEdBQUc7QUFDYixtQkFBVyxFQUFFLDJDQUEyQztBQUN4RCxlQUFPLEVBQUUsU0FBUztBQUNsQixhQUFLLEVBQUU7QUFDSCwyQkFBZSxFQUFFLEdBQUc7QUFDcEIscUJBQVMsRUFBRSxHQUFHO0FBQ2QsMkJBQWUsRUFBRSxHQUFHO0FBQ3BCLHdCQUFZLEVBQUUsR0FBRztBQUNqQix1QkFBVyxFQUFFLEdBQUc7QUFDaEIsNEJBQWdCLEVBQUUsR0FBRztBQUNyQiwwQkFBYyxFQUFFLEdBQUc7QUFDbkIseUJBQWEsRUFBRSxHQUFHO0FBQ2xCLG9CQUFRLEVBQUUsR0FBRztTQUNoQjtBQUNELHdCQUFnQixFQUFFLElBQUk7QUFDdEIsb0JBQVksRUFBRSxZQUFZO0FBQzFCLGVBQU8sRUFBRSxTQUFTLHNCQUFzQixDQUFDLEtBQUssRUFBRSxNQUFNLEVBQUU7QUFDcEQsZ0JBQUksWUFBWSxHQUFHLEtBQUssQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLENBQUM7O0FBRXZDLGdCQUFJLE1BQU0sQ0FBQyxZQUFZLEVBQUU7QUFDckIsNEJBQVksQ0FBQyxJQUFJLENBQUMsZ0JBQWdCLEVBQUUsTUFBTSxDQUFDLFlBQVksQ0FBQyxDQUFDO2FBQzVEOztBQUVELGdCQUFJLE1BQU0sQ0FBQyxXQUFXLEVBQUU7QUFDcEIsNEJBQVksQ0FBQyxJQUFJLENBQUMsZUFBZSxFQUFFLE1BQU0sQ0FBQyxXQUFXLENBQUMsQ0FBQzthQUMxRDs7QUFFRCxtQkFBTyxTQUFTLHVCQUF1QixDQUFDLEtBQUssRUFBRSxPQUFPLEVBQUUsS0FBSyxFQUFFLFdBQVcsRUFBRTtBQUN4RSxxQkFBSyxDQUFDLFVBQVUsQ0FBQyxJQUFJLENBQUMsV0FBVyxDQUFDLENBQUM7YUFDdEMsQ0FBQztTQUNMO0FBQ0Qsa0JBQVUsRUFBRSxTQUFTLG1CQUFtQixDQUFDLE1BQU0sRUFBRSxRQUFRLEVBQUUsTUFBTSxFQUFFO0FBQy9ELGdCQUFJLElBQUksR0FBRyxJQUFJLENBQUM7OztBQUdoQixnQkFBSSxDQUFDLFdBQVcsR0FBRyxPQUFPLENBQUMsU0FBUyxDQUFDLE1BQU0sQ0FBQyxXQUFXLENBQUMsSUFBSSxNQUFNLENBQUMsV0FBVyxLQUFLLE9BQU8sQ0FBQztBQUMzRixnQkFBSSxDQUFDLE9BQU8sR0FBRyxPQUFPLENBQUMsU0FBUyxDQUFDLE1BQU0sQ0FBQyxPQUFPLENBQUMsSUFBSSxNQUFNLENBQUMsT0FBTyxLQUFLLE9BQU8sQ0FBQzs7O0FBRy9FLGdCQUFJLENBQUMsU0FBUyxHQUFHLE1BQU0sQ0FBQyxjQUFjLENBQUM7OztBQUd2QyxnQkFBSSxDQUFDLFFBQVEsR0FBRyxXQUFXLENBQUMsU0FBUyxDQUFDLENBQUM7QUFDdkMsZ0JBQUksQ0FBQyxpQkFBaUIsR0FBRyxXQUFXLENBQUMseUJBQXlCLENBQUMsQ0FBQzs7QUFFaEUsZ0JBQUksQ0FBQyxJQUFJLEdBQUcsSUFBSSxDQUFDO0FBQ2pCLGdCQUFJLENBQUMsV0FBVyxHQUFHLFdBQVcsQ0FBQzs7QUFFL0IscUJBQVMsSUFBSSxDQUFDLFdBQVcsRUFBRTtBQUN2QixvQkFBSSxDQUFDLFdBQVcsR0FBRyxXQUFXLENBQUM7QUFDL0Isb0JBQUksQ0FBQyxLQUFLLEdBQUcsSUFBSSxDQUFDLFdBQVcsQ0FBQyxXQUFXLENBQUM7O0FBRTFDLHNCQUFNLENBQUMsTUFBTSxDQUFDLG9DQUFvQyxFQUFFLFNBQVMsa0JBQWtCLENBQUMsUUFBUSxFQUFFO0FBQ3RGLHdCQUFJLENBQUMsS0FBSyxHQUFHLFFBQVEsQ0FBQzs7QUFFdEIsd0JBQUksQ0FBQyxTQUFTLEdBQUcsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxRQUFRLENBQUMsR0FBRyxHQUFHLEdBQUcsUUFBUSxHQUFHLEdBQUcsS0FBSyxJQUFJLENBQUMsV0FBVyxHQUFHLFFBQVEsQ0FBQztBQUM3Rix3QkFBSSxDQUFDLFNBQVMsR0FBRyxDQUFDLENBQUMsSUFBSSxDQUFDLFNBQVMsR0FBRyxJQUFJLENBQUMsYUFBYSxHQUFFLElBQUksQ0FBQyxjQUFjLENBQUM7aUJBQy9FLENBQUMsQ0FBQzthQUNOOztBQUVELHFCQUFTLFdBQVcsR0FBRztBQUNuQixvQkFBSSxDQUFDLFdBQVcsQ0FBQyxhQUFhLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxDQUFDO2FBQzlDO1NBRUo7S0FDSixDQUFDO0NBQ0wsQ0FBQyxDQUFDOzs7QUNqR1AsT0FBTyxDQUFDLE1BQU0sQ0FBQywwQkFBMEIsRUFBRSxDQUN2QyxvQ0FBb0MsQ0FDdkMsQ0FBQyxDQUFDOzs7QUNGSCxPQUFPLENBQUMsTUFBTSxDQUFDLG1EQUFtRCxFQUFFLENBQ2hFLDJDQUEyQyxDQUM5QyxDQUFDLENBQ0csT0FBTyxDQUFDLHNCQUFzQixFQUFFLFNBQVMsb0JBQW9CLENBQUMsSUFBSSxFQUFFLGFBQWEsRUFBRTtBQUNoRixRQUFJLE1BQU0sR0FBRyxFQUFFO1FBQ1gsT0FBTyxHQUFHO0FBQ04sY0FBTSxFQUFFLE1BQU07QUFDZCxXQUFHLEVBQUUsR0FBRztBQUNSLGNBQU0sRUFBRSxNQUFNO0tBQ2pCLENBQUM7O0FBRU4sYUFBUyxNQUFNLENBQUMsT0FBTyxFQUFFLFdBQVcsRUFBRTtBQUNsQyxZQUFJLE9BQU8sSUFBSSxNQUFNLEVBQUU7QUFDbkIsbUJBQU8sT0FBTyxDQUFDLEdBQUcsQ0FBQyxPQUFPLENBQUMsQ0FBQztTQUMvQjs7QUFFRCxZQUFJLENBQUMsT0FBTyxFQUFFO0FBQ1YsbUJBQU8sR0FBRyxDQUFDLENBQUMsUUFBUSxDQUFDLDJCQUEyQixDQUFDLENBQUM7U0FDckQ7O0FBRUQsY0FBTSxDQUFDLE9BQU8sQ0FBQyxHQUFHLElBQUksYUFBYSxDQUFDLE9BQU8sRUFBRSxXQUFXLENBQUMsQ0FBQzs7QUFFMUQsZUFBTyxNQUFNLENBQUMsT0FBTyxDQUFDLENBQUM7S0FDMUI7O0FBRUQsYUFBUyxHQUFHLENBQUMsT0FBTyxFQUFFO0FBQ2xCLGVBQU8sTUFBTSxDQUFDLE9BQU8sQ0FBQyxDQUFDO0tBQzFCOztBQUVELGFBQVMsTUFBTSxDQUFDLE9BQU8sRUFBRTtBQUNyQixlQUFPLE1BQU0sQ0FBQyxPQUFPLENBQUMsQ0FBQztLQUMxQjs7QUFFRCxXQUFPLE9BQU8sQ0FBQztDQUNsQixDQUFDLENBQUM7OztBQ2xDUCxPQUFPLENBQUMsTUFBTSxDQUFDLDJDQUEyQyxFQUFFLENBQ3hELFdBQVcsQ0FDZCxDQUFDLENBQ0csT0FBTyxDQUFDLGVBQWUsRUFBRSxTQUFTLGFBQWEsQ0FBQyxJQUFJLEVBQUUsTUFBTSxFQUFFLFlBQVksRUFBRTtBQUN6RSxRQUFJLGtCQUFrQixHQUFHO0FBQ3JCLGVBQU8sRUFBRSxFQUFFO0FBQ1gsaUJBQVMsRUFBRTtBQUNQLGdCQUFJLEVBQUUsTUFBTTtBQUNaLGlCQUFLLEVBQUUsT0FBTztBQUNkLGtCQUFNLEVBQUUsU0FBUztBQUNqQixtQkFBTyxFQUFFLFlBQVk7U0FDeEI7QUFDRCxnQkFBUSxFQUFFLElBQUk7QUFDZCxxQkFBYSxFQUFFO0FBQ1gsZUFBRyxFQUFFLEtBQUs7QUFDVixnQkFBSSxFQUFFLE1BQU07U0FDZjtLQUNKLENBQUM7O0FBRUYsYUFBUyxXQUFXLENBQUMsT0FBTyxFQUFFLFdBQVcsRUFBRTtBQUN2QyxZQUFJLENBQUMsV0FBVyxHQUFHLEtBQUssQ0FBQztBQUN6QixZQUFJLENBQUMsT0FBTyxHQUFHLEVBQUUsQ0FBQztBQUNsQixZQUFJLENBQUMsRUFBRSxHQUFHLE9BQU8sQ0FBQztBQUNsQixZQUFJLENBQUMsVUFBVSxHQUFHO0FBQ2QsZ0JBQUksRUFBRSxJQUFJO0FBQ1YsaUJBQUssRUFBRSxJQUFJO0FBQ1gsaUJBQUssRUFBRSxJQUFJO1NBQ2QsQ0FBQztBQUNGLFlBQUksQ0FBQyxjQUFjLEdBQUcsS0FBSyxDQUFDO0FBQzVCLFlBQUksQ0FBQyxnQkFBZ0IsR0FBRyxPQUFPLENBQUMsSUFBSSxDQUFDO0FBQ3JDLFlBQUksQ0FBQyxJQUFJLEdBQUcsRUFBRSxDQUFDO0FBQ2YsWUFBSSxDQUFDLFlBQVksR0FBRyxFQUFFLENBQUM7QUFDdkIsWUFBSSxDQUFDLE1BQU0sR0FBRyxFQUFFLENBQUM7QUFDakIsWUFBSSxDQUFDLE9BQU8sR0FBRyxFQUFFLENBQUM7O0FBRWxCLFlBQUksQ0FBQyxXQUFXLEdBQUcsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxXQUFXLENBQUMsR0FBRyxXQUFXLEdBQUcsRUFBRSxDQUFDO0FBQzlELFlBQUksQ0FBQyxXQUFXLEdBQUcsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsV0FBVyxFQUFFLGtCQUFrQixDQUFDLENBQUM7S0FDdkU7O0FBRUQsZUFBVyxDQUFDLFNBQVMsR0FBRztBQUNwQiwwQkFBa0IsRUFBRSxrQkFBa0I7QUFDdEMscUJBQWEsRUFBRSxhQUFhO0FBQzVCLHVCQUFlLEVBQUUsZUFBZTtBQUNoQyxZQUFJLEVBQUUsSUFBSTtBQUNWLHFCQUFhLEVBQUUsYUFBYTtBQUM1Qix1QkFBZSxFQUFFLGVBQWU7QUFDaEMscUJBQWEsRUFBRSxhQUFhO0FBQzVCLDJCQUFtQixFQUFFLG1CQUFtQjtBQUN4QyxlQUFPLEVBQUUsT0FBTztBQUNoQix3QkFBZ0IsRUFBRSxnQkFBZ0I7QUFDbEMsa0JBQVUsRUFBRSxVQUFVO0FBQ3RCLGtCQUFVLEVBQUUsVUFBVTtBQUN0QixtQkFBVyxFQUFFLFdBQVc7QUFDeEIsd0JBQWdCLEVBQUUsZ0JBQWdCO0tBQ3JDLENBQUM7O0FBRUYsYUFBUyxrQkFBa0IsR0FBRztBQUMxQixZQUFJLE1BQU0sR0FBRyxFQUFFO1lBQ1gsU0FBUyxHQUFHLElBQUksQ0FBQyxXQUFXLENBQUMsU0FBUztZQUN0QyxhQUFhLEdBQUcsQ0FBQztBQUNULG9CQUFRLEVBQUUsU0FBUyxDQUFDLElBQUk7QUFDeEIsaUJBQUssRUFBRSxJQUFJLENBQUMsVUFBVSxDQUFDLElBQUk7U0FDOUIsRUFBRTtBQUNDLG9CQUFRLEVBQUUsU0FBUyxDQUFDLEtBQUs7QUFDekIsaUJBQUssRUFBRSxJQUFJLENBQUMsVUFBVSxDQUFDLEtBQUs7U0FDL0IsRUFBRTtBQUNDLG9CQUFRLEVBQUUsU0FBUyxDQUFDLE1BQU07QUFDMUIsaUJBQUssRUFBRSxJQUFJLENBQUMsTUFBTTtTQUNyQixFQUFFO0FBQ0Msb0JBQVEsRUFBRSxTQUFTLENBQUMsT0FBTztBQUMzQixpQkFBSyxFQUFFLElBQUksQ0FBQyxPQUFPO1NBQ3RCLENBQUMsQ0FBQzs7QUFFWCxTQUFDLENBQUMsSUFBSSxDQUFDLGFBQWEsRUFBRSxTQUFTLGlCQUFpQixDQUFDLEtBQUssRUFBRTtBQUNwRCxnQkFBSSxLQUFLLENBQUMsUUFBUSxLQUFLLFNBQVMsRUFBRTtBQUM5QixzQkFBTSxDQUFDLEtBQUssQ0FBQyxRQUFRLENBQUMsR0FBRyxLQUFLLENBQUMsS0FBSyxDQUFDO2FBQ3hDO1NBQ0osQ0FBQyxDQUFDOztBQUVILFNBQUMsQ0FBQyxNQUFNLENBQUMsTUFBTSxFQUFFLElBQUksQ0FBQyxPQUFPLENBQUMsQ0FBQzs7QUFFL0IsZUFBTyxNQUFNLENBQUM7S0FDakI7O0FBRUQsYUFBUyxhQUFhLEdBQUc7QUFDckIsWUFBSSxLQUFLLEdBQUcsSUFBSSxDQUFDOztBQUVqQixZQUFJLENBQUMsY0FBYyxHQUFHLElBQUksQ0FBQztBQUMzQixlQUFPLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxJQUFJLENBQUMsa0JBQWtCLEVBQUUsQ0FBQyxDQUNsRCxJQUFJLENBQUMsU0FBUyxvQkFBb0IsQ0FBQyxRQUFRLEVBQUU7QUFDMUMsZ0JBQUksS0FBSyxDQUFDLGdCQUFnQixDQUFDLFFBQVEsQ0FBQyxFQUFFO0FBQ2xDLHFCQUFLLENBQUMsT0FBTyxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsQ0FBQztBQUM3QixxQkFBSyxDQUFDLG1CQUFtQixDQUFDLFFBQVEsQ0FBQyxVQUFVLENBQUMsQ0FBQzthQUNsRDs7QUFFRCxtQkFBTyxLQUFLLENBQUM7U0FDaEIsQ0FBQyxTQUNJLENBQUMsU0FBUyxxQkFBcUIsR0FBRztBQUNwQyxnQkFBSSxDQUFDLEtBQUssQ0FBQyxxREFBcUQsQ0FBQyxDQUFDO1NBQ3JFLENBQUMsV0FDTSxDQUFDLFNBQVMsdUJBQXVCLEdBQUc7QUFDeEMsaUJBQUssQ0FBQyxjQUFjLEdBQUcsS0FBSyxDQUFDO1NBQ2hDLENBQUMsQ0FBQztLQUNWOztBQUVELGFBQVMsZUFBZSxHQUFHO0FBQ3ZCLFlBQUksS0FBSyxHQUFHLElBQUksQ0FBQzs7QUFFakIsZUFBTyxDQUFDLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxJQUFJLEVBQUUsU0FBUyxxQkFBcUIsQ0FBQyxHQUFHLEVBQUU7QUFDM0QsbUJBQU8sS0FBSyxDQUFDLGFBQWEsQ0FBQyxHQUFHLENBQUMsQ0FBQztTQUNuQyxDQUFDLENBQUM7S0FDTjs7QUFFRCxhQUFTLElBQUksQ0FBQyxNQUFNLEVBQUU7QUFDbEIsWUFBSSxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsTUFBTSxDQUFDLEVBQUU7QUFDckIsa0JBQU0sR0FBRyxFQUFFLENBQUM7U0FDZjs7QUFFRCxZQUFJLENBQUMsQ0FBQyxVQUFVLENBQUMsTUFBTSxDQUFDLGdCQUFnQixDQUFDLEVBQUU7QUFDdkMsZ0JBQUksQ0FBQyxnQkFBZ0IsR0FBRyxNQUFNLENBQUMsZ0JBQWdCLENBQUM7U0FDbkQ7O0FBRUQsZUFBTyxJQUFJLENBQ04sZUFBZSxDQUFDLE1BQU0sQ0FBQyxXQUFXLENBQUMsQ0FDbkMsYUFBYSxFQUFFLENBQUM7S0FDeEI7O0FBRUQsYUFBUyxhQUFhLENBQUMsR0FBRyxFQUFFO0FBQ3hCLGVBQU8sSUFBSSxDQUFDLFlBQVksQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDO0tBQzVEOztBQUVELGFBQVMsZUFBZSxDQUFDLFdBQVcsRUFBRTtBQUNsQyxZQUFJLFNBQVMsR0FBRyxJQUFJLENBQUMsV0FBVyxDQUFDLFNBQVM7WUFDdEMsS0FBSyxHQUFHLElBQUksQ0FBQzs7QUFFakIsbUJBQVcsR0FBRyxXQUFXLElBQUksWUFBWSxDQUFDOztBQUUxQyxZQUFJLENBQUMsbUJBQW1CLENBQUM7QUFDckIsZ0JBQUksRUFBRSxXQUFXLENBQUMsU0FBUyxDQUFDLElBQUksQ0FBQztBQUNqQyxpQkFBSyxFQUFFLFdBQVcsQ0FBQyxTQUFTLENBQUMsS0FBSyxDQUFDO1NBQ3RDLENBQUMsQ0FBQzs7QUFFSCxZQUFJLENBQUMsZ0JBQWdCLENBQUMsV0FBVyxDQUFDLFNBQVMsQ0FBQyxNQUFNLENBQUMsRUFBRSxXQUFXLENBQUMsU0FBUyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUM7OztBQUdyRixTQUFDLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxXQUFXLENBQUMsT0FBTyxFQUFFLFNBQVMsY0FBYyxDQUFDLEtBQUssRUFBRTtBQUM1RCxpQkFBSyxDQUFDLE9BQU8sQ0FBQyxLQUFLLENBQUMsR0FBRyxXQUFXLENBQUMsS0FBSyxDQUFDLENBQUM7U0FDN0MsQ0FBQyxDQUFDOztBQUVILGVBQU8sSUFBSSxDQUFDO0tBQ2Y7O0FBRUQsYUFBUyxhQUFhLEdBQUc7QUFDckIsWUFBSSxLQUFLLEdBQUcsSUFBSSxDQUFDOztBQUVqQixZQUFJLENBQUMsV0FBVyxHQUFHLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBQztBQUNyQyxTQUFDLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxZQUFZLEVBQUUsU0FBUyxpQkFBaUIsQ0FBQyxLQUFLLEVBQUUsR0FBRyxFQUFFO0FBQzdELGlCQUFLLENBQUMsWUFBWSxDQUFDLEdBQUcsQ0FBQyxHQUFHLEtBQUssQ0FBQyxXQUFXLENBQUM7U0FDL0MsQ0FBQyxDQUFDOztBQUVILGVBQU8sSUFBSSxDQUFDO0tBQ2Y7O0FBRUQsYUFBUyxtQkFBbUIsQ0FBQyxVQUFVLEVBQUU7QUFDckMsWUFBSSxDQUFDLFVBQVUsR0FBRyxJQUFJLENBQUMsVUFBVSxJQUFJLEVBQUUsQ0FBQztBQUN4QyxTQUFDLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxVQUFVLEVBQUUsVUFBVSxDQUFDLENBQUM7O0FBRXRDLGVBQU8sSUFBSSxDQUFDO0tBQ2Y7O0FBRUQsYUFBUyxPQUFPLENBQUMsSUFBSSxFQUFFO0FBQ25CLFlBQUksS0FBSyxHQUFHLElBQUksQ0FBQzs7QUFFakIsWUFBSSxDQUFDLElBQUksR0FBRyxJQUFJLENBQUM7QUFDakIsWUFBSSxDQUFDLFlBQVksR0FBRyxDQUFDLENBQUMsTUFBTSxDQUFDLElBQUksRUFBRSxTQUFTLDRCQUE0QixDQUFDLEtBQUssRUFBRSxHQUFHLEVBQUU7QUFDakYsaUJBQUssQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLFdBQVcsQ0FBQyxRQUFRLENBQUMsQ0FBQyxHQUFHLEtBQUssQ0FBQztBQUMvQyxtQkFBTyxLQUFLLENBQUM7U0FDaEIsRUFBRSxFQUFFLENBQUMsQ0FBQzs7QUFFUCxlQUFPLElBQUksQ0FBQztLQUNmOztBQUVELGFBQVMsZ0JBQWdCLENBQUMsTUFBTSxFQUFFLE9BQU8sRUFBRTtBQUN2QyxZQUFJLENBQUMsTUFBTSxHQUFHLE1BQU0sSUFBSSxJQUFJLENBQUMsTUFBTSxDQUFDO0FBQ3BDLFlBQUksQ0FBQyxPQUFPLEdBQUcsT0FBTyxJQUFJLElBQUksQ0FBQyxPQUFPLENBQUM7O0FBRXZDLGVBQU8sSUFBSSxDQUFDO0tBQ2Y7O0FBRUQsYUFBUyxVQUFVLENBQUMsSUFBSSxFQUFFLEtBQUssRUFBRSxLQUFLLEVBQUU7QUFDcEMsZUFBTyxJQUFJLENBQ04sbUJBQW1CLENBQUMsSUFBSSxFQUFFLEtBQUssRUFBRSxLQUFLLENBQUMsQ0FDdkMsV0FBVyxFQUFFLENBQUM7S0FDdEI7O0FBRUQsYUFBUyxVQUFVLENBQUMsTUFBTSxFQUFFLE9BQU8sRUFBRTtBQUNqQyxlQUFPLElBQUksQ0FDTixnQkFBZ0IsQ0FBQyxNQUFNLEVBQUUsT0FBTyxDQUFDLENBQ2pDLG1CQUFtQixDQUFDO0FBQ2pCLGdCQUFJLEVBQUUsQ0FBQztTQUNWLENBQUMsQ0FDRCxXQUFXLEVBQUUsQ0FBQztLQUN0Qjs7QUFFRCxhQUFTLFdBQVcsR0FBRztBQUNuQixZQUFJLENBQUMsSUFBSSxDQUFDLGNBQWMsRUFBRTtBQUN0QixrQkFBTSxDQUFDLEVBQUUsQ0FBQyxNQUFNLENBQUMsT0FBTyxDQUFDLElBQUksRUFBRSxJQUFJLENBQUMsa0JBQWtCLEVBQUUsQ0FBQyxDQUFDO1NBQzdEOztBQUVELGVBQU8sSUFBSSxDQUFDO0tBQ2Y7O0FBRUQsYUFBUyxnQkFBZ0IsQ0FBQyxRQUFRLEVBQUU7QUFDaEMsWUFBSSxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsUUFBUSxDQUFDLEVBQUU7QUFDdkIsZ0JBQUksQ0FBQyxLQUFLLENBQUMsb0VBQW9FLENBQUMsQ0FBQztBQUNqRixtQkFBTyxLQUFLLENBQUM7U0FDaEI7O0FBRUQsWUFBSSxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxFQUFFO0FBQzNCLGdCQUFJLENBQUMsS0FBSyxDQUFDLDJGQUEyRixDQUFDLENBQUM7QUFDeEcsbUJBQU8sS0FBSyxDQUFDO1NBQ2hCOztBQUVELFlBQUksQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLFFBQVEsQ0FBQyxVQUFVLENBQUMsRUFBRTtBQUNsQyxnQkFBSSxDQUFDLEtBQUssQ0FBQyxrR0FBa0csQ0FBQyxDQUFDO0FBQy9HLG1CQUFPLEtBQUssQ0FBQztTQUNoQjs7QUFFRCxlQUFPLElBQUksQ0FBQztLQUNmOztBQUVELFdBQU8sV0FBVyxDQUFDO0NBQ3RCLENBQUMsQ0FBQzs7Ozs7Ozs7QUNuT1AsT0FBTyxDQUFDLE1BQU0sQ0FBQyxtREFBbUQsRUFBRSxFQUFFLENBQUMsQ0FDbEUsU0FBUyxDQUFDLFVBQVUsRUFBRSxTQUFTLGNBQWMsQ0FBQyxPQUFPLEVBQUU7QUFDcEQsV0FBTztBQUNILGVBQU8sRUFBRSxpQkFBVSxLQUFLLEVBQUUsS0FBSyxFQUFFO0FBQzdCLGdCQUFNLHFCQUFxQixHQUFHLENBQUMsQ0FBQzs7QUFFaEMsaUJBQUssQ0FBQyxJQUFJLENBQUMsY0FBYyxFQUFFLFFBQVEsQ0FBQyxDQUFDO0FBQ3JDLGlCQUFLLENBQUMsSUFBSSxDQUFDLFdBQVcsRUFBRSxxQkFBcUIsQ0FBQyxDQUFDO0FBQy9DLGlCQUFLLENBQUMsSUFBSSxDQUFDLFNBQVMsRUFBRSxRQUFRLENBQUMsQ0FBQzs7QUFFaEMsbUJBQU8sU0FBUyxZQUFZLENBQUMsS0FBSyxFQUFFLEtBQUssRUFBRSxLQUFLLEVBQUUsV0FBVyxFQUFFO0FBQzNELG9CQUFJLEVBQUUsQ0FBQzs7QUFFUCx5QkFBUyxJQUFJLEdBQUc7QUFDWiwrQkFBVyxDQUFDLFFBQVEsQ0FBQyxPQUFPLENBQUMsTUFBTSxDQUFDLENBQUM7QUFDckMsK0JBQVcsQ0FBQyxXQUFXLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxDQUFDO0FBQ3hDLCtCQUFXLENBQUMsV0FBVyxDQUFDLGVBQWUsR0FBRyxlQUFlLENBQUM7O0FBRTFELHlCQUFLLENBQUMsTUFBTSxDQUFDLFlBQVksRUFBRSxtQkFBbUIsQ0FBQyxDQUFDO2lCQUNuRDs7Ozs7QUFLRCx5QkFBUyxZQUFZLEdBQUc7QUFDcEIsMkJBQU8sV0FBVyxDQUFDLFVBQVUsQ0FBQztpQkFDakM7Ozs7O0FBS0QseUJBQVMsbUJBQW1CLENBQUMsU0FBUyxFQUFFLGFBQWEsRUFBRTtBQUNuRCx3QkFBSSxDQUFDLFNBQVMsRUFBRTtBQUNaLCtCQUFPO3FCQUNWOzs7QUFHRCx3QkFBTSxVQUFVLEdBQUcsU0FBUyxDQUFDLE1BQU0sR0FBRyxhQUFhLENBQUMsTUFBTSxDQUFDOztBQUUzRCwrQkFBVyxDQUFDLGFBQWEsQ0FBQyxNQUFNLENBQUMsU0FBUyxFQUFFLFVBQVUsQ0FBQyxDQUFDLENBQUM7QUFDekQsK0JBQVcsQ0FBQyxPQUFPLEVBQUUsQ0FBQztpQkFDekI7Ozs7O0FBS0QseUJBQVMsZUFBZSxDQUFDLFVBQVUsRUFBRTt3QkFDMUIsS0FBSyxHQUFVLFVBQVUsQ0FBekIsS0FBSzt3QkFBRSxJQUFJLEdBQUksVUFBVSxDQUFsQixJQUFJOztBQUVsQiwyQkFBTyxXQUFXLENBQUMsS0FBSyxFQUFFLElBQUksQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLEtBQUssRUFBRSxJQUFJLENBQUMsQ0FBQztpQkFDM0Q7Ozs7O0FBS0QseUJBQVMsV0FBVyxDQUFDLEtBQUssRUFBRSxJQUFJLEVBQUU7QUFDOUIsd0JBQU0sVUFBVSxHQUFHLFlBQVksQ0FBQztBQUNoQyx3QkFBTSxTQUFTLEdBQUcsWUFBWSxDQUFDOztBQUUvQiwyQkFBTyxDQUFDLENBQUMsUUFBUSxDQUFDLEtBQUssQ0FBQyxJQUNqQixDQUFDLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxJQUNoQixVQUFVLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxJQUN0QixTQUFTLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxJQUNwQixZQUFZLENBQUMsS0FBSyxDQUFDLENBQUM7aUJBQzlCOzs7OztBQUtELHlCQUFTLFlBQVksQ0FBQyxLQUFLLEVBQUU7QUFDekIseUJBQUssR0FBRyxDQUFDLENBQUMsUUFBUSxDQUFDLEtBQUssQ0FBQyxDQUFDOztBQUUxQiwyQkFBTyxLQUFLLEdBQUcsQ0FBQyxJQUFJLEtBQUssR0FBRyxFQUFFLENBQUM7aUJBQ2xDOzs7OztBQUtELHlCQUFTLE1BQU0sQ0FBQyxLQUFLLEVBQUUsSUFBSSxFQUFFO0FBQ3pCLDJCQUFPLGdCQUFnQixFQUFFLEdBQUcsSUFBSSxJQUFJLENBQUMsSUFBSSxFQUFFLEtBQUssR0FBRyxDQUFDLENBQUMsQ0FBQztpQkFDekQ7Ozs7O0FBS0QseUJBQVMsZ0JBQWdCLEdBQUc7QUFDeEIsd0JBQU0sSUFBSSxHQUFHLElBQUksSUFBSSxFQUFFLENBQUM7O0FBRXhCLDJCQUFPLElBQUksSUFBSSxDQUFDLElBQUksQ0FBQyxXQUFXLEVBQUUsRUFBRSxJQUFJLENBQUMsUUFBUSxFQUFFLENBQUMsQ0FBQztpQkFDeEQ7Ozs7O0FBS0QseUJBQVMsU0FBUyxHQUFXO3dCQUFWLEdBQUcseURBQUcsRUFBRTs7QUFDdkIsd0JBQU0sS0FBSyxHQUFHLEdBQUcsQ0FBQyxLQUFLLENBQUM7QUFDeEIsd0JBQU0sSUFBSSxHQUFHLEdBQUcsQ0FBQyxJQUFJLENBQUM7O0FBRXRCLHdCQUFJLENBQUMsQ0FBQyxPQUFPLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsRUFBRTtBQUNyQywrQkFBTyxFQUFFLENBQUM7cUJBQ2I7O0FBRUQsMkJBQU8sT0FBTyxDQUFDLE1BQU0sQ0FBQyxDQUFDLElBQUksSUFBSSxDQUFDLElBQUksRUFBRSxLQUFLLEdBQUcsQ0FBQyxDQUFDLEVBQUUsU0FBUyxDQUFDLENBQUM7aUJBQ2hFOzs7Ozs7QUFNRCx5QkFBUyxNQUFNLENBQUMsVUFBVSxFQUFFO0FBQ3hCLHdCQUFNLFFBQVEsR0FBRyxJQUFJLElBQUksRUFBRSxDQUFDLFdBQVcsRUFBRSxDQUFDLFFBQVEsRUFBRSxDQUFDLEtBQUssQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUM7QUFDakUsd0JBQU0sTUFBTSxHQUFHLFVBQVUsQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLENBQUM7QUFDckMsd0JBQU0sS0FBSyxHQUFHLE1BQU0sQ0FBQyxDQUFDLENBQUMsR0FBRyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxFQUFFLEdBQUcsRUFBRSxDQUFDO0FBQ2hELHdCQUFNLElBQUksR0FBRyxNQUFNLENBQUMsQ0FBQyxDQUFDLEdBQUcsUUFBUSxHQUFHLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLEVBQUUsR0FBRyxFQUFFLENBQUM7O0FBRTFELDJCQUFPLEVBQUUsS0FBSyxFQUFMLEtBQUssRUFBRSxJQUFJLEVBQUosSUFBSSxFQUFFLENBQUM7aUJBQzFCOzs7OztBQUtELHlCQUFTLE1BQU0sQ0FBQyxNQUFNLEVBQUUsVUFBVSxFQUFFO0FBQ2hDLHdCQUFNLE1BQU0sR0FBRyxNQUFNLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxDQUFDO0FBQ2pDLHdCQUFNLEtBQUssR0FBRyxNQUFNLENBQUMsQ0FBQyxDQUFDLEdBQUcsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksRUFBRSxHQUFHLEVBQUUsQ0FBQztBQUNoRCx3QkFBTSxJQUFJLEdBQUcsTUFBTSxDQUFDLENBQUMsQ0FBQyxHQUFHLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLEVBQUUsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxFQUFFLENBQUM7OztBQUd6RCx3QkFBSSxBQUFDLENBQUMsVUFBVSxJQUFJLENBQUMsSUFBSSxJQUFLLEtBQUssQ0FBQyxNQUFNLEdBQUcsQ0FBQyxFQUFFO0FBQzVDLCtCQUFPLEtBQUssQ0FBQztxQkFDaEI7OztBQUdELHdCQUFJLFVBQVUsSUFBSSxDQUFDLElBQUksSUFBSSxLQUFLLENBQUMsTUFBTSxHQUFHLENBQUMsRUFBRTtBQUN6QywrQkFBVSxLQUFLLENBQUMsS0FBSyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsV0FBTSxLQUFLLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFHO3FCQUNyRDs7QUFFRCwyQkFBVSxLQUFLLFdBQU0sSUFBSSxDQUFHO2lCQUMvQjthQUNKLENBQUM7U0FDTDtBQUNELGVBQU8sRUFBRSxTQUFTO0FBQ2xCLGdCQUFRLEVBQUUsR0FBRztLQUNoQixDQUFDO0NBQ0wsQ0FBQyxDQUFDOzs7QUNwSlAsT0FBTyxDQUFDLE1BQU0sQ0FBQyx5Q0FBeUMsRUFBRSxDQUN0RCxtREFBbUQsQ0FDdEQsQ0FBQyxDQUFDIiwiZmlsZSI6ImJjYXBwLXBhdHRlcm4tbGFiLWNvbXBvbmVudHMuanMiLCJzb3VyY2VzQ29udGVudCI6WyJhbmd1bGFyLm1vZHVsZSgnYmNhcHAtcGF0dGVybi1sYWInLCBbXG4gICAgJ2dldHRleHQnLFxuICAgICduZ0FuaW1hdGUnLFxuICAgICduZ01lc3NhZ2VzJyxcbiAgICAnbW0uZm91bmRhdGlvbicsXG4gICAgJ2JjYXBwLXBhdHRlcm4tbGFiLXRlbXBsYXRlcycsXG4gICAgJ2JjYXBwLXBhdHRlcm4tbGFiLmJjLWRhdGVwaWNrZXInLFxuICAgICdiY2FwcC1wYXR0ZXJuLWxhYi5iYy1kcm9wZG93bicsXG4gICAgJ2JjYXBwLXBhdHRlcm4tbGFiLmJjLW1vZGFsJyxcbiAgICAnYmNhcHAtcGF0dGVybi1sYWIuYmMtcGFnaW5hdGlvbicsXG4gICAgJ2JjYXBwLXBhdHRlcm4tbGFiLmJjLXNlcnZlci10YWJsZScsXG4gICAgJ2JjYXBwLXBhdHRlcm4tbGFiLmNoZWNrYm94LWxpc3QnLFxuICAgICdiY2FwcC1wYXR0ZXJuLWxhYi5jcmVkaXQtY2FyZCcsXG4gICAgJ2JjYXBwLXBhdHRlcm4tbGFiLmZvcm0nLFxuICAgICdiY2FwcC1wYXR0ZXJuLWxhYi5mb3JtLWZpZWxkJyxcbiAgICAnYmNhcHAtcGF0dGVybi1sYWIuaWNvbicsXG4gICAgJ2JjYXBwLXBhdHRlcm4tbGFiLmxvYWRpbmctbm90aWZpY2F0aW9uJyxcbiAgICAnYmNhcHAtcGF0dGVybi1sYWIubG9hZGluZy1vdmVybGF5JyxcbiAgICAnYmNhcHAtcGF0dGVybi1sYWIuc3ByaXRlJyxcbiAgICAnYmNhcHAtcGF0dGVybi1sYWIuc3dpdGNoJ1xuXSk7XG4iLCIvKiBnbG9iYWxzIG1vbWVudCAqL1xuYW5ndWxhci5tb2R1bGUoJ2JjYXBwLXBhdHRlcm4tbGFiLmJjLWRhdGVwaWNrZXIuY29uc3RhbnRzJywgW10pXG4gICAgLmNvbnN0YW50KCdCQ19EQVRFUElDS0VSX0RFRkFVTFRTJywge1xuICAgICAgICBkYXlGb3JtYXQ6ICdEJyxcbiAgICAgICAgaW5wdXRGb3JtYXQ6IG1vbWVudC5sb2NhbGVEYXRhKCkubG9uZ0RhdGVGb3JtYXQoJ0wnKSxcbiAgICAgICAgc3R5bGVzOiB7XG4gICAgICAgICAgICBiYWNrOiAnZGF0ZXBpY2tlci1iYWNrJyxcbiAgICAgICAgICAgIGNvbnRhaW5lcjogJ2RhdGVwaWNrZXInLFxuICAgICAgICAgICAgZGF0ZTogJ2RhdGVwaWNrZXItZGF0ZScsXG4gICAgICAgICAgICBkYXlCb2R5OiAnZGF0ZXBpY2tlci1kYXlzLWJvZHknLFxuICAgICAgICAgICAgZGF5Qm9keUVsZW06ICdkYXRlcGlja2VyLWRheScsXG4gICAgICAgICAgICBkYXlDb25jZWFsZWQ6ICdkYXRlcGlja2VyLWRheS1jb25jZWFsZWQnLFxuICAgICAgICAgICAgZGF5RGlzYWJsZWQ6ICdpcy1kaXNhYmxlZCcsXG4gICAgICAgICAgICBkYXlIZWFkOiAnZGF0ZXBpY2tlci1kYXlzLWhlYWQnLFxuICAgICAgICAgICAgZGF5SGVhZEVsZW06ICdkYXRlcGlja2VyLWRheS1uYW1lJyxcbiAgICAgICAgICAgIGRheVByZXZNb250aDogJ2RhdGVwaWNrZXItZGF5LXByZXYtbW9udGgnLFxuICAgICAgICAgICAgZGF5TmV4dE1vbnRoOiAnZGF0ZXBpY2tlci1kYXktbmV4dC1tb250aCcsXG4gICAgICAgICAgICBkYXlSb3c6ICdkYXRlcGlja2VyLWRheXMtcm93JyxcbiAgICAgICAgICAgIGRheVRhYmxlOiAnZGF0ZXBpY2tlci1kYXlzJyxcbiAgICAgICAgICAgIG1vbnRoOiAnZGF0ZXBpY2tlci1tb250aCcsXG4gICAgICAgICAgICBtb250aExhYmVsOiAnZGF0ZXBpY2tlci1tb250aCcsXG4gICAgICAgICAgICBuZXh0OiAnZGF0ZXBpY2tlci1uZXh0JyxcbiAgICAgICAgICAgIHBvc2l0aW9uZWQ6ICdkYXRlcGlja2VyLWF0dGFjaG1lbnQnLFxuICAgICAgICAgICAgc2VsZWN0ZWREYXk6ICdpcy1zZWxlY3RlZCcsXG4gICAgICAgICAgICBzZWxlY3RlZFRpbWU6ICdkYXRlcGlja2VyLXRpbWUtc2VsZWN0ZWQnLFxuICAgICAgICAgICAgdGltZTogJ2RhdGVwaWNrZXItdGltZScsXG4gICAgICAgICAgICB0aW1lTGlzdDogJ2RhdGVwaWNrZXItdGltZS1saXN0JyxcbiAgICAgICAgICAgIHRpbWVPcHRpb246ICdkYXRlcGlja2VyLXRpbWUtb3B0aW9uJ1xuICAgICAgICB9LFxuICAgICAgICB0aW1lOiBmYWxzZSxcbiAgICAgICAgd2Vla2RheUZvcm1hdDogJ3Nob3J0J1xuICAgIH0pO1xuIiwiLyogZ2xvYmFscyByb21lICovXG5hbmd1bGFyLm1vZHVsZSgnYmNhcHAtcGF0dGVybi1sYWIuYmMtZGF0ZXBpY2tlci5kaXJlY3RpdmUnLCBbXG4gICAgJ2JjYXBwLXBhdHRlcm4tbGFiLmJjLWRhdGVwaWNrZXIuY29uc3RhbnRzJ1xuXSlcbiAgICAuZGlyZWN0aXZlKCdiY0RhdGVwaWNrZXInLCBmdW5jdGlvbiBiY0RhdGVwaWNrZXJEaXJlY3RpdmUoQkNfREFURVBJQ0tFUl9ERUZBVUxUUykge1xuICAgICAgICByZXR1cm4ge1xuICAgICAgICAgICAgcmVzdHJpY3Q6ICdBJyxcbiAgICAgICAgICAgIHJlcXVpcmU6ICduZ01vZGVsJyxcbiAgICAgICAgICAgIHNjb3BlOiB7XG4gICAgICAgICAgICAgICAgb3B0aW9uczogJz0/J1xuICAgICAgICAgICAgfSxcblxuICAgICAgICAgICAgbGluazogZnVuY3Rpb24gZGF0ZXBpY2tlckxpbmtGdW5jdGlvbihzY29wZSwgZWxlbWVudCwgYXR0cnMsIG5nTW9kZWwpIHtcbiAgICAgICAgICAgICAgICBpZiAoc2NvcGUub3B0aW9ucyA9PT0gdW5kZWZpbmVkKSB7XG4gICAgICAgICAgICAgICAgICAgIHNjb3BlLm9wdGlvbnMgPSB7fTtcbiAgICAgICAgICAgICAgICB9XG5cbiAgICAgICAgICAgICAgICAvLyBBZGQgZGVmYXVsdHMgdG8gdGhlIG9wdGlvbnMgb2JqZWN0XG4gICAgICAgICAgICAgICAgXy5kZWZhdWx0cyhzY29wZS5vcHRpb25zLCBCQ19EQVRFUElDS0VSX0RFRkFVTFRTKTtcblxuICAgICAgICAgICAgICAgIC8vIENyZWF0ZSBhIG5ldyByb21lIChjYWxlbmRhcikgaW5zdGFuY2VcbiAgICAgICAgICAgICAgICBzY29wZS5jYWxlbmRhciA9IHJvbWUoZWxlbWVudFswXSwgc2NvcGUub3B0aW9ucyk7XG5cbiAgICAgICAgICAgICAgICAvLyBPbiAnZGF0YScgZXZlbnQgc2V0IG5nTW9kZWwgdG8gdGhlIHBhc3NlZCB2YWx1ZVxuICAgICAgICAgICAgICAgIHNjb3BlLmNhbGVuZGFyLm9uKCdkYXRhJywgZnVuY3Rpb24gb25EYXRhKHZhbHVlKSB7XG4gICAgICAgICAgICAgICAgICAgIG5nTW9kZWwuJHNldFZpZXdWYWx1ZSh2YWx1ZSk7XG4gICAgICAgICAgICAgICAgICAgIHNjb3BlLiRhcHBseSgpO1xuICAgICAgICAgICAgICAgIH0pO1xuXG4gICAgICAgICAgICAgICAgc2NvcGUuY2FsZW5kYXIub24oJ3JlYWR5JywgZnVuY3Rpb24gb25SZWFkeShvcHRpb25zKSB7XG4gICAgICAgICAgICAgICAgICAgIGlmIChhdHRycy5wbGFjZWhvbGRlciA9PT0gdW5kZWZpbmVkKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICBhdHRycy4kc2V0KCdwbGFjZWhvbGRlcicsIG9wdGlvbnMuaW5wdXRGb3JtYXQpO1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgfSk7XG5cbiAgICAgICAgICAgICAgICAvLyBSZW1vdmluZyBjYWxlbmRhciBldmVudCBsaXN0ZW5lcnNcbiAgICAgICAgICAgICAgICBlbGVtZW50Lm9uKCckZGVzdHJveScsIGZ1bmN0aW9uIG9uRGVzdHJveSgpIHtcbiAgICAgICAgICAgICAgICAgICAgc2NvcGUuY2FsZW5kYXIuZGVzdHJveSgpO1xuICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgfVxuICAgICAgICB9O1xuICAgIH0pO1xuIiwiYW5ndWxhci5tb2R1bGUoJ2JjYXBwLXBhdHRlcm4tbGFiLmJjLWRhdGVwaWNrZXInLCBbXG4gICAgJ2JjYXBwLXBhdHRlcm4tbGFiLmJjLWRhdGVwaWNrZXIuZGlyZWN0aXZlJ1xuXSk7XG4iLCJhbmd1bGFyLm1vZHVsZSgnYmNhcHAtcGF0dGVybi1sYWIuYmMtZHJvcGRvd24tbWVudS5kaXJlY3RpdmUnLCBbXSlcbiAgICAuZGlyZWN0aXZlKCdiY0Ryb3Bkb3duTWVudScsIGZ1bmN0aW9uIGJjRHJvcGRvd25NZW51RGlyZWN0aXZlKCkge1xuICAgICAgICByZXR1cm4ge1xuICAgICAgICAgICAgcmVzdHJpY3Q6ICdBJyxcbiAgICAgICAgICAgIHJlcXVpcmU6ICdeYmNEcm9wZG93bicsXG4gICAgICAgICAgICBjb21waWxlOiBmdW5jdGlvbiBiY0Ryb3Bkb3duTWVudURpcmVjdGl2ZUNvbXBpbGUodEVsZW1lbnQpIHtcbiAgICAgICAgICAgICAgICB0RWxlbWVudC5hZGRDbGFzcygnZHJvcGRvd24tbWVudScpO1xuXG4gICAgICAgICAgICAgICAgcmV0dXJuIGZ1bmN0aW9uIGJjRHJvcGRvd25NZW51RGlyZWN0aXZlTGluayhzY29wZSwgZWxlbWVudCwgYXR0cnMsIGJjRHJvcGRvd25DdHJsKSB7XG4gICAgICAgICAgICAgICAgICAgIGVsZW1lbnQuYXR0cignaWQnLCBiY0Ryb3Bkb3duQ3RybC5nZXRVbmlxdWVJZCgpKTtcbiAgICAgICAgICAgICAgICB9O1xuICAgICAgICAgICAgfVxuICAgICAgICB9O1xuICAgIH0pO1xuIiwiYW5ndWxhci5tb2R1bGUoJ2JjYXBwLXBhdHRlcm4tbGFiLmJjLWRyb3Bkb3duLXRvZ2dsZS5kaXJlY3RpdmUnLCBbXSlcbiAgICAuZGlyZWN0aXZlKCdiY0Ryb3Bkb3duVG9nZ2xlJywgZnVuY3Rpb24gYmNEcm9wZG93blRvZ2dsZURpcmVjdGl2ZSgkY29tcGlsZSkge1xuICAgICAgICByZXR1cm4ge1xuICAgICAgICAgICAgcmVzdHJpY3Q6ICdBJyxcbiAgICAgICAgICAgIHRlcm1pbmFsOiB0cnVlLFxuICAgICAgICAgICAgcHJpb3JpdHk6IDEwMDEsIC8vIHNldCBoaWdoZXIgdGhhbiBuZy1yZXBlYXQgdG8gcHJldmVudCBkb3VibGUgY29tcGlsYXRpb25cbiAgICAgICAgICAgIHJlcXVpcmU6ICdeYmNEcm9wZG93bicsXG4gICAgICAgICAgICBjb21waWxlOiBmdW5jdGlvbiBiY0Ryb3Bkb3duVG9nZ2xlRGlyZWN0aXZlQ29tcGlsZSh0RWxlbWVudCkge1xuICAgICAgICAgICAgICAgIHRFbGVtZW50LnJlbW92ZUF0dHIoJ2JjLWRyb3Bkb3duLXRvZ2dsZScpO1xuXG4gICAgICAgICAgICAgICAgcmV0dXJuIGZ1bmN0aW9uIGJjRHJvcGRvd25Ub2dnbGVEaXJlY3RpdmVMaW5rKHNjb3BlLCBlbGVtZW50LCBhdHRycywgYmNEcm9wZG93bkN0cmwpIHtcbiAgICAgICAgICAgICAgICAgICAgZWxlbWVudC5hdHRyKCdkcm9wZG93bi10b2dnbGUnLCAnIycgKyBiY0Ryb3Bkb3duQ3RybC5nZXRVbmlxdWVJZCgpKTtcbiAgICAgICAgICAgICAgICAgICAgJGNvbXBpbGUoZWxlbWVudCkoc2NvcGUpO1xuICAgICAgICAgICAgICAgIH07XG4gICAgICAgICAgICB9XG4gICAgICAgIH07XG4gICAgfSk7XG4iLCJhbmd1bGFyLm1vZHVsZSgnYmNhcHAtcGF0dGVybi1sYWIuYmMtZHJvcGRvd24uZGlyZWN0aXZlJywgW10pXG4gICAgLmRpcmVjdGl2ZSgnYmNEcm9wZG93bicsIGZ1bmN0aW9uIGJjRHJvcGRvd25EaXJlY3RpdmUoKSB7XG4gICAgICAgIHJldHVybiB7XG4gICAgICAgICAgICByZXN0cmljdDogJ0VBJyxcbiAgICAgICAgICAgIGNvbnRyb2xsZXI6IGZ1bmN0aW9uIGJjRHJvcGRvd25EaXJlY3RpdmVDb250cm9sbGVyKCkge1xuICAgICAgICAgICAgICAgIHZhciBjdHJsID0gdGhpcyxcbiAgICAgICAgICAgICAgICAgICAgdW5pcXVlSWQ7XG5cbiAgICAgICAgICAgICAgICBjdHJsLmdldFVuaXF1ZUlkID0gZ2V0VW5pcXVlSWQ7XG5cbiAgICAgICAgICAgICAgICBmdW5jdGlvbiBnZXRVbmlxdWVJZCgpIHtcbiAgICAgICAgICAgICAgICAgICAgaWYgKCF1bmlxdWVJZCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgdW5pcXVlSWQgPSBfLnVuaXF1ZUlkKCdiYy1kcm9wZG93bi0nKTtcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICByZXR1cm4gdW5pcXVlSWQ7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICB9O1xuICAgIH0pO1xuIiwiYW5ndWxhci5tb2R1bGUoJ2JjYXBwLXBhdHRlcm4tbGFiLmJjLWRyb3Bkb3duJywgW1xuICAgICdiY2FwcC1wYXR0ZXJuLWxhYi5iYy1kcm9wZG93bi5kaXJlY3RpdmUnLFxuICAgICdiY2FwcC1wYXR0ZXJuLWxhYi5iYy1kcm9wZG93bi10b2dnbGUuZGlyZWN0aXZlJyxcbiAgICAnYmNhcHAtcGF0dGVybi1sYWIuYmMtZHJvcGRvd24tbWVudS5kaXJlY3RpdmUnXG5dKTtcbiIsImFuZ3VsYXIubW9kdWxlKCdiY2FwcC1wYXR0ZXJuLWxhYi5iYy1wYWdpbmF0aW9uLmRpcmVjdGl2ZScsIFtdKVxuICAgIC5kaXJlY3RpdmUoJ2JjUGFnaW5hdGlvbicsIGZ1bmN0aW9uIGJjUGFnaW5hdGlvbkRpcmVjdGl2ZSgkcGFyc2UpIHtcbiAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICAgIHJlc3RyaWN0OiAnRScsXG4gICAgICAgICAgICBzY29wZTogdHJ1ZSxcbiAgICAgICAgICAgIHRlbXBsYXRlVXJsOiAnc3JjL2pzL2JpZ2NvbW1lcmNlL2JjLXBhZ2luYXRpb24vYmMtcGFnaW5hdGlvbi50cGwuaHRtbCcsXG5cbiAgICAgICAgICAgIGNvbXBpbGU6IGZ1bmN0aW9uIGJjUGFnaW5hdGlvbkNvbXBpbGUodEVsZW1lbnQsIHRBdHRycykge1xuICAgICAgICAgICAgICAgIHZhciBhdHRyT2JqID0ge307XG5cbiAgICAgICAgICAgICAgICAvLyBTaW5jZSB0aGlzIGlzIGEgd3JhcHBlciBvZiBhbmd1bGFyLWZvdW5kYXRpb24ncyBwYWdpbmF0aW9uIGRpcmVjdGl2ZSB3ZSBuZWVkIHRvIGNvcHkgYWxsXG4gICAgICAgICAgICAgICAgLy8gb2YgdGhlIGF0dHJpYnV0ZXMgcGFzc2VkIHRvIG91ciBkaXJlY3RpdmUgYW5kIHN0b3JlIHRoZW0gaW4gdGhlIGF0dHJPYmouXG4gICAgICAgICAgICAgICAgXy5lYWNoKHRBdHRycy4kYXR0ciwgZnVuY3Rpb24oa2V5KSB7XG4gICAgICAgICAgICAgICAgICAgIGlmIChrZXkgIT09ICdjbGFzcycpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGF0dHJPYmpba2V5XSA9IHRFbGVtZW50LmF0dHIoa2V5KTtcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIH0pO1xuXG4gICAgICAgICAgICAgICAgLy8gQWRkaW5nIG91ciBjdXN0b20gY2FsbGJhY2sgdG8gdGhlIGF0dHJPYmosIGFuZ3VsYXItZm91bmRhdGlvbiB3aWxsIGNhbGwgdGhpcyBmdW5jdGlvblxuICAgICAgICAgICAgICAgIC8vIHdoZW4gYSBwYWdlIG51bWJlciBpcyBjbGlja2VkIGluIHRoZSBwYWdpbmF0aW9uLlxuICAgICAgICAgICAgICAgIGF0dHJPYmpbJ29uLXNlbGVjdC1wYWdlJ10gPSAncGFnaW5hdGlvbkNhbGxiYWNrKHBhZ2UpJztcblxuICAgICAgICAgICAgICAgIC8vIEFkZCBhbGwgdGhlIGF0dHJpYnV0ZXMgdG8gYW5ndWxhci1mb3VuZGF0aW9uJ3MgcGFnaW5hdGlvbiBkaXJlY3RpdmVcbiAgICAgICAgICAgICAgICB0RWxlbWVudC5maW5kKCdwYWdpbmF0aW9uJykuYXR0cihhdHRyT2JqKTtcblxuICAgICAgICAgICAgICAgIHJldHVybiBmdW5jdGlvbiBiY1BhZ2luYXRpb25MaW5rKCRzY29wZSwgZWxlbWVudCwgYXR0cnMpIHtcbiAgICAgICAgICAgICAgICAgICAgdmFyIG9uQ2hhbmdlUGFyc2VHZXR0ZXIgPSAkcGFyc2UoYXR0cnMub25DaGFuZ2UpLFxuICAgICAgICAgICAgICAgICAgICAgICAgZGVmYXVsdExpbWl0cyA9IFsxMCwgMjAsIDMwLCA1MCwgMTAwXTtcblxuICAgICAgICAgICAgICAgICAgICAkc2NvcGUuc2V0TGltaXQgPSBmdW5jdGlvbihsaW1pdCwgZXZlbnQpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGV2ZW50LnByZXZlbnREZWZhdWx0KCk7XG4gICAgICAgICAgICAgICAgICAgICAgICBsaW1pdCA9IF8ucGFyc2VJbnQobGltaXQpO1xuICAgICAgICAgICAgICAgICAgICAgICAgJHBhcnNlKGF0dHJzLml0ZW1zUGVyUGFnZSkuYXNzaWduKCRzY29wZS4kcGFyZW50LCBsaW1pdCk7XG4gICAgICAgICAgICAgICAgICAgICAgICAkc2NvcGUucGFnaW5hdGlvbkNhbGxiYWNrKDEsIGxpbWl0KTtcbiAgICAgICAgICAgICAgICAgICAgfTtcblxuICAgICAgICAgICAgICAgICAgICAkc2NvcGUuZ2V0Q3VycmVudFBhZ2UgPSBmdW5jdGlvbigpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiAkcGFyc2UoYXR0cnMucGFnZSkoJHNjb3BlLiRwYXJlbnQpO1xuICAgICAgICAgICAgICAgICAgICB9O1xuXG4gICAgICAgICAgICAgICAgICAgICRzY29wZS5nZXRDdXJyZW50TGltaXQgPSBmdW5jdGlvbigpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiAkcGFyc2UoYXR0cnMuaXRlbXNQZXJQYWdlKSgkc2NvcGUuJHBhcmVudCk7XG4gICAgICAgICAgICAgICAgICAgIH07XG5cbiAgICAgICAgICAgICAgICAgICAgJHNjb3BlLnNob3dMaW1pdHMgPSBmdW5jdGlvbigpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiAkcGFyc2UoYXR0cnMuc2hvd0xpbWl0cykoJHNjb3BlLiRwYXJlbnQpICE9PSBmYWxzZTtcbiAgICAgICAgICAgICAgICAgICAgfTtcblxuICAgICAgICAgICAgICAgICAgICAkc2NvcGUuZ2V0TGltaXRzID0gZnVuY3Rpb24oKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICB2YXIgbGltaXRzID0gJHBhcnNlKGF0dHJzLmxpbWl0cykoJHNjb3BlLiRwYXJlbnQpO1xuXG4gICAgICAgICAgICAgICAgICAgICAgICBpZiAoIUFycmF5LmlzQXJyYXkobGltaXRzKSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiBkZWZhdWx0TGltaXRzO1xuICAgICAgICAgICAgICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gbGltaXRzO1xuICAgICAgICAgICAgICAgICAgICB9O1xuXG4gICAgICAgICAgICAgICAgICAgICRzY29wZS5wYWdpbmF0aW9uQ2FsbGJhY2sgPSBmdW5jdGlvbihwYWdlLCBsaW1pdCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgdmFyIGFkZGl0aW9uYWxTY29wZVByb3BlcnRpZXMgPSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGxpbWl0OiBsaW1pdCB8fCAkc2NvcGUuZ2V0Q3VycmVudExpbWl0KCksXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHBhZ2U6IHBhZ2VcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlUGFyc2VSZXN1bHQ7XG5cbiAgICAgICAgICAgICAgICAgICAgICAgICRwYXJzZShhdHRycy5wYWdlKS5hc3NpZ24oJHNjb3BlLiRwYXJlbnQsIHBhZ2UpO1xuXG4gICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZVBhcnNlUmVzdWx0ID0gb25DaGFuZ2VQYXJzZUdldHRlcigkc2NvcGUsIGFkZGl0aW9uYWxTY29wZVByb3BlcnRpZXMpO1xuXG4gICAgICAgICAgICAgICAgICAgICAgICAvLyBpZiB0aGUgb25DaGFuZ2Ugc3RyaW5nIGlzIGEgZnVuY3Rpb24gYW5kIG5vdCBhbiBleHByZXNzaW9uOiBjYWxsIGl0IHdpdGggdGhlIGFkZGl0aW9uYWxTY29wZVByb3BlcnRpZXMgb2JqIChmb3IgYmFja3dhcmRzIGNvbXBhdGFiaWxpdHkpXG4gICAgICAgICAgICAgICAgICAgICAgICAvLyBlbHNlIHRoZSBleHByZXNzaW9uIGhhcyBhbHJlYWR5IGJlZW4gcmFuOiBkbyBub3RoaW5nXG4gICAgICAgICAgICAgICAgICAgICAgICBpZiAodHlwZW9mIG9uQ2hhbmdlUGFyc2VSZXN1bHQgPT09ICdmdW5jdGlvbicpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZVBhcnNlUmVzdWx0KGFkZGl0aW9uYWxTY29wZVByb3BlcnRpZXMpO1xuICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICB9O1xuICAgICAgICAgICAgICAgIH07XG4gICAgICAgICAgICB9XG4gICAgICAgIH07XG4gICAgfSk7XG4iLCJhbmd1bGFyLm1vZHVsZSgnYmNhcHAtcGF0dGVybi1sYWIuYmMtcGFnaW5hdGlvbicsIFtcbiAgICAnYmNhcHAtcGF0dGVybi1sYWIuYmMtcGFnaW5hdGlvbi5kaXJlY3RpdmUnXG5dKTtcbiIsImFuZ3VsYXIubW9kdWxlKCdiY2FwcC1wYXR0ZXJuLWxhYi5iYy1zZXJ2ZXItdGFibGUuY29udHJvbGxlcicsIFtcbiAgICAnYmNhcHAtcGF0dGVybi1sYWIuYmMtc2VydmVyLXRhYmxlLnNlcnZpY2UnXG5dKVxuXG4gICAgLmNvbnRyb2xsZXIoJ0JjU2VydmVyVGFibGVDdHJsJywgZnVuY3Rpb24gQmNTZXJ2ZXJUYWJsZUN0cmwoJGF0dHJzLCAkbG9nLCAkcGFyc2UsICRzY29wZSwgQmNTZXJ2ZXJUYWJsZSkge1xuICAgICAgICB2YXIgY3RybCA9IHRoaXMsXG4gICAgICAgICAgICBiY1NlcnZlclRhYmxlUHJvdG90eXBlID0gQmNTZXJ2ZXJUYWJsZS5wcm90b3R5cGU7XG5cbiAgICAgICAgLy8gQ2FsbCB0aGUgQmNTZXJ2ZXJUYWJsZSBjb25zdHJ1Y3RvciBvbiB0aGUgY29udHJvbGxlclxuICAgICAgICAvLyBpbiBvcmRlciB0byBzZXQgYWxsIHRoZSBjb250cm9sbGVyIHByb3BlcnRpZXMgZGlyZWN0bHkuXG4gICAgICAgIC8vIFRoaXMgaXMgaGVyZSBmb3IgYmFja3dhcmRzIGNvbXBhdGFiaWxpdHkgcHVycG9zZXMuXG4gICAgICAgIEJjU2VydmVyVGFibGUuY2FsbChjdHJsLCBudWxsLCAoJHBhcnNlKCRhdHRycy50YWJsZUNvbmZpZykoJHNjb3BlKSkpO1xuXG4gICAgICAgIC8vIGNvbnRyb2xsZXIgZnVuY3Rpb25zXG4gICAgICAgIGN0cmwuY3JlYXRlUGFyYW1zT2JqZWN0ID0gYmNTZXJ2ZXJUYWJsZVByb3RvdHlwZS5jcmVhdGVQYXJhbXNPYmplY3Q7XG4gICAgICAgIGN0cmwuZmV0Y2hSZXNvdXJjZSA9IGJjU2VydmVyVGFibGVQcm90b3R5cGUuZmV0Y2hSZXNvdXJjZTtcbiAgICAgICAgY3RybC5nZXRTZWxlY3RlZFJvd3MgPSBiY1NlcnZlclRhYmxlUHJvdG90eXBlLmdldFNlbGVjdGVkUm93cztcbiAgICAgICAgY3RybC5pbml0ID0gYmNTZXJ2ZXJUYWJsZVByb3RvdHlwZS5pbml0O1xuICAgICAgICBjdHJsLmlzUm93U2VsZWN0ZWQgPSBiY1NlcnZlclRhYmxlUHJvdG90eXBlLmlzUm93U2VsZWN0ZWQ7XG4gICAgICAgIGN0cmwubG9hZFN0YXRlUGFyYW1zID0gYmNTZXJ2ZXJUYWJsZVByb3RvdHlwZS5sb2FkU3RhdGVQYXJhbXM7XG4gICAgICAgIGN0cmwuc2VsZWN0QWxsUm93cyA9IGJjU2VydmVyVGFibGVQcm90b3R5cGUuc2VsZWN0QWxsUm93cztcbiAgICAgICAgY3RybC5zZXRQYWdpbmF0aW9uVmFsdWVzID0gYmNTZXJ2ZXJUYWJsZVByb3RvdHlwZS5zZXRQYWdpbmF0aW9uVmFsdWVzO1xuICAgICAgICBjdHJsLnNldFJvd3MgPSBiY1NlcnZlclRhYmxlUHJvdG90eXBlLnNldFJvd3M7XG4gICAgICAgIGN0cmwuc2V0U29ydGluZ1ZhbHVlcyA9IGJjU2VydmVyVGFibGVQcm90b3R5cGUuc2V0U29ydGluZ1ZhbHVlcztcbiAgICAgICAgY3RybC51cGRhdGVQYWdlID0gXy5iaW5kKGJjU2VydmVyVGFibGVQcm90b3R5cGUudXBkYXRlUGFnZSwgY3RybCk7XG4gICAgICAgIGN0cmwudXBkYXRlU29ydCA9IGJjU2VydmVyVGFibGVQcm90b3R5cGUudXBkYXRlU29ydDtcbiAgICAgICAgY3RybC51cGRhdGVUYWJsZSA9IGJjU2VydmVyVGFibGVQcm90b3R5cGUudXBkYXRlVGFibGU7XG4gICAgICAgIGN0cmwudmFsaWRhdGVSZXNvdXJjZSA9IGJjU2VydmVyVGFibGVQcm90b3R5cGUudmFsaWRhdGVSZXNvdXJjZTtcblxuICAgICAgICBpbml0KCk7XG5cbiAgICAgICAgZnVuY3Rpb24gaW5pdCgpIHtcbiAgICAgICAgICAgIHZhciByZXNvdXJjZUNhbGxiYWNrO1xuXG4gICAgICAgICAgICByZXNvdXJjZUNhbGxiYWNrID0gJHBhcnNlKCRhdHRycy5yZXNvdXJjZUNhbGxiYWNrKSgkc2NvcGUpO1xuICAgICAgICAgICAgaWYgKCFfLmlzRnVuY3Rpb24ocmVzb3VyY2VDYWxsYmFjaykpIHtcbiAgICAgICAgICAgICAgICAkbG9nLmVycm9yKCdiYy1zZXJ2ZXItdGFibGUgZGlyZWN0aXZlOiByZXNvdXJjZS1jYWxsYmFjayBtdXN0IGJlIGEgZnVuY3Rpb24uJyk7XG4gICAgICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgY3RybC5yZXNvdXJjZUNhbGxiYWNrID0gcmVzb3VyY2VDYWxsYmFjaztcblxuICAgICAgICAgICAgY3RybC5pbml0KCk7XG4gICAgICAgIH1cbiAgICB9KTtcbiIsImFuZ3VsYXIubW9kdWxlKCdiY2FwcC1wYXR0ZXJuLWxhYi5iYy1zZXJ2ZXItdGFibGUuZGlyZWN0aXZlJywgW1xuICAgICdiY2FwcC1wYXR0ZXJuLWxhYi5iYy1zZXJ2ZXItdGFibGUuY29udHJvbGxlcicsXG4gICAgJ2JjYXBwLXBhdHRlcm4tbGFiLmJjLXNlcnZlci10YWJsZS5zb3J0LWJ5LmRpcmVjdGl2ZScsXG4gICAgJ3VpLnJvdXRlcidcbl0pXG4gICAgLyoqXG4gICAgICogVGhlIGJjLXNlcnZlci10YWJsZSBkaXJlY3RpdmUgY3JlYXRlcyBhIGRhdGEgdGFibGUgdGhhdCBoYW5kbGVzXG4gICAgICogc2VydmVyIHNpZGUgcGFnaW5hdGlvbiwgc29ydGluZywgYW5kIGZpbHRlcmluZy4gSXQgZXhwb3NlcyBhIGZldyBzY29wZSB2YXJpYWJsZXMsXG4gICAgICogdGhhdCBjYW4gYmUgdXNlZCB0byBkaXNwbGF5IHRoZSB0YWJsZSBjb250ZW50IHdpdGggY3VzdG9tIG1hcmt1cCAoc2VlIGV4YW1wbGVcbiAgICAgKiBpbiB0aGUgcGF0dGVybiBsYWIgZm9yIGFuIGFjdHVhbCBpbXBsZW1lbnRhdGlvbiBvZiB0aGUgYmMtc2VydmVyLXRhYmxlKS5cbiAgICAgKlxuICAgICAqIFRoZSBmb2xsb3dpbmcgYXR0cmlidXRlcyBjYW4gYmUgcGFzc2VkIGluIG9yZGVyIHRvIGNvbmZpZ3VyZSB0aGUgYmMtc2VydmVyLXRhYmxlOlxuICAgICAqIC0gcmVzb3VyY2UtY2FsbGJhY2sgKHJlcXVpcmVkKVxuICAgICAqIC0gdGFibGVDb25maWcgKG9wdGlvbmFsKVxuICAgICAqXG4gICAgICogLSByZXNvdXJjZS1jYWxsYmFjayAtIGEgZnVuY3Rpb24gdGhhdCByZXR1cm5zIGEgcHJvbWlzZSB3aGljaCBpcyByZXNvdmxlZFxuICAgICAqIHdpdGggYW4gb2JqZWN0IG9mIHRoZSBmb2xsb3dpbmcgZm9ybWF0OlxuICAgICAqICAgICAge1xuICAgICAqICAgICAgICAgIHJvd3M6IEFycmF5LFxuICAgICAqICAgICAgICAgIHBhZ2luYXRpb246IHtcbiAgICAgKiAgICAgICAgICAgICAgcGFnZTogTnVtYmVyLFxuICAgICAqICAgICAgICAgICAgICBsaW1pdDogTnVtYmVyLFxuICAgICAqICAgICAgICAgICAgICB0b3RhbDogTnVtYmVyXG4gICAgICogICAgICAgICAgfVxuICAgICAqICAgICAgfVxuICAgICAqXG4gICAgICogVGhpcyBkaXJlY3RpdmUgZXhwb3NlcyBhIHNjb3BlIHZhcmlhYmxlIGNhbGxlZCBiY1NlcnZlclRhYmxlIHRoYXRcbiAgICAgKiBjYW4gYmUgdXNlZCB0byBkaXNwbGF5IGNvbnRlbnQsIGFuZCBpbXBsZW1lbnQgYWRkaXRpb25hbCBmdW5jdGlvbmFsaXR5XG4gICAgICogdG8gdGhlIHRhYmxlIChzdWNoIGFzIHBhZ2luYXRpb24sIHNvcnRpbmcsIGFuZCBzZWxlY3Rpb24gbG9naWMpLlxuICAgICAqXG4gICAgICogLSBiY1NlcnZlclRhYmxlLnJvd3NcbiAgICAgKiAgICAgIC0gQ2FuIGJlIHVzZWQgd2l0aCBuZy1yZXBlYXQgdG8gZGlzcGxheSB0aGUgZGF0YVxuICAgICAqIC0gYmNTZXJ2ZXJUYWJsZS5maWx0ZXJzXG4gICAgICogICAgICAtIENhbiBiZSB1c2VkIHRvIGNoYW5nZS91cGRhdGUgZmlsdGVycy4gVGhlc2UgZmlsdGVycyBtdXN0IGFwcGVhclxuICAgICAqICAgICAgICBpbiB0aGUgc3RhdGUgZGVmaW5pdGlvbiBpbiBvcmRlciB0byB3b3JrIGNvcnJlY3RseS5cbiAgICAgKiAtIGJjU2VydmVyVGFibGUudXBkYXRlVGFibGUoKVxuICAgICAqICAgICAgLSBQZXJmb3JtIGEgc3RhdGUgdHJhbnNpc3Rpb24gd2l0aCB0aGUgY3VycmVudCB0YWJsZSBpbmZvXG4gICAgICogLSBiY1NlcnZlclRhYmxlLnBhZ2luYXRpb25cbiAgICAgKiAgICAgIC0gZXhwb3NlcyBwYWdlLCBsaW1pdCwgYW5kIHRvdGFsXG4gICAgICogLSBiY1NlcnZlclRhYmxlLnNldFBhZ2luYXRpb25WYWx1ZXMocGFnaW5hdGlvbilcbiAgICAgKiAgICAgIC0gY29udmVuaWVuY2UgbWV0aG9kIGZvciBzZXR0aW5nIHBhZ2luYXRpb24gdmFsdWVzIGF0IG9uY2UuXG4gICAgICpcbiAgICAgKiAtIGJjU2VydmVyVGFibGUuc2VsZWN0ZWRSb3dzXG4gICAgICogICAgICAtIGFuIG1hcCBvYmplY3Qgd2l0aCB1bmlxdWUgaWQncyBhcyBrZXlzIGFuZCBib29sZWFuIHZhbHVlcyBhcyB0aGUgc2VsZWN0ZWQgc3RhdGVcbiAgICAgKiAtIGJjU2VydmVyVGFibGUuYWxsU2VsZWN0ZWRcbiAgICAgKiAgICAgIC0gYSBib29sZWFuIHZhbHVlIHVzZWQgdG8gZGV0ZXJtaW5lIGlmIGFsbCByb3dzIHdlcmUgc2VsZWN0ZWQgb3IgY2xlYXJlZFxuICAgICAqIC0gYmNTZXJ2ZXJUYWJsZS5zZWxlY3RBbGxSb3dzKClcbiAgICAgKiAgICAgIC0gdG9nZ2xlIGFsbCByb3dzIHNlbGVjdGlvbiBzdGF0ZVxuICAgICAqIC0gYmNTZXJ2ZXJUYWJsZS5pc1Jvd1NlbGVjdGVkKHJvdylcbiAgICAgKiAgICAgIC0gaGVscGVyIGZ1bmN0aW9uIHRvIGRldGVybWluZSBpZiBhIHJvdyBpcyBzZWxlY3RlZFxuICAgICAqIC0gYmNTZXJ2ZXJUYWJsZS5nZXRTZWxlY3RlZFJvd3MoKVxuICAgICAqICAgICAgLSBmdW5jdGlvbiB0aGF0IHJldHVybnMgYW4gYXJyYXkgb2Ygcm93IG9iamVjdHMgdGhhdCBhcmUgY3VycmVudGx5IHNlbGVjdGVkXG4gICAgICpcbiAgICAgKi9cbiAgICAuZGlyZWN0aXZlKCdiY1NlcnZlclRhYmxlJywgZnVuY3Rpb24gYmNTZXJ2ZXJUYWJsZURpcmVjdGl2ZSgkcGFyc2UpIHtcbiAgICAgICAgdmFyIGRpcmVjdGl2ZSA9IHtcbiAgICAgICAgICAgIHJlc3RyaWN0OiAnRUEnLFxuICAgICAgICAgICAgY29udHJvbGxlcjogJ0JjU2VydmVyVGFibGVDdHJsIGFzIGJjU2VydmVyVGFibGUnLFxuICAgICAgICAgICAgbGluazogZnVuY3Rpb24gYmNTZXJ2ZXJUYWJsZUxpbmsoJHNjb3BlLCBlbGVtZW50LCBhdHRycywgYmNTZXJ2ZXJUYWJsZUN0cmwpIHtcbiAgICAgICAgICAgICAgICBpZiAoYXR0cnMudGFibGVDb250cm9sbGVyKSB7XG4gICAgICAgICAgICAgICAgICAgIC8vIGV4cG9zZSBiY1NlcnZlclRhYmxlQ3RybCB0byB0YWJsZUNvbnRyb2xsZXIgaWYgaXQgZXhpc3RzXG4gICAgICAgICAgICAgICAgICAgICRwYXJzZShhdHRycy50YWJsZUNvbnRyb2xsZXIpLmFzc2lnbigkc2NvcGUsIGJjU2VydmVyVGFibGVDdHJsKTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgIH07XG5cbiAgICAgICAgcmV0dXJuIGRpcmVjdGl2ZTtcbiAgICB9KTtcbiIsImFuZ3VsYXIubW9kdWxlKCdiY2FwcC1wYXR0ZXJuLWxhYi5iYy1zZXJ2ZXItdGFibGUnLCBbXG4gICAgJ2JjYXBwLXBhdHRlcm4tbGFiLmJjLXNlcnZlci10YWJsZS5kaXJlY3RpdmUnLFxuICAgICdiY2FwcC1wYXR0ZXJuLWxhYi5iYy1zZXJ2ZXItdGFibGUuc29ydC1ieS5kaXJlY3RpdmUnLFxuICAgICdiY2FwcC1wYXR0ZXJuLWxhYi5iYy1zZXJ2ZXItdGFibGUtZmFjdG9yeS5zZXJ2aWNlJ1xuXSk7XG4iLCJhbmd1bGFyLm1vZHVsZSgnYmNhcHAtcGF0dGVybi1sYWIuYmMtc2VydmVyLXRhYmxlLnNvcnQtYnkuZGlyZWN0aXZlJywgW1xuICAgICdiY2FwcC1wYXR0ZXJuLWxhYi5iYy1zZXJ2ZXItdGFibGUtZmFjdG9yeS5zZXJ2aWNlJ1xuXSlcbiAgICAuZGlyZWN0aXZlKCdiY1NvcnRCeScsIGZ1bmN0aW9uIGJjU29ydEJ5RGlyZWN0aXZlKCRsb2csIGJjU2VydmVyVGFibGVGYWN0b3J5KSB7XG4gICAgICAgIHZhciBkaXJlY3RpdmUgPSB7XG4gICAgICAgICAgICB0ZW1wbGF0ZVVybDogJ3NyYy9qcy9iaWdjb21tZXJjZS9iYy1zZXJ2ZXItdGFibGUvYmMtc29ydC1ieS50cGwuaHRtbCcsXG4gICAgICAgICAgICByZXN0cmljdDogJ0UnLFxuICAgICAgICAgICAgdHJhbnNjbHVkZTogdHJ1ZSxcbiAgICAgICAgICAgIHNjb3BlOiB7XG4gICAgICAgICAgICAgICAgc29ydFZhbHVlOiAnQCcsXG4gICAgICAgICAgICAgICAgY29sdW1uTmFtZTogJ0AnLFxuICAgICAgICAgICAgICAgIHRhYmxlSWQ6ICdAJ1xuICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIHJlcXVpcmU6ICc/Xl5iY1NlcnZlclRhYmxlJyxcbiAgICAgICAgICAgIGxpbms6IGJjU29ydEJ5RGlyZWN0aXZlTGlua1xuICAgICAgICB9O1xuXG4gICAgICAgIGZ1bmN0aW9uIGJjU29ydEJ5RGlyZWN0aXZlTGluayhzY29wZSwgZWxlbWVudCwgYXR0cnMsIGJjU2VydmVyVGFibGVDdHJsKSB7XG4gICAgICAgICAgICB2YXIgYmNTZXJ2ZXJUYWJsZSxcbiAgICAgICAgICAgICAgICBzb3J0RGlyVmFsdWVzO1xuXG4gICAgICAgICAgICBpZiAoc2NvcGUudGFibGVJZCkge1xuICAgICAgICAgICAgICAgIGJjU2VydmVyVGFibGUgPSBiY1NlcnZlclRhYmxlRmFjdG9yeS5nZXQoc2NvcGUudGFibGVJZCk7XG4gICAgICAgICAgICB9IGVsc2UgaWYgKGJjU2VydmVyVGFibGVDdHJsKSB7XG4gICAgICAgICAgICAgICAgYmNTZXJ2ZXJUYWJsZSA9IGJjU2VydmVyVGFibGVDdHJsO1xuICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgICAkbG9nLmVycm9yKCdiYy1zb3J0LWJ5IGRpcmVjdGl2ZSByZXF1aXJlcyBhIHRhYmxlLWlkLCBvciBhIHBhcmVudCBiY1NlcnZlclRhYmxlQ3RybCBkaXJlY3RpdmUuJyk7XG4gICAgICAgICAgICB9XG5cbiAgICAgICAgICAgIHNvcnREaXJWYWx1ZXMgPSBiY1NlcnZlclRhYmxlLnRhYmxlQ29uZmlnLnNvcnREaXJWYWx1ZXM7XG5cbiAgICAgICAgICAgIHNjb3BlLmFzYyA9IHNvcnREaXJWYWx1ZXMuYXNjO1xuICAgICAgICAgICAgc2NvcGUuZGVzYyA9IHNvcnREaXJWYWx1ZXMuZGVzYztcbiAgICAgICAgICAgIHNjb3BlLnNvcnRCeSA9IGJjU2VydmVyVGFibGUuc29ydEJ5O1xuICAgICAgICAgICAgc2NvcGUuc29ydERpciA9IGJjU2VydmVyVGFibGUuc29ydERpcjtcbiAgICAgICAgICAgIHNjb3BlLnNvcnQgPSBzb3J0O1xuXG4gICAgICAgICAgICBmdW5jdGlvbiBzb3J0KCRldmVudCkge1xuICAgICAgICAgICAgICAgIHZhciBzb3J0QnksXG4gICAgICAgICAgICAgICAgICAgIHNvcnREaXI7XG5cbiAgICAgICAgICAgICAgICBpZiAoJGV2ZW50KSB7XG4gICAgICAgICAgICAgICAgICAgICRldmVudC5wcmV2ZW50RGVmYXVsdCgpO1xuICAgICAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgICAgIGlmIChiY1NlcnZlclRhYmxlLnNvcnRCeSA9PT0gc2NvcGUuc29ydFZhbHVlKSB7XG4gICAgICAgICAgICAgICAgICAgIHNvcnRCeSA9IGJjU2VydmVyVGFibGUuc29ydEJ5O1xuICAgICAgICAgICAgICAgICAgICBzb3J0RGlyID0gYmNTZXJ2ZXJUYWJsZS5zb3J0RGlyID09PSBzY29wZS5hc2MgPyBzY29wZS5kZXNjIDogc2NvcGUuYXNjO1xuICAgICAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgICAgICAgIHNvcnRCeSA9IHNjb3BlLnNvcnRWYWx1ZTtcbiAgICAgICAgICAgICAgICAgICAgc29ydERpciA9IHNjb3BlLmFzYztcbiAgICAgICAgICAgICAgICB9XG5cbiAgICAgICAgICAgICAgICBiY1NlcnZlclRhYmxlLnVwZGF0ZVNvcnQoc29ydEJ5LCBzb3J0RGlyKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuXG4gICAgICAgIHJldHVybiBkaXJlY3RpdmU7XG4gICAgfSk7XG4iLCJhbmd1bGFyLm1vZHVsZSgnYmNhcHAtcGF0dGVybi1sYWIuY2hlY2tib3gtbGlzdC5jb250cm9sbGVyJywgW10pXG4gICAgLmNvbnRyb2xsZXIoJ0NoZWNrYm94TGlzdEN0cmwnLCBmdW5jdGlvbiBDaGVja2JveExpc3RDdHJsKCRhdHRycywgJGVsZW1lbnQsICRsb2csICRwYXJzZSwgJHNjb3BlKSB7XG4gICAgICAgIHZhciBjdHJsID0gdGhpcyxcbiAgICAgICAgICAgIGZhbHNlVmFsdWUgPSAkcGFyc2UoJGF0dHJzLm5nRmFsc2VWYWx1ZSkoY3RybCkgfHwgZmFsc2UsXG4gICAgICAgICAgICB0cnVlVmFsdWUgPSAkcGFyc2UoJGF0dHJzLm5nVHJ1ZVZhbHVlKShjdHJsKSB8fCB0cnVlLFxuICAgICAgICAgICAgbmdNb2RlbCA9ICRlbGVtZW50LmNvbnRyb2xsZXIoJ25nTW9kZWwnKTtcblxuICAgICAgICBpbml0KCk7XG5cbiAgICAgICAgLy8gR2V0dGVyc1xuICAgICAgICBmdW5jdGlvbiBnZXRNb2RlbFZhbHVlKCkge1xuICAgICAgICAgICAgcmV0dXJuIG5nTW9kZWwuJG1vZGVsVmFsdWU7XG4gICAgICAgIH1cblxuICAgICAgICBmdW5jdGlvbiBnZXRWYWx1ZSgpIHtcbiAgICAgICAgICAgIHJldHVybiBjdHJsLnZhbHVlIHx8IGN0cmwubmdWYWx1ZTtcbiAgICAgICAgfVxuXG4gICAgICAgIGZ1bmN0aW9uIGdldFNlbGVjdGVkVmFsdWVzKCkge1xuICAgICAgICAgICAgcmV0dXJuIGN0cmwuc2VsZWN0ZWRWYWx1ZXM7XG4gICAgICAgIH1cblxuICAgICAgICAvLyBTZXR0ZXJzXG4gICAgICAgIGZ1bmN0aW9uIHVwZGF0ZU1vZGVsVmFsdWUobW9kZWxWYWx1ZSkge1xuICAgICAgICAgICAgbmdNb2RlbC4kc2V0Vmlld1ZhbHVlKG1vZGVsVmFsdWUpO1xuICAgICAgICAgICAgbmdNb2RlbC4kY29tbWl0Vmlld1ZhbHVlKCk7XG4gICAgICAgICAgICBuZ01vZGVsLiRyZW5kZXIoKTtcbiAgICAgICAgfVxuXG4gICAgICAgIGZ1bmN0aW9uIHVwZGF0ZVNlbGVjdGVkVmFsdWVzKG1vZGVsVmFsdWUpIHtcbiAgICAgICAgICAgIGlmIChtb2RlbFZhbHVlID09PSB0cnVlVmFsdWUpIHtcbiAgICAgICAgICAgICAgICBhZGRUb1NlbGVjdGVkVmFsdWVzKCk7XG4gICAgICAgICAgICB9IGVsc2UgaWYgKG1vZGVsVmFsdWUgPT09IGZhbHNlVmFsdWUpIHtcbiAgICAgICAgICAgICAgICByZW1vdmVGcm9tU2VsZWN0ZWRWYWx1ZXMoKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuXG4gICAgICAgIGZ1bmN0aW9uIGFkZFRvU2VsZWN0ZWRWYWx1ZXMoKSB7XG4gICAgICAgICAgICB2YXIgaXNJbmNsdWRlZCA9IF8uaW5jbHVkZShjdHJsLnNlbGVjdGVkVmFsdWVzLCBnZXRWYWx1ZSgpKTtcblxuICAgICAgICAgICAgaWYgKCFpc0luY2x1ZGVkKSB7XG4gICAgICAgICAgICAgICAgY3RybC5zZWxlY3RlZFZhbHVlcy5wdXNoKGdldFZhbHVlKCkpO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG5cbiAgICAgICAgZnVuY3Rpb24gcmVtb3ZlRnJvbVNlbGVjdGVkVmFsdWVzKCkge1xuICAgICAgICAgICAgdmFyIGluZGV4ID0gXy5pbmRleE9mKGN0cmwuc2VsZWN0ZWRWYWx1ZXMsIGdldFZhbHVlKCkpO1xuXG4gICAgICAgICAgICBpZiAoaW5kZXggIT09IC0xKSB7XG4gICAgICAgICAgICAgICAgY3RybC5zZWxlY3RlZFZhbHVlcy5zcGxpY2UoaW5kZXgsIDEpO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG5cbiAgICAgICAgLy8gV2F0Y2hlcnNcbiAgICAgICAgZnVuY3Rpb24gbW9kZWxWYWx1ZVdhdGNoKG1vZGVsVmFsdWUsIG9sZE1vZGVsVmFsdWUpIHtcbiAgICAgICAgICAgIHZhciBvbGRTZWxlY3RlZFZhbHVlcyxcbiAgICAgICAgICAgICAgICBzZWxlY3RlZFZhbHVlc0NoYW5nZWQ7XG5cbiAgICAgICAgICAgIC8vIFdoZW4gbmdNb2RlbCB2YWx1ZSBjaGFuZ2VzXG4gICAgICAgICAgICBpZiAoXy5pc1VuZGVmaW5lZChtb2RlbFZhbHVlKSB8fCBtb2RlbFZhbHVlID09PSBvbGRNb2RlbFZhbHVlKSB7XG4gICAgICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAvLyBSZXRhaW4gYSBzaGFsbG93IGNvcHkgb2Ygc2VsZWN0ZWRWYWx1ZXMgYmVmb3JlIHVwZGF0ZVxuICAgICAgICAgICAgb2xkU2VsZWN0ZWRWYWx1ZXMgPSBjdHJsLnNlbGVjdGVkVmFsdWVzLnNsaWNlKCk7XG5cbiAgICAgICAgICAgIC8vIFVwZGF0ZSBzZWxlY3RlZFZhbHVlc1xuICAgICAgICAgICAgdXBkYXRlU2VsZWN0ZWRWYWx1ZXMobW9kZWxWYWx1ZSk7XG5cbiAgICAgICAgICAgIC8vIERldGVybWluZSBpZiBzZWxlY3RlZFZhbHVlcyBhcnJheSBoYXMgY2hhbmdlZFxuICAgICAgICAgICAgc2VsZWN0ZWRWYWx1ZXNDaGFuZ2VkID0gISFfLnhvcihjdHJsLnNlbGVjdGVkVmFsdWVzLCBvbGRTZWxlY3RlZFZhbHVlcykubGVuZ3RoO1xuXG4gICAgICAgICAgICAvLyBJZiBjaGFuZ2VkLCBldm9rZSBkZWxlZ2F0ZSBtZXRob2QgKGlmIGRlZmluZWQpXG4gICAgICAgICAgICBpZiAoY3RybC5vbkNoYW5nZSAmJiBzZWxlY3RlZFZhbHVlc0NoYW5nZWQpIHtcbiAgICAgICAgICAgICAgICBjdHJsLm9uQ2hhbmdlKHtcbiAgICAgICAgICAgICAgICAgICAgc2VsZWN0ZWRWYWx1ZXM6IGN0cmwuc2VsZWN0ZWRWYWx1ZXMsXG4gICAgICAgICAgICAgICAgICAgIG9sZFNlbGVjdGVkVmFsdWVzOiBvbGRTZWxlY3RlZFZhbHVlc1xuICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG5cbiAgICAgICAgZnVuY3Rpb24gc2VsZWN0ZWRWYWx1ZXNXYXRjaChzZWxlY3RlZFZhbHVlcykge1xuICAgICAgICAgICAgLy8gV2hlbiBzZWxlY3RlZFZhbHVlcyBjb2xsZWN0aW9uIGNoYW5nZXNcbiAgICAgICAgICAgIHZhciBpc0luY2x1ZGVkID0gXy5pbmNsdWRlKHNlbGVjdGVkVmFsdWVzLCBnZXRWYWx1ZSgpKSxcbiAgICAgICAgICAgICAgICBtb2RlbFZhbHVlID0gZ2V0TW9kZWxWYWx1ZSgpO1xuXG4gICAgICAgICAgICBpZiAoaXNJbmNsdWRlZCAmJiBtb2RlbFZhbHVlICE9PSB0cnVlVmFsdWUpIHtcbiAgICAgICAgICAgICAgICB1cGRhdGVNb2RlbFZhbHVlKHRydWVWYWx1ZSk7XG4gICAgICAgICAgICB9IGVsc2UgaWYgKCFpc0luY2x1ZGVkICYmIG1vZGVsVmFsdWUgIT09IGZhbHNlVmFsdWUpIHtcbiAgICAgICAgICAgICAgICB1cGRhdGVNb2RlbFZhbHVlKGZhbHNlVmFsdWUpO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG5cbiAgICAgICAgLy8gSW5pdGlhbGl6ZXJcbiAgICAgICAgZnVuY3Rpb24gaW5pdCgpIHtcbiAgICAgICAgICAgIGlmICgkYXR0cnMudHlwZSAhPT0gJ2NoZWNrYm94Jykge1xuICAgICAgICAgICAgICAgICRsb2cuZXJyb3IoJ2NoZWNrYm94LWxpc3QgZGlyZWN0aXZlOiBlbGVtZW50IG11c3QgYmUgPGlucHV0IHR5cGU9XCJjaGVja2JveFwiPicpO1xuXG4gICAgICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAkc2NvcGUuJHdhdGNoKGdldE1vZGVsVmFsdWUsIG1vZGVsVmFsdWVXYXRjaCk7XG4gICAgICAgICAgICAkc2NvcGUuJHdhdGNoQ29sbGVjdGlvbihnZXRTZWxlY3RlZFZhbHVlcywgc2VsZWN0ZWRWYWx1ZXNXYXRjaCk7XG4gICAgICAgIH1cbiAgICB9KTtcbiIsImFuZ3VsYXIubW9kdWxlKCdiY2FwcC1wYXR0ZXJuLWxhYi5jaGVja2JveC1saXN0LmRpcmVjdGl2ZScsIFtcbiAgICAnYmNhcHAtcGF0dGVybi1sYWIuY2hlY2tib3gtbGlzdC5jb250cm9sbGVyJ1xuXSlcblxuICAgIC8qKlxuICAgICAqIEEgZGlyZWN0aXZlIGZvciBjb2xsYXRpbmcgdmFsdWVzIGZyb20gYW4gYXJyYXkgb2YgY2hlY2tib3hlcy5cbiAgICAgKlxuICAgICAqIEByZXF1aXJlIG5nTW9kZWxcbiAgICAgKiBAcGFyYW0ge0FycmF5LjxzdHJpbmd8bnVtYmVyfE9iamVjdD59IGNoZWNrYm94TGlzdCAtIEFycmF5IHRvIGhvbGQgc2VsZWN0ZWQgdmFsdWVzXG4gICAgICogQHBhcmFtIHsqfSB2YWx1ZSAtIFZhbHVlIHRvIGFkZCB0byBjaGVja2JveExpc3RcbiAgICAgKiBAcGFyYW0ge2Z1bmN0aW9uKHNlbGVjdGVkVmFsdWVzLCBvbGRTZWxlY3RlZFZhbHVlc30gW2NoZWNrYm94TGlzdENoYW5nZV0gLSBPcHRpb25hbCBvbkNoYW5nZSBjYWxsYmFja1xuICAgICAqXG4gICAgICogQGV4YW1wbGU6XG4gICAgICogYGBgaHRtbFxuICAgICAqIDxkaXYgbmctcmVwZWF0PVwib3B0aW9uIGluIG9wdGlvbnNcIj5cbiAgICAgKiAgICAgPGlucHV0IHR5cGU9XCJjaGVja2JveFwiIFxuICAgICAqICAgICAgICAgbmFtZT1cIm9wdGlvbnt7IG9wdGlvbi5pZCB9fVwiXG4gICAgICogICAgICAgICB2YWx1ZT1cIm9wdGlvbi5pZFwiIFxuICAgICAqICAgICAgICAgY2hlY2tib3gtbGlzdD1cInNlbGVjdGVkVmFsdWVzXCIgXG4gICAgICogICAgICAgICBjaGVja2JveC1saXN0LWNoYW5nZT1cIm9uQ2hhbmdlKHNlbGVjdGVkVmFsdWVzKVwiIFxuICAgICAqICAgICAgICAgbmctbW9kZWw9XCJvcHRpb24uY2hlY2tlZFwiXG4gICAgICogICAgIC8+XG4gICAgICogPC9kaXY+XG4gICAgICogYGBgXG4gICAgICogXG4gICAgICogYGBganNcbiAgICAgKiBzY29wZS5zZWxlY3RlZFZhbHVlcyA9IFtdO1xuICAgICAqIHNjb3BlLm9wdGlvbnMgPSBbXG4gICAgICogICAgIHtcbiAgICAgKiAgICAgICAgIGlkOiAxLFxuICAgICAqICAgICAgICAgbGFiZWw6ICdPcHRpb24gMSdcbiAgICAgKiAgICAgfSxcbiAgICAgKiAgICAge1xuICAgICAqICAgICAgICAgaWQ6IDIsXG4gICAgICogICAgICAgICBsYWJlbDogJ09wdGlvbiAyJ1xuICAgICAqICAgICB9LFxuICAgICAqICAgICB7XG4gICAgICogICAgICAgICBpZDogMyxcbiAgICAgKiAgICAgICAgIGxhYmVsOiAnT3B0aW9uIDMnXG4gICAgICogICAgIH1cbiAgICAgKiBdO1xuICAgICAqIFxuICAgICAqIHNjb3BlLm9uQ2hhbmdlID0gZnVuY3Rpb24gb25DaGFuZ2Uoc2VsZWN0ZWRWYWx1ZXMpIHtcbiAgICAgKiAgICAgY29uc29sZS5sb2coc2VsZWN0ZWRWYWx1ZXMpO1xuICAgICAqIH07XG4gICAgICogYGBgXG4gICAgICogXG4gICAgICogV2hlbiBvcHRpb25zWzBdIGFuZCBvcHRpb25zWzFdIGFyZSBjaGVja2VkLCBzZWxlY3RlZFZhbHVlcyBzaG91bGQgYmUgWzEsIDJdXG4gICAgICogYW5kIG9uQ2hhbmdlIHdpbGwgYmUgZXZva2VkLiBUaGlzIGRpcmVjdGl2ZSBhbHNvIHdvcmtzIHdpdGggYW4gYXJyYXkgb2YgcHJpbWl0aXZlIHZhbHVlcy5cbiAgICAgKiBpLmUuOiBzY29wZS5vcHRpb25zID0gW1wiYVwiLCBcImJcIiwgXCJjXCJdLlxuICAgICAqL1xuXG4gICAgLmRpcmVjdGl2ZSgnY2hlY2tib3hMaXN0JywgZnVuY3Rpb24gY2hlY2tib3hMaXN0RGlyZWN0aXZlKCkge1xuICAgICAgICByZXR1cm4ge1xuICAgICAgICAgICAgcmVzdHJpY3Q6ICdBJyxcbiAgICAgICAgICAgIHJlcXVpcmU6ICduZ01vZGVsJyxcbiAgICAgICAgICAgIGNvbnRyb2xsZXI6ICdDaGVja2JveExpc3RDdHJsJyxcbiAgICAgICAgICAgIGNvbnRyb2xsZXJBczogJ2NoZWNrYm94TGlzdEN0cmwnLFxuICAgICAgICAgICAgYmluZFRvQ29udHJvbGxlcjogdHJ1ZSxcbiAgICAgICAgICAgIHNjb3BlOiB7XG4gICAgICAgICAgICAgICAgb25DaGFuZ2U6ICcmY2hlY2tib3hMaXN0Q2hhbmdlJyxcbiAgICAgICAgICAgICAgICBzZWxlY3RlZFZhbHVlczogJz1jaGVja2JveExpc3QnLFxuICAgICAgICAgICAgICAgIHZhbHVlOiAnPScsXG4gICAgICAgICAgICAgICAgbmdWYWx1ZTogJz0nXG4gICAgICAgICAgICB9XG4gICAgICAgIH07XG4gICAgfSk7XG4iLCJhbmd1bGFyLm1vZHVsZSgnYmNhcHAtcGF0dGVybi1sYWIuY2hlY2tib3gtbGlzdCcsIFtcbiAgICAnYmNhcHAtcGF0dGVybi1sYWIuY2hlY2tib3gtbGlzdC5kaXJlY3RpdmUnXG5dKTtcbiIsIi8qKlxuICogQG5hbWUgY3JlZGl0LWNhcmQgZGlyZWN0aXZlXG4gKiBAZGVzY3JpcHRpb24gQ29tcG9uZW50IGNvbnRhaW5pbmcgY2MgbnVtYmVyLCBjdmMsIG5hbWUsIGFuZCBleHBpcnkuIEhhcyBhbiBpc29sYXRlZCBzY29wZSB3aXRoIG5vIGNvbnRyb2xsZXIuXG4gKiBAcmVxdWlyZSBmb3JtXG4gKlxuICogQHBhcmFtIGNjRGF0YSB7b2JqZWN0fSBDb250YWlucyBjY051bWJlciwgY2NUeXBlLCBjY0V4cGlyeSwgYW5kIGNjTmFtZVxuICogQHBhcmFtIGNjQ29uZmlnIHtvYmplY3R9IFRoZSBjb25maWd1cmF0aW9uIG9iamVjdC4gQ3VycmVudGx5IHN1cHBvcnRpbmcgYGNhcmRDb2RlYCBhbmQgYGZ1bGxOYW1lYCwgYm90aCBib29sZWFuIHRvIGluZGljYXRlXG4gKiB3aGV0aGVyIHRoZSByZXNwZWN0aXZlIGZpZWxkcyBzaG91bGQgYmUgc2hvd25cbiAqL1xuYW5ndWxhci5tb2R1bGUoJ2JjYXBwLXBhdHRlcm4tbGFiLmNyZWRpdC1jYXJkLmRpcmVjdGl2ZScsIFtdKVxuICAgIC5kaXJlY3RpdmUoJ2NyZWRpdENhcmQnLCBmdW5jdGlvbiBjcmVkaXRDYXJkRGlyZWN0aXZlKCkge1xuICAgICAgICByZXR1cm4ge1xuICAgICAgICAgICAgbGluazogZnVuY3Rpb24gY3JlZGl0Q2FyZExpbmsoc2NvcGUsIGVsZW0sIGF0dHIsIGZvcm1DdHJsKSB7XG4gICAgICAgICAgICAgICAgY29uc3QgZGVmYXVsdENvbmZpZyA9IHtcbiAgICAgICAgICAgICAgICAgICAgY2FyZENvZGU6IHRydWUsXG4gICAgICAgICAgICAgICAgICAgIGZ1bGxOYW1lOiB0cnVlLFxuICAgICAgICAgICAgICAgIH07XG5cbiAgICAgICAgICAgICAgICBzY29wZS5jY0NvbmZpZyA9IF8uZGVmYXVsdHMoc2NvcGUuY2NDb25maWcsIGRlZmF1bHRDb25maWcpO1xuXG4gICAgICAgICAgICAgICAgLyoqXG4gICAgICAgICAgICAgICAgICogVGhlIGNyZWRpdCBjYXJkIHR5cGUgaXMgZGVkdWNlZCBieSB0aGUgYGNjTnVtYmVyYCBkaXJlY3RpdmUuIFRoaXMgaXMgaW4gdHVybiBleHBvc2VkXG4gICAgICAgICAgICAgICAgICogYXMgYCRjY0VhZ2VyVHlwZWAgb24gdGhlIGlucHV0IGNvbnRyb2wgZWxlbWVudC4gV2F0Y2ggZm9yIGNoYW5nZXMgYW5kIGJpbmQgdGhlIHR5cGUgdG8gdGhlIGNvcnJlc3BvbmRpbmdcbiAgICAgICAgICAgICAgICAgKiB2YWx1ZSBvbiBjY0RhdGEuXG4gICAgICAgICAgICAgICAgICovXG4gICAgICAgICAgICAgICAgc2NvcGUuJHdhdGNoKGdldENjVHlwZSwgc2V0Q2NUeXBlKTtcblxuICAgICAgICAgICAgICAgIHNjb3BlLmZvcm1DdHJsID0gZm9ybUN0cmw7XG5cbiAgICAgICAgICAgICAgICBmdW5jdGlvbiBnZXRDY1R5cGUoKSB7XG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBmb3JtQ3RybC5jY051bWJlci4kY2NFYWdlclR5cGU7XG4gICAgICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAgICAgZnVuY3Rpb24gc2V0Q2NUeXBlKHR5cGUpIHtcbiAgICAgICAgICAgICAgICAgICAgc2NvcGUuY2NEYXRhLmNjVHlwZSA9IHR5cGU7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIHJlcXVpcmU6ICdeZm9ybScsXG4gICAgICAgICAgICByZXN0cmljdDogJ0VBJyxcbiAgICAgICAgICAgIHNjb3BlOiB7XG4gICAgICAgICAgICAgICAgY2NEYXRhOiAnPScsXG4gICAgICAgICAgICAgICAgY2NDb25maWc6ICc9JyxcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICB0ZW1wbGF0ZVVybDogJ3NyYy9qcy9iaWdjb21tZXJjZS9jcmVkaXQtY2FyZC9jcmVkaXQtY2FyZC50cGwuaHRtbCdcbiAgICAgICAgfTtcbiAgICB9KTtcbiIsImFuZ3VsYXIubW9kdWxlKCdiY2FwcC1wYXR0ZXJuLWxhYi5jcmVkaXQtY2FyZCcsIFtcbiAgICAnY3JlZGl0LWNhcmRzJyxcbiAgICAnYmNhcHAtcGF0dGVybi1sYWIuY3JlZGl0LWNhcmQuY2MtZXhwaXJ5JyxcbiAgICAnYmNhcHAtcGF0dGVybi1sYWIuY3JlZGl0LWNhcmQuZGlyZWN0aXZlJyxcbiAgICAnZ2V0dGV4dCcsXG5dKTtcbiIsImFuZ3VsYXIubW9kdWxlKCdiY2FwcC1wYXR0ZXJuLWxhYi5mb3JtLmRpcmVjdGl2ZScsIFtdKVxuICAgIC5kaXJlY3RpdmUoJ2Zvcm0nLCBmdW5jdGlvbiBmb3JtRGlyZWN0aXZlKCkge1xuICAgICAgICByZXR1cm4ge1xuICAgICAgICAgICAgcmVzdHJpY3Q6ICdFJyxcbiAgICAgICAgICAgIGxpbms6IGZ1bmN0aW9uIGZvcm1MaW5rKHNjb3BlLCBlbGVtZW50LCBhdHRycykge1xuICAgICAgICAgICAgICAgIGVsZW1lbnQuYWRkQ2xhc3MoJ2Zvcm0nKTtcbiAgICAgICAgICAgICAgICBlbGVtZW50LmF0dHIoJ25vdmFsaWRhdGUnLCAnJyk7XG5cbiAgICAgICAgICAgICAgICAvLyBVc2UgZGlzYWJsZS1hdXRvLWZvY3VzPVwidHJ1ZVwiIHRvIHR1cm4gb2ZmIGF1dG9tYXRpYyBlcnJvciBmb2N1c2luZ1xuICAgICAgICAgICAgICAgIGlmICghYXR0cnMuZGlzYWJsZUF1dG9Gb2N1cykge1xuICAgICAgICAgICAgICAgICAgICBlbGVtZW50Lm9uKCdzdWJtaXQnLCBmdW5jdGlvbiBmb3JtQXV0b0ZvY3VzU3VibWl0SGFuZGxlcigpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHZhciBpbnZhbGlkRmllbGQgPSBlbGVtZW50WzBdLnF1ZXJ5U2VsZWN0b3IoJy5uZy1pbnZhbGlkJyk7XG5cbiAgICAgICAgICAgICAgICAgICAgICAgIGlmIChpbnZhbGlkRmllbGQpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpbnZhbGlkRmllbGQuZm9jdXMoKTtcblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vIEF1dG8tc2VsZWN0IGV4aXN0aW5nIHRleHQgZm9yIGZpZWxkcyB0aGF0IHN1cHBvcnQgaXQgKHRleHQsIGVtYWlsLCBwYXNzd29yZCwgZXRjLilcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAoaW52YWxpZEZpZWxkLnNlbGVjdCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpbnZhbGlkRmllbGQuc2VsZWN0KCk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgIH07XG4gICAgfSk7XG4iLCJhbmd1bGFyLm1vZHVsZSgnYmNhcHAtcGF0dGVybi1sYWIuZm9ybScsIFtcbiAgICAnYmNhcHAtcGF0dGVybi1sYWIuZm9ybS5kaXJlY3RpdmUnXG5dKTtcbiIsImFuZ3VsYXIubW9kdWxlKCdiY2FwcC1wYXR0ZXJuLWxhYi5mb3JtLWZpZWxkLmRpcmVjdGl2ZScsIFtdKVxuICAgIC5kaXJlY3RpdmUoJ2Zvcm1GaWVsZCcsIGZ1bmN0aW9uIGZvcm1GaWVsZERpcmVjdGl2ZSgkbG9nKSB7XG4gICAgICAgIHJldHVybiB7XG4gICAgICAgICAgICByZXF1aXJlOiAnXmZvcm0nLFxuICAgICAgICAgICAgcmVzdHJpY3Q6ICdFQScsXG4gICAgICAgICAgICBzY29wZTogdHJ1ZSxcbiAgICAgICAgICAgIGxpbms6IHtcbiAgICAgICAgICAgICAgICBwcmU6IGZ1bmN0aW9uIGZvcm1GaWVsZExpbmsoc2NvcGUsIGVsZW1lbnQsIGF0dHJzKSB7XG4gICAgICAgICAgICAgICAgICAgIC8vIEluaGVyaXRlZCBieSB0aGUgZm9ybS1maWVsZC1lcnJvcnMgZGlyZWN0aXZlIHRvIGF2b2lkIHJlZGVjbGFyYXRpb25cbiAgICAgICAgICAgICAgICAgICAgc2NvcGUucHJvcGVydHkgPSBhdHRycy5wcm9wZXJ0eTtcbiAgICAgICAgICAgICAgICB9LFxuXG4gICAgICAgICAgICAgICAgcG9zdDogZnVuY3Rpb24gZm9ybUZpZWxkTGluayhzY29wZSwgZWxlbWVudCwgYXR0cnMsIGZvcm1DdHJsKSB7XG4gICAgICAgICAgICAgICAgICAgIC8vIExvY2F0ZXMgYW5kIHdhdGNoZXMgdGhlIG1hdGNoaW5nIGlucHV0L3NlbGVjdC9ldGMgKGJhc2VkIG9uIGl0cyBuYW1lIGF0dHJpYnV0ZSkgaW4gdGhlIHBhcmVudCBmb3JtXG4gICAgICAgICAgICAgICAgICAgIHZhciBwcm9wZXJ0eSA9IGF0dHJzLnByb3BlcnR5LFxuICAgICAgICAgICAgICAgICAgICAgICAgcHJvcGVydHlWYWxpZEZuID0gZnVuY3Rpb24gcHJvcGVydHlWYWxpZEZuKCkgeyByZXR1cm4gZm9ybUN0cmxbcHJvcGVydHldLiR2YWxpZDsgfSxcbiAgICAgICAgICAgICAgICAgICAgICAgIGZvcm1TdWJtaXR0ZWRGbiA9IGZ1bmN0aW9uIGZvcm1TdWJtaXR0ZWRGbigpIHsgcmV0dXJuIGZvcm1DdHJsLiRzdWJtaXR0ZWQ7IH07XG5cbiAgICAgICAgICAgICAgICAgICAgZWxlbWVudC5hZGRDbGFzcygnZm9ybS1maWVsZCcpO1xuXG4gICAgICAgICAgICAgICAgICAgIC8vIElmIGEgcHJvcGVydHkgd2Fzbid0IHByb3ZpZGVkLCB3ZSBjYW4ndCBkbyBtdWNoIGVsc2VcbiAgICAgICAgICAgICAgICAgICAgaWYgKCFwcm9wZXJ0eSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICAgICAgICAgICAgICB9XG5cbiAgICAgICAgICAgICAgICAgICAgLy8gSWYgYSBwcm9wZXJ0eSB3YXMgcHJvdmlkZWQsIGJ1dCBubyBuZy1tb2RlbCB3YXMgZGVmaW5lZCBmb3IgdGhlIGZpZWxkLCB2YWxpZGF0aW9uIHdvbid0IHdvcmtcbiAgICAgICAgICAgICAgICAgICAgaWYgKCFmb3JtQ3RybFtwcm9wZXJ0eV0pIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiAkbG9nLmluZm8oJ0Zvcm0gZmllbGRzIGNvbnRhaW5pbmcgaW5wdXRzIHdpdGhvdXQgYW4gbmctbW9kZWwgcHJvcGVydHkgd2lsbCBub3QgYmUgdmFsaWRhdGVkJyk7XG4gICAgICAgICAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgICAgICAgICBpbml0KCk7XG5cbiAgICAgICAgICAgICAgICAgICAgZnVuY3Rpb24gaW5pdCgpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIC8vIFVwZGF0ZSB0aGUgaW50ZXJmYWNlIGlmIHRoZSBmb3JtIGlzIHN1Ym1pdHRlZCBvciB0aGUgcHJvcGVydHkncyB2YWxpZGl0eSBzdGF0ZSBjaGFuZ2VzXG4gICAgICAgICAgICAgICAgICAgICAgICBzY29wZS4kd2F0Y2goZm9ybVN1Ym1pdHRlZEZuLCBjaGVja1ZhbGlkaXR5KTtcbiAgICAgICAgICAgICAgICAgICAgICAgIHNjb3BlLiR3YXRjaChwcm9wZXJ0eVZhbGlkRm4sIGNoZWNrVmFsaWRpdHkpO1xuICAgICAgICAgICAgICAgICAgICB9XG5cbiAgICAgICAgICAgICAgICAgICAgZnVuY3Rpb24gY2hlY2tWYWxpZGl0eSgpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIC8vIE9ubHkgc2hvdyBhbiBlcnJvciBpZiB0aGUgdXNlciBoYXMgYWxyZWFkeSBhdHRlbXB0ZWQgdG8gc3VibWl0IHRoZSBmb3JtXG4gICAgICAgICAgICAgICAgICAgICAgICBlbGVtZW50LnRvZ2dsZUNsYXNzKCdmb3JtLWZpZWxkLS1lcnJvcicsIGZvcm1DdHJsLiRzdWJtaXR0ZWQgJiYgZm9ybUN0cmxbcHJvcGVydHldLiRpbnZhbGlkKTtcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgfTtcbiAgICB9KTtcbiIsImFuZ3VsYXIubW9kdWxlKCdiY2FwcC1wYXR0ZXJuLWxhYi5mb3JtLWZpZWxkJywgW1xuICAgICdiY2FwcC1wYXR0ZXJuLWxhYi5mb3JtLWZpZWxkLmRpcmVjdGl2ZScsXG4gICAgJ2JjYXBwLXBhdHRlcm4tbGFiLmZvcm0tZmllbGQtZXJyb3InLFxuICAgICdiY2FwcC1wYXR0ZXJuLWxhYi5mb3JtLWZpZWxkLWVycm9ycydcbl0pO1xuIiwiYW5ndWxhci5tb2R1bGUoJ2JjYXBwLXBhdHRlcm4tbGFiLmZvcm0tZmllbGQtZXJyb3JzLmRpcmVjdGl2ZScsIFtdKVxuICAgIC5kaXJlY3RpdmUoJ2Zvcm1GaWVsZEVycm9ycycsIGZ1bmN0aW9uIGZvcm1GaWVsZEVycm9yc0RpcmVjdGl2ZSgpIHtcbiAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICAgIHJlcGxhY2U6IHRydWUsXG4gICAgICAgICAgICByZXF1aXJlOiAnXmZvcm0nLFxuICAgICAgICAgICAgcmVzdHJpY3Q6ICdFQScsXG4gICAgICAgICAgICB0ZW1wbGF0ZVVybDogJ3NyYy9qcy9iaWdjb21tZXJjZS9mb3JtLWZpZWxkLWVycm9ycy9mb3JtLWZpZWxkLWVycm9ycy50cGwuaHRtbCcsXG4gICAgICAgICAgICB0cmFuc2NsdWRlOiB0cnVlLFxuICAgICAgICAgICAgbGluazoge1xuICAgICAgICAgICAgICAgIC8vIFByZS1saW5rIGlzIHJlcXVpcmVkLCBhcyB3ZSBoYXZlIHRvIGluamVjdCBvdXIgc2NvcGUgcHJvcGVydGllcyBiZWZvcmUgdGhlIGNoaWxkXG4gICAgICAgICAgICAgICAgLy8gZm9ybS1maWVsZC1lcnJvciBkaXJlY3RpdmUgKGFuZCBpdHMgaW50ZXJuYWwgbmctbWVzc2FnZSBkaXJlY3RpdmUncykgcG9zdC1saW5rIGZ1bmN0aW9uc1xuICAgICAgICAgICAgICAgIHByZTogZnVuY3Rpb24gZm9ybUZpZWxkRXJyb3JzUHJlTGluayhzY29wZSwgZWxlbWVudCwgYXR0cnMsIGZvcm1DdHJsKSB7XG4gICAgICAgICAgICAgICAgICAgIC8vIFByb3BlcnR5IG5hbWUgY2FuIGJlIGluaGVyaXRlZCBmcm9tIHBhcmVudCBzY29wZSwgc3VjaCBhcyBmcm9tIHRoZSBmb3JtLWZpZWxkIGRpcmVjdGl2ZVxuICAgICAgICAgICAgICAgICAgICB2YXIgcHJvcGVydHkgPSBzY29wZS5wcm9wZXJ0eSB8fCBhdHRycy5wcm9wZXJ0eSxcbiAgICAgICAgICAgICAgICAgICAgICAgIHByb3BlcnR5RmllbGQgPSBmb3JtQ3RybFtwcm9wZXJ0eV07XG5cbiAgICAgICAgICAgICAgICAgICAgLy8gSW5oZXJpdGVkIGJ5IGZvcm0tZmllbGQtZXJyb3IgZGlyZWN0aXZlLiBMaXZlcyBkaXJlY3RseSBvbiBzY29wZSBiZWNhdXNlIHRoZSByZXF1aXJlXG4gICAgICAgICAgICAgICAgICAgIC8vIHByb3BlcnR5IGRvZXMgbm90IHdvcmsgd2VsbCB3aXRoIGRpcmVjdGl2ZSBjb250cm9sbGVyIGluc3RhbmNlc1xuICAgICAgICAgICAgICAgICAgICBzY29wZS5mb3JtQ3RybCA9IGZvcm1DdHJsO1xuICAgICAgICAgICAgICAgICAgICBzY29wZS5wcm9wZXJ0eSA9IHByb3BlcnR5O1xuICAgICAgICAgICAgICAgICAgICBzY29wZS5wcm9wZXJ0eUZpZWxkID0gcHJvcGVydHlGaWVsZDtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgIH07XG4gICAgfSk7XG4iLCJhbmd1bGFyLm1vZHVsZSgnYmNhcHAtcGF0dGVybi1sYWIuZm9ybS1maWVsZC1lcnJvcnMnLCBbXG4gICAgJ2JjYXBwLXBhdHRlcm4tbGFiLmZvcm0tZmllbGQtZXJyb3JzLmRpcmVjdGl2ZSdcbl0pO1xuIiwiYW5ndWxhci5tb2R1bGUoJ2JjYXBwLXBhdHRlcm4tbGFiLmZvcm0tZmllbGQtZXJyb3IuZGlyZWN0aXZlJywgW10pXG4gICAgLmRpcmVjdGl2ZSgnZm9ybUZpZWxkRXJyb3InLCBmdW5jdGlvbiBmb3JtRmllbGRFcnJvckRpcmVjdGl2ZSgkY29tcGlsZSkge1xuICAgICAgICByZXR1cm4ge1xuICAgICAgICAgICAgcHJpb3JpdHk6IDEwLFxuICAgICAgICAgICAgcmVwbGFjZTogdHJ1ZSxcbiAgICAgICAgICAgIHJlc3RyaWN0OiAnRUEnLFxuICAgICAgICAgICAgdGVtcGxhdGVVcmw6ICdzcmMvanMvYmlnY29tbWVyY2UvZm9ybS1maWVsZC1lcnJvci9mb3JtLWZpZWxkLWVycm9yLnRwbC5odG1sJyxcbiAgICAgICAgICAgIHRlcm1pbmFsOiB0cnVlLFxuICAgICAgICAgICAgdHJhbnNjbHVkZTogdHJ1ZSxcbiAgICAgICAgICAgIGNvbXBpbGU6IGZ1bmN0aW9uIGZvcm1GaWVsZEVycm9yQ29tcGlsZSh0RWxlbWVudCwgdEF0dHJzKSB7XG4gICAgICAgICAgICAgICAgLy8gVGhlIHRyYW5zbGF0ZSBwcm9wZXJ0eSB3aXBlcyBvdXQgb3VyIG5nLW1lc3NhZ2UgbG9naWMgaW4gdGhlIHBvc3QgbGluayBmdW5jdGlvblxuICAgICAgICAgICAgICAgIC8vIFRoZSBwcmlvcml0eSBhbmQgdGVybWluYWwgcHJvcGVydGllcyBhYm92ZSBlbnN1cmUgdGhpcyBjaGVjayBvY2N1cnNcbiAgICAgICAgICAgICAgICBpZiAodEVsZW1lbnQuYXR0cigndHJhbnNsYXRlJykgIT09IHVuZGVmaW5lZCkge1xuICAgICAgICAgICAgICAgICAgICB0aHJvdyBuZXcgU3ludGF4RXJyb3IoXG4gICAgICAgICAgICAgICAgICAgICAgICAnVGhlIHRyYW5zbGF0ZSBhdHRyaWJ1dGUgY2Fubm90IGJlIHVzZWQgd2l0aCB0aGUgZm9ybS1maWVsZC1lcnJvciBkaXJlY3RpdmUuICcgK1xuICAgICAgICAgICAgICAgICAgICAgICAgJ1VzZSB0aGUgdHJhbnNsYXRlIGZpbHRlciBpbnN0ZWFkIChleGFtcGxlOiB7eyBcIm15IGVycm9yIG1lc3NhZ2VcIiB8IHRyYW5zbGF0ZSB9fSkuICcgK1xuICAgICAgICAgICAgICAgICAgICAgICAgJ1ZhbGlkYXRvcjogJyArIHRBdHRycy52YWxpZGF0ZVxuICAgICAgICAgICAgICAgICAgICApO1xuICAgICAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgICAgIHJldHVybiB7XG4gICAgICAgICAgICAgICAgICAgIHBvc3Q6IGZ1bmN0aW9uIGZvcm1GaWVsZEVycm9yUG9zdExpbmsoc2NvcGUsIGVsZW1lbnQsIGF0dHJzLCBjb250cm9sbGVycywgdHJhbnNjbHVkZSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgc2NvcGUucHJvcGVydHkgPSBzY29wZS5wcm9wZXJ0eSB8fCBhdHRycy5wcm9wZXJ0eTtcblxuICAgICAgICAgICAgICAgICAgICAgICAgdHJhbnNjbHVkZShmdW5jdGlvbiBmb3JtRmllbGRFcnJvclRyYW5zY2x1ZGUoZXJyb3JDbG9uZSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhciBsYWJlbEVsZW1lbnQgPSBhbmd1bGFyLmVsZW1lbnQoJzxsYWJlbD4nKTtcblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vIG5nTWVzc2FnZSBkb2Vzbid0IHBsYXkgd2VsbCB3aXRoIGR5bmFtaWMgbWVzc2FnZSBpbnNlcnRpb24sIHRyYW5zbGF0aW9uLCBvclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vIG1lc3NhZ2UgZXhwcmVzc2lvbnMsIHNvIHdlIGJ1aWxkIGl0cyBlbGVtZW50IHVwIGhlcmUgYW5kIGluamVjdCBpdCBpbnRvIHRoZSBET01cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBsYWJlbEVsZW1lbnQuYXR0cignZm9yJywgc2NvcGUucHJvcGVydHkpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGxhYmVsRWxlbWVudC5hdHRyKCduZy1tZXNzYWdlJywgYXR0cnMudmFsaWRhdGUpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGxhYmVsRWxlbWVudC5hdHRyKCdyb2xlJywgJ2FsZXJ0Jyk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgbGFiZWxFbGVtZW50LmFkZENsYXNzKCdmb3JtLWlubGluZU1lc3NhZ2UnKTtcblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vIFRoZSBlcnJvciBzcGFuIHNob3VsZCBhbHJlYWR5IGhhdmUgYSB0cmFuc2xhdGlvbiB3YXRjaGVyIG9uIGl0IGJ5IG5vdywgdXNpbmcgYSBmaWx0ZXJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBsYWJlbEVsZW1lbnQuYXBwZW5kKGVycm9yQ2xvbmUpO1xuXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgZWxlbWVudC5hcHBlbmQobGFiZWxFbGVtZW50KTtcblxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICRjb21waWxlKGVsZW1lbnQpKHNjb3BlKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgfTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfTtcbiAgICB9KTtcbiIsImFuZ3VsYXIubW9kdWxlKCdiY2FwcC1wYXR0ZXJuLWxhYi5mb3JtLWZpZWxkLWVycm9yJywgW1xuICAgICdiY2FwcC1wYXR0ZXJuLWxhYi5mb3JtLWZpZWxkLWVycm9yLmRpcmVjdGl2ZSdcbl0pO1xuIiwiYW5ndWxhci5tb2R1bGUoJ2JjYXBwLXBhdHRlcm4tbGFiLmljb24uY29udHJvbGxlcicsIFtcbiAgICAnYmNhcHAtcGF0dGVybi1sYWIuaWNvbi5zdmdSb290UGF0aCdcbl0pXG4gICAgLmNvbnRyb2xsZXIoJ0ljb25DdHJsJywgZnVuY3Rpb24gaWNvbkRpcmVjdGl2ZUNvbnRyb2xsZXIoJGh0dHAsICR0ZW1wbGF0ZUNhY2hlLCBzdmdSb290UGF0aCkge1xuICAgICAgICB2YXIgY3RybCA9IHRoaXM7XG5cbiAgICAgICAgY3RybC51cGRhdGVHbHlwaCA9IHVwZGF0ZUdseXBoO1xuXG4gICAgICAgIGZ1bmN0aW9uIHVwZGF0ZUdseXBoKGdseXBoKSB7XG4gICAgICAgICAgICB2YXIgZnVsbFN2Z1BhdGggPSBzdmdSb290UGF0aCArIGdseXBoICsgJy5zdmcnO1xuXG4gICAgICAgICAgICByZXR1cm4gJGh0dHAuZ2V0KGZ1bGxTdmdQYXRoLCB7IGNhY2hlOiAkdGVtcGxhdGVDYWNoZSB9KVxuICAgICAgICAgICAgICAgIC50aGVuKGZ1bmN0aW9uIGljb25EaXJlY3RpdmVIdHRwU3VjY2VzcyhyZXNwb25zZSkge1xuICAgICAgICAgICAgICAgICAgICByZXR1cm4gcmVzcG9uc2UuZGF0YTtcbiAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgfVxuICAgIH0pO1xuIiwiLyoqXG4gKiBAZGVzY3JpcHRpb24gSWNvbiBkaXJlY3RpdmUgdXNlZCB0byBsb2FkIGFuIGlubGluZSBzdmcgaWNvbiwgc2ltbGlhciB0byBpY29uXG4gKiAgICAgICAgICAgICAgZm9udCBtZXRob2RzIG9mIHBhc3QgPGkgY2xhc3M9XCJpY29uLWZvby1iYXJcIj48L2k+XG4gKiBAZXhhbXBsZVxuICogPGljb24gZ2x5cGg9XCJpYy1hZGQtY2lyY2xlXCI+PC9pY29uPlxuICovXG5hbmd1bGFyLm1vZHVsZSgnYmNhcHAtcGF0dGVybi1sYWIuaWNvbi5kaXJlY3RpdmUnLCBbXG4gICAgJ2JjYXBwLXBhdHRlcm4tbGFiLmljb24uY29udHJvbGxlcidcbl0pXG4gICAgLmRpcmVjdGl2ZSgnaWNvbicsIGZ1bmN0aW9uIGljb25EaXJlY3RpdmUoKSB7XG4gICAgICAgIHJldHVybiB7XG4gICAgICAgICAgICBiaW5kVG9Db250cm9sbGVyOiB0cnVlLFxuICAgICAgICAgICAgY29udHJvbGxlcjogJ0ljb25DdHJsIGFzIGljb25DdHJsJyxcbiAgICAgICAgICAgIHJlc3RyaWN0OiAnRScsXG4gICAgICAgICAgICBzY29wZToge1xuICAgICAgICAgICAgICAgIGdseXBoOiAnQCdcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICBjb21waWxlOiBmdW5jdGlvbiBpY29uRGlyZWN0aXZlQ29tcGlsZSh0RWxlbWVudCkge1xuICAgICAgICAgICAgICAgIHRFbGVtZW50LmFkZENsYXNzKCdpY29uJyk7XG4gICAgICAgICAgICAgICAgdEVsZW1lbnQuYXR0cignYXJpYS1oaWRkZW4nLCB0cnVlKTtcblxuICAgICAgICAgICAgICAgIHJldHVybiBmdW5jdGlvbiBpY29uRGlyZWN0aXZlTGluaygkc2NvcGUsIGVsZW1lbnQsIGF0dHJzLCBjdHJsKSB7XG4gICAgICAgICAgICAgICAgICAgICRzY29wZS4kd2F0Y2goJ2ljb25DdHJsLmdseXBoJywgZnVuY3Rpb24gaWNvbkRpcmVjdGl2ZUxpbmtXYXRjaChuZXdWYWx1ZSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgY3RybC51cGRhdGVHbHlwaChuZXdWYWx1ZSlcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAudGhlbihmdW5jdGlvbiBpY29uVXBkYXRlR2x5cGhUaGVuKHN2Zykge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBlbGVtZW50Lmh0bWwoc3ZnKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgfTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfTtcbiAgICB9KTtcbiIsImFuZ3VsYXIubW9kdWxlKCdiY2FwcC1wYXR0ZXJuLWxhYi5pY29uJywgW1xuICAgICdiY2FwcC1wYXR0ZXJuLWxhYi5pY29uLmRpcmVjdGl2ZSdcbl0pO1xuIiwiYW5ndWxhci5tb2R1bGUoJ2JjYXBwLXBhdHRlcm4tbGFiLmljb24uc3ZnUm9vdFBhdGgnLCBbXSlcbiAgICAucHJvdmlkZXIoJ3N2Z1Jvb3RQYXRoJywgZnVuY3Rpb24gc3ZnUm9vdFBhdGhQcm92aWRlckNvbmZpZygpIHtcbiAgICAgICAgdGhpcy5zZXRSb290UGF0aCA9IHNldFJvb3RQYXRoO1xuICAgICAgICB0aGlzLiRnZXQgPSBmdW5jdGlvbiBzdmdSb290UGF0aFByb3ZpZGVyR2V0KCRsb2cpIHtcbiAgICAgICAgICAgIGlmICh0aGlzLnN2Z1Jvb3RQYXRoID09PSB1bmRlZmluZWQpIHtcbiAgICAgICAgICAgICAgICAkbG9nLmVycm9yKCdObyBzdmdSb290UGF0aCBwcm92aWRlZC4gUGxlYXNlIGNvbmZpZ3VyZSB0aGlzIHVzaW5nIHRoZSBzdmdSb290UGF0aFByb3ZpZGVyJyk7XG4gICAgICAgICAgICB9XG5cbiAgICAgICAgICAgIHJldHVybiB0aGlzLnN2Z1Jvb3RQYXRoO1xuICAgICAgICB9O1xuXG4gICAgICAgIGZ1bmN0aW9uIHNldFJvb3RQYXRoKG5ld1Jvb3RQYXRoKSB7XG4gICAgICAgICAgICB0aGlzLnN2Z1Jvb3RQYXRoID0gbmV3Um9vdFBhdGg7XG4gICAgICAgIH1cbiAgICB9KTtcbiIsImFuZ3VsYXIubW9kdWxlKCdiY2FwcC1wYXR0ZXJuLWxhYi5sb2FkaW5nLW92ZXJsYXkuY29udHJvbGxlcicsIFtdKVxuICAgIC5jb250cm9sbGVyKCdMb2FkaW5nT3ZlcmxheUN0cmwnLCBmdW5jdGlvbiBMb2FkaW5nT3ZlcmxheUN0cmwoJHJvb3RTY29wZSwgJHRpbWVvdXQpIHtcbiAgICAgICAgdmFyIGN0cmwgPSB0aGlzLFxuICAgICAgICAgICAgZGVmYXVsdERlYm91bmNlID0gMTAwLFxuICAgICAgICAgICAgdGltZW91dDtcblxuICAgICAgICBpZiAoY3RybC5kZWJvdW5jZSA9PT0gdW5kZWZpbmVkKSB7XG4gICAgICAgICAgICBjdHJsLmRlYm91bmNlID0gZGVmYXVsdERlYm91bmNlO1xuICAgICAgICB9XG5cbiAgICAgICAgaWYgKGN0cmwudXNlVWlSb3V0ZXIpIHtcbiAgICAgICAgICAgICRyb290U2NvcGUuJG9uKCckc3RhdGVDaGFuZ2VTdGFydCcsIHN0YXJ0TG9hZGluZyk7XG4gICAgICAgICAgICAkcm9vdFNjb3BlLiRvbignJHN0YXRlQ2hhbmdlU3VjY2VzcycsIHN0b3BMb2FkaW5nKTtcbiAgICAgICAgICAgICRyb290U2NvcGUuJG9uKCckc3RhdGVDaGFuZ2VFcnJvcicsIHN0b3BMb2FkaW5nKTtcbiAgICAgICAgfVxuXG4gICAgICAgIGZ1bmN0aW9uIHN0YXJ0TG9hZGluZyhldmVudCkge1xuICAgICAgICAgICAgaWYgKGV2ZW50LmRlZmF1bHRQcmV2ZW50ZWQpIHtcbiAgICAgICAgICAgICAgICByZXR1cm47XG4gICAgICAgICAgICB9XG5cbiAgICAgICAgICAgIHRpbWVvdXQgPSAkdGltZW91dChmdW5jdGlvbiBzdGFydExvYWRpbmdUaW1lcigpIHtcbiAgICAgICAgICAgICAgICBjdHJsLmxvYWRpbmcgPSB0cnVlO1xuICAgICAgICAgICAgfSwgY3RybC5kZWJvdW5jZSk7XG4gICAgICAgIH1cblxuICAgICAgICBmdW5jdGlvbiBzdG9wTG9hZGluZyhldmVudCkge1xuICAgICAgICAgICAgaWYgKGV2ZW50LmRlZmF1bHRQcmV2ZW50ZWQpIHtcbiAgICAgICAgICAgICAgICByZXR1cm47XG4gICAgICAgICAgICB9XG5cbiAgICAgICAgICAgICR0aW1lb3V0LmNhbmNlbCh0aW1lb3V0KTtcbiAgICAgICAgICAgIGN0cmwubG9hZGluZyA9IGZhbHNlO1xuICAgICAgICB9XG4gICAgfSk7XG4iLCJhbmd1bGFyLm1vZHVsZSgnYmNhcHAtcGF0dGVybi1sYWIubG9hZGluZy1vdmVybGF5LmRpcmVjdGl2ZScsIFtcbiAgICAnYmNhcHAtcGF0dGVybi1sYWIubG9hZGluZy1vdmVybGF5LmNvbnRyb2xsZXInXG5dKVxuICAgIC5kaXJlY3RpdmUoJ2xvYWRpbmdPdmVybGF5JywgZnVuY3Rpb24gbG9hZGluZ092ZXJsYXkoKSB7XG4gICAgICAgIHJldHVybiB7XG4gICAgICAgICAgICBiaW5kVG9Db250cm9sbGVyOiB0cnVlLFxuICAgICAgICAgICAgY29udHJvbGxlcjogJ0xvYWRpbmdPdmVybGF5Q3RybCBhcyBsb2FkaW5nT3ZlcmxheUN0cmwnLFxuICAgICAgICAgICAgcmVzdHJpY3Q6ICdBJyxcbiAgICAgICAgICAgIHNjb3BlOiB7XG4gICAgICAgICAgICAgICAgZGVib3VuY2U6ICc9PycsXG4gICAgICAgICAgICAgICAgbG9hZGluZzogJz0/bG9hZGluZ092ZXJsYXknLFxuICAgICAgICAgICAgICAgIHVzZVVpUm91dGVyOiAnPT8nXG4gICAgICAgICAgICB9LFxuICAgICAgICAgICAgdGVtcGxhdGVVcmw6ICdzcmMvanMvYmlnY29tbWVyY2UvbG9hZGluZy1vdmVybGF5L2xvYWRpbmctb3ZlcmxheS50cGwuaHRtbCcsXG4gICAgICAgICAgICB0cmFuc2NsdWRlOiB0cnVlLFxuICAgICAgICAgICAgY29tcGlsZTogZnVuY3Rpb24gbG9hZGluZ092ZXJsYXlDb21waWxlKGVsZW1lbnQpIHtcbiAgICAgICAgICAgICAgICBlbGVtZW50LmFkZENsYXNzKCdsb2FkaW5nT3ZlcmxheS1jb250YWluZXInKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfTtcbiAgICB9KTtcbiIsImFuZ3VsYXIubW9kdWxlKCdiY2FwcC1wYXR0ZXJuLWxhYi5sb2FkaW5nLW92ZXJsYXknLCBbXG4gICAgJ2JjYXBwLXBhdHRlcm4tbGFiLmxvYWRpbmctb3ZlcmxheS5kaXJlY3RpdmUnXG5dKTtcbiIsImFuZ3VsYXIubW9kdWxlKCdiY2FwcC1wYXR0ZXJuLWxhYi5sb2FkaW5nLW5vdGlmaWNhdGlvbi5kaXJlY3RpdmUnLCBbXSlcbiAgICAuZGlyZWN0aXZlKCdsb2FkaW5nTm90aWZpY2F0aW9uJywgZnVuY3Rpb24gbG9hZGluZ05vdGlmaWNhdGlvbkRpcmVjdGl2ZSgkcm9vdFNjb3BlKSB7XG4gICAgICAgIHJldHVybiB7XG4gICAgICAgICAgICByZXN0cmljdDogJ0UnLFxuICAgICAgICAgICAgdGVtcGxhdGVVcmw6ICdzcmMvanMvYmlnY29tbWVyY2UvbG9hZGluZy1ub3RpZmljYXRpb24vbG9hZGluZy1ub3RpZmljYXRpb24udHBsLmh0bWwnLFxuXG4gICAgICAgICAgICBsaW5rOiBmdW5jdGlvbihzY29wZSkge1xuICAgICAgICAgICAgICAgICRyb290U2NvcGUuJG9uKCdhamF4UmVxdWVzdFJ1bm5pbmcnLCBmdW5jdGlvbihldmVudCwgdmFsKSB7XG4gICAgICAgICAgICAgICAgICAgIHNjb3BlLnJlcXVlc3RJblByb2dyZXNzID0gdmFsO1xuICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgfVxuICAgICAgICB9O1xuICAgIH0pO1xuIiwiYW5ndWxhci5tb2R1bGUoJ2JjYXBwLXBhdHRlcm4tbGFiLmxvYWRpbmctbm90aWZpY2F0aW9uJywgW1xuICAgICdiY2FwcC1wYXR0ZXJuLWxhYi5sb2FkaW5nLW5vdGlmaWNhdGlvbi5kaXJlY3RpdmUnXG5dKTtcbiIsIi8qXG4gKiBPdmVycmlkZSBhbmd1bGFyIGZvdW5kYXRpb24ncyAkbW9kYWxTdGFjayBzZXJ2aWNlIHRvIHJlbW92ZSB0aGUgYHRvcGAgY3NzIHByb3BlcnR5LlxuICogY2Fubm90IHVzZSBhIGRlY29yYXRvciBiZWNhdXNlIHRoZSBgb3BlbmAgcmVsaWVzIG9uIGNsb3N1cmVzIGFuZCBkb2VzIG5vdCByZXR1cm4gdGhlIGNvbXBpbGVkIGVsZW1lbnQuXG4gKiBDaGFuZ2VzIGFyZSBiZXR3ZWVuIGAvLyBDaGFuZ2VzYCBjb21tZW50c1xuKi9cbmFuZ3VsYXIubW9kdWxlKCdiY2FwcC1wYXR0ZXJuLWxhYi5iYy1tb2RhbC5tb2RhbFN0YWNrLnNlcnZpY2UnLCBbXG5cbl0pXG4gIC5mYWN0b3J5KCckbW9kYWxTdGFjaycsIFsnJHdpbmRvdycsICckdHJhbnNpdGlvbicsICckdGltZW91dCcsICckZG9jdW1lbnQnLCAnJGNvbXBpbGUnLCAnJHJvb3RTY29wZScsICckJHN0YWNrZWRNYXAnLFxuICAgIGZ1bmN0aW9uICgkd2luZG93LCAkdHJhbnNpdGlvbiwgJHRpbWVvdXQsICRkb2N1bWVudCwgJGNvbXBpbGUsICRyb290U2NvcGUsICQkc3RhY2tlZE1hcCkge1xuICAgICAgLy8gQ2hhbmdlczogY2hhbmdlIGZyb20gYG1vZGFsLW9wZW5gIHRvIGBoYXMtYWN0aXZlTW9kYWxgXG4gICAgICB2YXIgT1BFTkVEX01PREFMX0NMQVNTID0gJ2hhcy1hY3RpdmVNb2RhbCc7XG4gICAgICAvLyBDaGFuZ2VzXG5cbiAgICAgIHZhciBiYWNrZHJvcERvbUVsLCBiYWNrZHJvcFNjb3BlO1xuICAgICAgdmFyIG9wZW5lZFdpbmRvd3MgPSAkJHN0YWNrZWRNYXAuY3JlYXRlTmV3KCk7XG4gICAgICB2YXIgJG1vZGFsU3RhY2sgPSB7fTtcblxuICAgICAgZnVuY3Rpb24gYmFja2Ryb3BJbmRleCgpIHtcbiAgICAgICAgdmFyIHRvcEJhY2tkcm9wSW5kZXggPSAtMTtcbiAgICAgICAgdmFyIG9wZW5lZCA9IG9wZW5lZFdpbmRvd3Mua2V5cygpO1xuICAgICAgICBmb3IgKHZhciBpID0gMDsgaSA8IG9wZW5lZC5sZW5ndGg7IGkrKykge1xuICAgICAgICAgIGlmIChvcGVuZWRXaW5kb3dzLmdldChvcGVuZWRbaV0pLnZhbHVlLmJhY2tkcm9wKSB7XG4gICAgICAgICAgICB0b3BCYWNrZHJvcEluZGV4ID0gaTtcbiAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIHRvcEJhY2tkcm9wSW5kZXg7XG4gICAgICB9XG5cbiAgICAgICRyb290U2NvcGUuJHdhdGNoKGJhY2tkcm9wSW5kZXgsIGZ1bmN0aW9uKG5ld0JhY2tkcm9wSW5kZXgpe1xuICAgICAgICBpZiAoYmFja2Ryb3BTY29wZSkge1xuICAgICAgICAgIGJhY2tkcm9wU2NvcGUuaW5kZXggPSBuZXdCYWNrZHJvcEluZGV4O1xuICAgICAgICB9XG4gICAgICB9KTtcblxuICAgICAgZnVuY3Rpb24gcmVtb3ZlTW9kYWxXaW5kb3cobW9kYWxJbnN0YW5jZSkge1xuICAgICAgICB2YXIgYm9keSA9ICRkb2N1bWVudC5maW5kKCdib2R5JykuZXEoMCk7XG4gICAgICAgIHZhciBtb2RhbFdpbmRvdyA9IG9wZW5lZFdpbmRvd3MuZ2V0KG1vZGFsSW5zdGFuY2UpLnZhbHVlO1xuXG4gICAgICAgIC8vY2xlYW4gdXAgdGhlIHN0YWNrXG4gICAgICAgIG9wZW5lZFdpbmRvd3MucmVtb3ZlKG1vZGFsSW5zdGFuY2UpO1xuXG4gICAgICAgIC8vcmVtb3ZlIHdpbmRvdyBET00gZWxlbWVudFxuICAgICAgICByZW1vdmVBZnRlckFuaW1hdGUobW9kYWxXaW5kb3cubW9kYWxEb21FbCwgbW9kYWxXaW5kb3cubW9kYWxTY29wZSwgMzAwLCBmdW5jdGlvbigpIHtcbiAgICAgICAgICBtb2RhbFdpbmRvdy5tb2RhbFNjb3BlLiRkZXN0cm95KCk7XG4gICAgICAgICAgYm9keS50b2dnbGVDbGFzcyhPUEVORURfTU9EQUxfQ0xBU1MsIG9wZW5lZFdpbmRvd3MubGVuZ3RoKCkgPiAwKTtcbiAgICAgICAgICBjaGVja1JlbW92ZUJhY2tkcm9wKCk7XG4gICAgICAgIH0pO1xuICAgICAgfVxuXG4gICAgICBmdW5jdGlvbiBjaGVja1JlbW92ZUJhY2tkcm9wKCkge1xuICAgICAgICAvL3JlbW92ZSBiYWNrZHJvcCBpZiBubyBsb25nZXIgbmVlZGVkXG4gICAgICAgIGlmIChiYWNrZHJvcERvbUVsICYmIGJhY2tkcm9wSW5kZXgoKSA9PSAtMSkge1xuICAgICAgICAgIHZhciBiYWNrZHJvcFNjb3BlUmVmID0gYmFja2Ryb3BTY29wZTtcbiAgICAgICAgICByZW1vdmVBZnRlckFuaW1hdGUoYmFja2Ryb3BEb21FbCwgYmFja2Ryb3BTY29wZSwgMTUwLCBmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICBiYWNrZHJvcFNjb3BlUmVmLiRkZXN0cm95KCk7XG4gICAgICAgICAgICBiYWNrZHJvcFNjb3BlUmVmID0gbnVsbDtcbiAgICAgICAgICB9KTtcbiAgICAgICAgICBiYWNrZHJvcERvbUVsID0gdW5kZWZpbmVkO1xuICAgICAgICAgIGJhY2tkcm9wU2NvcGUgPSB1bmRlZmluZWQ7XG4gICAgICAgIH1cbiAgICAgIH1cblxuICAgICAgZnVuY3Rpb24gcmVtb3ZlQWZ0ZXJBbmltYXRlKGRvbUVsLCBzY29wZSwgZW11bGF0ZVRpbWUsIGRvbmUpIHtcbiAgICAgICAgLy8gQ2xvc2luZyBhbmltYXRpb25cbiAgICAgICAgc2NvcGUuYW5pbWF0ZSA9IGZhbHNlO1xuXG4gICAgICAgIHZhciB0cmFuc2l0aW9uRW5kRXZlbnROYW1lID0gJHRyYW5zaXRpb24udHJhbnNpdGlvbkVuZEV2ZW50TmFtZTtcbiAgICAgICAgaWYgKHRyYW5zaXRpb25FbmRFdmVudE5hbWUpIHtcbiAgICAgICAgICAvLyB0cmFuc2l0aW9uIG91dFxuICAgICAgICAgIHZhciB0aW1lb3V0ID0gJHRpbWVvdXQoYWZ0ZXJBbmltYXRpbmcsIGVtdWxhdGVUaW1lKTtcblxuICAgICAgICAgIGRvbUVsLmJpbmQodHJhbnNpdGlvbkVuZEV2ZW50TmFtZSwgZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgJHRpbWVvdXQuY2FuY2VsKHRpbWVvdXQpO1xuICAgICAgICAgICAgYWZ0ZXJBbmltYXRpbmcoKTtcbiAgICAgICAgICAgIHNjb3BlLiRhcHBseSgpO1xuICAgICAgICAgIH0pO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgIC8vIEVuc3VyZSB0aGlzIGNhbGwgaXMgYXN5bmNcbiAgICAgICAgICAkdGltZW91dChhZnRlckFuaW1hdGluZywgMCk7XG4gICAgICAgIH1cblxuICAgICAgICBmdW5jdGlvbiBhZnRlckFuaW1hdGluZygpIHtcbiAgICAgICAgICBpZiAoYWZ0ZXJBbmltYXRpbmcuZG9uZSkge1xuICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICAgIH1cbiAgICAgICAgICBhZnRlckFuaW1hdGluZy5kb25lID0gdHJ1ZTtcblxuICAgICAgICAgIGRvbUVsLnJlbW92ZSgpO1xuICAgICAgICAgIGlmIChkb25lKSB7XG4gICAgICAgICAgICBkb25lKCk7XG4gICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICB9XG5cbiAgICAgICRkb2N1bWVudC5iaW5kKCdrZXlkb3duJywgZnVuY3Rpb24gKGV2dCkge1xuICAgICAgICB2YXIgbW9kYWw7XG5cbiAgICAgICAgaWYgKGV2dC53aGljaCA9PT0gMjcpIHtcbiAgICAgICAgICBtb2RhbCA9IG9wZW5lZFdpbmRvd3MudG9wKCk7XG4gICAgICAgICAgaWYgKG1vZGFsICYmIG1vZGFsLnZhbHVlLmtleWJvYXJkKSB7XG4gICAgICAgICAgICAkcm9vdFNjb3BlLiRhcHBseShmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICAgICRtb2RhbFN0YWNrLmRpc21pc3MobW9kYWwua2V5KTtcbiAgICAgICAgICAgIH0pO1xuICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgfSk7XG5cbiAgICAgICRtb2RhbFN0YWNrLm9wZW4gPSBmdW5jdGlvbiAobW9kYWxJbnN0YW5jZSwgbW9kYWwpIHtcblxuICAgICAgICBvcGVuZWRXaW5kb3dzLmFkZChtb2RhbEluc3RhbmNlLCB7XG4gICAgICAgICAgZGVmZXJyZWQ6IG1vZGFsLmRlZmVycmVkLFxuICAgICAgICAgIG1vZGFsU2NvcGU6IG1vZGFsLnNjb3BlLFxuICAgICAgICAgIGJhY2tkcm9wOiBtb2RhbC5iYWNrZHJvcCxcbiAgICAgICAgICBrZXlib2FyZDogbW9kYWwua2V5Ym9hcmRcbiAgICAgICAgfSk7XG5cbiAgICAgICAgdmFyIGJvZHkgPSAkZG9jdW1lbnQuZmluZCgnYm9keScpLmVxKDApLFxuICAgICAgICAgICAgY3VyckJhY2tkcm9wSW5kZXggPSBiYWNrZHJvcEluZGV4KCk7XG5cbiAgICAgICAgaWYgKGN1cnJCYWNrZHJvcEluZGV4ID49IDAgJiYgIWJhY2tkcm9wRG9tRWwpIHtcbiAgICAgICAgICBiYWNrZHJvcFNjb3BlID0gJHJvb3RTY29wZS4kbmV3KHRydWUpO1xuICAgICAgICAgIGJhY2tkcm9wU2NvcGUuaW5kZXggPSBjdXJyQmFja2Ryb3BJbmRleDtcbiAgICAgICAgICBiYWNrZHJvcERvbUVsID0gJGNvbXBpbGUoJzxkaXYgbW9kYWwtYmFja2Ryb3A+PC9kaXY+JykoYmFja2Ryb3BTY29wZSk7XG4gICAgICAgICAgYm9keS5hcHBlbmQoYmFja2Ryb3BEb21FbCk7XG4gICAgICAgIH1cblxuICAgICAgICAvLyBDaGFuZ2VzOiBkZWxldGlvbiBvZiBjc3MgdG9wIHByb3BlcnR5IGNhbGN1bGF0aW9uXG4gICAgICAgIHZhciBhbmd1bGFyRG9tRWwgPSBhbmd1bGFyLmVsZW1lbnQoJzxkaXYgbW9kYWwtd2luZG93IHN0eWxlPVwidmlzaWJpbGl0eTogdmlzaWJsZTsgZGlzcGxheTogYmxvY2tcIj48L2Rpdj4nKTtcbiAgICAgICAgYW5ndWxhckRvbUVsLmF0dHIoJ3dpbmRvdy1jbGFzcycsIG1vZGFsLndpbmRvd0NsYXNzKTtcbiAgICAgICAgYW5ndWxhckRvbUVsLmF0dHIoJ2luZGV4Jywgb3BlbmVkV2luZG93cy5sZW5ndGgoKSAtIDEpO1xuICAgICAgICBhbmd1bGFyRG9tRWwuYXR0cignYW5pbWF0ZScsICdhbmltYXRlJyk7XG4gICAgICAgIGFuZ3VsYXJEb21FbC5odG1sKG1vZGFsLmNvbnRlbnQpO1xuXG4gICAgICAgIHZhciBtb2RhbERvbUVsID0gJGNvbXBpbGUoYW5ndWxhckRvbUVsKShtb2RhbC5zY29wZSk7XG4gICAgICAgIG9wZW5lZFdpbmRvd3MudG9wKCkudmFsdWUubW9kYWxEb21FbCA9IG1vZGFsRG9tRWw7XG4gICAgICAgIGJvZHkuYXBwZW5kKG1vZGFsRG9tRWwpO1xuICAgICAgICBib2R5LmFkZENsYXNzKE9QRU5FRF9NT0RBTF9DTEFTUyk7XG4gICAgICB9O1xuXG4gICAgICAkbW9kYWxTdGFjay5jbG9zZSA9IGZ1bmN0aW9uIChtb2RhbEluc3RhbmNlLCByZXN1bHQpIHtcbiAgICAgICAgdmFyIG1vZGFsV2luZG93ID0gb3BlbmVkV2luZG93cy5nZXQobW9kYWxJbnN0YW5jZSkudmFsdWU7XG4gICAgICAgIGlmIChtb2RhbFdpbmRvdykge1xuICAgICAgICAgIG1vZGFsV2luZG93LmRlZmVycmVkLnJlc29sdmUocmVzdWx0KTtcbiAgICAgICAgICByZW1vdmVNb2RhbFdpbmRvdyhtb2RhbEluc3RhbmNlKTtcbiAgICAgICAgfVxuICAgICAgfTtcblxuICAgICAgJG1vZGFsU3RhY2suZGlzbWlzcyA9IGZ1bmN0aW9uIChtb2RhbEluc3RhbmNlLCByZWFzb24pIHtcbiAgICAgICAgdmFyIG1vZGFsV2luZG93ID0gb3BlbmVkV2luZG93cy5nZXQobW9kYWxJbnN0YW5jZSkudmFsdWU7XG4gICAgICAgIGlmIChtb2RhbFdpbmRvdykge1xuICAgICAgICAgIG1vZGFsV2luZG93LmRlZmVycmVkLnJlamVjdChyZWFzb24pO1xuICAgICAgICAgIHJlbW92ZU1vZGFsV2luZG93KG1vZGFsSW5zdGFuY2UpO1xuICAgICAgICB9XG4gICAgICB9O1xuXG4gICAgICAkbW9kYWxTdGFjay5kaXNtaXNzQWxsID0gZnVuY3Rpb24gKHJlYXNvbikge1xuICAgICAgICB2YXIgdG9wTW9kYWwgPSB0aGlzLmdldFRvcCgpO1xuICAgICAgICB3aGlsZSAodG9wTW9kYWwpIHtcbiAgICAgICAgICB0aGlzLmRpc21pc3ModG9wTW9kYWwua2V5LCByZWFzb24pO1xuICAgICAgICAgIHRvcE1vZGFsID0gdGhpcy5nZXRUb3AoKTtcbiAgICAgICAgfVxuICAgICAgfTtcblxuICAgICAgJG1vZGFsU3RhY2suZ2V0VG9wID0gZnVuY3Rpb24gKCkge1xuICAgICAgICByZXR1cm4gb3BlbmVkV2luZG93cy50b3AoKTtcbiAgICAgIH07XG5cbiAgICAgIHJldHVybiAkbW9kYWxTdGFjaztcbiAgICB9XSk7XG5cbiIsIi8qXG4gKiBUaGlzIG1vZHVsZSBtb2RpZmllcyBhbmd1bGFyIGZvdW5kYXRpb24ncyBtb2RhbCBpbXBsZW1lbnRhdGlvbi4gVGhpcyBkb2VzIG5vdCBjcmVhdGUgYSBuZXcgbW9kYWwgc2VydmljZS9kaXJlY3RpdmUuXG4gKiBcbiovXG5hbmd1bGFyLm1vZHVsZSgnYmNhcHAtcGF0dGVybi1sYWIuYmMtbW9kYWwnLCBbXG4gICAgJ2JjYXBwLXBhdHRlcm4tbGFiLmJjLW1vZGFsLm1vZGFsU3RhY2suc2VydmljZSdcbl0pO1xuIiwiLyoqXG4gKiBAZGVzY3JpcHRpb24gU3ByaXRlIGRpcmVjdGl2ZSB1c2VkIHRvIGxvYWQgYW4gaWNvbiBmcm9tIGFuIGltYWdlIHNwcml0ZSxcbiAqICAgICAgICAgICAgICBzaW1saWFyIHRvIHRoZSBpY29uIGRpcmVjdGl2ZSBidXQgbGVzcyBTVkdcbiAqIEBleGFtcGxlXG4gKiA8c3ByaXRlIGdseXBoPVwiaWMtYW1leFwiPjwvc3ByaXRlPlxuICovXG5cbmFuZ3VsYXIubW9kdWxlKCdiY2FwcC1wYXR0ZXJuLWxhYi5zcHJpdGUuZGlyZWN0aXZlJywgW10pXG4gICAgLmRpcmVjdGl2ZSgnc3ByaXRlJywgZnVuY3Rpb24gc3ByaXRlRGlyZWN0aXZlKCkge1xuICAgICAgICByZXR1cm4ge1xuICAgICAgICAgICAgcmVzdHJpY3Q6ICdFJyxcbiAgICAgICAgICAgIHNjb3BlOiB7XG4gICAgICAgICAgICAgICAgZ2x5cGg6ICdAJ1xuICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIGNvbXBpbGU6IHNwcml0ZURpcmVjdGl2ZUNvbXBpbGVcbiAgICAgICAgfTtcblxuICAgICAgICBmdW5jdGlvbiBzcHJpdGVEaXJlY3RpdmVDb21waWxlKHRFbGVtZW50KSB7XG4gICAgICAgICAgICB0RWxlbWVudC5hZGRDbGFzcygnc3ByaXRlJyk7XG4gICAgICAgICAgICB0RWxlbWVudC5hdHRyKCdhcmlhLWhpZGRlbicsIHRydWUpO1xuXG4gICAgICAgICAgICByZXR1cm4gZnVuY3Rpb24gc3ByaXRlRGlyZWN0aXZlTGluaygkc2NvcGUsIGVsZW1lbnQsIGF0dHJzKSB7XG4gICAgICAgICAgICAgICAgYXR0cnMuJG9ic2VydmUoJ2dseXBoJywgKG5ld1ZhbHVlKSA9PiB7XG4gICAgICAgICAgICAgICAgICAgIGVsZW1lbnQuYXR0cignY2xhc3MnLCAnc3ByaXRlIHNwcml0ZS0tJyArIG5ld1ZhbHVlKTtcbiAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgIH07XG4gICAgICAgIH1cbiAgICB9KTtcbiIsImFuZ3VsYXIubW9kdWxlKCdiY2FwcC1wYXR0ZXJuLWxhYi5zcHJpdGUnLCBbXG4gICAgJ2JjYXBwLXBhdHRlcm4tbGFiLnNwcml0ZS5kaXJlY3RpdmUnXG5dKTtcbiIsIi8qKlxuICogQGRlc2NyaXB0aW9uIFVzZWQgdG8gY3JlYXRlIGEgdG9nZ2xlIHN3aXRjaCBmb3IgZm9ybXNcbiAqIEBleGFtcGxlXG4gICAgPHN3aXRjaCBuZy1tb2RlbD1cImN0cmwuc3dpdGNoTW9kZWwxXCI+PC9zd2l0Y2g+XG5cbiAgICA8c3dpdGNoXG4gICAgICAgIHRvZ2dsZS1vZmYtdGV4dD1cIk9mZlwiXG4gICAgICAgIHRvZ2dsZS1vbi10ZXh0PVwiT25cIlxuICAgICAgICBuZy1tb2RlbD1cImN0cmwuc3dpdGNoTW9kZWwyXCI+XG4gICAgPC9zd2l0Y2g+XG5cbiAgICA8c3dpdGNoXG4gICAgICAgIGhhcy1pY29uXG4gICAgICAgIG5nLW1vZGVsPVwiY3RybC5zd2l0Y2hNb2RlbDNcIj5cbiAgICA8L3N3aXRjaD5cblxuICAgIDxzd2l0Y2hcbiAgICAgICAgaXMtaW1wb3J0YW50XG4gICAgICAgIGxlZnQtbGFiZWw9XCJEb3duIGZvciBNYWludGVuYW5jZVwiXG4gICAgICAgIHJpZ2h0LWxhYmVsPVwiT3BlblwiXG4gICAgICAgIG5nLW1vZGVsPVwiY3RybC5zd2l0Y2hNb2RlbDRcIj5cbiAgICA8L3N3aXRjaD5cbiAqL1xuYW5ndWxhci5tb2R1bGUoJ2JjYXBwLXBhdHRlcm4tbGFiLnN3aXRjaC5kaXJlY3RpdmUnLCBbXSlcbiAgICAuZGlyZWN0aXZlKCdzd2l0Y2gnLCBmdW5jdGlvbiBzd2l0Y2hEaXJlY3RpdmUoKSB7XG5cbiAgICAgICAgZnVuY3Rpb24gZ2V0VW5pcXVlSUQoaWRQcmVmaXgpIHtcbiAgICAgICAgICAgIHJldHVybiBfLnVuaXF1ZUlkKGlkUHJlZml4KTtcbiAgICAgICAgfVxuXG4gICAgICAgIHJldHVybiB7XG4gICAgICAgICAgICByZXN0cmljdDogJ0UnLFxuICAgICAgICAgICAgdGVtcGxhdGVVcmw6ICdzcmMvanMvYmlnY29tbWVyY2Uvc3dpdGNoL3N3aXRjaC50cGwuaHRtbCcsXG4gICAgICAgICAgICByZXF1aXJlOiAnbmdNb2RlbCcsXG4gICAgICAgICAgICBzY29wZToge1xuICAgICAgICAgICAgICAgIGFyaWFEZXNjcmlwdGlvbjogJ0AnLFxuICAgICAgICAgICAgICAgIGxhYmVsVGV4dDogJ0AnLFxuICAgICAgICAgICAgICAgIGxlZnREZXNjcmlwdGlvbjogJ0AnLFxuICAgICAgICAgICAgICAgIG5nRmFsc2VWYWx1ZTogJ0AnLFxuICAgICAgICAgICAgICAgIG5nVHJ1ZVZhbHVlOiAnQCcsXG4gICAgICAgICAgICAgICAgcmlnaHREZXNjcmlwdGlvbjogJ0AnLFxuICAgICAgICAgICAgICAgIHRvZ2dsZU9mZkxhYmVsOiAnQCcsXG4gICAgICAgICAgICAgICAgdG9nZ2xlT25MYWJlbDogJ0AnLFxuICAgICAgICAgICAgICAgIHVuaXF1ZUlkOiAnQCdcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICBiaW5kVG9Db250cm9sbGVyOiB0cnVlLFxuICAgICAgICAgICAgY29udHJvbGxlckFzOiAnc3dpdGNoQ3RybCcsXG4gICAgICAgICAgICBjb21waWxlOiBmdW5jdGlvbiBzd2l0Y2hEaXJlY3RpdmVDb21waWxlKHRFbGVtLCB0QXR0cnMpIHtcbiAgICAgICAgICAgICAgICB2YXIgY2hlY2tib3hFbGVtID0gdEVsZW0uZmluZCgnaW5wdXQnKTtcblxuICAgICAgICAgICAgICAgIGlmICh0QXR0cnMubmdGYWxzZVZhbHVlKSB7XG4gICAgICAgICAgICAgICAgICAgIGNoZWNrYm94RWxlbS5hdHRyKCduZy1mYWxzZS12YWx1ZScsIHRBdHRycy5uZ0ZhbHNlVmFsdWUpO1xuICAgICAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgICAgIGlmICh0QXR0cnMubmdUcnVlVmFsdWUpIHtcbiAgICAgICAgICAgICAgICAgICAgY2hlY2tib3hFbGVtLmF0dHIoJ25nLXRydWUtdmFsdWUnLCB0QXR0cnMubmdUcnVlVmFsdWUpO1xuICAgICAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgICAgIHJldHVybiBmdW5jdGlvbiBzd2l0Y2hEaXJlY3RpdmVQb3N0TGluayhzY29wZSwgZWxlbWVudCwgYXR0cnMsIG5nTW9kZWxDdHJsKSB7XG4gICAgICAgICAgICAgICAgICAgIHNjb3BlLnN3aXRjaEN0cmwuaW5pdChuZ01vZGVsQ3RybCk7XG4gICAgICAgICAgICAgICAgfTtcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICBjb250cm9sbGVyOiBmdW5jdGlvbiBzd2l0Y2hEaXJlY3RpdmVDdHJsKCRzY29wZSwgJGVsZW1lbnQsICRhdHRycykge1xuICAgICAgICAgICAgICAgIHZhciBjdHJsID0gdGhpcztcblxuICAgICAgICAgICAgICAgIC8vIHN0YXRlXG4gICAgICAgICAgICAgICAgY3RybC5pc0ltcG9ydGFudCA9IGFuZ3VsYXIuaXNEZWZpbmVkKCRhdHRycy5pc0ltcG9ydGFudCkgJiYgJGF0dHJzLmlzSW1wb3J0YW50ICE9PSAnZmFsc2UnO1xuICAgICAgICAgICAgICAgIGN0cmwuaGFzSWNvbiA9IGFuZ3VsYXIuaXNEZWZpbmVkKCRhdHRycy5oYXNJY29uKSAmJiAkYXR0cnMuaGFzSWNvbiAhPT0gJ2ZhbHNlJztcblxuICAgICAgICAgICAgICAgIC8vIGxhYmVsc1xuICAgICAgICAgICAgICAgIGN0cmwubGFiZWxUZXh0ID0gJGF0dHJzLnRvZ2dsZU9mZkxhYmVsO1xuXG4gICAgICAgICAgICAgICAgLy8gaWRzXG4gICAgICAgICAgICAgICAgY3RybC51bmlxdWVJZCA9IGdldFVuaXF1ZUlEKCdzd2l0Y2gtJyk7XG4gICAgICAgICAgICAgICAgY3RybC5hcmlhRGVzY3JpcHRpb25JRCA9IGdldFVuaXF1ZUlEKCdzd2l0Y2gtYXJpYURlc2NyaXB0aW9uLScpO1xuXG4gICAgICAgICAgICAgICAgY3RybC5pbml0ID0gaW5pdDtcbiAgICAgICAgICAgICAgICBjdHJsLnVwZGF0ZU1vZGVsID0gdXBkYXRlTW9kZWw7XG5cbiAgICAgICAgICAgICAgICBmdW5jdGlvbiBpbml0KG5nTW9kZWxDdHJsKSB7XG4gICAgICAgICAgICAgICAgICAgIGN0cmwubmdNb2RlbEN0cmwgPSBuZ01vZGVsQ3RybDtcbiAgICAgICAgICAgICAgICAgICAgY3RybC52YWx1ZSA9IGN0cmwubmdNb2RlbEN0cmwuJG1vZGVsVmFsdWU7XG5cbiAgICAgICAgICAgICAgICAgICAgJHNjb3BlLiR3YXRjaCgnc3dpdGNoQ3RybC5uZ01vZGVsQ3RybC4kbW9kZWxWYWx1ZScsIGZ1bmN0aW9uIHN3aXRjaFZhbHVlQ2hhbmdlZChuZXdWYWx1ZSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgY3RybC52YWx1ZSA9IG5ld1ZhbHVlO1xuXG4gICAgICAgICAgICAgICAgICAgICAgICBjdHJsLmlzQ2hlY2tlZCA9IF8uaXNTdHJpbmcobmV3VmFsdWUpID8gXCInXCIgKyBuZXdWYWx1ZSArIFwiJ1wiID09PSBjdHJsLm5nVHJ1ZVZhbHVlIDogbmV3VmFsdWU7XG4gICAgICAgICAgICAgICAgICAgICAgICBjdHJsLmxhYmVsVGV4dCA9ICEhY3RybC5pc0NoZWNrZWQgPyBjdHJsLnRvZ2dsZU9uTGFiZWw6IGN0cmwudG9nZ2xlT2ZmTGFiZWw7XG4gICAgICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgICAgIGZ1bmN0aW9uIHVwZGF0ZU1vZGVsKCkge1xuICAgICAgICAgICAgICAgICAgICBjdHJsLm5nTW9kZWxDdHJsLiRzZXRWaWV3VmFsdWUoY3RybC52YWx1ZSk7XG4gICAgICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICB9XG4gICAgICAgIH07XG4gICAgfSk7XG4iLCJhbmd1bGFyLm1vZHVsZSgnYmNhcHAtcGF0dGVybi1sYWIuc3dpdGNoJywgW1xuICAgICdiY2FwcC1wYXR0ZXJuLWxhYi5zd2l0Y2guZGlyZWN0aXZlJ1xuXSk7XG4iLCJhbmd1bGFyLm1vZHVsZSgnYmNhcHAtcGF0dGVybi1sYWIuYmMtc2VydmVyLXRhYmxlLWZhY3Rvcnkuc2VydmljZScsIFtcbiAgICAnYmNhcHAtcGF0dGVybi1sYWIuYmMtc2VydmVyLXRhYmxlLnNlcnZpY2UnXG5dKVxuICAgIC5mYWN0b3J5KCdiY1NlcnZlclRhYmxlRmFjdG9yeScsIGZ1bmN0aW9uIGJjU2VydmVyVGFibGVGYWN0b3J5KCRsb2csIEJjU2VydmVyVGFibGUpIHtcbiAgICAgICAgdmFyIHRhYmxlcyA9IHt9LFxuICAgICAgICAgICAgc2VydmljZSA9IHtcbiAgICAgICAgICAgICAgICBjcmVhdGU6IGNyZWF0ZSxcbiAgICAgICAgICAgICAgICBnZXQ6IGdldCxcbiAgICAgICAgICAgICAgICByZW1vdmU6IHJlbW92ZVxuICAgICAgICAgICAgfTtcblxuICAgICAgICBmdW5jdGlvbiBjcmVhdGUodGFibGVJZCwgdGFibGVDb25maWcpIHtcbiAgICAgICAgICAgIGlmICh0YWJsZUlkIGluIHRhYmxlcykge1xuICAgICAgICAgICAgICAgIHJldHVybiBzZXJ2aWNlLmdldCh0YWJsZUlkKTtcbiAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgaWYgKCF0YWJsZUlkKSB7XG4gICAgICAgICAgICAgICAgdGFibGVJZCA9IF8udW5pcXVlSWQoJ2JjLXNlcnZlci10YWJsZS1pbnN0YW5jZS0nKTtcbiAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgdGFibGVzW3RhYmxlSWRdID0gbmV3IEJjU2VydmVyVGFibGUodGFibGVJZCwgdGFibGVDb25maWcpO1xuXG4gICAgICAgICAgICByZXR1cm4gdGFibGVzW3RhYmxlSWRdO1xuICAgICAgICB9XG5cbiAgICAgICAgZnVuY3Rpb24gZ2V0KHRhYmxlSWQpIHtcbiAgICAgICAgICAgIHJldHVybiB0YWJsZXNbdGFibGVJZF07XG4gICAgICAgIH1cblxuICAgICAgICBmdW5jdGlvbiByZW1vdmUodGFibGVJZCkge1xuICAgICAgICAgICAgZGVsZXRlIHRhYmxlc1t0YWJsZUlkXTtcbiAgICAgICAgfVxuXG4gICAgICAgIHJldHVybiBzZXJ2aWNlO1xuICAgIH0pO1xuIiwiYW5ndWxhci5tb2R1bGUoJ2JjYXBwLXBhdHRlcm4tbGFiLmJjLXNlcnZlci10YWJsZS5zZXJ2aWNlJywgW1xuICAgICd1aS5yb3V0ZXInXG5dKVxuICAgIC5mYWN0b3J5KCdCY1NlcnZlclRhYmxlJywgZnVuY3Rpb24gYmNTZXJ2ZXJUYWJsZSgkbG9nLCAkc3RhdGUsICRzdGF0ZVBhcmFtcykge1xuICAgICAgICB2YXIgZGVmYXVsdFRhYmxlQ29uZmlnID0ge1xuICAgICAgICAgICAgZmlsdGVyczogW10sXG4gICAgICAgICAgICBxdWVyeUtleXM6IHtcbiAgICAgICAgICAgICAgICBwYWdlOiAncGFnZScsXG4gICAgICAgICAgICAgICAgbGltaXQ6ICdsaW1pdCcsXG4gICAgICAgICAgICAgICAgc29ydEJ5OiAnc29ydC1ieScsXG4gICAgICAgICAgICAgICAgc29ydERpcjogJ3NvcnQtb3JkZXInXG4gICAgICAgICAgICB9LFxuICAgICAgICAgICAgcm93SWRLZXk6ICdpZCcsXG4gICAgICAgICAgICBzb3J0RGlyVmFsdWVzOiB7XG4gICAgICAgICAgICAgICAgYXNjOiAnYXNjJyxcbiAgICAgICAgICAgICAgICBkZXNjOiAnZGVzYydcbiAgICAgICAgICAgIH1cbiAgICAgICAgfTtcblxuICAgICAgICBmdW5jdGlvbiBTZXJ2ZXJUYWJsZSh0YWJsZUlkLCB0YWJsZUNvbmZpZykge1xuICAgICAgICAgICAgdGhpcy5hbGxTZWxlY3RlZCA9IGZhbHNlO1xuICAgICAgICAgICAgdGhpcy5maWx0ZXJzID0ge307XG4gICAgICAgICAgICB0aGlzLmlkID0gdGFibGVJZDtcbiAgICAgICAgICAgIHRoaXMucGFnaW5hdGlvbiA9IHtcbiAgICAgICAgICAgICAgICBwYWdlOiBudWxsLFxuICAgICAgICAgICAgICAgIGxpbWl0OiBudWxsLFxuICAgICAgICAgICAgICAgIHRvdGFsOiBudWxsXG4gICAgICAgICAgICB9O1xuICAgICAgICAgICAgdGhpcy5wZW5kaW5nUmVxdWVzdCA9IGZhbHNlO1xuICAgICAgICAgICAgdGhpcy5yZXNvdXJjZUNhbGxiYWNrID0gYW5ndWxhci5ub29wO1xuICAgICAgICAgICAgdGhpcy5yb3dzID0gW107XG4gICAgICAgICAgICB0aGlzLnNlbGVjdGVkUm93cyA9IHt9O1xuICAgICAgICAgICAgdGhpcy5zb3J0QnkgPSAnJztcbiAgICAgICAgICAgIHRoaXMuc29ydERpciA9ICcnO1xuICAgICAgICAgICAgXG4gICAgICAgICAgICB0aGlzLnRhYmxlQ29uZmlnID0gXy5pc09iamVjdCh0YWJsZUNvbmZpZykgPyB0YWJsZUNvbmZpZyA6IHt9O1xuICAgICAgICAgICAgdGhpcy50YWJsZUNvbmZpZyA9IF8uZGVmYXVsdHModGhpcy50YWJsZUNvbmZpZywgZGVmYXVsdFRhYmxlQ29uZmlnKTtcbiAgICAgICAgfVxuXG4gICAgICAgIFNlcnZlclRhYmxlLnByb3RvdHlwZSA9IHtcbiAgICAgICAgICAgIGNyZWF0ZVBhcmFtc09iamVjdDogY3JlYXRlUGFyYW1zT2JqZWN0LFxuICAgICAgICAgICAgZmV0Y2hSZXNvdXJjZTogZmV0Y2hSZXNvdXJjZSxcbiAgICAgICAgICAgIGdldFNlbGVjdGVkUm93czogZ2V0U2VsZWN0ZWRSb3dzLFxuICAgICAgICAgICAgaW5pdDogaW5pdCxcbiAgICAgICAgICAgIGlzUm93U2VsZWN0ZWQ6IGlzUm93U2VsZWN0ZWQsXG4gICAgICAgICAgICBsb2FkU3RhdGVQYXJhbXM6IGxvYWRTdGF0ZVBhcmFtcyxcbiAgICAgICAgICAgIHNlbGVjdEFsbFJvd3M6IHNlbGVjdEFsbFJvd3MsXG4gICAgICAgICAgICBzZXRQYWdpbmF0aW9uVmFsdWVzOiBzZXRQYWdpbmF0aW9uVmFsdWVzLFxuICAgICAgICAgICAgc2V0Um93czogc2V0Um93cyxcbiAgICAgICAgICAgIHNldFNvcnRpbmdWYWx1ZXM6IHNldFNvcnRpbmdWYWx1ZXMsXG4gICAgICAgICAgICB1cGRhdGVQYWdlOiB1cGRhdGVQYWdlLFxuICAgICAgICAgICAgdXBkYXRlU29ydDogdXBkYXRlU29ydCxcbiAgICAgICAgICAgIHVwZGF0ZVRhYmxlOiB1cGRhdGVUYWJsZSxcbiAgICAgICAgICAgIHZhbGlkYXRlUmVzb3VyY2U6IHZhbGlkYXRlUmVzb3VyY2VcbiAgICAgICAgfTtcblxuICAgICAgICBmdW5jdGlvbiBjcmVhdGVQYXJhbXNPYmplY3QoKSB7XG4gICAgICAgICAgICB2YXIgcGFyYW1zID0ge30sXG4gICAgICAgICAgICAgICAgcXVlcnlLZXlzID0gdGhpcy50YWJsZUNvbmZpZy5xdWVyeUtleXMsXG4gICAgICAgICAgICAgICAgcXVlcnlQYXJhbU1hcCA9IFt7XG4gICAgICAgICAgICAgICAgICAgICAgICBxdWVyeUtleTogcXVlcnlLZXlzLnBhZ2UsXG4gICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZTogdGhpcy5wYWdpbmF0aW9uLnBhZ2VcbiAgICAgICAgICAgICAgICAgICAgfSwge1xuICAgICAgICAgICAgICAgICAgICAgICAgcXVlcnlLZXk6IHF1ZXJ5S2V5cy5saW1pdCxcbiAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlOiB0aGlzLnBhZ2luYXRpb24ubGltaXRcbiAgICAgICAgICAgICAgICAgICAgfSwge1xuICAgICAgICAgICAgICAgICAgICAgICAgcXVlcnlLZXk6IHF1ZXJ5S2V5cy5zb3J0QnksXG4gICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZTogdGhpcy5zb3J0QnlcbiAgICAgICAgICAgICAgICAgICAgfSwge1xuICAgICAgICAgICAgICAgICAgICAgICAgcXVlcnlLZXk6IHF1ZXJ5S2V5cy5zb3J0RGlyLFxuICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU6IHRoaXMuc29ydERpclxuICAgICAgICAgICAgICAgICAgICB9XTtcblxuICAgICAgICAgICAgXy5lYWNoKHF1ZXJ5UGFyYW1NYXAsIGZ1bmN0aW9uIHF1ZXJ5UGFyYW1NYXBFYWNoKHBhcmFtKSB7XG4gICAgICAgICAgICAgICAgaWYgKHBhcmFtLnF1ZXJ5S2V5ICE9PSB1bmRlZmluZWQpIHtcbiAgICAgICAgICAgICAgICAgICAgcGFyYW1zW3BhcmFtLnF1ZXJ5S2V5XSA9IHBhcmFtLnZhbHVlO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH0pO1xuXG4gICAgICAgICAgICBfLmV4dGVuZChwYXJhbXMsIHRoaXMuZmlsdGVycyk7XG5cbiAgICAgICAgICAgIHJldHVybiBwYXJhbXM7XG4gICAgICAgIH1cblxuICAgICAgICBmdW5jdGlvbiBmZXRjaFJlc291cmNlKCkge1xuICAgICAgICAgICAgdmFyIF90aGlzID0gdGhpcztcblxuICAgICAgICAgICAgdGhpcy5wZW5kaW5nUmVxdWVzdCA9IHRydWU7XG4gICAgICAgICAgICByZXR1cm4gdGhpcy5yZXNvdXJjZUNhbGxiYWNrKHRoaXMuY3JlYXRlUGFyYW1zT2JqZWN0KCkpXG4gICAgICAgICAgICAgICAgLnRoZW4oZnVuY3Rpb24gcmVzb3VyY2VDYWxsYmFja1RoZW4ocmVzb3VyY2UpIHtcbiAgICAgICAgICAgICAgICAgICAgaWYgKF90aGlzLnZhbGlkYXRlUmVzb3VyY2UocmVzb3VyY2UpKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICBfdGhpcy5zZXRSb3dzKHJlc291cmNlLnJvd3MpO1xuICAgICAgICAgICAgICAgICAgICAgICAgX3RoaXMuc2V0UGFnaW5hdGlvblZhbHVlcyhyZXNvdXJjZS5wYWdpbmF0aW9uKTtcbiAgICAgICAgICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBfdGhpcztcbiAgICAgICAgICAgICAgICB9KVxuICAgICAgICAgICAgICAgIC5jYXRjaChmdW5jdGlvbiByZXNvdXJjZUNhbGxiYWNrQ2F0Y2goKSB7XG4gICAgICAgICAgICAgICAgICAgICRsb2cuZXJyb3IoJ2JjLXNlcnZlci10YWJsZSBkaXJlY3RpdmU6IGZhaWxlZCB0byBmZXRjaCByZXNvdXJjZScpO1xuICAgICAgICAgICAgICAgIH0pXG4gICAgICAgICAgICAgICAgLmZpbmFsbHkoZnVuY3Rpb24gcmVzb3VyY2VDYWxsYmFja0ZpbmFsbHkoKSB7XG4gICAgICAgICAgICAgICAgICAgIF90aGlzLnBlbmRpbmdSZXF1ZXN0ID0gZmFsc2U7XG4gICAgICAgICAgICAgICAgfSk7XG4gICAgICAgIH1cblxuICAgICAgICBmdW5jdGlvbiBnZXRTZWxlY3RlZFJvd3MoKSB7XG4gICAgICAgICAgICB2YXIgX3RoaXMgPSB0aGlzO1xuXG4gICAgICAgICAgICByZXR1cm4gXy5maWx0ZXIodGhpcy5yb3dzLCBmdW5jdGlvbiBnZXRTZWxlY3RlZFJvd3NGaWx0ZXIocm93KSB7XG4gICAgICAgICAgICAgICAgcmV0dXJuIF90aGlzLmlzUm93U2VsZWN0ZWQocm93KTtcbiAgICAgICAgICAgIH0pO1xuICAgICAgICB9XG5cbiAgICAgICAgZnVuY3Rpb24gaW5pdChjb25maWcpIHtcbiAgICAgICAgICAgIGlmICghXy5pc09iamVjdChjb25maWcpKSB7XG4gICAgICAgICAgICAgICAgY29uZmlnID0ge307XG4gICAgICAgICAgICB9XG5cbiAgICAgICAgICAgIGlmIChfLmlzRnVuY3Rpb24oY29uZmlnLnJlc291cmNlQ2FsbGJhY2spKSB7XG4gICAgICAgICAgICAgICAgdGhpcy5yZXNvdXJjZUNhbGxiYWNrID0gY29uZmlnLnJlc291cmNlQ2FsbGJhY2s7XG4gICAgICAgICAgICB9XG5cbiAgICAgICAgICAgIHJldHVybiB0aGlzXG4gICAgICAgICAgICAgICAgLmxvYWRTdGF0ZVBhcmFtcyhjb25maWcuc3RhdGVQYXJhbXMpXG4gICAgICAgICAgICAgICAgLmZldGNoUmVzb3VyY2UoKTtcbiAgICAgICAgfVxuXG4gICAgICAgIGZ1bmN0aW9uIGlzUm93U2VsZWN0ZWQocm93KSB7XG4gICAgICAgICAgICByZXR1cm4gdGhpcy5zZWxlY3RlZFJvd3Nbcm93W3RoaXMudGFibGVDb25maWcucm93SWRLZXldXTtcbiAgICAgICAgfVxuXG4gICAgICAgIGZ1bmN0aW9uIGxvYWRTdGF0ZVBhcmFtcyhzdGF0ZVBhcmFtcykge1xuICAgICAgICAgICAgdmFyIHF1ZXJ5S2V5cyA9IHRoaXMudGFibGVDb25maWcucXVlcnlLZXlzLFxuICAgICAgICAgICAgICAgIF90aGlzID0gdGhpcztcblxuICAgICAgICAgICAgc3RhdGVQYXJhbXMgPSBzdGF0ZVBhcmFtcyB8fCAkc3RhdGVQYXJhbXM7XG5cbiAgICAgICAgICAgIHRoaXMuc2V0UGFnaW5hdGlvblZhbHVlcyh7XG4gICAgICAgICAgICAgICAgcGFnZTogc3RhdGVQYXJhbXNbcXVlcnlLZXlzLnBhZ2VdLFxuICAgICAgICAgICAgICAgIGxpbWl0OiBzdGF0ZVBhcmFtc1txdWVyeUtleXMubGltaXRdXG4gICAgICAgICAgICB9KTtcblxuICAgICAgICAgICAgdGhpcy5zZXRTb3J0aW5nVmFsdWVzKHN0YXRlUGFyYW1zW3F1ZXJ5S2V5cy5zb3J0QnldLCBzdGF0ZVBhcmFtc1txdWVyeUtleXMuc29ydERpcl0pO1xuXG4gICAgICAgICAgICAvLyBzZXQgZmlsdGVycyBmcm9tIHF1ZXJ5IHBhcmFtc1xuICAgICAgICAgICAgXy5lYWNoKHRoaXMudGFibGVDb25maWcuZmlsdGVycywgZnVuY3Rpb24gc2V0RmlsdGVyc0VhY2godmFsdWUpIHtcbiAgICAgICAgICAgICAgICBfdGhpcy5maWx0ZXJzW3ZhbHVlXSA9IHN0YXRlUGFyYW1zW3ZhbHVlXTtcbiAgICAgICAgICAgIH0pO1xuXG4gICAgICAgICAgICByZXR1cm4gdGhpcztcbiAgICAgICAgfVxuXG4gICAgICAgIGZ1bmN0aW9uIHNlbGVjdEFsbFJvd3MoKSB7XG4gICAgICAgICAgICB2YXIgX3RoaXMgPSB0aGlzO1xuXG4gICAgICAgICAgICB0aGlzLmFsbFNlbGVjdGVkID0gIXRoaXMuYWxsU2VsZWN0ZWQ7XG4gICAgICAgICAgICBfLmVhY2godGhpcy5zZWxlY3RlZFJvd3MsIGZ1bmN0aW9uIHNlbGVjdEFsbFJvd3NFYWNoKHZhbHVlLCBrZXkpIHtcbiAgICAgICAgICAgICAgICBfdGhpcy5zZWxlY3RlZFJvd3Nba2V5XSA9IF90aGlzLmFsbFNlbGVjdGVkO1xuICAgICAgICAgICAgfSk7XG5cbiAgICAgICAgICAgIHJldHVybiB0aGlzO1xuICAgICAgICB9XG5cbiAgICAgICAgZnVuY3Rpb24gc2V0UGFnaW5hdGlvblZhbHVlcyhwYWdpbmF0aW9uKSB7XG4gICAgICAgICAgICB0aGlzLnBhZ2luYXRpb24gPSB0aGlzLnBhZ2luYXRpb24gfHwge307XG4gICAgICAgICAgICBfLmV4dGVuZCh0aGlzLnBhZ2luYXRpb24sIHBhZ2luYXRpb24pO1xuXG4gICAgICAgICAgICByZXR1cm4gdGhpcztcbiAgICAgICAgfVxuXG4gICAgICAgIGZ1bmN0aW9uIHNldFJvd3Mocm93cykge1xuICAgICAgICAgICAgdmFyIF90aGlzID0gdGhpcztcblxuICAgICAgICAgICAgdGhpcy5yb3dzID0gcm93cztcbiAgICAgICAgICAgIHRoaXMuc2VsZWN0ZWRSb3dzID0gXy5yZWR1Y2Uocm93cywgZnVuY3Rpb24gaW5pdGlhbGl6ZVNlbGVjdGVkUm93c09iamVjdChhY2N1bSwgcm93KSB7XG4gICAgICAgICAgICAgICAgYWNjdW1bcm93W190aGlzLnRhYmxlQ29uZmlnLnJvd0lkS2V5XV0gPSBmYWxzZTtcbiAgICAgICAgICAgICAgICByZXR1cm4gYWNjdW07XG4gICAgICAgICAgICB9LCB7fSk7XG5cbiAgICAgICAgICAgIHJldHVybiB0aGlzO1xuICAgICAgICB9XG5cbiAgICAgICAgZnVuY3Rpb24gc2V0U29ydGluZ1ZhbHVlcyhzb3J0QnksIHNvcnREaXIpIHtcbiAgICAgICAgICAgIHRoaXMuc29ydEJ5ID0gc29ydEJ5IHx8IHRoaXMuc29ydEJ5O1xuICAgICAgICAgICAgdGhpcy5zb3J0RGlyID0gc29ydERpciB8fCB0aGlzLnNvcnREaXI7XG5cbiAgICAgICAgICAgIHJldHVybiB0aGlzO1xuICAgICAgICB9XG5cbiAgICAgICAgZnVuY3Rpb24gdXBkYXRlUGFnZShwYWdlLCBsaW1pdCwgdG90YWwpIHtcbiAgICAgICAgICAgIHJldHVybiB0aGlzXG4gICAgICAgICAgICAgICAgLnNldFBhZ2luYXRpb25WYWx1ZXMocGFnZSwgbGltaXQsIHRvdGFsKVxuICAgICAgICAgICAgICAgIC51cGRhdGVUYWJsZSgpO1xuICAgICAgICB9XG5cbiAgICAgICAgZnVuY3Rpb24gdXBkYXRlU29ydChzb3J0QnksIHNvcnREaXIpIHtcbiAgICAgICAgICAgIHJldHVybiB0aGlzXG4gICAgICAgICAgICAgICAgLnNldFNvcnRpbmdWYWx1ZXMoc29ydEJ5LCBzb3J0RGlyKVxuICAgICAgICAgICAgICAgIC5zZXRQYWdpbmF0aW9uVmFsdWVzKHtcbiAgICAgICAgICAgICAgICAgICAgcGFnZTogMVxuICAgICAgICAgICAgICAgIH0pXG4gICAgICAgICAgICAgICAgLnVwZGF0ZVRhYmxlKCk7XG4gICAgICAgIH1cblxuICAgICAgICBmdW5jdGlvbiB1cGRhdGVUYWJsZSgpIHtcbiAgICAgICAgICAgIGlmICghdGhpcy5wZW5kaW5nUmVxdWVzdCkge1xuICAgICAgICAgICAgICAgICRzdGF0ZS5nbygkc3RhdGUuY3VycmVudC5uYW1lLCB0aGlzLmNyZWF0ZVBhcmFtc09iamVjdCgpKTtcbiAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgcmV0dXJuIHRoaXM7XG4gICAgICAgIH1cblxuICAgICAgICBmdW5jdGlvbiB2YWxpZGF0ZVJlc291cmNlKHJlc291cmNlKSB7XG4gICAgICAgICAgICBpZiAoIV8uaXNPYmplY3QocmVzb3VyY2UpKSB7XG4gICAgICAgICAgICAgICAgJGxvZy5lcnJvcignYmMtc2VydmVyLXRhYmxlIGRpcmVjdGl2ZTogUmVzb3VyY2UgY2FsbGJhY2sgbXVzdCByZXR1cm4gYW4gb2JqZWN0Jyk7XG4gICAgICAgICAgICAgICAgcmV0dXJuIGZhbHNlO1xuICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICBpZiAoIV8uaXNBcnJheShyZXNvdXJjZS5yb3dzKSkge1xuICAgICAgICAgICAgICAgICRsb2cuZXJyb3IoJ2JjLXNlcnZlci10YWJsZSBkaXJlY3RpdmU6IHJldHVybmVkIG9iamVjdCBtdXN0IGNvbnRhaW4gYSByb3dzIHByb3BlcnR5IHRoYXQgaXMgYW4gYXJyYXkuJyk7XG4gICAgICAgICAgICAgICAgcmV0dXJuIGZhbHNlO1xuICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICBpZiAoIV8uaXNPYmplY3QocmVzb3VyY2UucGFnaW5hdGlvbikpIHtcbiAgICAgICAgICAgICAgICAkbG9nLmVycm9yKCdiYy1zZXJ2ZXItdGFibGUgZGlyZWN0aXZlOiByZXR1cm5lZCBvYmplY3QgbXVzdCBjb250YWluIGEgcGFnaW5hdGlvbiBwcm9wZXJ0eSB0aGF0IGlzIGFuIG9iamVjdC4nKTtcbiAgICAgICAgICAgICAgICByZXR1cm4gZmFsc2U7XG4gICAgICAgICAgICB9XG5cbiAgICAgICAgICAgIHJldHVybiB0cnVlO1xuICAgICAgICB9XG5cbiAgICAgICAgcmV0dXJuIFNlcnZlclRhYmxlO1xuICAgIH0pO1xuIiwiLyoqXG4gKiBAbmFtZSBjYy1leHBpcnkgZGlyZWN0aXZlXG4gKiBAZGVzY3JpcHRpb24gQSBkaXJlY3RpdmUgZm9sbG93aW5nIGFuZ3VsYXItY3JlZGl0LWNhcmQncyBhcHByb2FjaCB0byB2YWxpZGF0aW5nL2Zvcm1hdHRpbmcgY3JlZGl0IGNhcmQgZXhwaXJhdGlvbiBkYXRlLlxuICogRXhwZWN0IHRoZSBjYy1leHBpcnkgbmdNb2RlbCB0byBiZSBpbiB0aGUgZm9ybWF0IG9mIGB7IG1vbnRoOiAnMDUnLCB5ZWFyOiAnMjAxNyd9YC5cbiAqL1xuYW5ndWxhci5tb2R1bGUoJ2JjYXBwLXBhdHRlcm4tbGFiLmNyZWRpdC1jYXJkLmNjLWV4cGlyeS5kaXJlY3RpdmUnLCBbXSlcbiAgICAuZGlyZWN0aXZlKCdjY0V4cGlyeScsIGZ1bmN0aW9uIGNjRXhwRGlyZWN0aXZlKCRmaWx0ZXIpIHtcbiAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICAgIGNvbXBpbGU6IGZ1bmN0aW9uICh0RWxlbSwgdEF0dHIpIHtcbiAgICAgICAgICAgICAgICBjb25zdCBFWFBJUkFUSU9OX01BWF9MRU5HVEggPSA3OyAvLyBsZW5ndGggb2YgYE1NIC8geXlgXG5cbiAgICAgICAgICAgICAgICB0QXR0ci4kc2V0KCdhdXRvY29tcGxldGUnLCAnY2MtZXhwJyk7XG4gICAgICAgICAgICAgICAgdEF0dHIuJHNldCgnbWF4bGVuZ3RoJywgRVhQSVJBVElPTl9NQVhfTEVOR1RIKTtcbiAgICAgICAgICAgICAgICB0QXR0ci4kc2V0KCdwYXR0ZXJuJywgJ1swLTldKicpOyAvLyBmb3IgbW9iaWxlIGtleWJvYXJkIGRpc3BsYXlcblxuICAgICAgICAgICAgICAgIHJldHVybiBmdW5jdGlvbiBjY0V4cGlyeUxpbmsoc2NvcGUsIHRFbGVtLCB0QXR0ciwgbmdNb2RlbEN0cmwpIHtcbiAgICAgICAgICAgICAgICAgICAgaW5pdCgpO1xuXG4gICAgICAgICAgICAgICAgICAgIGZ1bmN0aW9uIGluaXQoKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICBuZ01vZGVsQ3RybC4kcGFyc2Vycy51bnNoaWZ0KHBhcnNlcik7XG4gICAgICAgICAgICAgICAgICAgICAgICBuZ01vZGVsQ3RybC4kZm9ybWF0dGVycy5wdXNoKGZvcm1hdHRlcik7XG4gICAgICAgICAgICAgICAgICAgICAgICBuZ01vZGVsQ3RybC4kdmFsaWRhdG9ycy52YWxpZEZ1dHVyZURhdGUgPSB2YWxpZEZ1dHVyZURhdGU7XG5cbiAgICAgICAgICAgICAgICAgICAgICAgIHNjb3BlLiR3YXRjaChnZXRWaWV3VmFsdWUsIHJlbmRlckZvcm1hdHRlZFZpZXcpO1xuICAgICAgICAgICAgICAgICAgICB9XG5cbiAgICAgICAgICAgICAgICAgICAgLyoqXG4gICAgICAgICAgICAgICAgICAgICAqIGdldCB0aGUgaW5wdXQncyB2aWV3IHZhbHVlXG4gICAgICAgICAgICAgICAgICAgICAqL1xuICAgICAgICAgICAgICAgICAgICBmdW5jdGlvbiBnZXRWaWV3VmFsdWUoKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gbmdNb2RlbEN0cmwuJHZpZXdWYWx1ZTtcbiAgICAgICAgICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAgICAgICAgIC8qKlxuICAgICAgICAgICAgICAgICAgICAgKiBmb3JtYXRzIHRoZSBpbnB1dCB2aWV3IHZhbHVlIHRvIGJlIHRoZSBmb3JtYXQgYE1NIC8geXlgIGFuZCByZS1yZW5kZXJzIHZpZXdcbiAgICAgICAgICAgICAgICAgICAgICovXG4gICAgICAgICAgICAgICAgICAgIGZ1bmN0aW9uIHJlbmRlckZvcm1hdHRlZFZpZXcodmlld1ZhbHVlLCBwcmV2Vmlld1ZhbHVlKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICBpZiAoIXZpZXdWYWx1ZSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgICAgICAgICAgICAgLy8gYSBuZXcgdmFsdWUgaXMgYWRkZWQgKGFzIG9wcG9zZWQgdG8gcHJlc3NpbmcgYmFja3NwYWNlKVxuICAgICAgICAgICAgICAgICAgICAgICAgY29uc3QgaXNBZGRpdGlvbiA9IHZpZXdWYWx1ZS5sZW5ndGggPiBwcmV2Vmlld1ZhbHVlLmxlbmd0aDtcblxuICAgICAgICAgICAgICAgICAgICAgICAgbmdNb2RlbEN0cmwuJHNldFZpZXdWYWx1ZShmb3JtYXQodmlld1ZhbHVlLCBpc0FkZGl0aW9uKSk7XG4gICAgICAgICAgICAgICAgICAgICAgICBuZ01vZGVsQ3RybC4kcmVuZGVyKCk7XG4gICAgICAgICAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgICAgICAgICAvKipcbiAgICAgICAgICAgICAgICAgICAgICogVmFsaWRhdGVzIHdoZXRoZXIgdGhlIGVudGVyZWQgZXhwaXJhdGlvbiBkYXRlIGlzIHZhbGlkXG4gICAgICAgICAgICAgICAgICAgICAqL1xuICAgICAgICAgICAgICAgICAgICBmdW5jdGlvbiB2YWxpZEZ1dHVyZURhdGUobW9kZWxWYWx1ZSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgY29uc3Qge21vbnRoLCB5ZWFyfSA9IG1vZGVsVmFsdWU7XG5cbiAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiBpc1ZhbGlkRGF0ZShtb250aCwgeWVhcikgJiYgIWlzUGFzdChtb250aCwgeWVhcik7XG4gICAgICAgICAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgICAgICAgICAvKipcbiAgICAgICAgICAgICAgICAgICAgICogVmFsaWRhdGVzIHdoZXRoZXIgdGhlIGdpdmVuIG1vbnRoIGFuZCB5ZWFyIGFyZSBudW1iZXIgc3RyaW5ncyB3aXRoIGxlbmd0aCBvZiAyIGFuZCA0IHJlc3BlY3RpdmVseVxuICAgICAgICAgICAgICAgICAgICAgKi9cbiAgICAgICAgICAgICAgICAgICAgZnVuY3Rpb24gaXNWYWxpZERhdGUobW9udGgsIHllYXIpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IG1vbnRoUmVnZXggPSAvXlswLTldezJ9JC87XG4gICAgICAgICAgICAgICAgICAgICAgICBjb25zdCB5ZWFyUmVnZXggPSAvXlswLTldezR9JC87XG5cbiAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiBfLmlzU3RyaW5nKG1vbnRoKSAmJlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIF8uaXNTdHJpbmcoeWVhcikgJiZcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBtb250aFJlZ2V4LnRlc3QobW9udGgpICYmXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgeWVhclJlZ2V4LnRlc3QoeWVhcikgJiZcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpc1ZhbGlkTW9udGgobW9udGgpO1xuICAgICAgICAgICAgICAgICAgICB9XG5cbiAgICAgICAgICAgICAgICAgICAgLyoqXG4gICAgICAgICAgICAgICAgICAgICAqIENoZWNrcyB3aGV0aGVyIHRoZSBtb250aCBpcyB2YWxpZFxuICAgICAgICAgICAgICAgICAgICAgKi9cbiAgICAgICAgICAgICAgICAgICAgZnVuY3Rpb24gaXNWYWxpZE1vbnRoKG1vbnRoKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICBtb250aCA9IF8ucGFyc2VJbnQobW9udGgpO1xuXG4gICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gbW9udGggPiAwICYmIG1vbnRoIDwgMTM7XG4gICAgICAgICAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgICAgICAgICAvKipcbiAgICAgICAgICAgICAgICAgICAgICogQ2hlY2tzIHdoZXRoZXIgdGhlIGdpdmVuIG1vbnRoIGFuZCBkYXRlIGlzIGluIHRoZSBwYXN0XG4gICAgICAgICAgICAgICAgICAgICAqL1xuICAgICAgICAgICAgICAgICAgICBmdW5jdGlvbiBpc1Bhc3QobW9udGgsIHllYXIpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiBnZXRDdXJyTW9udGhEYXRlKCkgPiBuZXcgRGF0ZSh5ZWFyLCBtb250aCAtIDEpO1xuICAgICAgICAgICAgICAgICAgICB9XG5cbiAgICAgICAgICAgICAgICAgICAgLyoqXG4gICAgICAgICAgICAgICAgICAgICAqIEdldCB0aGUgZGF0ZSBvYmplY3QgYmFzZWQgb24gY3VycmVudCBtb250aCBhbmQgeWVhclxuICAgICAgICAgICAgICAgICAgICAgKi9cbiAgICAgICAgICAgICAgICAgICAgZnVuY3Rpb24gZ2V0Q3Vyck1vbnRoRGF0ZSgpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IGRhdGUgPSBuZXcgRGF0ZSgpO1xuXG4gICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gbmV3IERhdGUoZGF0ZS5nZXRGdWxsWWVhcigpLCBkYXRlLmdldE1vbnRoKCkpO1xuICAgICAgICAgICAgICAgICAgICB9XG5cbiAgICAgICAgICAgICAgICAgICAgLyoqXG4gICAgICAgICAgICAgICAgICAgICAqIFVzZXMgYW5ndWxhciBkYXRlIGZpbHRlciB0byBmb3JtYXQgZGF0ZSBtb2RlbCB0byBjb3JyZXNwb25kaW5nIHZpZXcgZm9ybWF0XG4gICAgICAgICAgICAgICAgICAgICAqL1xuICAgICAgICAgICAgICAgICAgICBmdW5jdGlvbiBmb3JtYXR0ZXIoZXhwID0ge30pIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IG1vbnRoID0gZXhwLm1vbnRoO1xuICAgICAgICAgICAgICAgICAgICAgICAgY29uc3QgeWVhciA9IGV4cC55ZWFyO1xuXG4gICAgICAgICAgICAgICAgICAgICAgICBpZiAoXy5pc0VtcHR5KG1vbnRoKSAmJiBfLmlzRW1wdHkoeWVhcikpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gJyc7XG4gICAgICAgICAgICAgICAgICAgICAgICB9XG5cbiAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiAkZmlsdGVyKCdkYXRlJykobmV3IERhdGUoeWVhciwgbW9udGggLSAxKSwgJ01NIC8geXknKTtcbiAgICAgICAgICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAgICAgICAgIC8qKlxuICAgICAgICAgICAgICAgICAgICAgKiBQYXJzZXMgdGhlIGZvcm1hdHRlZCB2aWV3IHZhbHVlcyB0byBtb2RlbC4gQ29udmVydHMgMiBkaWdpdCB5ZWFyIHRvIGZ1bGwgNCBkaWdpdCB5ZWFyXG4gICAgICAgICAgICAgICAgICAgICAqIEBwYXJhbSBleHBpcmF0aW9uIHtvYmplY3R9IFRoZSBleHBpcmF0aW9uIG9iamVjdCB7bW9udGgsIHllYXJ9XG4gICAgICAgICAgICAgICAgICAgICAqL1xuICAgICAgICAgICAgICAgICAgICBmdW5jdGlvbiBwYXJzZXIoZXhwaXJhdGlvbikge1xuICAgICAgICAgICAgICAgICAgICAgICAgY29uc3QgYmFzZVllYXIgPSBuZXcgRGF0ZSgpLmdldEZ1bGxZZWFyKCkudG9TdHJpbmcoKS5zbGljZSgwLCAyKTsgLy8gYCcyMCdgXG4gICAgICAgICAgICAgICAgICAgICAgICBjb25zdCB2YWx1ZXMgPSBleHBpcmF0aW9uLnNwbGl0KCcvJyk7XG4gICAgICAgICAgICAgICAgICAgICAgICBjb25zdCBtb250aCA9IHZhbHVlc1swXSA/IHZhbHVlc1swXS50cmltKCkgOiAnJztcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IHllYXIgPSB2YWx1ZXNbMV0gPyBiYXNlWWVhciArIHZhbHVlc1sxXS50cmltKCkgOiAnJztcblxuICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIHsgbW9udGgsIHllYXIgfTtcbiAgICAgICAgICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAgICAgICAgIC8qKlxuICAgICAgICAgICAgICAgICAgICAgKiBmb3JtYXRzIHRoZSB2aWV3IHZhbHVlIHRvIHRoZSBmb3JtICdNTSAvIHl5J1xuICAgICAgICAgICAgICAgICAgICAgKi9cbiAgICAgICAgICAgICAgICAgICAgZnVuY3Rpb24gZm9ybWF0KGV4cFN0ciwgaXNBZGRpdGlvbikge1xuICAgICAgICAgICAgICAgICAgICAgICAgY29uc3QgdmFsdWVzID0gZXhwU3RyLnNwbGl0KCcvJyk7XG4gICAgICAgICAgICAgICAgICAgICAgICBjb25zdCBtb250aCA9IHZhbHVlc1swXSA/IHZhbHVlc1swXS50cmltKCkgOiAnJztcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IHllYXIgPSB2YWx1ZXNbMV0gPyB2YWx1ZXNbMV0udHJpbSgpLnNsaWNlKC0yKSA6ICcnO1xuXG4gICAgICAgICAgICAgICAgICAgICAgICAvLyBkb24ndCBhZGQgc2xhc2hcbiAgICAgICAgICAgICAgICAgICAgICAgIGlmICgoIWlzQWRkaXRpb24gJiYgIXllYXIpIHx8IG1vbnRoLmxlbmd0aCA8IDIpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gbW9udGg7XG4gICAgICAgICAgICAgICAgICAgICAgICB9XG5cbiAgICAgICAgICAgICAgICAgICAgICAgIC8vIGFkZCBzbGFzaCBpbiB0aGUgcmlnaHQgc3BvdFxuICAgICAgICAgICAgICAgICAgICAgICAgaWYgKGlzQWRkaXRpb24gJiYgIXllYXIgJiYgbW9udGgubGVuZ3RoID4gMikge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiBgJHttb250aC5zbGljZSgwLCAyKX0gLyAke21vbnRoLnNsaWNlKDIpfWA7XG4gICAgICAgICAgICAgICAgICAgICAgICB9XG5cbiAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiBgJHttb250aH0gLyAke3llYXJ9YDtcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIH07XG4gICAgICAgICAgICB9LFxuICAgICAgICAgICAgcmVxdWlyZTogJ25nTW9kZWwnLFxuICAgICAgICAgICAgcmVzdHJpY3Q6ICdBJyxcbiAgICAgICAgfTtcbiAgICB9KTtcbiIsImFuZ3VsYXIubW9kdWxlKCdiY2FwcC1wYXR0ZXJuLWxhYi5jcmVkaXQtY2FyZC5jYy1leHBpcnknLCBbXG4gICAgJ2JjYXBwLXBhdHRlcm4tbGFiLmNyZWRpdC1jYXJkLmNjLWV4cGlyeS5kaXJlY3RpdmUnLFxuXSk7XG4iXSwic291cmNlUm9vdCI6Ii9zb3VyY2UvIn0=