/* */ 
(function(module) {
try { module = angular.module("bcapp-pattern-lab-templates"); }
catch(err) { module = angular.module("bcapp-pattern-lab-templates", []); }
module.run(["$templateCache", function($templateCache) {
  "use strict";
  $templateCache.put("src/js/bigcommerce/bc-pagination/bc-pagination.tpl.html",
    "<pagination></pagination>\n" +
    "\n" +
    "<div bc-dropdown class=\"pagination-limits\" ng-show=\"showLimits()\">\n" +
    "    <a bc-dropdown-toggle class=\"dropdown-button dropdown-button--tiny\" translate>View {{ getCurrentLimit() }}</a>\n" +
    "    <ul bc-dropdown-menu class=\"pagination-limits-list\">\n" +
    "        <li class=\"dropdown-menu-item pagination-limits-item\" ng-repeat=\"limit in getLimits()\">\n" +
    "            <a href=\"#\" ng-click=\"setLimit(limit, $event)\">{{ limit }}</a>\n" +
    "        </li>\n" +
    "    </ul>\n" +
    "</div>\n" +
    "");
}]);
})();

(function(module) {
try { module = angular.module("bcapp-pattern-lab-templates"); }
catch(err) { module = angular.module("bcapp-pattern-lab-templates", []); }
module.run(["$templateCache", function($templateCache) {
  "use strict";
  $templateCache.put("src/js/bigcommerce/bc-server-table/bc-sort-by.tpl.html",
    "<a href=\"#\" ng-click=\"sort($event)\">\n" +
    "    {{ columnName }}\n" +
    "    <icon glyph=\"ic-expand-less\" ng-if=\"sortBy === sortValue && sortDir === asc\"></icon>\n" +
    "    <icon glyph=\"ic-expand-more\" ng-if=\"sortBy === sortValue && sortDir === desc\"></icon>\n" +
    "</a>\n" +
    "");
}]);
})();

(function(module) {
try { module = angular.module("bcapp-pattern-lab-templates"); }
catch(err) { module = angular.module("bcapp-pattern-lab-templates", []); }
module.run(["$templateCache", function($templateCache) {
  "use strict";
  $templateCache.put("src/js/bigcommerce/credit-card/credit-card.tpl.html",
    "<div class=\"form-ccFields\">\n" +
    "    <form-field class=\"form-field--ccNumber\" property=\"ccNumber\">\n" +
    "        <label class=\"form-label\" for=\"ccNumber\" translate>\n" +
    "            Credit Card Number\n" +
    "        </label>\n" +
    "        <input autocomplete=\"cc-number\"\n" +
    "               cc-eager-type\n" +
    "               cc-format\n" +
    "               cc-number\n" +
    "               class=\"form-input\"\n" +
    "               id=\"ccNumber\"\n" +
    "               name=\"ccNumber\"\n" +
    "               ng-model=\"ccData.ccNumber\"\n" +
    "               ng-required=\"true\"\n" +
    "               type=\"text\"/>\n" +
    "\n" +
    "        <form-field-errors>\n" +
    "            <form-field-error validate=\"ccNumber\">{{ 'Credit Card Number must be valid' | translate }}</form-field-error>\n" +
    "            <form-field-error validate=\"required\">{{ 'Credit Card Number is required' | translate }}</form-field-error>\n" +
    "        </form-field-errors>\n" +
    "    </form-field>\n" +
    "\n" +
    "    <form-field class=\"form-field--ccExpiry\" property=\"ccExpiry\">\n" +
    "        <label class=\"form-label\" for=\"ccExpiry\" translate>\n" +
    "            Expiration\n" +
    "        </label>\n" +
    "        <input autocomplete=\"cc-exp\"\n" +
    "               cc-expiry\n" +
    "               class=\"form-input\"\n" +
    "               id=\"ccExpiry\"\n" +
    "               name=\"ccExpiry\"\n" +
    "               ng-model=\"ccData.ccExpiry\"\n" +
    "               ng-required=\"true\"\n" +
    "               placeholder=\"MM / YY\"\n" +
    "               type=\"text\"/>\n" +
    "\n" +
    "        <form-field-errors>\n" +
    "            <form-field-error validate=\"validFutureDate\">{{ 'Expiration Date must be a valid future date' | translate }}</form-field-error>\n" +
    "            <form-field-error validate=\"required\">{{ 'Expiration Date is required' | translate }}</form-field-error>\n" +
    "        </form-field-errors>\n" +
    "    </form-field>\n" +
    "\n" +
    "    <form-field class=\"form-field--ccName\" ng-if=\"ccConfig.fullName\" property=\"ccName\">\n" +
    "        <label class=\"form-label\" for=\"ccName\" translate>\n" +
    "            Name on Card\n" +
    "        </label>\n" +
    "        <input autocomplete=\"cc-name\"\n" +
    "               class=\"form-input\"\n" +
    "               id=\"ccName\"\n" +
    "               name=\"ccName\"\n" +
    "               ng-model=\"ccData.ccName\"\n" +
    "               ng-required=\"true\"\n" +
    "               type=\"text\"/>\n" +
    "\n" +
    "        <form-field-errors>\n" +
    "            <form-field-error validate=\"required\">{{ 'Full name is required' | translate }}</form-field-error>\n" +
    "        </form-field-errors>\n" +
    "    </form-field>\n" +
    "\n" +
    "    <form-field class=\"form-field--ccCvv\" ng-if=\"ccConfig.cardCode\" property=\"ccCvv\">\n" +
    "        <label class=\"form-label\" for=\"ccCvv\" translate>\n" +
    "            CVV\n" +
    "            <icon glyph=\"ic-help\"></icon>\n" +
    "        </label>\n" +
    "        <input autocomplete=\"cc-csc\"\n" +
    "               cc-cvc\n" +
    "               class=\"form-input\"\n" +
    "               id=\"ccCvv\"\n" +
    "               name=\"ccCvv\"\n" +
    "               ng-model=\"ccData.ccCvv\"\n" +
    "               ng-required=\"true\"\n" +
    "               type=\"text\"/>\n" +
    "\n" +
    "        <form-field-errors>\n" +
    "            <form-field-error validate=\"ccCvc\">{{ 'CVV must be valid' | translate }}</form-field-error>\n" +
    "            <form-field-error validate=\"required\">{{ 'CVV is required' | translate }}</form-field-error>\n" +
    "        </form-field-errors>\n" +
    "    </form-field>\n" +
    "</div>\n" +
    "");
}]);
})();

(function(module) {
try { module = angular.module("bcapp-pattern-lab-templates"); }
catch(err) { module = angular.module("bcapp-pattern-lab-templates", []); }
module.run(["$templateCache", function($templateCache) {
  "use strict";
  $templateCache.put("src/js/bigcommerce/form-field-error/form-field-error.tpl.html",
    "<li class=\"form-field-error\">\n" +
    "    <!-- translated, message-enabled label is transclued here -->\n" +
    "</li>\n" +
    "");
}]);
})();

(function(module) {
try { module = angular.module("bcapp-pattern-lab-templates"); }
catch(err) { module = angular.module("bcapp-pattern-lab-templates", []); }
module.run(["$templateCache", function($templateCache) {
  "use strict";
  $templateCache.put("src/js/bigcommerce/form-field-errors/form-field-errors.tpl.html",
    "<ul class=\"form-field-errors\"\n" +
    "    ng-messages=\"propertyField.$error\"\n" +
    "    ng-show=\"formCtrl.$submitted && propertyField.$invalid\"\n" +
    "    ng-transclude>\n" +
    "</ul>\n" +
    "");
}]);
})();

(function(module) {
try { module = angular.module("bcapp-pattern-lab-templates"); }
catch(err) { module = angular.module("bcapp-pattern-lab-templates", []); }
module.run(["$templateCache", function($templateCache) {
  "use strict";
  $templateCache.put("src/js/bigcommerce/loading-notification/loading-notification.tpl.html",
    "<div class=\"loadingNotification\" ng-show=\"requestInProgress\">\n" +
    "    <div class=\"loadingNotification-label\" translate>Loading&hellip;</div>\n" +
    "</div>\n" +
    "");
}]);
})();

(function(module) {
try { module = angular.module("bcapp-pattern-lab-templates"); }
catch(err) { module = angular.module("bcapp-pattern-lab-templates", []); }
module.run(["$templateCache", function($templateCache) {
  "use strict";
  $templateCache.put("src/js/bigcommerce/loading-overlay/loading-overlay.tpl.html",
    "<ng-transclude></ng-transclude>\n" +
    "<div class=\"loadingOverlay\" ng-if=\"loadingOverlayCtrl.loading\"></div>\n" +
    "");
}]);
})();

(function(module) {
try { module = angular.module("bcapp-pattern-lab-templates"); }
catch(err) { module = angular.module("bcapp-pattern-lab-templates", []); }
module.run(["$templateCache", function($templateCache) {
  "use strict";
  $templateCache.put("src/js/bigcommerce/switch/switch.tpl.html",
    "<div\n" +
    "    class=\"switch\"\n" +
    "    ng-class=\"{'switch--important': switchCtrl.isImportant, 'switch--checked': switchCtrl.isChecked }\">\n" +
    "\n" +
    "    <span\n" +
    "        class=\"switch-description--off\"\n" +
    "        ng-if=\"!!switchCtrl.leftDescription\">{{ switchCtrl.leftDescription }}</span>\n" +
    "\n" +
    "\n" +
    "    <input\n" +
    "        class=\"switch-checkbox\"\n" +
    "        type=\"checkbox\"\n" +
    "        id=\"{{ switchCtrl.uniqueId }}\"\n" +
    "        aria-describedby=\"{{ switchCtrl.ariaDescriptionID }}\"\n" +
    "        ng-change=\"switchCtrl.updateModel()\"\n" +
    "        ng-model=\"switchCtrl.value\">\n" +
    "\n" +
    "    <label class=\"switch-toggle\" for=\"{{ switchCtrl.uniqueId }}\">\n" +
    "\n" +
    "        <span class=\"switch-label\" ng-if=\"switchCtrl.labelText && !switchCtrl.hasIcon\">{{ switchCtrl.labelText }}</span>\n" +
    "        <icon\n" +
    "            class=\"switch-label switch-label--icon\"\n" +
    "            icon\n" +
    "            glyph=\"ic-check\"\n" +
    "            ng-if=\"switchCtrl.hasIcon\"\n" +
    "            ng-show=\"switchCtrl.isChecked\"></icon>\n" +
    "        <icon\n" +
    "            class=\"switch-label switch-label--icon\"\n" +
    "            icon\n" +
    "            glyph=\"ic-close\"\n" +
    "            ng-if=\"switchCtrl.hasIcon\"\n" +
    "            ng-show=\"!switchCtrl.isChecked\"></icon>\n" +
    "\n" +
    "    </label>\n" +
    "\n" +
    "    <span\n" +
    "        class=\"switch-description--on\"\n" +
    "        ng-if=\"!!switchCtrl.rightDescription\">{{ switchCtrl.rightDescription }}</span>\n" +
    "\n" +
    "    <span\n" +
    "        id=\"{{ switchCtrl.ariaDescriptionID }}\"\n" +
    "        ng-class=\"{'switch-ariaDescription': switchCtrl.ariaDescription }\">\n" +
    "        {{ switchCtrl.ariaDescription || 'Please use aria-description to describe this switch to screen readers' }}\n" +
    "    </span>\n" +
    "</div>\n" +
    "");
}]);
})();

(function(module) {
try { module = angular.module("bcapp-pattern-lab-templates"); }
catch(err) { module = angular.module("bcapp-pattern-lab-templates", []); }
module.run(["$templateCache", function($templateCache) {
  "use strict";
  $templateCache.put("template/accordion/accordion-group.html",
    "<article ng-class=\"{ 'is-open': isOpen }\">\n" +
    "    <h2 class=\"accordion-navigation\"  ng-class=\"{ 'is-open': isOpen }\">\n" +
    "        <a href=\"javascript:void(0)\" class=\"accordion-title\" ng-click=\"isOpen = !isOpen\" accordion-transclude=\"heading\">\n" +
    "            {{heading}}\n" +
    "        </a>\n" +
    "        <icon class=\"accordion-indicator\" glyph=\"{{ isOpen ? 'ic-remove' : 'ic-add' }}\" ng-click=\"isOpen = !isOpen\"></icon>\n" +
    "    </h2>\n" +
    "    <div class=\"accordion-content\" ng-class=\"{ 'is-open': isOpen }\" ng-transclude></div>\n" +
    "</article>\n" +
    "");
}]);
})();

(function(module) {
try { module = angular.module("bcapp-pattern-lab-templates"); }
catch(err) { module = angular.module("bcapp-pattern-lab-templates", []); }
module.run(["$templateCache", function($templateCache) {
  "use strict";
  $templateCache.put("template/accordion/accordion.html",
    "<section class=\"accordion\" ng-transclude></section>\n" +
    "");
}]);
})();

(function(module) {
try { module = angular.module("bcapp-pattern-lab-templates"); }
catch(err) { module = angular.module("bcapp-pattern-lab-templates", []); }
module.run(["$templateCache", function($templateCache) {
  "use strict";
  $templateCache.put("template/alert/alert.html",
    "<div class=\"alertBox\" ng-class=\"type ? 'alertBox--' + type : ''\">\n" +
    "    <div class=\"alertBox-column alertBox-icon\" ng-switch=\"type\">\n" +
    "        <icon ng-switch-when=\"info\" glyph=\"ic-info\"></icon>\n" +
    "        <icon ng-switch-when=\"success\" glyph=\"ic-check-circle\"></icon>\n" +
    "        <icon ng-switch-when=\"warning\" glyph=\"ic-error\"></icon>\n" +
    "        <icon ng-switch-when=\"error\" glyph=\"ic-error\"></icon>\n" +
    "        <icon ng-switch-default glyph=\"ic-info\"></icon>\n" +
    "    </div>\n" +
    "    <div class=\"alertBox-column alertBox-message\" ng-transclude></div>\n" +
    "    <a ng-show=\"closeable\" class=\"alertBox-column alertBox-close\" ng-click=\"close(); $event.preventDefault();\" tabindex=\"0\" href=\"#\">\n" +
    "        <icon glyph=\"ic-close\"></icon>\n" +
    "    </a>\n" +
    "</div>\n" +
    "");
}]);
})();

(function(module) {
try { module = angular.module("bcapp-pattern-lab-templates"); }
catch(err) { module = angular.module("bcapp-pattern-lab-templates", []); }
module.run(["$templateCache", function($templateCache) {
  "use strict";
  $templateCache.put("template/modal/backdrop.html",
    "<div class=\"modal-background\" ng-class=\"{'is-active': animate}\" ng-click=\"close($event)\"></div>\n" +
    "");
}]);
})();

(function(module) {
try { module = angular.module("bcapp-pattern-lab-templates"); }
catch(err) { module = angular.module("bcapp-pattern-lab-templates", []); }
module.run(["$templateCache", function($templateCache) {
  "use strict";
  $templateCache.put("template/modal/window.html",
    "<section class=\"modal fade {{ windowClass }}\"\n" +
    "    ng-class=\"{'is-active': animate}\"\n" +
    "    tabindex=\"-1\"\n" +
    "    ng-transclude\n" +
    "></section>\n" +
    "");
}]);
})();

(function(module) {
try { module = angular.module("bcapp-pattern-lab-templates"); }
catch(err) { module = angular.module("bcapp-pattern-lab-templates", []); }
module.run(["$templateCache", function($templateCache) {
  "use strict";
  $templateCache.put("template/pagination/pager.html",
    "<ul class=\"pagination-list\">\n" +
    "    <li\n" +
    "        ng-repeat=\"page in pages\"\n" +
    "        class=\"arrow\"\n" +
    "        ng-class=\"{unavailable: page.disabled, left: page.previous, right: page.next}\">\n" +
    "            <a class=\"pagination-link\" ng-click=\"selectPage(page.number)\">\n" +
    "                {{page.text}}\n" +
    "            </a>\n" +
    "    </li>\n" +
    "</ul>\n" +
    "");
}]);
})();

(function(module) {
try { module = angular.module("bcapp-pattern-lab-templates"); }
catch(err) { module = angular.module("bcapp-pattern-lab-templates", []); }
module.run(["$templateCache", function($templateCache) {
  "use strict";
  $templateCache.put("template/pagination/pagination.html",
    "<ul class=\"pagination-list\">\n" +
    "    <li\n" +
    "        class=\"pagination-item\"\n" +
    "        ng-repeat=\"page in pages\"\n" +
    "        ng-class=\"{'pagination-item--arrow': $first || $last, 'pagination-item--current': page.active, 'pagination-item--unavailable': page.disabled}\"\n" +
    "        ng-hide=\"$first && pages[$index + 1].active || $last && pages[$index - 1].active\"\n" +
    "    >\n" +
    "        <a class=\"pagination-link\" href=\"#\" ng-click=\"selectPage(page.number); $event.preventDefault();\">\n" +
    "            {{page.text}}\n" +
    "        </a>\n" +
    "    </li>\n" +
    "</ul>\n" +
    "");
}]);
})();

(function(module) {
try { module = angular.module("bcapp-pattern-lab-templates"); }
catch(err) { module = angular.module("bcapp-pattern-lab-templates", []); }
module.run(["$templateCache", function($templateCache) {
  "use strict";
  $templateCache.put("template/popover/popover.html",
    "<div class=\"joyride-tip-guide\" ng-class=\"{ in: isOpen(), fade: animation() }\">\n" +
    "  <span class=\"joyride-nub\" ng-class=\"{\n" +
    "    bottom: placement === 'top',\n" +
    "    left: placement === 'right',\n" +
    "    right: placement === 'left',\n" +
    "    top: placement === 'bottom'\n" +
    "  }\"></span>\n" +
    "  <div class=\"joyride-content-wrapper\">\n" +
    "    <h4 ng-bind=\"title\" ng-show=\"title\"></h4>\n" +
    "    <p ng-bind=\"content\"></p>\n" +
    "  </div>\n" +
    "</div>\n" +
    "");
}]);
})();

(function(module) {
try { module = angular.module("bcapp-pattern-lab-templates"); }
catch(err) { module = angular.module("bcapp-pattern-lab-templates", []); }
module.run(["$templateCache", function($templateCache) {
  "use strict";
  $templateCache.put("template/progressbar/bar.html",
    "<span class=\"meter\" ng-transclude></span>\n" +
    "");
}]);
})();

(function(module) {
try { module = angular.module("bcapp-pattern-lab-templates"); }
catch(err) { module = angular.module("bcapp-pattern-lab-templates", []); }
module.run(["$templateCache", function($templateCache) {
  "use strict";
  $templateCache.put("template/progressbar/progress.html",
    "<div class=\"progress\" ng-class=\"type\" ng-transclude></div>\n" +
    "");
}]);
})();

(function(module) {
try { module = angular.module("bcapp-pattern-lab-templates"); }
catch(err) { module = angular.module("bcapp-pattern-lab-templates", []); }
module.run(["$templateCache", function($templateCache) {
  "use strict";
  $templateCache.put("template/progressbar/progressbar.html",
    "<div class=\"progress\" ng-class=\"type\">\n" +
    "  <span class=\"meter\" ng-transclude></span>\n" +
    "</div>\n" +
    "");
}]);
})();

(function(module) {
try { module = angular.module("bcapp-pattern-lab-templates"); }
catch(err) { module = angular.module("bcapp-pattern-lab-templates", []); }
module.run(["$templateCache", function($templateCache) {
  "use strict";
  $templateCache.put("template/rating/rating.html",
    "<span ng-mouseleave=\"reset()\">\n" +
    "  <i ng-repeat=\"r in range\" ng-mouseenter=\"enter($index + 1)\" ng-click=\"rate($index + 1)\" class=\"fa\"\n" +
    "    ng-class=\"$index < val && (r.stateOn || 'fa-star') || (r.stateOff || 'fa-star-o')\"></i>\n" +
    "</span>\n" +
    "");
}]);
})();

(function(module) {
try { module = angular.module("bcapp-pattern-lab-templates"); }
catch(err) { module = angular.module("bcapp-pattern-lab-templates", []); }
module.run(["$templateCache", function($templateCache) {
  "use strict";
  $templateCache.put("template/tabs/tab.html",
    "<li ng-class=\"{'is-active': active}\" class=\"tab\" role=\"presentation\">\n" +
    "    <a ng-click=\"select()\"\n" +
    "        href=\"javascript:void(0)\"\n" +
    "        role=\"tab\"\n" +
    "        aria-selected=\"{{active ? true : false}}\"\n" +
    "        class=\"tab-title\"\n" +
    "        tab-heading-transclude>{{heading}}</a>\n" +
    "</li>\n" +
    "");
}]);
})();

(function(module) {
try { module = angular.module("bcapp-pattern-lab-templates"); }
catch(err) { module = angular.module("bcapp-pattern-lab-templates", []); }
module.run(["$templateCache", function($templateCache) {
  "use strict";
  $templateCache.put("template/tabs/tabset.html",
    "<tabbed-content>\n" +
    "    <ul class=\"tabs\" ng-class=\"{'tabs--vertical': vertical}\" role=\"tablist\" ng-transclude></ul>\n" +
    "    <div class=\"tabs-contents\" ng-class=\"{'tabs-contents--vertical': vertical}\">\n" +
    "        <div class=\"tab-content\"\n" +
    "            ng-repeat=\"tab in tabs\"\n" +
    "            ng-class=\"{'is-active': tab.active}\"\n" +
    "            role=\"tabpanel\"\n" +
    "            aria-hidden=\"{{tab.active ? false : true}}\"\n" +
    "            tab-content-transclude=\"tab\">\n" +
    "        </div>\n" +
    "    </div>\n" +
    "</tabbed-content>\n" +
    "");
}]);
})();

(function(module) {
try { module = angular.module("bcapp-pattern-lab-templates"); }
catch(err) { module = angular.module("bcapp-pattern-lab-templates", []); }
module.run(["$templateCache", function($templateCache) {
  "use strict";
  $templateCache.put("template/tooltip/tooltip-html-unsafe-popup.html",
    "<span class=\"tooltip tip-{{placement}}\"\n" +
    "  ng-class=\"{ in: isOpen(), fade: animation() }\"\n" +
    "  style=\"width: auto\">\n" +
    "  <span bind-html-unsafe=\"content\"></span>\n" +
    "  <span class=\"nub\"></span>\n" +
    "</span>\n" +
    "");
}]);
})();

(function(module) {
try { module = angular.module("bcapp-pattern-lab-templates"); }
catch(err) { module = angular.module("bcapp-pattern-lab-templates", []); }
module.run(["$templateCache", function($templateCache) {
  "use strict";
  $templateCache.put("template/tooltip/tooltip-popup.html",
    "<span class=\"tooltip tip-{{placement}}\"\n" +
    "  ng-class=\"{ in: isOpen(), fade: animation() }\"\n" +
    "  style=\"width: auto\">\n" +
    "  <span ng-bind=\"content\"></span>\n" +
    "  <span class=\"nub\"></span>\n" +
    "</span>\n" +
    "");
}]);
})();

(function(module) {
try { module = angular.module("bcapp-pattern-lab-templates"); }
catch(err) { module = angular.module("bcapp-pattern-lab-templates", []); }
module.run(["$templateCache", function($templateCache) {
  "use strict";
  $templateCache.put("template/tour/tour.html",
    "<div class=\"joyride-tip-guide\" ng-class=\"{ in: isOpen(), fade: animation() }\">\n" +
    "  <span class=\"joyride-nub\" ng-class=\"{\n" +
    "    bottom: placement === 'top',\n" +
    "    left: placement === 'right',\n" +
    "    right: placement === 'left',\n" +
    "    top: placement === 'bottom'\n" +
    "  }\"></span>\n" +
    "  <div class=\"joyride-content-wrapper\">\n" +
    "    <h4 ng-bind=\"title\" ng-show=\"title\"></h4>\n" +
    "    <p ng-bind=\"content\"></p>\n" +
    "    <a class=\"small button joyride-next-tip\" ng-show=\"!isLastStep()\" ng-click=\"nextStep()\">Next</a>\n" +
    "    <a class=\"small button joyride-next-tip\" ng-show=\"isLastStep()\" ng-click=\"endTour()\">End</a>\n" +
    "    <a class=\"joyride-close-tip\" ng-click=\"endTour()\">&times;</a>\n" +
    "  </div>\n" +
    "</div>\n" +
    "");
}]);
})();

(function(module) {
try { module = angular.module("bcapp-pattern-lab-templates"); }
catch(err) { module = angular.module("bcapp-pattern-lab-templates", []); }
module.run(["$templateCache", function($templateCache) {
  "use strict";
  $templateCache.put("template/topbar/has-dropdown.html",
    "<li class=\"has-dropdown\" ng-transclude></li>");
}]);
})();

(function(module) {
try { module = angular.module("bcapp-pattern-lab-templates"); }
catch(err) { module = angular.module("bcapp-pattern-lab-templates", []); }
module.run(["$templateCache", function($templateCache) {
  "use strict";
  $templateCache.put("template/topbar/toggle-top-bar.html",
    "<li class=\"toggle-topbar menu-icon\" ng-transclude></li>");
}]);
})();

(function(module) {
try { module = angular.module("bcapp-pattern-lab-templates"); }
catch(err) { module = angular.module("bcapp-pattern-lab-templates", []); }
module.run(["$templateCache", function($templateCache) {
  "use strict";
  $templateCache.put("template/topbar/top-bar-dropdown.html",
    "<ul class=\"dropdown\" ng-transclude></ul>");
}]);
})();

(function(module) {
try { module = angular.module("bcapp-pattern-lab-templates"); }
catch(err) { module = angular.module("bcapp-pattern-lab-templates", []); }
module.run(["$templateCache", function($templateCache) {
  "use strict";
  $templateCache.put("template/topbar/top-bar-section.html",
    "<section class=\"top-bar-section\" ng-transclude></section>");
}]);
})();

(function(module) {
try { module = angular.module("bcapp-pattern-lab-templates"); }
catch(err) { module = angular.module("bcapp-pattern-lab-templates", []); }
module.run(["$templateCache", function($templateCache) {
  "use strict";
  $templateCache.put("template/topbar/top-bar.html",
    "<nav class=\"top-bar\" ng-transclude></nav>");
}]);
})();

(function(module) {
try { module = angular.module("bcapp-pattern-lab-templates"); }
catch(err) { module = angular.module("bcapp-pattern-lab-templates", []); }
module.run(["$templateCache", function($templateCache) {
  "use strict";
  $templateCache.put("template/typeahead/typeahead-match.html",
    "<a tabindex=\"-1\" bind-html-unsafe=\"match.label | typeaheadHighlight:query\"></a>");
}]);
})();

(function(module) {
try { module = angular.module("bcapp-pattern-lab-templates"); }
catch(err) { module = angular.module("bcapp-pattern-lab-templates", []); }
module.run(["$templateCache", function($templateCache) {
  "use strict";
  $templateCache.put("template/typeahead/typeahead-popup.html",
    "<ul class=\"f-dropdown\" ng-style=\"{display: isOpen()&&'block' || 'none', top: position.top+'px', left: position.left+'px'}\">\n" +
    "    <li ng-repeat=\"match in matches\" ng-class=\"{active: isActive($index) }\" ng-mouseenter=\"selectActive($index)\" ng-click=\"selectMatch($index)\">\n" +
    "        <div typeahead-match index=\"$index\" match=\"match\" query=\"query\" template-url=\"templateUrl\"></div>\n" +
    "    </li>\n" +
    "</ul>\n" +
    "");
}]);
})();
