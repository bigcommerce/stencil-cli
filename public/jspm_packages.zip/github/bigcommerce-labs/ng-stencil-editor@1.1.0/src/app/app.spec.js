import 'angular';
import 'angular-mocks';

import AppCtrl from './app.controller.js';

describe('App Ctrl: ', () => {
    let appService = jasmine.createSpyObj('appService', [
        'getEditorToken',
    ]);
    let channelService = jasmine.createSpyObj('channelService', [
        'emit',
    ]);
    let configService = jasmine.createSpyObj('configService', [
        'clear',
        'getConfig',
        'hasChanges',
        'reset',
        'saveNative',
    ]);
    let $cookies = jasmine.createSpyObj('$cookies', ['remove']);
    let $controller;
    let $rootScope;
    let $scope;
    let $window;
    let controller;

    function createController($scope) {
        return $controller(AppCtrl, {
            $cookies,
            $scope,
            $window,
            appService,
            channelService,
            configService,
        });
    }

    beforeEach(inject(($injector) => {
        $rootScope = $injector.get('$rootScope');
        $scope = $rootScope.$new();
        $controller = $injector.get('$controller');
        $window = $injector.get('$window');
    }));

    describe('constructor', () => {
        it('should setup the eventListeners', () => {
            spyOn($window, 'addEventListener');

            controller = createController($scope);

            expect($window.addEventListener).toHaveBeenCalledWith('beforeunload', jasmine.any(Function));
            expect($window.addEventListener).toHaveBeenCalledWith('unload', jasmine.any(Function));
            expect($window.addEventListener).toHaveBeenCalledWith('mouseover', jasmine.any(Function));
        });

        it('should setup the initial cookie', () => {
            const token = 'testToken';

            appService.getEditorToken.and.returnValue(token);
            controller = createController($scope);

            expect($cookies.stencil_editor_enabled).toBe(token);
        });
    });

    describe('confirmExit() method', () => {
        const event = {};

        it('should return a confirmation message', () => {
            controller = createController($scope);
            configService.hasChanges.and.returnValue(true);

            expect(controller.confirmExit(event)).toEqual(jasmine.any(String));
        });

        it('should set the event.returnValue for cross-browser support', () => {
            controller = createController($scope);

            const confirmationMessage = controller.confirmExit(event);

            expect(event.returnValue).toEqual(confirmationMessage);
        });
    });

    describe('resetConfig() method', () => {
        configService.hasChanges.and.returnValue(true);

        it('should call configService reset method', () => {
            controller = createController($scope);

            controller.resetConfig();

            expect(configService.clear).toHaveBeenCalled();
        });

        it('should call configService saveNative method', () => {
            controller = createController($scope);

            controller.resetConfig();

            expect(configService.saveNative).toHaveBeenCalled();
        });
    });
});
