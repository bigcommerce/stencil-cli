export default class StencilPreviewCtrl {
    /*@ngInject*/
    constructor ($scope, appService, configService, channelService, previewControls) {
        this._$scope = $scope;
        this._appService = appService;
        this._channelService = channelService;
        this._configService = configService;
        this._previewControls = previewControls;
    }

    getSize() {
        return this._previewControls.getSize();
    }

    getStoreUrl() {
        return this._appService.getStoreUrl();
    }

    isFlipped() {
        return this._previewControls.isFlipped();
    }

    refreshIframe() {
        this._channelService.emit('reload-page');
        this._configService.requiresRefresh(false);
    }

    requiresRefresh() {
        return this._configService.requiresRefresh();
    }
}
