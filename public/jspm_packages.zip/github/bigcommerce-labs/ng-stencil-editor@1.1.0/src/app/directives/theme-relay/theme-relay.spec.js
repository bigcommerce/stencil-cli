import 'angular';
import 'angular-mocks';

import ThemeRelayCtrl from './theme-relay.controller.js';

describe('ThemeRelay Ctrl: ', () => {
    let appService = jasmine.createSpyObj('appService', [
        'getEditorToken'
    ]);
    let channelService = jasmine.createSpyObj('channelService', [
        'createChannel',
        'emit'
    ]);
    let $controller;
    let $rootScope;
    let $scope;
    let controller;

    function createController($scope) {
        return $controller(ThemeRelayCtrl, {
            $scope: $scope,
            appService: appService,
            channelService: channelService,
        });
    }

    beforeEach(inject(($injector) => {
        $controller = $injector.get('$controller');
        $rootScope = $injector.get('$rootScope');
        $scope = $rootScope.$new();
    }));

    describe('channelReady() method', () => {
        it('should call emit with expected event name and data', () => {
            const token = 'Test Token';

            controller = createController($scope);
            controller._appService.getEditorToken.and.returnValue(token);

            controller.channelReady();

            expect(controller._channelService.emit).toHaveBeenCalledWith('on-ready', {
                token: token
            });
        });
    });
});
