export default class {
    /*@ngInject*/
    constructor (appService, channelService) {
        this._appService = appService;
        this._channelService = channelService;
        this.createChannel = channelService.createChannel.bind(channelService);
    }

    channelReady() {
        const token = this._appService.getEditorToken();

        this._channelService.emit('on-ready', {
            token: token
        });
    }
}
