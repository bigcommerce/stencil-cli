export default class ChannelService {
    /*@ngInject*/
    constructor($window) {
        this._$window = $window;
        this._channel = null;
    }

    createChannel(options) {
        this._channel = this._$window.Channel.build(options);
    }

    emit(name, data = {}, success = angular.noop) {
        if (this._channel) {
            this._channel.call({
                method: name,
                params: JSON.stringify(data),
                success: success,
            });
        }
    }
}
