import 'angular';
import 'angular-mocks';

import servicesModule from './services.module.js';

describe('AppService: ', () => {
    const url = 'example.com';

    let appService;

    beforeEach(module(servicesModule.name));

    beforeEach(inject(function ($injector) {
        appService = $injector.get('appService');

        appService._BC_APP_CONFIG = {
            storeUrl: url
        };
    }));

    describe('getEditorToken() method', () => {
        it('should call urlParser.getParam', () => {
            spyOn(appService._urlParser, 'getParam');

            appService.getEditorToken();

            expect(appService._urlParser.getParam).toHaveBeenCalledWith(jasmine.any(Object), 'stencilEditor');
        });
    });

    describe('getStoreUrl() method', () => {
        it('should return a trusted resource url', () => {
            spyOn(appService._$sce, 'trustAsResourceUrl');

            appService.getStoreUrl();

            expect(appService._$sce.trustAsResourceUrl).toHaveBeenCalledWith(url);
        });
    });
});
