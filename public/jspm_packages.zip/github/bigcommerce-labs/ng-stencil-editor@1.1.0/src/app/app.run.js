function run($log, $rootScope) {
    $rootScope
        .$on('$stateChangeError', (event, toState, toParams, fromState, fromParams, error) => {
            $log.error('Error in state transition: ', error);
        });
}

run.$inject = ['$log', '$rootScope'];

export default run;
