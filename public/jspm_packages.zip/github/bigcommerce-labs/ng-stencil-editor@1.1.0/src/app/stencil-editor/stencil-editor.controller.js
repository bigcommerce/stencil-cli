import _ from 'lodash';
import ConfirmClearModalCtrl from 'src/app/modals/confirm-clear-modal/confirm-clear-modal.controller.js';
import ConfirmResetModalCtrl from 'src/app/modals/confirm-reset-modal/confirm-reset-modal.controller.js';
import ApplyThemeNotAvailableModalCtrl from 'src/app/modals/apply-theme-not-available-modal/apply-theme-not-available-modal.controller.js';
import ResetThemeNotAvailableModalCtrl from 'src/app/modals/reset-theme-not-available-modal/reset-theme-not-available-modal.controller.js';

export default class StencilEditorCtrl {
    /*@ngInject*/
    constructor($modal, BC_APP_CONFIG, channelService, configService, fontsService, versionService) {
        this._$modal = $modal;
        this._BC_APP_CONFIG = BC_APP_CONFIG;
        this._channelService = channelService;
        this._configService = configService;
        this._fontsService = fontsService;
        this._versionService = versionService;
        this._fields = [];

        this.init();
    }

    init() {
        // Clear the existing fields, if any
        this._fields.length = 0;

        // Expose the current model data to the template
        this.config = this._configService.getConfig();
        this.version = this._versionService.getVersion();
        this.fieldsets = this._versionService.getFieldsets();

        // Hydrate the fields with the config data
        _.each(this.fieldsets, (fieldset) => {
            _.each(fieldset.settings, (field) => {
                const key = field.key;

                if (_.isUndefined(key)) {
                    return;
                }

                if (_.isUndefined(this.config.settings[key])) {
                    return;
                }

                field.defaultValue = _.toString(this.config.settings[key]);

                field.templateOptions.onChange = newValue => {
                    this._configService.hasChanges(true);

                    this._configService
                        .preview(this._configService.getConfig(), { requiresRefresh: field.data.forceReload })
                        .then(() => this.reloadStylesheets());

                    field.templateOptions.updated = true;

                    if (field.type === 'font') {
                        this._fontsService.addFont(newValue);
                    }
                };

                this._fields.push(field);
            });
        });
    }

    apply() {
        // @TODO: Implement apply endpoint in production (v2)
        this._$modal
            .open({
                controller: ApplyThemeNotAvailableModalCtrl,
                controllerAs: 'applyThemeNotAvailableModalCtrl',
                templateUrl: 'app/modals/apply-theme-not-available-modal/apply-theme-not-available-modal.tpl.html',
                windowClass: 'modal'
            });
    }

    clear() {
        this._$modal
            .open({
                controller: ConfirmClearModalCtrl,
                controllerAs: 'confirmClearModalCtrl',
                templateUrl: 'app/modals/confirm-clear-modal/confirm-clear-modal.tpl.html',
                windowClass: 'modal'
            })
            .result.then(() => {
                return this._configService
                    .clear(this.needsForceReload())
                    .then(() => this.reloadStylesheets())
                    .then(() => this.resetForm());
            });
    }

    needsForceReload() {
        const changes = this._configService.findChanges();

        return _.any(changes, (value, key) => this._versionService.needsForceReload(key));
    }

    reloadStylesheets() {
        return this._channelService.emit('reload-stylesheets');
    }

    resetForm() {
        // ensure our form is in its pristine state
        if (this.editorForm) {
            this.editorForm.$setPristine();
            this.editorForm.$setUntouched();

            _.each(this._fields, (field) => {
                if (field.templateOptions) {
                    field.templateOptions.updated = false;
                }
            });
        }
    }

    resetVariant() {
        this._$modal
            .open({
                controller: ConfirmResetModalCtrl,
                controllerAs: 'confirmResetModalCtrl',
                templateUrl: 'app/modals/confirm-reset-modal/confirm-reset-modal.tpl.html',
                windowClass: 'modal'
            })
            .result.then(() => {
                this._configService
                    .reset()
                    .catch(() => this.resetVariantError());
            });
    }

    resetVariantError() {
        this._$modal
            .open({
                controller: ResetThemeNotAvailableModalCtrl,
                controllerAs: 'resetThemeNotAvailableModalCtrl',
                templateUrl: 'app/modals/reset-theme-not-available-modal/reset-theme-not-available-modal.tpl.html',
                windowClass: 'modal'
            });
    }

    submit() {
        this._configService.save(this.config)
            .then(() => this.resetForm());
    }
}
