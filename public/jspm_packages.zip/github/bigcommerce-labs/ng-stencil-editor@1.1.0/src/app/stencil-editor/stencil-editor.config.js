function config(formlyConfigProvider) {
    // fully wrapped fields with labels
    _.each(['input', 'range', 'select', 'textarea', 'upload', 'font'], (field) => {
        formlyConfigProvider.setType({
            name: field,
            templateUrl: templateUrl(field),
            wrapper: ['formFieldLabel']
        });
    });

    // wrapped fields with their own labels
    _.each(['checkbox', 'radio'], (field) => {
        formlyConfigProvider.setType({
            name: field,
            templateUrl: templateUrl(field),
            wrapper: ['formField']
        });
    });

    // unwrapped fields
    _.each(['color'], (field) => {
        formlyConfigProvider.setType({
            name: field,
            templateUrl: templateUrl(field)
        });
    });

    // non-field elements
    _.each(['heading', 'paragraph'], (field) => {
        formlyConfigProvider.setType({
            name: field,
            templateUrl: templateUrl(field)
        });
    });

    formlyConfigProvider.setWrapper([
        {
            name: 'formField',
            templateUrl: 'app/field-wrappers/form-field.tpl.html'
        },
        {
            name: 'formFieldLabel',
            templateUrl: 'app/field-wrappers/form-field-label.tpl.html'
        }
    ]);

    function templateUrl(field) {
        return 'app/fields/form-' + field + '.tpl.html';
    }
}

config.$inject = ['formlyConfigProvider'];

export default config;
