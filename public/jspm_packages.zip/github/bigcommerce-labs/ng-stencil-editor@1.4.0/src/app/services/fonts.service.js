export default class FontsService {
    /*@ngInject*/
    constructor(channelService) {
        this._channelService = channelService;
        this._loadedFonts = {};
    }

    addFont(font) {
        if (!this._loadedFonts[font])  {
            this._loadedFonts[font] = true;

            this.emitInjectFont(this.parseFont(font));
        }
    }

    emitInjectFont(fontUrl) {
        if (fontUrl) {
            this._channelService.emit('add-font', {
                data: { fontUrl }
            });
        }
    }

    parseFont(font) {
        const provider = font.split('_')[0];

        switch (provider) {
            case 'Google':
                return this.parseGoogleFont(font);
            default:
                return;
        }
    }

    parseGoogleFont(font) {
        const split = font.split('_');

        let formattedFont = '';
        let family = split[1];
        let weight = split[2];

        if (split.length === 2) {
            formattedFont += family + '|';
        } else if (split.length > 2) {
            weight = weight.split(',')[0];
            formattedFont += family + ':' + weight + '|';
        }

        return '//fonts.googleapis.com/css?family=' + formattedFont;
    }

    setInitialFonts(settings) {
        const fontKeyFormat = new RegExp(/\w+-font$/);

        _.each(settings, (value, key) => {
            if (fontKeyFormat.test(key)) {
                this.addFont(value);
            }
        });
    }
}
