import 'angular';
import 'angular-mocks';

import apiModule from 'src/app/app.api.js';
import servicesModule from './services.module.js';

describe('SessionService: ', () => {
    const BC_SEED_DATA = {
        oauthBaseUrl: 'http://login.bcservices.dev'
    };

    let $httpBackend;
    let sessionService;

    beforeEach(module(apiModule.name));
    beforeEach(module(servicesModule.name));

    beforeEach(inject(function ($injector) {
        $httpBackend = $injector.get('$httpBackend');
        sessionService = $injector.get('sessionService');
    }));

    describe('heartbeat() method', () => {
        beforeEach(() => {
            $httpBackend.expectJSONP(BC_SEED_DATA.oauthBaseUrl + '/session/heartbeat?callback=JSON_CALLBACK')
                .respond(200, { data: {
                    ok: true
                }});
        });

        afterEach(() => {
            $httpBackend.verifyNoOutstandingExpectation();
            $httpBackend.verifyNoOutstandingRequest();
        });

        it('should call A&As heartbeat JSONP endpoint', () => {
            sessionService._BC_SEED_DATA = BC_SEED_DATA;
            sessionService.heartbeat();
            $httpBackend.flush();
        });
    });
});
