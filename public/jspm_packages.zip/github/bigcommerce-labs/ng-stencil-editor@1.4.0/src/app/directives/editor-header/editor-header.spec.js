import 'angular';
import 'angular-mocks';
import './editor-header.module.js';
import mockVersion from 'tests/mocks/version.mock.js';

describe('Stencil Editor Left Panel Header', () => {
    const $modal = {};

    let $compile;
    let $scope;
    let compiledElement;

    beforeEach(() => {
        angular.mock.module('ng-stencil-editor.directives.editor-header');

        angular.mock.module(function($provide) {
            $provide.value('$modal', $modal);
        });
    });

    beforeEach(inject($injector => {
        $compile = $injector.get('$compile');
        $scope = $injector.get('$rootScope').$new();
        $scope.theme = mockVersion;
    }));

    function compileDirective(scope, tpl) {
        const element = angular.element(tpl || '<editor-header theme="theme"></editor-header>');

        compiledElement = $compile(element)(scope);

        scope.$digest();
    }

    describe('Editor Header', () => {
        beforeEach(() => {
            compileDirective($scope);
        });

        it('should display the theme name', () => {
            expect(compiledElement.find('h1').text().replace(/(\r\n|\n|\r)/gm,'').replace(/ /g,'')).toBe(mockVersion.name + mockVersion.displayVersion);
        });

        it('should display the theme version', () => {
            expect(compiledElement.find('small').text()).toBe(mockVersion.displayVersion);
        });
    });
});
