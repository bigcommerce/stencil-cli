/* globals ColorPicker */
angular.module('bcapp-pattern-lab.color-picker.controller', [])
    .controller('ColorPickerCtrl', function ColorPickerCtrl($element) {
        const ctrl = this;

        let colorSelection;
        let colorSelectionIndicator;
        let colorSlider;
        let colorSliderIndicator;

        ctrl.createColorPicker = createColorPicker;
        ctrl.createNewPaletteColor = createNewPaletteColor;
        ctrl.setModelCtrl = setModelCtrl;
        ctrl.setNewColor = setNewColor;

        function createColorPicker() {
            colorSelection = $element[0].querySelector('[data-bc-picker]');
            colorSelectionIndicator = $element[0].querySelector('[data-bc-picker-indicator]');
            colorSlider = $element[0].querySelector('[data-bc-slider]');
            colorSliderIndicator = $element[0].querySelector('[data-bc-slider-indicator]');

            ColorPicker.fixIndicators(
                colorSliderIndicator,
                colorSelectionIndicator);

            ctrl.cp = new ColorPicker(
                colorSlider,
                colorSelection,
                pickNewColor
            );
        }

        function createNewPaletteColor() {
            if (ctrl.palette.indexOf(getSelectedColor()) < 0) {
                ctrl.palette.push(getSelectedColor());
            }
        }

        function getSelectedColor() {
            return ctrl.color;
        }

        function pickNewColor(hex, hsv, rgb, pickerCoordinate, sliderCoordinate) {
            ColorPicker.positionIndicators(
                colorSliderIndicator,
                colorSelectionIndicator,
                sliderCoordinate, pickerCoordinate
            );

            ctrl.ngModelCtrl.$setViewValue(hex);
            ctrl.ngModelCtrl.$render();
        }

        function render() {
            ctrl.color = ctrl.ngModelCtrl.$viewValue;
        }

        function setModelCtrl(ngModelCtrl) {
            ctrl.ngModelCtrl = ngModelCtrl;
            ctrl.ngModelCtrl.$render = render;
        }

        function setNewColor($event, newColor) {
            $event.preventDefault();

            ctrl.cp.setHex(newColor);
        }
    });
