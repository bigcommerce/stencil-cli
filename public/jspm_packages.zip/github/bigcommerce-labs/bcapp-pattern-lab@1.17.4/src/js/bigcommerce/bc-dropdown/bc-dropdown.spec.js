/* */ 
describe('bc-dropdown directive', function () {
    var $compile,
        $scope;

    beforeEach(module('mm.foundation'));
    beforeEach(module('bcapp-pattern-lab.bc-dropdown'));

    beforeEach(inject(function ($injector) {
        $compile = $injector.get('$compile');
        $scope = $injector.get('$rootScope').$new();
    }));

    function compileDirective(scope, tpl) {
        tpl = tpl || ([
            '<div bc-dropdown>',
            '    <a bc-dropdown-toggle>Click here for a dropdown<\/a>',
            '    <ul bc-dropdown-menu>',
            '        <li>One<\/li>',
            '        <li>Two<\/li>',
            '        <li>Three<\/li>',
            '    <\/ul>',
            '<\/div>'
        ]).join('');

        var element = angular.element(tpl);

        return $compile(element)(scope);
    }

    describe('getUniqueId method', function () {
        it('should be exposed on the controller', function () {
            var element = compileDirective($scope);
            $scope.$digest();
            expect(element.controller('bcDropdown').getUniqueId).toBeDefined();
        });
    });

    describe('bc-dropdown', function() {
        var element;
        beforeEach(function() {
            element = compileDirective($scope);
            $scope.$digest();
        });

        it('should add aria role of combobox', function() {
            expect(element.attr('role')).toEqual('combobox');
        });
    });

    describe('bc-dropdown-toggle', function() {
        var element, toggle;
        beforeEach(function() {
            element = compileDirective($scope);
            $scope.$digest();
            toggle = element.find('a');
        });

        it('should remove the bc-dropdown-toggle attribute from the element', function() {
            expect(toggle.attr('bc-dropdown-toggle')).toBeUndefined();
        });

        it('should add the dropdown-toggle directive to the element with the proper selector', function() {
            var sel = '#' + element.controller('bcDropdown').getUniqueId();
            expect(toggle.attr('dropdown-toggle')).toEqual(sel);
        });

        it('should add aria-controls attribute to the element with the proper id', function() {
            var sel = element.controller('bcDropdown').getUniqueId();
            expect(toggle.attr('aria-controls')).toEqual(sel);
        });

        it('should compile the dropdown-toggle angular-foundation directive', function() {
            var toggleCtrl = toggle.controller('dropdownToggle');
            expect(toggleCtrl).toBeDefined();
        });
    });

    describe('bc-dropdown-menu', function() {
        var element, menu, toggle;
        beforeEach(function() {
            element = compileDirective($scope);
            $scope.$digest();
            menu = element.find('ul');
            toggle = element.find('a')[0];
        });

        it('should add the dropdown-menu class', function() {
            expect(menu.hasClass('dropdown-menu')).toBe(true);
        });

        it('should add the unique id to the element', function() {
            var id = element.controller('bcDropdown').getUniqueId();
            expect(menu.attr('id')).toEqual(id);
        });

        it('should add the role listbox', function() {
            expect(menu.attr('role')).toEqual('listbox');
        });

        it('should add the aria-expanded false on render', function() {
            expect(menu.attr('aria-expanded')).toEqual('false');
        });
    });

});
