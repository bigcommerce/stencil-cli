/* */ 
describe('Form Input Color directive', function() {
    var $compile,
        $rootScope,
        scope,
        element;

    beforeEach(module('bcapp-pattern-lab-templates'));
    beforeEach(module('bcapp-pattern-lab.form-input-color.directive'));

    beforeEach(inject(function ($injector) {
        $compile = $injector.get('$compile');
        $rootScope = $injector.get('$rootScope');
    }));

    function compileDirective(scope) {
        var tpl = angular.element(
            '<form-input-color label-text="inputLabelText" ng-model="inputModelValue" palette="inputPalette" placeholder-text="inputPlaceholderText"></form-input-color>'
        );

        scope = scope || $rootScope.$new();

        element = $compile(tpl)(scope);

        scope.$digest();

        return scope;
    }

    // before each test, create a new fresh scope
    beforeEach(inject(function($rootScope) {
        scope = $rootScope.$new();
        scope.inputLabelText = 'Label Text';
        scope.inputModelValue = '#ffffff';
        scope.inputPalette = ['#ffffff'];
        scope.inputPlaceholderText = 'Input Placeholder';
    }));

    beforeEach(function() {
        compileDirective(scope);
    });

    describe('form-color-input element' , function() {
        it('should include the standard class', function() {
            expect(element.hasClass('form-inputColor')).toBe(true);
        });

        it('should set the label text', function() {
            var label = element[0].querySelector('.form-label');
            expect(label.textContent.trim()).toBe(scope.inputLabelText);
        });

        it('should set the palette array on the controller', function() {
            expect(element.isolateScope().formInputColorCtrl.palette).toBe(scope.inputPalette);
        });

        it('should set the placeholder text', function() {
            var input = element[0].querySelector('.form-input');
            expect(input.placeholder.trim()).toBe(scope.inputPlaceholderText);
        });

        it('should set the color value', function() {
            expect(element.isolateScope().formInputColorCtrl.color).toBe(scope.inputModelValue);
        });
    });

});
