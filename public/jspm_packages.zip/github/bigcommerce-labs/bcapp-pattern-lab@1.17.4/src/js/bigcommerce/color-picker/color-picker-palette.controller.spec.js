/* */ 
describe('Color picker palette controller', function() {
    var $controller,
        controller,
        mockEvent;

    function createController() {
        return $controller('ColorPickerPaletteCtrl');
    }

    beforeEach(function() {
        module('bcapp-pattern-lab.color-picker-palette.controller');
    });

    beforeEach(inject(function($injector) {
        $controller = $injector.get('$controller');
    }));

    beforeEach(function() {
        controller = createController();
        controller.createNewPaletteColor = function() {};
        mockEvent = { preventDefault: _.noop };
        spyOn(controller, 'createNewPaletteColor');
    });

    describe('createNewColor method', function() {
        it('should call createNewPaletteColor callback', function() {
            controller.createNewColor(mockEvent);
            expect(controller.createNewPaletteColor).toHaveBeenCalled();
        });
    });
});
