/* */ 
describe('Color picker controller', function() {
    var $controller,
        controller,
        mockEvent,
        mockNewColor;

    function createController() {
        return $controller('ColorPickerCtrl', {
            $element: angular.element('<div></div>')
        });
    }

    beforeEach(function() {
        module('bcapp-pattern-lab.color-picker.controller');
    });

    beforeEach(inject(function($injector) {
        $controller = $injector.get('$controller');
    }));

    beforeEach(function() {
        controller = createController();
        controller.palette = [
            '#00ABC9',
            '#E5F6F9',
            '#95DB89',
            '#FFB800'
        ];
        controller.color = '#00ABC9';
        controller.cp = {
            setHex: function() {}
        };
        mockEvent = { preventDefault: _.noop };
        mockNewColor = '#cccccc';
        spyOn(controller.cp, 'setHex');
    });

    describe('createNewPaletteColor method', function() {

        it('should not add existing color to the palette array', function() {
            var initialNumberOfColors = controller.palette.length;
            controller.createNewPaletteColor();
            expect(controller.palette.length).toEqual(initialNumberOfColors);
        });

        it('should add new color to the palette array', function() {
            var initialNumberOfColors = controller.palette.length;
            controller.color = mockNewColor;
            controller.createNewPaletteColor();
            expect(controller.palette.length).toEqual(initialNumberOfColors + 1);
        });

    });

    describe('setNewColor method', function() {
        it('should call the setHex method of the color picker plugin assigned to the controller', function() {
            controller.setNewColor(mockEvent, mockNewColor);
            expect(controller.cp.setHex).toHaveBeenCalledWith(mockNewColor);
        });
    });
});
