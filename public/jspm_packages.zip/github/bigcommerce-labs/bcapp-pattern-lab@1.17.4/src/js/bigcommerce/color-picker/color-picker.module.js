/* */ 
angular.module('bcapp-pattern-lab.color-picker', [
    'bcapp-pattern-lab.color-picker.directive',
    'bcapp-pattern-lab.color-picker-palette.directive'
]);
