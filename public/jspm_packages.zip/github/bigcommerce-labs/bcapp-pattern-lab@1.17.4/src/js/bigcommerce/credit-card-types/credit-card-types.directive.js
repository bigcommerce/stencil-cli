/**
 * @name credit-card-types directive
 * @description Component displaying and greying out credit card type icons based on the selected credit card type.
 * `.is-active` is added to the corresponding selected credit card type. `.not-active` is added for the other
 * types. If no credit card types has been selected, then neither `.is-active` and `.not-active` will be added at all.
 *
 * @param selectedType {String} Credit card type. Valid types are 'Visa', 'MasterCard', 'Diners Club', 'Discover', and 'American Express'
 * @param supportedTypes {Array} Array of credit card types to display. The card types use the same strings: 'American Express', 'Discover', 'MasterCard', 'Visa'
 */
angular.module('bcapp-pattern-lab.credit-card-types.directive', [
    'bcapp-pattern-lab.credit-card-types.controller',
])
    .directive('creditCardTypes', function creditCardTypesDirective() {
        return {
            bindToController: true,
            controller: 'CreditCardTypesCtrl as creditCardTypesCtrl',
            restrict: 'E',
            scope: {
                getSelectedType: '&selectedType',
                getSupportedTypes: '&supportedTypes'
            },
            templateUrl: 'src/js/bigcommerce/credit-card-types/credit-card-types.tpl.html'
        };
    });
