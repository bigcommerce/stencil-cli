/* */ 
angular.module('bcapp-pattern-lab.html5Mode.service', [])
    .provider('html5Mode', function html5ModeProvider($locationProvider) {
        this.$get = function html5ModeService() {
            return $locationProvider.html5Mode();
        };
    });
