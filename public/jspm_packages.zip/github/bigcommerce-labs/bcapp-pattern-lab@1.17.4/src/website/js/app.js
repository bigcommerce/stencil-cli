/* */ 
angular.module('website', [
    'bcapp-pattern-lab',
    'mm.foundation',
    'website-templates',
    'ui.codemirror',
    'ui.router',

    // JS Components
    'website.accordion',
    'website.alerts',
    'website.aside-nav',
    'website.bc-datepicker',
    'website.bc-dropdown',
    'website.bc-pagination',
    'website.bc-server-table',
    'website.buttons',
    'website.color-picker-example',
    'website.credit-card',
    'website.loading-indicators',
    'website.icons',
    'website.modal',
    'website.switch',
    'website.tabs',
    'website.tooltip'
])
    .constant('BC_APP_CONFIG', {})

    .config(function($stateProvider, svgRootPathProvider) {
        $stateProvider
            .state('components', {
                abstract: true,
                url: '/components',
                template: '<ui-view/>'
            });

        svgRootPathProvider.setRootPath('/svg/icons/');
    });
