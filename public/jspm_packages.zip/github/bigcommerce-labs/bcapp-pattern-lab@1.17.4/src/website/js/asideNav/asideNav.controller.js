/* */ 
angular.module('website.aside-nav.controller', [])

    .controller('AsideNavCtrl', function($scope) {
        $scope.isActive = false;
    });
