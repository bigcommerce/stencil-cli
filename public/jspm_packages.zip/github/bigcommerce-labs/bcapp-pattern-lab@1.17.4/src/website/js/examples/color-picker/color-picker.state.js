/* */ 
angular.module('website.color-picker-example.state', [
    'ui.router',
    'website.color-picker-example.controller'
])

    .config(function($stateProvider) {
        $stateProvider
            .state('components.color-picker-example', {
                url: '/color-picker',
                templateUrl: 'src/website/js/examples/color-picker/color-picker.tpl.html',
                controller: 'ColorPickerExampleCtrl as colorPickerExampleCtrl'
            });
    });
