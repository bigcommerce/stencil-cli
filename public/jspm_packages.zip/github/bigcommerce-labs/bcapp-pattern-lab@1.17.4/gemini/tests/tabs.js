/* */ 
"format global";
var gemini = require('gemini');

gemini.suite('tabs', function(suite) {
    suite.setUrl('/tabs.html');

    gemini.suite('tabs', function(suite) {
        suite
            .setCaptureElements('#labExampleTabs')
            .capture('normal');
    });

    gemini.suite('tabs vertical', function(suite) {
        suite
            .setCaptureElements('#labExampleTabsVertical')
            .capture('normal');
    });
});
