/* */ 
"format global";
var gemini = require('gemini');

gemini.suite('form errors', function(suite) {
    suite.setUrl('/forms.html');

    gemini.suite('input valid', function(suite) {
        suite
            .setCaptureElements('#labExampleInputValid')
            .capture('normal');
    });

    gemini.suite('input error', function(suite) {
        suite
            .setCaptureElements('#labExampleInputError')
            .capture('normal');
    });

    gemini.suite('input warning', function(suite) {
        suite
            .setCaptureElements('#labExampleInputWarning')
            .capture('normal');
    });

    gemini.suite('select error', function(suite) {
        suite
            .setCaptureElements('#labExampleSelectError')
            .capture('normal');
    });

    gemini.suite('checkbox error', function(suite) {
        suite
            .setCaptureElements('#labExampleCheckboxError')
            .capture('normal');
    });

    gemini.suite('radio error', function(suite) {
        suite
            .setCaptureElements('#labExampleRadioError')
            .capture('normal');
    });

    gemini.suite('input prefix error', function(suite) {
        suite
            .setCaptureElements('#labExampleInputPrefixError')
            .capture('normal');
    });

    gemini.suite('input postfix error', function(suite) {
        suite
            .setCaptureElements('#labExampleInputPostfixError')
            .capture('normal');
    });

    gemini.suite('input postfix button error', function(suite) {
        suite
            .setCaptureElements('#labExampleInputPostfixButtonError')
            .capture('normal');
    });
});
