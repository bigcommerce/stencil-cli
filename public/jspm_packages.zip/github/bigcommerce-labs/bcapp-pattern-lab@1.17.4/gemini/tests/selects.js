/* */ 
"format global";
var gemini = require('gemini');

gemini.suite('selects', function(suite) {
    suite.setUrl('/forms.html');

    gemini.suite('select', function(suite) {
        suite
            .setCaptureElements('#labExampleSelect .form-field')
            .capture('normal');
    });

    gemini.suite('multi select', function(suite) {
        suite
            .setCaptureElements('#labExampleMultiSelect .form-field')
            .capture('normal');
    });
});
