/* */ 
"format global";
var gemini = require('gemini'),
    viewport = require('../viewport');

gemini.suite('credit-cards', function(suite) {
    suite.setUrl('/js-components.html#/components/credit-card');

    gemini.suite('credit-card', function(suite) {
        suite
            .setCaptureElements('#labExampleCreditCard')
            .capture('normal');
    });

    gemini.suite('credit-card xsmall', function(suite) {
        suite
            .before(viewport.xsmallViewport)
            .setCaptureElements('#labExampleCreditCard')
            .capture('normal');
    });
});
