/* */ 
"format global";
var gemini = require('gemini');

gemini.suite('inputs', function(suite) {
    suite.setUrl('/forms.html');

    gemini.suite('input', function(suite) {
        suite
            .setCaptureElements('#labExampleInput')
            .capture('normal')
            .capture('focus', function(actions) {
                actions.focus('#labExampleInput .form-input');
            })
            .capture('typed', function(actions) {
                actions.sendKeys('#labExampleInput .form-input', 'Bigcommerce');
            });
    });

    gemini.suite('input prefix postfix label', function(suite) {
        suite
            .setCaptureElements('#labExampleInputPrefixPostfix')
            .capture('normal');
    });

    gemini.suite('input prefix postfix button', function(suite) {
        suite
            .setCaptureElements('#labExampleInputPrefixPostfixButton')
            .capture('normal');
    });

    gemini.suite('input prefix postfix label button', function(suite) {
        suite
            .setCaptureElements('#labExampleInputPrefixPostfixLabelButton')
            .capture('normal');
    });

    gemini.suite('input action', function(suite) {
        suite
            .setCaptureElements('#labExampleInputAction')
            .capture('normal');
    });
});
