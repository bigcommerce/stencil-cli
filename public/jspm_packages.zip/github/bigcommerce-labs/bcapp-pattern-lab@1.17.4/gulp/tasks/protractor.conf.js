/* */ 
"format global";
// An example configuration file.

exports.config = {
    // Capabilities to be passed to the webdriver instance.
    capabilities: {
        'browserName': process.env.TRAVIS ? 'phantomjs' : 'chrome'
    },
    rootElement: 'div',
    allScriptsTimeout: 20000,

    // Options to be passed to Jasmine-node.
    jasmineNodeOpts: {
        showColors: true,
        defaultTimeoutInterval: 30000
    },

    onPrepare: function() {
        require('./../../test-helpers/to-have-class');
    }
};
