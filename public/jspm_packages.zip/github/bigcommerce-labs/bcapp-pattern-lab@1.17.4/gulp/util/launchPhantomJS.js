/* */ 
"format global";
var childProcess = require('child_process'),
    http = require('http'),
    phantomjs = require('phantomjs2'),
    url = require('url'),
    config = require('./geminiConfig'),
    gridUrlPort = url.parse(config.gridUrl).port,
    maxRetries = 10,
    numRetries = 0;

function whenPhantomJSLaunched(done) {
    var retryInterval = 1000;

    function handleResponse(err, res) {
        if (numRetries >= maxRetries) {
            done(new Error('Unable to connect to PhantomJS'));

            return;
        }

        if (err || res.statusCode !== 200) {
            numRetries++;

            setTimeout(function() {
                whenPhantomJSLaunched(done);
            }, retryInterval);

            return;
        }

        done();
    }

    function handleSuccess(res) {
        handleResponse(null, res);
    }

    function handleError(err) {
        handleResponse(err);
    }

    http.get(config.gridUrl, handleSuccess)
        .on('error', handleError);
}

function launchPhantomJS(done) {
    var args,
        child;

    args = [
        '--webdriver=' + gridUrlPort
    ];

    child = childProcess.execFile(phantomjs.path, args);

    whenPhantomJSLaunched(function(err) {
        done(err, child);
    });
}

module.exports = launchPhantomJS;
