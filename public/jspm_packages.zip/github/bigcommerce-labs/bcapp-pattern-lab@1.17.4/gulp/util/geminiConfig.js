/* */ 
"format global";
var path = require('path'),
    yaml = require('yamljs'),
    cwd = process.cwd(),
    configPath = path.join(cwd, '.gemini.yml'),
    config = yaml.load(configPath);

module.exports = config;
